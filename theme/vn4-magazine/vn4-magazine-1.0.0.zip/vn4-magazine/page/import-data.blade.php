<?php

use_module('read_html');
/*
$dataCategory = [
	'https://www.latimes.com/world-nation',
	'https://www.latimes.com/food',
	'https://www.latimes.com/science',
	'https://www.latimes.com/business'=>[
		'https://www.latimes.com/business/technology',
		'https://www.latimes.com/business/real-estate',
		'https://www.latimes.com/business/autos',
	],
	'https://www.latimes.com/travel',
	'https://www.latimes.com/entertainment-arts'=>[
		'https://www.latimes.com/entertainment-arts/movies',
		'https://www.latimes.com/entertainment-arts/tv',
		'https://www.latimes.com/entertainment-arts/music',
		'https://www.latimes.com/entertainment-arts/business',
		'https://www.latimes.com/entertainment-arts/books',
		'https://www.latimes.com/entertainment-arts/awards',
	],
	'https://www.latimes.com/california',
	'https://www.latimes.com/sports'=>[
		'https://www.latimes.com/sports/lakers',
		'https://www.latimes.com/sports/dodgers',
		'https://www.latimes.com/sports/clippers',
		'https://www.latimes.com/sports/rams',
		'https://www.latimes.com/sports/usc',
		'https://www.latimes.com/sports/ucla',
		'https://www.latimes.com/sports/angels',
		'https://www.latimes.com/sports/chargers',
		'https://www.latimes.com/sports/highschool',
		'https://www.latimes.com/sports/hockey',
		'https://www.latimes.com/sports/soccer',
	],
	'https://www.latimes.com/politics',
	'https://www.latimes.com/environment',
];

function load_news_of_category($category, $link_category){

	$content = file_get_contents($link_category);
	$html = str_get_html($content);

	$taga = $html->find('a');
	$tagaNews = [];

	foreach ($taga as $key => $value) {
		if( $value->href !== $link_category && strpos($value->href, $link_category) !== false && !isset($tagaNews[$value->href]) && strpos($value->href, '/story/') !== false ){
			$tagaNews[$value->href] = 1;
		}
	}
	$i = 2;

	$link_next_page = substr( $html->find('.ListI-nextPage .Link',0)->href, 0, -1);

	while ( count($tagaNews) < 100 && $i < 15 ) {

		
		$link_content = $link_category.$link_next_page.$i;

		$content = file_get_contents($link_content);
		$html = str_get_html($content);

		$taga = $html->find('a');

		foreach ($taga as $key => $value) {
			if( $value->href !== $link_category && strpos($value->href, $link_category) !== false && !isset($tagaNews[$value->href]) && strpos($value->href, '/story/') !== false ){
				$tagaNews[$value->href] = 1;
			}
		}


		$i++;

	}

	file_put_contents('categories/'.$category->id.'.json', json_encode($tagaNews));


}

foreach ($dataCategory as $key => $value) {

	if( is_string($value) ){
		$content = file_get_contents($value);
	}else{
		$content = file_get_contents($key);
	}


	$html = str_get_html($content);

	$title_category = html_entity_decode($html->find('meta[property="og:title"]',0)->content);

	if( !($category = DB::table('news_category')->where('title', $title_category )->first()) ){

		$category = Vn4Model::createPost('news_category',[
			'title'=>$title_category, 
			'slug'=>registerSlug($title_category, 'news_category'),
			'description'=> html_entity_decode($html->find('meta[property="og:description"]',0)->content??''),
			'language'=>'en',
		]);

	}

	if( is_array($value) ){

		foreach ($value as $key2 => $value2) {
			
			$content2 = file_get_contents($value2);

			$html2 = str_get_html($content2);

			$title_category2 = html_entity_decode($html2->find('meta[property="og:title"]',0)->content);

			if( !($category2 = DB::table('news_category')->where('title', $title_category2 )->first()) ){

				$category2 = Vn4Model::createPost('news_category',[
					'title'=>$title_category2, 
					'slug'=>registerSlug($title_category2, 'news_category'),
					'description'=> html_entity_decode($html2->find('meta[property="og:description"]',0)->content??''),
					'parent'=>$category->id,
					'language'=>'en',
				]);
			}

			load_news_of_category($category2, $value2);

		}

	}else{
		load_news_of_category($category, $value);
	}

	

	// $taga = $html->find('a');
	// $tagaNews = [];

	// foreach ($taga as $key2 => $value2) {
	// 	if( $value2->href !== $value && strpos($value2->href, $value) !== false && !isset($tagaNews[$value2->href]) ){
	// 		$tagaNews[$value2->href] = $value2;
	// 	}
	// }
	// dd($tagaNews);

}

dd(1);

*/


$category = get_posts('news_category',100);

foreach ($category as $c) {

	if( file_exists('categories/'.$c->id.'.json') ){

		$link = json_decode(file_get_contents('categories/'.$c->id.'.json'),true);

		$link = array_keys($link);

		$count = count($link) - 1;

		$posts = [];

		for ($i= $count ; $i >= 0 ; $i--) { 

			try {
				
				$l = $link[$i];

				$content = file_get_contents_curl($l);
				$html = str_get_html($content);


				$post['title'] = html_entity_decode(trim($html->find('.ArticlePage-headline',0)->plaintext));
				$post['slug'] = registerSlug($post['title'], 'news_post');

				if( DB::table('news_post')->where('slug', $post['slug'] )->first() ){
					continue;
				}

				$post['description'] = $html->find('meta[property="og:description"]',0)->content;

				$content = $html->find('.RichTextArticleBody-body',0);

				foreach ($content->children as $k => $v) {
					if( $v->tag === 'div' ){
						unset($content->children[$k]);
					}


				}
				$post['content'] = $content->innertext;

				if( $img = $html->find('.ArticlePage-lead img',0) ){
					$img = $img->src;
				}else{
					$img = $html->find('meta[property="og:image:url"]',0)->content;
				}

				$post['image'] = '{"link":"'.$img.'","type_link":"external"}';
				$post['category'] = $c->id;
				$post['language'] = 'en';


				$tags = [];

				$tagsHtml = $html->find('.ArticlePage-tags a');

				foreach ($tagsHtml as $t) {

					if( !($tag = DB::table('news_tag')->where('title', trim($t->plaintext))->first()) ){
						$tag = Vn4Model::createPost('news_tag',[
							'title'=>trim($t->plaintext), 
							'slug'=>registerSlug(trim($t->plaintext), 'news_tag'),
							'language'=>'en',
						]);
					}

					$tags[] = $tag;
				}


				$post['tag'] = json_encode($tags);

				Vn4Model::createPost('news_post',$post);

			} catch (Exception $e) {

			}


		}


	}
}


dd(1);



$page = request()->get('trang');

$dataCategory = [
	'https://vnexpress.net/thoi-su-p',
	'https://vnexpress.net/the-gioi-p',
	'https://vnexpress.net/kinh-doanh/p',
	'https://vnexpress.net/giai-tri/p',
	'https://vnexpress.net/the-thao/p',
	'https://vnexpress.net/phap-luat-p',
	'https://vnexpress.net/giao-duc-p',
	'https://vnexpress.net/suc-khoe/p',
	'https://vnexpress.net/doi-song/p',
	'https://vnexpress.net/du-lich/p',
	'https://vnexpress.net/khoa-hoc-p',
	'https://vnexpress.net/so-hoa/p',
	'https://vnexpress.net/oto-xe-may-p',
	'https://vnexpress.net/y-kien-p',
	'https://vnexpress.net/tam-su-p',
	'https://vnexpress.net/cuoi-p',
];



function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

foreach ($dataCategory as $category) {
	
	$content = file_get_contents_curl($category.$page);

	use_module('read_html');

	$html = str_get_html($content);


	$title_category = $html->find('meta[property="og:title"]',0)->content;
	dd($title_category);

	if( !($category = DB::table('news_category')->where('title', $html->find('.breadcrumb a',0)->plaintext)->first()) ){


		$category = Vn4Model::createPost('news_category',[
			'title'=>$html->find('.breadcrumb a',0)->plaintext, 
			'slug'=>registerSlug($html->find('.breadcrumb a',0)->plaintext, 'news_category'),
			'description'=>$html->find('meta[name="keywords"]',0)->content,
			'color'=>get_string_between($content,'#sub_menu{background:',';width:1000px;margin:0 auto'),
			'language'=>'vi',
		]);
	}


	$articles = $html->find('article');

	$data = [];

	foreach ($articles as $article) {

		try {
			$taga = $article->find('a',0);

			$href = $taga->href;

			$content = file_get_contents_curl($href);

			$html = str_get_html($content);

			if( !DB::table('news_post')->where('title', trim($html->find('.title_news_detail',0)->plaintext))->first() ){



				if( !$html->find('.sidebar_1') ) continue;

				$tagsVnExpress = $html->find('.block_tag h3 a');

				$tags = [];

				foreach ($tagsVnExpress as $t) {

					if( !($tag = DB::table('news_tag')->where('title', trim($t->plaintext))->first()) ){
						$tag = Vn4Model::createPost('news_tag',[
							'title'=>trim($t->plaintext), 
							'slug'=>registerSlug(trim($t->plaintext), 'news_tag'),
							'language'=>'vi',
						]);
					}

					$tags[] = $tag;
				}


				$post = [];

				$post['title'] = $html->find('.title_news_detail',0)->plaintext;
				$post['slug'] = registerSlug(trim($html->find('.title_news_detail',0)->plaintext), 'news_post');
				$post['description'] = $html->find('.description',0)->plaintext;
				$post['content'] = $html->find('.content_detail',0)->innertext;
				$post['image'] = '{"link":"'.$html->find('meta[property="og:image"]',0)->content.'","type_link":"external"}';
				$post['category'] = $category->id;
				$post['language'] = 'vi';
				$post['tag'] = json_encode($tags);

				$post = Vn4Model::createPost('news_post',$post);

				DB::table('vn4_news_post_news_category')->insert([
					['post_id'=>$post->id, 'tag_id'=>$category->id,'field'=>'category','type'=>'news_category']
				]);

				$tagConnect = [];
				foreach ($tags as $tag) {
					$tagConnect[] = ['post_id'=>$post->id, 'tag_id'=>$tag->id,'field'=>'tag','type'=>'news_tag'];
				}

				DB::table('vn4_news_post_news_tag')->insert($tagConnect);
				// dd(1);
			}else{

				// die( route('page',['page'=>'import-data','trang'=>($page + 1)]) );
				// return vn4_redirect(route('page',['page'=>'import-data','trang'=>($page + 1)]));
			}
		} catch (Exception $e) {
			
		}

	}
}

echo 'done';


die( route('page',['page'=>'import-data','trang'=>($page + 1)]) );
// vn4_redirect(route('page',['page'=>'import-data','trang'=>($page + 1)]));
// return redirect()->route('page',['import-data','page'=>($page + 1)]);
