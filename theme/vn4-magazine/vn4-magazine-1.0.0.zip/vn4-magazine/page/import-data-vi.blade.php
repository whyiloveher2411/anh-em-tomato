<?php

// $category = get_posts('news_category',2000);

// $categoryArray = [];


// $tagsArray = [];

// foreach ($category as $c) {
// 	$posts = $c->related('news_post','category',['count'=>150]);

// 	$postArray = [];

// 	foreach ($posts as $p) {
		
// 		$tags = json_decode($p->tags);

// 		$tag = [];

// 		if( is_array($tags) ){
// 			foreach ($tags as $t) {
// 				$tagsArray[$t->title] = 1;
// 				$tag[] = $t->title;
// 			}
// 		}

// 		$p = $p->toArray();
// 		$p['tag'] = json_encode($tag);
// 		unset($p['id']);

// 		$postArray[] = $p;


// 	}

// 	$categoryArray[] = [
// 		'detail'=>$c->toArray(),
// 		'posts'=>$postArray
// 	];


// }

// file_put_contents('data-vi.json', json_encode($categoryArray));

// dd(1);



$categorys = json_decode(file_get_contents('data-vi.json'),true);


foreach ($categorys as $key => $c) {
	

	if( !($category = DB::table('news_category')->where('title', $c['detail']['title'])->first()) ){


		$category = Vn4Model::createPost('news_category',[
			'title'=>$c['detail']['title'], 
			'slug'=>registerSlug($c['detail']['title'], 'news_category'),
			'description'=>$c['detail']['description'],
			'language'=>'vi',
		]);

	}


	foreach ($c['posts'] as $p) {
		
		try {
		
			if( !DB::table('news_post')->where('title',$p['title'])->count() ){
			
				$tags = json_decode($p['tag'],true);

				$tag = [];

				if( is_array($tags) ){
					

					foreach ($tags as $t) {
						
						if( !($ta = DB::table('news_tag')->where('title', $t)->first()) ){


							$ta = Vn4Model::createPost('news_tag',[
								'title'=>$t, 
								'slug'=>registerSlug($t, 'news_tag'),
								'language'=>'vi',
							]);

						}

						$tag[] = $ta;

					}
				}


				$post = [];

				$post['title'] = $p['title'];
				$post['slug'] = registerSlug(trim($p['title']), 'news_post');
				$post['description'] = $p['description'];
				$post['content'] = $p['content'];
				$post['image'] = $p['image'];
				$post['category'] = $category->id;
				$post['category_detail'] = json_encode(['id'=>$category->id,'title'=>$category->title,'type'=>'news_category','slug'=>$category->slug]);
				$post['language'] = 'vi';
				$post['tag'] = json_encode($tag);

				$post = Vn4Model::createPost('news_post',$post);

				$tagConnect = [];
				foreach ($tag as $t) {
					$tagConnect[] = ['post_id'=>$post->id, 'tag_id'=>$tag->id,'field'=>'tag','type'=>'news_tag'];
				}

				DB::table('vn4_news_post_news_tag')->insert($tagConnect);
			}
		} catch (Exception $e) {
			
		}

	}

}
dd($content);
