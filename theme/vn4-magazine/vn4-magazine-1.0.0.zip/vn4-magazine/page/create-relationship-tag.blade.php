<?php

// $posts = get_posts('news_post',['count'=>10000]);

// $tags = [];


// foreach ($posts as $key => $value) {
	
// 	$tagsTemp = json_decode($value->tag);

// 	foreach ($tagsTemp as $key2 => $value2) {
// 		$tags[] = [
// 			'post_id'=>$value->id,
// 			'tag_id'=>$value2->id,
// 			'field'=>'tag',
// 			'type'=>'news_tag',
// 		];
// 	}

// }

// DB::table('vn4_news_post_news_tag')->insert($tags);

// dd(1);