@extends(theme_extends())

@section('content')
	
	<h1>404 Not Found</h1>
	
@stop