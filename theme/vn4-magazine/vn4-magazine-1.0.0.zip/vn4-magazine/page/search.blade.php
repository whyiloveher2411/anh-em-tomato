@extends(theme_extends())

<?php 
  title_head('Home');
  add_filter('body_class',function($filter){
    unset($filter[array_search('post-detail', $filter)]);
    return $filter;
  });

  $search = e(Request::get('q'));

 ?>

@section('content')
<div class="section">
        <div class="container">
            <h1 class="title">{!!$search!!}</h1>
            <ul class="breadcrumb">
                <li><a href="{!!route('index')!!}">Trang chủ</a></li>
                <li><a href="javascript:void(0)">{!!$search!!}</a></li>
            </ul>
        </div>
    </div>

<div class="section template-list-post-with--category">
    <!-- CONTAINER -->
    <div class="container">
        <!-- ROW -->
        <div class="row">
            <!-- Main Column -->
            <div class="col-md-8">


                 <?php 
                    $posts = get_posts('news_post',['count'=>10,'paginate'=>'page','callback'=>function($q) use ($search) {
                        return $q->where('title','LIKE','%'.$search.'%');
                    }]);
                 ?>

               @foreach($posts as $p)
                <article class="article row-article">
                    <div class="article-img">
                        <a href="{!!$link = get_permalinks($p)!!}">
                            <img data-src="{!!get_media($p->image)!!}" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                        </ul>
                        <p>{!!$p->description!!}</p>
                    </div>
                </article>
               @endforeach

                {!!get_paginate($posts,'posts')!!}
            </div>
            <!-- /Main Column -->
            <!-- Aside Column -->
            <div class="col-md-4">
                {!!get_sidebar('sidebar-primary-1','sidebar-primary')!!}
                {!!get_sidebar('sidebar-primary-2','sidebar-primary')!!}
            </div>
            <!-- /Aside Column -->
        </div>
        <!-- /ROW -->
    </div>
    <!-- /CONTAINER -->
</div>

@stop