 <header id="header">
    <!-- Top Header -->
    <div id="top-header">
        <div class="container">
            <div class="header-links">
               {!!vn4_nav_menu_db(theme_options('header','menu-top'))!!}
            </div>
            <div class="header-social">



                <ul>

                     <?php 
                        if( is_callable('the_languages') ){
                            $languages = the_languages();
                            $language_default = language_default();
                            $language_current = $languages[App::getLocale()]??$language_default;
                            ?>
                             <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="{!!$language_current['flag_image']!!}"> {!!$language_current['lang_name']!!} <span class="caret"></span></a>
                                  <ul class="dropdown-menu dropdown-menu-left" role="menu">
                                    <?php
                                    foreach ($languages as $k => $v) {

                                        if( !$v['active'] ){
                                        ?>
                                        <li style="display: block;">
                                            <a href="{!!$v['url']!!}" title="languages {!!$v['country_name']!!}" style="text-align: left;">
                                                <img src="{!!$v['flag_image']!!}"> {!!$v['lang_name']!!}
                                            </a>
                                        </li>
                                        <?php
                                        }
                                    }
                                    ?>
                                  </ul>
                             </li>
                            <?php
                        }
                     ?>

                    <?php 
                        $social_network = theme_options('contact','list-social');
                     ?>
                    @forif($social_network as $s) 
                    <li>
                        <a href="{!!$s['link']!!}" title="{!!$s['title']!!}" target="_blank" rel="nofollow" >
                            <i class="fa  {!!$s['icon']!!}"></i>
                        </a>
                    </li>
                    @endforif
                </ul>
            </div>
        </div>
    </div>
    <!-- /Top Header -->
    <!-- Center Header -->
    <div id="center-header">
        <div class="container">
            <div class="header-logo">
                <a href="{!!route('index')!!}" class="logo"><img src="@theme_asset()img/logo.png" alt=""></a>
            </div>
            <div class="pull-right">
                {!!theme_options('header','banner-ads')!!}
            </div>
        </div>
    </div>
    <!-- /Center Header -->
    <!-- Nav Header -->
    <div id="nav-header">
        <div class="container">
        	<div class="header-logo">
                <a href="{!!route('index')!!}" class="logo"><img src="{!!get_media(theme_options('general','logo-black'))!!}" alt=""></a>
            </div>
            <nav id="main-nav">
                <div class="nav-logo">
                    <a href="{!!route('index')!!}" style="height: auto;padding: 0 30px;" class="logo"><img style="height: auto;" src="{!!get_media(theme_options('general','logo-white'))!!}" alt=""></a>
                </div>
                 {!!vn4_nav_menu('header','nav-header-pc')!!}
                <div class="close">
                    <span></span>
                    <span></span>
                </div>
            </nav>
            <div class="button-nav">
                <div class="search-form">
                    <form action="{!!route('page','search')!!}">
                        <input class="search-input" type="text" name="q" placeholder="@__t('Search')">
                    </form>
                </div>
                <button class="search-collapse-btn"><i class="fa fa-search"></i></button>
                <button class="nav-collapse-btn"><i class="fa fa-bars"></i></button>
            </div>
        </div>
    </div>
    <!-- /Nav Header -->
</header>