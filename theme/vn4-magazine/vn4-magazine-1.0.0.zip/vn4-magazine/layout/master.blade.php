@html

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />


    @head

  	<link type="text/css" rel="stylesheet" href="@theme_asset()css/bootstrap.min.css" />
    <!-- Owl Carousel -->
    <link type="text/css" rel="stylesheet" href="@theme_asset()css/owl.carousel.css" />
    <link type="text/css" rel="stylesheet" href="@theme_asset()css/owl.theme.default.css" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="@theme_asset()css/font-awesome.min.css">
    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="@theme_asset()css/style.css" />

	@yield('css')

    <style type="text/css">
        @media only screen and (max-width: 500px){
            .article.row-article .article-img {
                width: 100%;
            }
        }
    </style>
</head>

@body

	@header

	@yield('content')

	@footer

	<div id="back-to-top"></div>
	
	<script src="@theme_asset()js/jquery.min.js"></script>
	<script src="@theme_asset()js/bootstrap.min.js"></script>
	<script src="@theme_asset()js/owl.carousel.min.js"></script>
	<script src="@theme_asset()js/main.js"></script>


    @yield('js')

	  <script type="text/javascript">
	 	$(window).load(function(){
	 		$('img[data-src]').each(function(index, el){
	 			$(el).attr('src',$(el).data('src'));
	 		});
	 	});

	 	 $('.form-subscribe').submit(function(){
            event.preventDefault();
            var isValidate = true;
            $(this).find('.input_field').each(function(index,el){
                $(el).closest('.input').find('.error_message').remove();
                if( !$(el).val() ){
                    isValidate = false;
                    $(el).closest('.input').append('<p class="error_message">Thông tin này là bắt buộc.</p>');
                }
            });

            if( isValidate ){
                var $this = $(this);
                var data = $this.serializeArray();
                data.push({name:'_token',value:'{!!csrf_token()!!}'});
                data.push({name:'language',value:'{!!App::getLocale()!!}'});

                $.ajax({
                    url: $this.attr('action'),
                    type:'POST',
                    dataType:'Json',
                    data:data,
                    success:function(data){
                        if(data.message){
                            alert(data.message);
                        }

                        if( data.reset ){
                            $this[0].reset();
                        }
                    }
                });
            }

            

        });

         if( $('#widget-corona') ){
             setTimeout(function() {

                $.ajax({
                    url: '{!!route('post',['corona','get','url'=>'cms.vn4cms.com'])!!}',
                    dataType:'html',
                    data:{
                        _token: '{!!csrf_token()!!}',
                        language: '{!!App::getLocale()!!}',
                    },
                    type:'POST',
                    success:function(html){
                       $('#widget-corona').html(html); 
                    }
                });

             }, 10);
         }
         $(document).on('click','.main-nav>.dropdown>a',function(event){
            event.preventDefault();
            event.stopPropagation();
            return false;
         });
	 </script>
	 
@endbody


@endhtml