 <ul class="footer-links">
 	@foreach($menu as $m)
 		<li><a {!!$m['attrtitle']!!} >{!!$m['label']!!}</a></li>
    @endforeach
</ul>
