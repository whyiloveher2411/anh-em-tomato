 <ul class="main-nav nav navbar-nav">
 	@foreach($menu as $m)
 	@if( isset($m['children']))
	 	<li class="dropdown">
 		 	<a {!!$m['attrtitle']!!}>{!!$m['label']!!} <i class="fa fa-chevron-down" aria-hidden="true"></i></a>
 		 	 <ul class="sub">
	 		 	@foreach($m['children'] as $m2)
 		 	 	<li><a {!!$m2['attrtitle']!!}>{!!$m2['label']!!}</a></li>
 		 	 	@endforeach
 		 	 </ul>
	    </li>
 	@else
 		<li><a {!!$m['attrtitle']!!} >{!!$m['label']!!}</a></li>
 	@endif
    @endforeach
</ul>