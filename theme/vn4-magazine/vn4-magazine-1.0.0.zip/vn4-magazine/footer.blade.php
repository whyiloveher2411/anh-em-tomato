 <?php 
  $theme_options_footer = theme_options('Footer');
 ?>

 <footer id="footer">
    <!-- Top Footer -->
    <div id="top-footer" class="section">
        <!-- CONTAINER -->
        <div class="container">
            <!-- ROW -->
            <div class="row">
                <div class="col-md-4">
                    {!!get_sidebar('sidebar-footer-1','sidebar-footer')!!}
                </div>
                <div class="col-md-4">
                    {!!get_sidebar('sidebar-footer-2','sidebar-footer')!!}
                </div>
                <div class="col-md-4">
                    {!!get_sidebar('sidebar-footer-3','sidebar-footer')!!}
                </div>
            </div>
            <!-- /ROW -->
        </div>
        <!-- /CONTAINER -->
    </div>
    <!-- /Top Footer -->
    <!-- Bottom Footer -->
    <div id="bottom-footer" class="section">
        <!-- CONTAINER -->
        <div class="container">
            <!-- ROW -->
            <div class="row">
                <!-- footer links -->
                <div class="col-md-6 col-md-push-6">

               {!!vn4_nav_menu_db(theme_options('Footer','menu-footer-bottom'),'menu-footer-bottom',[],App::getLocale().'menu-footer-bottom')!!}

                </div>
                <!-- /footer links -->
                <!-- footer copyright -->
                <div class="col-md-6 col-md-pull-6">
                    <div class="footer-copyright">
                        <span>{!!theme_options('Footer','rights')!!}</span>
                    </div>
                </div>
                <!-- /footer copyright -->
            </div>
            <!-- /ROW -->
        </div>
        <!-- /CONTAINER -->
    </div>
    <!-- /Bottom Footer -->
</footer>