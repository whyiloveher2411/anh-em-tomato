@extends(theme_extends())

<?php 
    // Home
	title_head('Home');


    $section = cache_tag('home-page',App::getlocale().'.section-home-page', function() use ($post) {

        $section = $post->section;

        $listIDPost = [];

        foreach ($section as $key => $s) {

            if( !$s['delete'] ){

                switch ($s['type']) {
                    case 'slider-4-post-on-screen':
                        $data = get_posts('news_post',['callback'=>function($q) use ($s) { $q->whereIn(Vn4Model::$id, $s['list-post']); }] );

                        foreach ($data as $k => $v) {
                            $data[$k]->category = $v->relationship('category');
                        }

                        break;

                    case 'template-multi-category':

                        $categories =get_posts('news_category',['callback'=>function($q) use ($s) { $q->whereIn(Vn4Model::$id, $s['category'])->orderByRaw('FIELD('.Vn4Model::$id.', '.implode(',',$s['category']).')'); }]);

                        $data = [];

                        foreach ($categories as $k => $v) {

                            $data[] = [
                                'category'=>$v,
                                'posts'=>$v->related('news_post','category',['count'=>12])
                            ];
                        }
                        break;
                    case 'template-3-category':
                        
                        $data = [
                            'category-1'=>[
                                'category'=>$cat = get_post('news_category',$s['category-1']),
                                'posts'=>$cat->related('news_post','category',['count'=>3]),
                            ],
                            'category-2'=>[
                                'category'=>$cat = get_post('news_category',$s['category-2']),
                                'posts'=>$cat->related('news_post','category',['count'=>3]),
                            ],
                            'category-3'=>[
                                'category'=>$cat = get_post('news_category',$s['category-3']),
                                'posts'=>$cat->related('news_post','category',['count'=>8]),
                            ],
                        ];
                        break;
                    case 'ads':


                        $data = $s['html'];

                        break;
                    case 'slider-3-post-on-screen':
                        $data = get_posts('news_post',['callback'=>function($q) use ($s) { $q->whereIn(Vn4Model::$id, $s['list-post']); }] );

                        foreach ($data as $k => $v) {
                            $data[$k]->category = $v->relationship('category');
                        }

                        break;
                     case 'template-list-post-with--category':
                        $data = get_posts('news_post',['callback'=>function($q) use ($s) { $q->whereIn(Vn4Model::$id, $s['list-post']); }] );

                        foreach ($data as $k => $v) {
                            $data[$k]->category = $v->relationship('category');
                        }

                        break;
                }

                $section[$key]['data'] = $data;
            }

        }

        return $section;
    });

    // dd(Cache::store('theme-options')->get('demo'));
    // Cache::store('theme-options')->put('demo', ['sdfsdf'=>'sdfdsf','sdfsdf1'=>'sdfdsf'], 15);

    // dd($section);
 ?>

@section('content')
<style type="text/css">
    .rn_block{
        display: flex;
        flex-wrap: wrap;
    }

    @media (min-width: 768px){
        .article-img-temp1{
            height: 200px;
            position: relative;
            overflow: hidden;
        }
        .template-3-category .article-top .article-img, .template-3-category .article-top-2 .article-img{
            height: 300px;
            overflow: hidden;
        }
        .owl-item .article.thumb-article .article-img{
            height: 300px;
        }
    }
    
    .article-img-temp2 .article-img{
        position: relative;
        height: 190px;
        overflow: hidden;
    }

    .article-img-temp2 .article-img img{
        position: absolute;
        min-height: 100%;
        min-width: 100%;
    }
    .article .article-img{
        overflow: hidden;
    }
    .article .article-img > a{
        box-shadow: none;
        display: initial;
    }
    .article .article-img img{
        object-fit: cover;
        width: 100%;
        height: 100%;
        box-shadow: 0 0 5px #8a8a8a;

    }
    .article.row-article .article-img{
        overflow: hidden;
    }
  
    #owl-carousel-2 .owl-stage-outer .article.thumb-article .article-img{
        height: 300px;
    }
    .article.widget-article .article-img{
        width: 120px;
        height: 90px;
        margin-bottom: 20px;
        overflow: hidden;
    }
    @media (max-width: 768px){
        .article-img-temp2 .article-img{
            height: auto;
        }

        .article-img-temp2 .article-img img{
            position: initial;
            width: 100%;
            height: auto;
        }
       
        .article .article-img img{
            width: 100%;
            height: auto;
        }
    }
</style>
@forswitch($section as $s)
    @is('slider-4-post-on-screen')
    <div id="owl-carousel-1" class="owl-carousel owl-theme center-owl-nav">

        @foreach($s['data'] as $p)
        <article class="article thumb-article" style="height: 356px;">
            <div class="article-img" style="height: 100%;">
                <img data-src="{!!get_media($p->image)!!}" alt="" style="left: -9999px;right: -9999px;margin: 0 auto;width:100%;position: absolute;height: 100%;">
            </div>
            <div class="article-body">
                <ul class="article-info">
                    <li class="article-category"><a href="{!!get_permalinks($p->category)!!}">{!!$p->category->title!!}</a></li>
                </ul>
                <h2 class="article-title"><a href="{!!get_permalinks($p)!!}">{!!$p->title!!}</a></h2>
                <ul class="article-meta">
                    <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                </ul>
            </div>
        </article>
        @endforeach
       
    </div>
    @endis
    @is('template-multi-category')
    <div class="section template-multi-category">
        <!-- CONTAINER -->
        <div class="container">
            <!-- ROW -->
            <div class="row">
                <!-- Main Column -->
                <div class="col-md-12">
                    <!-- section title -->
                    <div class="section-title">
                        <h2 class="title">{!!$s['title']!!}</h2>
                        <!-- tab nav -->
                        <ul class="tab-nav pull-right">
                            @foreach($s['data'] as $k => $c)
                            <li @if( $k === 0) class="active" @endif ><a data-toggle="tab" href="#tab{!!$k!!}">{!!$c['category']->title!!}</a></li>
                            @endforeach
                        </ul>
                        <!-- /tab nav -->
                    </div>
                    <!-- /section title -->
                    <!-- Tab content -->
                    <div class="tab-content">
                        
                         @foreach($s['data'] as $k => $c)
                        <div id="tab{!!$k!!}" class="tab-pane fade in @if( $k === 0) active @endif">
                            <!-- row -->
                            <div class="row">
                                
                                @for( $i = 0 ; $i < 4 ; $i ++)
                                @if( isset($c['posts'][$i]) )
                                <?php 
                                    $p = $c['posts'][$i];
                                 ?>
                                <div class="col-md-3 col-sm-6">
                                    <article class="article">
                                        <div class="article-img article-img-temp1">
                                            <a href="{!!$link = get_permalinks($p)!!}">
                                                <img data-src="{!!get_media($p->image)!!}" alt="">
                                            </a>
                                           
                                        </div>
                                        <div class="article-body">
                                            <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                            <ul class="article-meta">
                                                <li><i class="fa fa-clock-o"></i>  {!!get_date($p->created_at)!!}</li>
                                            </ul>
                                        </div>
                                    </article>
                                </div>
                                @endif
                                @endfor

                            </div>
                            <!-- /row -->
                            <!-- row -->
                            <div class="row" style="display: flex;flex-wrap: wrap;">
                                <!-- Column 1 -->
                                <?php 
                                    $j = 0;
                                 ?>
                                @for($i = 4; $i < 12; $i ++)
                                 @if( isset($c['posts'][$i]) )

                                <?php 
                                    $p = $c['posts'][$i];
                                 ?>

                                <div class="col-md-3 col-sm-6">
                                    <article class="article widget-article">
                                        <div class="article-img">
                                            <a href="{!!$link = get_permalinks($p)!!}">
                                                <img data-src="{!!get_media($p->image)!!}" alt="">
                                            </a>
                                        </div>
                                        <div class="article-body">
                                            <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                            <ul class="article-meta">
                                                <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                            </ul>
                                        </div>
                                    </article>
                                  

                                </div>

                                @endif
                                @endfor
                            </div>
                        </div>
                        @endforeach
                        <!-- /tab1 -->
                    </div>
                    <!-- /tab content -->
                </div>
                <!-- /Main Column -->
            </div>
            <!-- /ROW -->
        </div>
        <!-- /CONTAINER -->
    </div>
    @endis
    @is('template-3-category')
    <div class="section template-3-category">
        <!-- CONTAINER -->
        <div class="container">
            <!-- ROW -->
            <div class="row">
                <!-- Main Column -->
                <div class="col-md-8">
                    <!-- row -->
                    <div class="row">

                        <div class="col-md-6 col-sm-6">
                            <!-- section title -->
                            <div class="section-title ">
                                <h2 class="title">{!!$s['data']['category-1']['category']->title!!}</h2>
                            </div>
                            <!-- /section title -->
                            <!-- ARTICLE -->

                            @foreach( $s['data']['category-1']['posts'] as $k => $p)
                            @if( $k === 0)
                            <article class="article article-top">
                                <div class="article-img ">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                   
                                </div>
                                <div class="article-body">
                                    <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                    <p>{!!$p->description!!}</p>
                                </div>
                            </article>
                            @else
                            <article class="article widget-article">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                </div>
                                <div class="article-body">
                                    <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                </div>
                            </article>
                            @endif
                            @endforeach
                        </div>


                        <div class="col-md-6 col-sm-6">
                            <!-- section title -->
                            <div class="section-title">
                                <h2 class="title">{!!$s['data']['category-2']['category']->title!!}</h2>
                            </div>
                            <!-- /section title -->
                            <!-- ARTICLE -->

                            @foreach( $s['data']['category-2']['posts'] as $k => $p)
                            @if( $k === 0)
                            <article class="article article-top">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                   
                                </div>
                                <div class="article-body">
                                    <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                    <p>{!!$p->description!!}</p>
                                </div>
                            </article>
                            @else
                            <article class="article widget-article">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                </div>
                                <div class="article-body">
                                    <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                </div>
                            </article>
                            @endif
                            @endforeach
                        </div>
                        
                    </div>
                    <!-- /row -->
                    <!-- row -->
                    <div class="row">
                        <!-- section title -->
                        <div class="col-md-12">
                            <div class="section-title">
                                <h2 class="title">{!!$s['data']['category-3']['category']->title!!}</h2>
                            </div>
                        </div>
                        <!-- /section title -->
                        @for($i = 0 ; $i < 2; $i ++)
                        @if( isset($s['data']['category-3']['posts'][$i]) )
                        <?php 
                            $p = $s['data']['category-3']['posts'][$i];
                         ?>
                        <div class="col-md-6 col-sm-6">
                            <!-- ARTICLE -->
                            <article class="article article-top-2">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                    
                                </div>
                                <div class="article-body">
                                    <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                    <p>{!!$p->description!!}</p>
                                </div>
                            </article>
                            <!-- /ARTICLE -->
                        </div>
                        @endif
                        @endfor
                       
                    </div>
                    <!-- /row -->
                    <!-- row -->
                    <div class="row">
                        <!-- Column 1 -->

                        @for($i = 2 ; $i < 5; $i ++)
                        @if( isset($s['data']['category-3']['posts'][$i]) )
                        <?php 
                            $p = $s['data']['category-3']['posts'][$i];
                         ?>
                        <div class="col-md-4 col-sm-4">
                            <article class="article article-img-temp2">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                </div>
                                <div class="article-body">
                                    <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                </div>
                            </article>
                        </div>
                        @endif
                        @endfor

                    </div>
                    <div class="row">
                        @for($i = 5 ; $i < 8; $i ++)
                        @if( isset($s['data']['category-3']['posts'][$i]) )
                        <?php 
                            $p = $s['data']['category-3']['posts'][$i];
                         ?>
                        <div class="col-md-4 col-sm-4">
                            <article class="article article-img-temp2">
                                <div class="article-img">
                                    <a href="{!!$link = get_permalinks($p)!!}">
                                        <img data-src="{!!get_media($p->image)!!}" alt="">
                                    </a>
                                </div>
                                <div class="article-body">
                                    <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                </div>
                            </article>
                        </div>
                        @endif
                        @endfor

                    </div>
                    <!-- /row -->
                </div>
                <!-- /Main Column -->
                <!-- Aside Column -->
                <div class="col-md-4">
                    <!-- Ad widget -->
                    {!!get_sidebar('sidebar-primary-1','sidebar-primary')!!}
                    <!-- /article widget -->
                </div>
                <!-- /Aside Column -->
            </div>
            <!-- /ROW -->
        </div>
        <!-- /CONTAINER -->
    </div>
    @endis
    @is('slider-3-post-on-screen')
        <div class="section slider-3-post-on-screen">
            <!-- CONTAINER -->
            <div class="container">
                <!-- ROW -->
                <div class="row">
                    <!-- Main Column -->
                    <div class="col-md-12">
                        <!-- section title -->
                        <div class="section-title">
                            <h2 class="title">{!!$s['title']!!}</h2>
                            <div id="nav-carousel-2" class="custom-owl-nav pull-right"></div>
                        </div>
                        <!-- /section title -->
                        <!-- owl carousel 2 -->
                        <div id="owl-carousel-2" class="owl-carousel owl-theme">
                            
                            @foreach( $s['data'] as $p)
                            <article class="article thumb-article">
                                <div class="article-img">
                                    <img data-src="{!!get_media($p->image)!!}" alt="">
                                </div>
                                <div class="article-body">
                                    <ul class="article-info">
                                        <li class="article-category"><a href="{!!get_permalinks($p->category)!!}">{!!$p->category->title!!}</a></li>
                                    </ul>
                                    <h3 class="article-title"><a href="{!!get_permalinks($p)!!}">{!!$p->title!!}</a></h3>
                                    <ul class="article-meta">
                                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                    </ul>
                                </div>
                            </article>
                            @endforeach

                            <!-- /ARTICLE -->
                        </div>
                        <!-- /owl carousel 2 -->
                    </div>
                    <!-- /Main Column -->
                </div>
                <!-- /ROW -->
            </div>
            <!-- /CONTAINER -->
        </div>
    @endis
    @is('ads')
    <div class="visible-lg visible-md">
        {!!$s['html']!!}
    </div>
    @endis
    @is('template-list-post-with--category')
    <div class="section template-list-post-with--category">
        <!-- CONTAINER -->
        <div class="container">
            <!-- ROW -->
            <div class="row">
                <!-- Main Column -->
                <div class="col-md-8">
                    <!-- section title -->
                    <div class="section-title">
                        <h2 class="title">{!!$s['title']!!}</h2>
                    </div>
                   
                   @foreach($s['data'] as $p)
                    <article class="article row-article">
                        <div class="article-img">
                            <a href="{!!$link = get_permalinks($p)!!}">
                                <img data-src="{!!get_media($p->image)!!}" alt="">
                            </a>
                        </div>
                        <div class="article-body">
                            <ul class="article-info">
                                <li class="article-category"><a href="{!!get_permalinks($p->category)!!}">{!!$p->category->title!!}</a></li>
                            </ul>
                            <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                            <ul class="article-meta">
                                <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                            </ul>
                            <p>{!!$p->description!!}</p>
                        </div>
                    </article>
                   @endforeach
                </div>
                <!-- /Main Column -->
                <!-- Aside Column -->
                <div class="col-md-4">
                    {!!get_sidebar('sidebar-primary-2','sidebar-primary')!!}
                </div>
                <!-- /Aside Column -->
            </div>
            <!-- /ROW -->
        </div>
        <!-- /CONTAINER -->
    </div>
    @endis
@endforswitch
@stop