@extends(theme_extends())

<?php 
  title_head('Home');
  add_filter('body_class',function($filter){
    unset($filter[array_search('post-detail', $filter)]);
    return $filter;
  });
 ?>

@section('content')
<style type="text/css">
  .content img{
    display: block;
    margin: 0 auto;
    max-width: 100%;
  }
  .post-wrapper .post-thumb{
    height: 200px;
  }
  .post-wrapper .post-thumb img{
      width: 100%;
      max-width: 100%;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%,-50%);
  }
  .post-title-author-details h4{
    line-height: 28px;
  }
</style>




<div class="container">
      <div class="row">
          <article class="content">
              <h1 class="title">{!!$post->title!!}</h1>
                <ul class="breadcrumb">
                    <li><a href="{!!route('index')!!}">@__t('Home page')</a></li>
                    <li><a href="{!!get_permalinks($post)!!}">{!!$post->title!!}</a></li>
                </ul>
              <br>
              {!!$post->content!!}
          </article>
      </div>
  </div>
@stop
