@extends(theme_extends())

<?php 
  title_head('Home');
  add_filter('body_class',function($filter){
    unset($filter[array_search('post-detail', $filter)]);
    return $filter;
  });
 ?>

@section('content')
<style type="text/css">
    #map{
        height: 415px;
        overflow: hidden;
        padding: 0;
        margin: 0;
        border: none;
    }
    .contact-address .top-icon{
        display: block;
    }
    .error_message{
        position: absolute;
        color: red;
    }
</style>
<div class="section">
    <div class="container">
        <h1 class="title">{!!$post->title!!}</h1>
        <div class="breadcrumb">
            <a href="{!!route('index')!!}">@__t('Home page')</a>
            <a href="javascript:void(0)">{!!$post->title!!}</a>
        </div>
    </div>
</div>
<!-- SECTION -->
<div class="section">
    <div class="container">
        
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <div class="contact-title" style="margin-bottom: 50px;">
                     {!!$post->content!!}
                </div>
            </div>

            <?php 
                $items = $post->{'list-item'};
             ?>

             @forif( $items as $i)
            <div class="col-sm-4">
                <div class="contact-address">
                    <!-- Address -->
                    <h3>{!!$i['title']!!}</h3>
                    <i class="fa {!!$i['icon']!!} top-icon" aria-hidden="true"></i>
                    {!!$i['content']!!}
                </div>
            </div>
            @endforif

            <div class="col-sm-8">
                <div class="contact-form-area">
                    <div class="row">

                        <form id="form-contact" action="{!!route('post',['contact','index'])!!}" method="POST">
                            <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                            <div class="col-sm-6">
                                <span class="input">
                                     <label class="" for="input-1">
                                           @__t('First Name')
                                    </label>
                                    <input class="input_field" name="first_name" required="required" type="text" id="input-1">
                                </span>
                            </div>
                            <div class="col-sm-6">
                                <span class="input">
                                        <label class="" for="input-2">@__t('Last Name')</label>
                                        <input class="input_field" name="last_name" required="required" type="text" id="input-2">
                                </span>
                            </div>
                            <div class="col-sm-6">
                                <span class="input">
                                        <label class="" for="input-3">@__t('Your Email')</label>
                                        <input class="input_field" name="email" required="required" type="email" id="input-3">
                                </span>
                            </div>
                            <div class="col-sm-6">
                                <span class="input">
                                        <label class="" for="input-4">@__t('Subject')</label>
                                        <input class="input_field" name="subject" required="required" type="text" id="input-4">
                                </span>
                            </div>
                            <div class="col-sm-12">
                                <span class="input">
                                        <label class="" for="message">@__t('Your Message')</label>
                                        <textarea class="input_field" name="message" required="required" id="message"></textarea>
                                </span>
                                <button type="submit" class="btn btn-style">@__t('Submit')</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div> 
            <div class="col-sm-4">
                <div id="map">
                </div>
            </div> 
        </div>
    </div>
</div>


@stop

@section('js')
    <script type="text/javascript">
        $(window).load(function(){
           setTimeout(function() { $('#map').html('{!!$post->{'iframe-map'}!!}'); }, 10);
        });

        $('#form-contact').submit(function(){
            event.preventDefault();
            var isValidate = true;
            $(this).find('.input_field').each(function(index,el){
                $(el).closest('.input').find('.error_message').remove();
                if( !$(el).val() ){
                    isValidate = false;
                    $(el).closest('.input').append('<p class="error_message">Thông tin này là bắt buộc.</p>');
                }
            });

            if( isValidate ){
                var $this = $(this);

                var data = $this.serializeArray();
                data.push({name:'_token',value:'{!!csrf_token()!!}'});
                
                $.ajax({
                    url: $this.attr('action'),
                    type:'POST',
                    dataType:'Json',
                    data:data,
                    success:function(data){
                        if(data.message){
                            alert(data.message);
                        }

                        if( data.reset ){
                            $this[0].reset();
                        }
                    }
                });
            }

            

        });

       

    </script>
@stop
