@extends(theme_extends())

<?php 
  title_head('Home');
  add_filter('body_class',function($filter){
    unset($filter[array_search('post-detail', $filter)]);
    return $filter;
  });

  $category = $post->relationship('category');

 ?>

@section('content')
<style type="text/css">
    .rn_block{
        display: flex;
        flex-wrap: wrap;
    }
    .article-temp-1 .article-img{
        height: 200px;
        position: relative;
        overflow: hidden;
    }

    .article-temp-1 .article-img img{
        position: absolute;
        min-height: 100%;
        min-width: 100%;
    }
   
   
</style>
<div class="section">
    <!-- CONTAINER -->
    <div class="container">
        @if( $category )
        <h1 class="title">{!!$category->title!!}</h1>
        <ul class="breadcrumb">
            <li><a href="{!!route('index')!!}">@__t('Home page')</a></li>
            <li><a href="{!!$link = get_permalinks($category)!!}">{!!$category->title!!}</a></li>
        </ul>
        @endif
        <!-- ROW -->
        <div class="row">
            <!-- Main Column -->
            <div class="col-md-8">
                <!-- breadcrumb -->
                
                <!-- /breadcrumb -->
                <!-- ARTICLE POST -->
                <article class="article article-post">
                    <div class="article-share">
                        <a  href="https://www.facebook.com/sharer/sharer.php?app_id=553103531550612&amp;sdk=joey&amp;u={!!Request::url()!!}&amp;display=popup&amp;ref=plugin&amp;src=share_button" onclick="return !window.open(this.href, 'Facebook', 'width=640,height=580')" class="facebook"><i class="fa fa-facebook"></i></a>
                        <a  href="https://twitter.com/intent/tweet?url={!!Request::url()!!}&amp;display=popup&amp;ref=plugin&amp;src=share_button" onclick="return !window.open(this.href, 'twitter', 'width=640,height=580')" class="twitter"><i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="article-main-img">
                        <img  data-src="{!!get_media($post->image)!!}" alt="">
                    </div>
                    <div class="article-body">
                        <ul class="article-info">
                            @if( $category )
                            <li class="article-category"><a href="{!!$link!!}">{!!$category->title!!}</a></li>
                            @endif
                        </ul>
                        <h1 class="article-title">{!!$post->title!!}</h1>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> {!!get_date($post->created_at)!!}</li>
                        </ul>
                         {!!$post->content!!}
                    </div>
                </article>
                <!-- /ARTICLE POST -->
                <!-- widget tags -->

                <?php 
                  $tags = json_decode($post->tag,true);

                  if( !is_array($tags) ) $tags = [];

                 ?>

                 @if( isset($tags[0]) )

                 <div class="widget-tags">
                    <ul>
                       @foreach( $tags  as $t)
                        <li> <a href="{!!get_permalinks($t)!!}">{!!$t['title']!!}</a></li>
                        @endforeach
                    </ul>
                </div>
                @endif
            </div>
            <!-- /Main Column -->
            <!-- Aside Column -->
            <div class="col-md-4">
                {!!get_sidebar('sidebar-primary-1','sidebar-primary')!!}
                {!!get_sidebar('sidebar-primary-2','sidebar-primary')!!}
            </div>
            <!-- /Aside Column -->
        </div>
        <!-- /ROW -->
    </div>
    <!-- /CONTAINER -->
</div>
<!-- /SECTION -->
<!-- AD SECTION -->
<div class="visible-lg visible-md">
    <img class="center-block"  data-src="http://localhost:8080/cms_ecommerce/uploads/bn-top.jpg" alt="">
</div>
<!-- /AD SECTION -->
<!-- SECTION -->
<div class="section">
    <!-- CONTAINER -->
    <div class="container">
        <!-- ROW -->
        <div class="row">
            <!-- Main Column -->
            <div class="col-md-12">
                <!-- section title -->
                <div class="section-title">
                    <h2 class="title">Có thể bạn quan tâm</h2>
                </div>
                <!-- /section title -->
                <!-- row -->
                <div class="row">
                    <!-- Column 1 -->

                    <?php 

                        $list_post = Cache::rememberForever('related news - '.$post->id, function() use( $post) {
                          return newsRelated($post,['count'=>4]);
                        });
                      
                      ?>

                      @foreach($list_post as $p)
                      <div class="col-md-3 col-sm-6">
                        <article class="article article-temp-1">
                            <div class="article-img">
                                <a href="{!!$link = get_permalinks($p)!!}">
                                    <img  data-src="{!!get_media($p->image)!!}" alt="">
                                </a>
                            </div>
                            <div class="article-body">
                                <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                                <ul class="article-meta">
                                    <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                                </ul>
                            </div>
                        </article>
                      </div>
                      @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@stop