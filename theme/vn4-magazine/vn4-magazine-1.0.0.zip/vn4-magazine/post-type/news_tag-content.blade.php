@extends(theme_extends())

<?php 
  title_head('Home');
  add_filter('body_class',function($filter){
    unset($filter[array_search('post-detail', $filter)]);
    return $filter;
  });

 ?>

@section('content')

 <div class="section">
        <div class="container">
            <h1 class="title">{!!$post->title!!}</h1>
            <ul class="breadcrumb">
                <li><a href="{!!route('index')!!}">@__t('Home page')</a></li>
                <li><a href="javascript:void(0)">{!!$post->title!!}</a></li>
            </ul>
        </div>
    </div>

<div class="section template-list-post-with--category">
    <!-- CONTAINER -->
    <div class="container">
        <!-- ROW -->
        <div class="row">
            <!-- Main Column -->
            <div class="col-md-8">


                <?php 

                    $page = Request::get('page','1');

                    $posts = cache_tag( 'news-tag - '.$post->id, App::getLocale().'-page-'.$page, function() use ($post) {
                        return $post->related('news_post','tag',['count'=>10,'paginate'=>'page']);
                    });


                 ?>

               @foreach($posts as $p)
                <article class="article row-article">
                    <div class="article-img">
                        <a href="{!!$link = get_permalinks($p)!!}">
                            <img data-src="{!!get_media($p->image)!!}" alt="">
                        </a>
                    </div>
                    <div class="article-body">
                        <h3 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h3>
                        <ul class="article-meta">
                            <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                        </ul>
                        <p>{!!$p->description!!}</p>
                    </div>
                </article>
               @endforeach

                {!!get_paginate($posts,'posts')!!}
            </div>
            <!-- /Main Column -->
            <!-- Aside Column -->
            <div class="col-md-4">
                {!!get_sidebar('sidebar-primary-1','sidebar-primary')!!}
                {!!get_sidebar('sidebar-primary-2','sidebar-primary')!!}
            </div>
            <!-- /Aside Column -->
        </div>
        <!-- /ROW -->
    </div>
    <!-- /CONTAINER -->
</div>


@stop