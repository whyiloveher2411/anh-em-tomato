<?php 

if( !Request::has('url') ){
   header('Content-Type: application/json');
    echo json_encode(['error'=>1,'message'=>'Your website address is required (url={YOUR-WEBSITE})']);
    die();
}
    vn4_log('Corona Report',null,null,'info','/corona-report-'.date('Y-m-d-H').'.log');
 ?>

@if( Request::get('type','html') === 'json' )
    <?php 
        $dataVietName = [];
        $row = explode("\r\n", $data['gdata']['detail']);

        foreach ($row as $value) {
            $dataVietName[] = explode(',', $value);
        }


         $total = explode("\r\n", $data['gdata']['total']);
         $label = explode(',', $total[0]);
         $total = explode(',', end($total));

         $worldDetail = $data['data']['data'][0]['table_left'];

         unset($worldDetail[0]);

        $data['world'] = [
            'detail'=>$worldDetail,
            'total'=>$data['data']['data'][0]['table_right']['total'],
        ];

         $data['vietname'] = [
            'detail'=>$dataVietName,
            'total'=>[$label ,$total],
         ];
         unset($data['data']);
         unset($data['gdata']);
        

        header('Content-Type: application/json');
        echo json_encode($data);
        die();
     ?>
@else
<style type="text/css">
    .corona{
        font-family: arial;
    }
    .corona table tr:not(:first-child) td:not(:first-child) {
        font-weight: 700;
        text-align: right;
        white-space: pre;
    }

    .corona table td {
        padding: 10px;
        border-top: 1px solid #e5e5e5;
    }
    .corona table td:first-child{
        text-align: left;
    }

    .corona_table::-webkit-scrollbar {
      width: 3px;
    }

    /* Track */
    .corona_table::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    /* Handle */
    .corona_table::-webkit-scrollbar-thumb {
      background: #888;
      height: 3px;
    }

    /* Handle on hover */
    .corona_table::-webkit-scrollbar-thumb:hover {
      background: #555;
    }
    .corona_virus_tab li {
        list-style: none;
        width: auto;
        position: relative;
        border-bottom: none;
        color: #757575;
        font-weight: 400;
        padding: 10px;
        padding-top: 20px;
        overflow: visible;
        cursor: pointer;
    }
    .corona_virus_tab li.active {
        color: #222222;
    }
    .corona_virus_tab li.active:before {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        margin: auto;
        content: '';
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 10px 10px 0 10px;
        border-color: #bdbdbd transparent transparent transparent;
    }
    .corona_virus_tab li.active:after {
        position: absolute;
        top: -2px;
        left: 0;
        right: 0;
        margin: auto;
        content: '';
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 10px 10px 0 10px;
        border-color: #f7f7f7 transparent transparent transparent;
    }
    .corona_virus_content{
        display: flex;
    }
    @if( Request::has('plugin_wp') )
    .corona_virus_content{
        display: block;
    }
    .corona_table{
        width: 100% !important;
        margin-bottom: 10px;
    }
    .corona_virus_data{
        width: 100% !important;
    }
    .corona_virus_data>div{
        width: 100%;
        font-size: 15px !important;
        line-height: 20px !important;
    }
    @endif
</style>
 <?php 
    // dd($data);

    function generateRandomString($length = 10) {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    $str_random = generateRandomString(10);

    $dataVietName = [];
    $row = explode("\r\n", $data['gdata']['detail']);

    foreach ($row as $value) {
        $dataVietName[] = explode(',', $value);
    }


     $total = explode("\r\n", $data['gdata']['total']);
     $total = explode(',', end($total));


 ?>

<div class="widget {!!$str_random!!} center-block" style="margin-bottom: 30px;">

   
    <div class="corona  corona_virus corona_virus--detail corona_virus_vietnam" style="display: none; background: #f7f7f7;border: 1px solid #e5e5e5;padding: 10px;text-align: center;color: #333333;font-size: 14px;clear: both;">
        <div class="corona_virus_title" style="font-weight: bold;font-size: 16px;line-height: 18px;text-align: left;border-bottom: 1px solid #c4c4c4;margin-bottom: 10px;padding-bottom: 10px;margin-top: 10px;">Covid-19 tại Việt Nam</div>
        
        <div class="corona_virus_content">

            <div class="corona_table" style="width: 65%;-webkit-box-flex: 1;-ms-flex-positive: 1;flex-grow: 1;margin-right: 10px;font-size: 14px;line-height: 16px;max-height: 209px;overflow: auto;">    
                <table style="width: 100%;">
                    <tbody>
                        <tr>
                            <td>Nơi khởi bệnh</td>
                            <td style="font-weight: normal;">Nhiễm</td>
                            <td style="font-weight: normal;white-space: pre;">Khỏi</td>
                        </tr>
                        <?php 
                             $count = count($dataVietName);
                         ?>
                         @for($i = 1; $i < $count; $i ++)
                        @if( $dataVietName[$i][2] )
                         <?php 
                            $d = $dataVietName[$i];
                         ?>
                        <tr>
                            <td>{!!$d[1]!!}</td>
                            <td>{!!$d[2]?number_format($d[2],0,',','.'):''!!}</td>
                            <td>{!!$d[7]?number_format($d[7],0,',','.'):''!!}</td>
                        </tr>
                        @endif

                        @endfor

                    </tbody>
                </table>
            </div>
            <div class="corona_virus_data" style="width: 35%;">                                    
                <div class="corona_nhiembenh" style="font-weight: bold; background: #e5e5e5;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;">{!!number_format($total[2],0,',','.')!!} <br> <small style="font-size: 12px;">Nhiểm</small></div>                                    
                <div class="corona_tuvong" style="color: white; font-weight: bold;margin-top:10px;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;background: #999999;">{!!number_format($total[3],0,',','.')!!} <br> <small style="font-size: 12px;">Tử vong</small></div>                                   
                <div class="corona_khoibenh" style="font-weight: bold;background: #e5e5e5;margin-top:10px;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;">{!!number_format($total[6],0,',','.')!!} <br> <small style="font-size: 12px;">Khỏi</small></div>                                
            </div>
        </div>
        
    </div>



    <div class="corona corona_virus corona_virus--detail corona_virus_thegioi" style="background: #f7f7f7;border: 1px solid #e5e5e5;padding: 10px;text-align: center;color: #333333;font-size: 14px;clear: both;">
        <div class="corona_virus_title" style="font-weight: bold;font-size: 16px;line-height: 18px;text-align: left;border-bottom: 1px solid #c4c4c4;margin-bottom: 10px;padding-bottom: 10px;margin-top: 10px;">Covid-19 trên Thế giới</div>
        
        <div class="corona_virus_content">
          
            <div class="corona_table" style="width: 65%;-webkit-box-flex: 1;-ms-flex-positive: 1;flex-grow: 1;margin-right: 10px;font-size: 14px;line-height: 16px;max-height: 209px;overflow: auto;">    
                <table style="width: 100%;">
                    <tbody>
                        <tr>
                            <td></td>
                            <td style="font-weight: normal;">Nhiễm</td>
                            <td style="font-weight: normal;white-space: pre;">Tử vong</td>
                        </tr>
                        @foreach($data['data']['data'][0]['table_left'] as $d)

                        @if( isset($d['country_vn']) )
                        <tr>
                            <td>{!!$d['country_vn']!!}</td>
                            <td>{!!number_format($d['cases'],0,',','.')!!}</td>
                            <td>{!!$d['deaths']?number_format($d['deaths'],0,',','.'):''!!}</td>
                        </tr>
                        @endif

                        @endforeach

                    </tbody>
                </table>
            </div>
            

            <div class="corona_virus_data" style="width: 35%;">                                    
                <div class="corona_nhiembenh" style="font-weight: bold; background: #e5e5e5;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;">{!!number_format($data['data']['data'][0]['table_right']['total']['cases'],0,',','.')!!} <br> <small style="font-size: 12px;">Nhiểm</small></div>                                    
                <div class="corona_tuvong" style="color: white; font-weight: bold;margin-top:10px;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;background: #999999;">{!!number_format($data['data']['data'][0]['table_right']['total']['deaths'],0,',','.')!!} <br> <small style="font-size: 12px;">Tử vong</small></div>                                   
                <div class="corona_khoibenh" style="font-weight: bold;background: #e5e5e5;margin-top:10px;font-size: 20px;line-height: 27px;padding: 10px 15px;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;">{!!number_format($data['data']['data'][0]['table_right']['total']['recovered'],0,',','.')!!} <br> <small style="font-size: 12px;">Khỏi</small></div>                                
            </div>
        </div>
        
        

    </div>

    <ul class="corona_virus_tab" style=" display: flex;margin-top: 10px;margin-bottom: 0;border-top: 1px solid #bdbdbd;-webkit-box-pack: start;-ms-flex-pack: start;justify-content: flex-start;">        
        <li data-id="vietnam" onclick="$f=this;[].forEach.call(document.querySelectorAll('.{!!$str_random!!} .corona_virus--detail'), function (el) { el.style.display = 'none'; }); [].forEach.call(document.querySelectorAll('.{!!$str_random!!} .corona_virus_tab li'), function (el) { el.classList.remove('active'); });$f.classList.add('active'); document.querySelector('.{!!$str_random!!} .corona_virus_'+$f.dataset.id).style.display = 'block';" style="margin-left: 10px;" >Việt Nam</li>                                
        <li data-id="thegioi" class="active" onclick="$f=this;[].forEach.call(document.querySelectorAll('.{!!$str_random!!} .corona_virus--detail'), function (el) { el.style.display = 'none'; }); [].forEach.call(document.querySelectorAll('.{!!$str_random!!} .corona_virus_tab li'), function (el) { el.classList.remove('active'); });$f.classList.add('active'); document.querySelector('.{!!$str_random!!} .corona_virus_'+$f.dataset.id).style.display = 'block';" style="margin-left: 10px;">Thế giới</li>                           
    </ul>
</div>
@endif