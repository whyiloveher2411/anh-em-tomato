<?php


register_post_type(function($list_post_type){

	$add_object = [];

	$add_object[] = [
			'news_category',
	    	1,
			[
			    'table'=>'news_category',
			    'title'=>__('News Category'),
			    'slug'=>'news-category',
			    'cache'=>function($post){
			    	cache_tag('news-category - '.$post->id ,null,'clear');
			    },
			    'fields'=>[
			        'title'=>[
			            'title'=>__('Title'),
			            'view'=>'text',
			            'required'=>true,
			            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
			        ],
			        'slug' => [
			            'title'=>'Slug',
			            'view' =>'slug',
			            'key_slug'=> 'title',
			            'type' =>'text',
			            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).',
			        ],
			        'parent' => [
			            'title'=>__('Parent'),
			            'view' =>'relationship_onetomany',
			            'show_data'=>false,
			            'object'=>'news_category',
			            'note'=>'Chuyên mục khác với thẻ, bạn có thể sử dụng nhiều cấp chuyên mục. Ví dụ: Trong chuyên mục nhạc, bạn có chuyên mục con là nhạc Pop, nhạc Jazz. Việc này hoàn toàn là tùy theo ý bạn.',

			        ],
			        'description' => [
			            'title'=>__('Description'),
			            'show_data'=>false,
			            'view' =>'textarea',
			            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
			        ],
			    ],
			]
		];


	$add_object[] = [
			'news_tag',
	    	1,
			[
			    'table'=>'news_tag',
			    'title'=> __('News Tag'),
			    'slug'=>'news-tag',
			    'fields'=>[
			        'title'=>[
			            'title'=>__('Title'),
			            'view'=>'text',
			            'required'=>true,
			            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
			        ],
			        'slug' => [
			            'title'=>'Slug',
			            'view' =>'slug',
			            'key_slug'=> 'title',
			            'type' =>'text',
			            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
			        ],
			        'description' => [
			            'title'=>__('Description'),
			            'show_data'=>false,
			            'view' =>'textarea',
			            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
			        ],
			    ],
			]
		];



	$add_object[] = [
			'news_post',
	    	1,
			[
			    'table'=>'news_post',
			    'title'=> __('News Post'),
			    'slug'=>'news',
			    'cache'=>function($post){
			    	cache_tag('news-category - '.$post->category ,null,'clear');
			    	cache_tag('home-page',null,'clear');
			    },
			    'fields'=>[
			        'title'=>[
			            'title'=>__('Title'),
			            'view'=>'text',
			            'required'=>true,
			        ],
			        'slug' => [
			            'title'=>__('Slug'),
			            'view' =>'slug',
			            'key_slug'=>'title',
			            'type' => 'text',
			            'show_data'=>false,
			        ],
			        'description' => [
			            'title'=>__('Description'),
			            'view' =>'textarea',
			            'show_data'=>false,
			        ],
			        'content' => [
			            'title'=>__('Content'),
			            'view' =>'editor',
			            'show_data'=>false,
			            'required'=>true,
			        ],
			        'category' => [
			            'title'=>__('Category'),
			            'view' =>'relationship_onetomany',
			            'object'=>'news_category',
			            'show_data'=>true,
			            'advance'=>'right',
			        ],
			        'tag' => [
			            'title'=>__('Tag'),
			            'view' =>'relationship_manytomany',
			            'object'=>'news_tag',
			            'type'=>'tags',
			            'show_data'=>true,
			            'advance'=>'right',
			        ],
			        'image' => [
			            'title'=>__('Featured Image'),
			            'view' =>'image',
			            'required'=>true,
			            'show_data'=>false,
			            'advance'=>'right',
			            'note'=>'featured image is the way it appears on your website',
			        ],
			    ],
			]
		];


	$add_object[] = [
			'news_contact',
	    	1,
			[
			    'table'=>'news_contact',
			    'title'=> __t('Contact'),
			    'slug'=>'news_contact',
			    'fields'=>[
			        'title'=>[
			            'title'=>__t('Email'),
			        ],
			        'first_name'=>[
			        	'title'=>__t('First Name'),
			        ],
			        'last_name'=>[
			        	'title'=>__t('First Name'),
			        ],
			        'subject'=>[
			        	'title'=>__t('First Name'),
			        ],
			        'message' => [
			            'title'=>__t('Message'),
			            'view'=>'textarea',
			        ],
			    ],
			]
		];


	$add_object[] = [
			'news_subscribe',
	    	1,
			[
			    'table'=>'news_subscribe',
			    'title'=> __t('Subscribe'),
			    'slug'=>'news_subscribe',
			    'fields'=>[
			        'title'=>[
			            'title'=>__t('Email'),
			        ],
			    ],
			]
		];


	return $add_object;

});


if( is_admin() ){

	include __DIR__.'/inc/backend.php';

}else{

	include __DIR__.'/inc/frontend.php';

}