<?php
$data = json_decode($sidebar->content,true);
?>

@foreach($data as $d)
	@switch( $d['type'] )
		@case('wiget-info')
	 	<div class="footer-widget about-widget">
            <div class="footer-logo">
                <a href="{!!route('index')!!}" class="logo"><img data-src="{!!get_media($d['data']['image'])!!}" alt=""></a>
                <p>{!!$d['data']['content']!!}</p>
            </div>
        </div>
		@break
		@case('wiget-social-network')
	 	<div class="footer-widget social-widget">
            <div class="widget-title">
                <h3 class="title">{!!$d['data']['title']!!}</h3>
            </div>
            <ul>

            	<?php 
            		$social_network = theme_options('contact','list-social');
            	 ?>
                @forif($social_network as $s) 
                <li>
                    <a href="{!!$s['link']!!}" title="{!!$s['title']!!}" class="facebook" style="background-color: {!!$s['color']!!};" target="_blank" rel="nofollow" >
                        <i class="fa  {!!$s['icon']!!}"></i>
                    </a>
                </li>
                @endforif

            </ul>
        </div>
		@break
		@case('wiget-subscribe')
	 	<div class="footer-widget subscribe-widget">
            <div class="widget-title">
                <h2 class="title">{!!$d['data']['title']!!}</h2>
            </div>
            <form class="form-subscribe" action="{!!route('post',['contact','subscribe'])!!}">
                <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                <input class="input input_field" name="email" type="email" placeholder="{!!$d['data']['placeholder']!!}">
                <button type="submit" class="input-btn">{!!$d['data']['label-button']!!}</button>
            </form>
        </div>
		@break
		@case('wiget-list-post')
	 	<div class="footer-widget">
            <div class="widget-title">
                <h2 class="title">{!!$d['data']['title']!!}</h2>
            </div>

            <?php 
            	$posts = get_posts('news_post',['callback'=>function($q) use ($d){
            		$q->whereIn(Vn4Model::$id, $d['data']['post']);
            	}]);
             ?>

             @foreach($posts as $p)
            <article class="article widget-article">
                <div class="article-img">
                    <a href="{!!$link = get_permalinks($p)!!}" style="margin-bottom: 30px;">
                        <img data-src="{!!get_media($p->image)!!}" alt="">
                    </a>
                </div>
                <div class="article-body">
                    <h4 class="article-title"><a href="{!!$link!!}">{!!$p->title!!}</a></h4>
                    <ul class="article-meta">
                        <li><i class="fa fa-clock-o"></i> {!!get_date($p->created_at)!!}</li>
                    </ul>
                </div>
            </article>
            @endforeach
           
        </div>
		@break
		@case('wiget-images')
        <div class="footer-widget galery-widget">
            <div class="widget-title">
                <h2 class="title">{!!$d['data']['title']!!}</h2>
            </div>
            <ul>
            	@forif( $d['data']['images'] as $i)
                <li><a href="{!!$i['link']!!}" target="_blank"><img alt="{!!$i['title']!!}"  title="{!!$i['title']!!}" data-src="{!!get_media($i['image'])!!}"></a></li>
                @endforif
            </ul>
        </div>
		@break
		@case('wiget-status')
		<div class="footer-widget tweets-widget">
            <div class="widget-title">
                <h2 class="title">{!!$d['data']['title']!!}</h2>
            </div>

            <ul>
                @foreach($d['data']['list-status'] as $p)
                <li class="tweet">
                   	<img data-src="{!!get_media($p['avatar'])!!}">
                    <div class="tweet-body">
                        <p>{!!$p['content']!!}</p>
                    </div>
                </li>
                @endforeach
            </ul>
        </div>

		@break
        @case('text-html')
        <div class="widget center-block">
            {!!$d['data']['content']!!}
        </div>
        @break
	@endswitch
@endforeach