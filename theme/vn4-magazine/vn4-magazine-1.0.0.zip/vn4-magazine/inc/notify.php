<?php

// return [
// 	[
// 		'type'=>'message',
// 		'message'=>'Hello notify from Theme',
// 		'color'=>'green',
// 		'place'=>[
// 			'notify','dashboard'
// 		]
// 	]
// ];