<?php

return [
	'index'=>function($r){
        App::setLocale($r->get('language'));
        if( $r->isMethod('POST') ){

    		$data = $r->only('first_name','last_name','subject','message');
    		$data['title'] = $r->get('email');

    		$validate = Validator::make($data, [
                'first_name'=>'required|max:255','last_name'=>'required|max:255','title'=>'required|email|max:255','subject'=>'required','message'=>'required'
            ],['required' => __t(':attribute is required.'),'email'=>__t('Please enter the correct email format'),'min'=>__t(':attribute Minimum of 8 characters.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

            if( $validate->fails() ){
            	$errors = $validate->errors();
            	return redirect()->back()->withErrors($errors->getMessages());;
            }

            $contact = Vn4Model::createPost('news_contact',$data);

            if($contact){
    			return response()->json(['reset'=>true,'message'=>__t('Send contact successful. We will contact you as soon as possible.')]);
            }

    		return response()->json(['message'=>__t('Failed to send contact.')]);

        }

        return redirect()->route('page','contact');

	},


    'subscribe'=>function($r){
        App::setLocale($r->get('language'));
        if( $r->isMethod('POST') ){
            $data = ['title'=>$r->get('email')];

            $validate = Validator::make($data, ['title'=>'required|email|max:255'
            ],['required' => __t(':attribute is required.'),'email'=>__t('Please enter the correct email format'),'max'=>__t(':attribute Maximum of 255 characters.')]);

            if( $validate->fails() ){
                $errors = $validate->errors();
                return redirect()->back()->withErrors($errors->getMessages());;
            }

            if( DB::table('news_subscribe')->where('title',$data['title'])->first() ){
                return response()->json(['message'=>__t('You have already subscribed to this email, please choose another email.')]);
            }

            $contact = Vn4Model::createPost('news_subscribe',$data);

            if($contact){
                return response()->json(['reset'=>true,'message'=>__t('Subscribe Success.')]);
            }

            return response()->json(['message'=>__t('Subscribe failed.')]);

        }

        return redirect()->route('index');

    }


];