<?php

return [
	'get'=>function($r){
		$dataCovid = json_decode(file_get_contents_curl('https://vnexpress.net/microservice/corona'),true);

		return theme_view('particle.widget-corona',['data'=>$dataCovid]);
	}	
];