<?php
return [
	'page.home'=> [
		'title'=>'Home Page',
		'fields'=>[
			'section'=>[
				'title'=>'Section',
				'view'=>'flexible',
				'templates'=>[
					'slider-4-post-on-screen'=>[
						'title'=>'Slider 4 Post On Screen',
						'items'=>[
							'list-post'=>[
								'title'=>'List Post',
								'view'=>'relationship_manytomany',
								'type'=>'many_record',
								'object'=>'news_post',
							]
						]
					],
					'slider-3-post-on-screen'=>[
						'title'=>'Slider 3 Post On Screen',
						'items'=>[
							'title'=>[
								'title'=>'Title',
								'view'=>'text',
							],
							'list-post'=>[
								'title'=>'List Post',
								'view'=>'relationship_manytomany',
								'type'=>'many_record',
								'object'=>'news_post',
							]
						]
					],
					'template-multi-category'=>[
						'title'=>'Multi Category full width',
						'items'=>[
							'title'=>[
								'title'=>'Title',
								'view'=>'text',
							],
							'category'=>[
								'title'=>'Category',
								'view'=>'relationship_manytomany',
								'type'=>'many_record',
								'object'=>'news_category',
							]
						]
					],
					'template-3-category'=>[
						'title'=>'3 Category with sidebar primary',
						'items'=>[
							'category-1'=>[
								'title'=>'Category 1',
								'view'=>'relationship_onetomany',
								'type'=>'many_record',
								'object'=>'news_category',
							],
							'category-2'=>[
								'title'=>'Category 2',
								'view'=>'relationship_onetomany',
								'type'=>'many_record',
								'object'=>'news_category',
							],
							'category-3'=>[
								'title'=>'Category 3',
								'view'=>'relationship_onetomany',
								'type'=>'many_record',
								'object'=>'news_category',
							],
						]
					],
					'template-list-post-with--category'=>[
						'title'=>'List post with sidebar primary 2',
						'items'=>[
							'title'=>[
								'title'=>'title',
								'view'=>'text',
							],
							'list-post'=>[
								'title'=>'Category',
								'view'=>'relationship_manytomany',
								'type'=>'many_record',
								'object'=>'news_post',
							]
						]
					],
					'ads'=>[
						'title'=>'HTML',
						'items'=>[
							'html'=>[
								'title'=>'HTML',
								'view'=>'textarea',
							]
						]
					],
					
				]
			],
		]
	],
	'page.contact'=> [
		'title'=>'Contact',
		'fields'=>[
			'list-item'=>[
				'title'=>'List Item',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title'],
					'icon'=>['title'=>'Icon (fontawesome)'],
					'content'=>['title'=>'Content','view'=>'textarea'],
				]
			],
			'iframe-map'=>[
				'title'=>'Iframe Map',
				'view'=>'textarea',
			]
		]

	]
];