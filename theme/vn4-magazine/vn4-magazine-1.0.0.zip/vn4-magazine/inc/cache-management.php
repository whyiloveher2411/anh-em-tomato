<?php


return [
	'home-page'=>[
		'title'=>'Home Page',
		'description'=>'The data used on the home page, for example news, category ...',
		'type'=>'Database',
	],
	'tag-category'=>[
		'title'=>'Category - Tag Page',
		'description'=>'Cache on page category and tag',
		'type'=>'Database',
		'flush'=>function(){
			$posts = get_posts('news_category',100000);

			foreach ($posts as $p) {
				cache_tag( 'news-category - '.$p->id,null, 'clear');
			}

			$posts = get_posts('news_tag',100000);

			foreach ($posts as $p) {
				cache_tag( 'news-tag - '.$p->id,null, 'clear');
			}
		}
	],

];