<?php
return [
	'general'=>[
		'title'=>'General',
		'fields'=>[
			'logo-black'=>['title'=>'Logo black','view'=>'image'],
			'logo-white'=>['title'=>'Logo white','view'=>'image'],
		]
	],
	'header'=>[
		'title'=>'Header',
		'fields'=>[
			'menu-top'=>[
				'title'=>'Menut Top',
				'view'=>'menu'
			],
			'banner-ads'=>[
				'title'=>'Banner Ads',
				'view'=>'textarea',
			]
		],
	],
	'Footer'=>[
		'title'=>'Footer',
		'fields'=>[
			'rights'=>['title'=>'Copyright','view'=>'text'],
			'menu-footer-bottom'=>[ 'title'=>'Menu Bottom','view'=>'menu'],
		]
	],
	'contact'=>[
		'title'=>'Contact',
		'fields'=>[
			'address'=>['title'=>'Address','view'=>'text'],
			'tell'=>['title'=>'Tell','view'=>'text'],
			'email'=>['title'=>'Email','view'=>'text'],
			'list-social'=>[
				'title'=>'List Social',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title','view'=>'text'],
					'icon'=>['title'=>'Icon (fontawesome)'],
					'color'=>['title'=>'Color','view'=>'color'],
					'link'=>['title'=>'Link','view'=>'text'],
				]
			]
		]
	]
];