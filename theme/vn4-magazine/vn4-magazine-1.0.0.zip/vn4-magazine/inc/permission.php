<?php
// return [
// 	[
// 		'group'=>'theme.demo',
// 		'title_group'=>'Theme Demo',
// 		'key'=>'theme_demo_permission',
// 		'title'=>'Permission Theme Demo',
// 	],
// ];

// check permission
// check_permission('theme_demo_permission')
