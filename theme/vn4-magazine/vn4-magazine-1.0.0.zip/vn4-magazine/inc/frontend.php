<?php

function newsRelated($post, $parameter = []){

	if( !isset($parameter['count']) ) $parameter['count'] = 10;

	if( isset($parameter['callback']) ){
		 $parameter['callback'] = [$parameter['callback']];
	}else{
		 $parameter['callback'] = [];
	}


	$parameter['callback'][] = function($q) use ($post){
		return $q->where('category','=', $post->category)->inRandomOrder();
	};

	return get_posts('news_post',$parameter);
}
