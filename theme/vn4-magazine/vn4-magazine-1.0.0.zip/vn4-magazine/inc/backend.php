<?php

add_sidebar_admin(function() {

    $filter['vn4news'] = [
        'title'=>'Vn4News',
        'icon'=>'fa-themeisle',
        'position'=>100,
        'submenu'=>[
            [
                'title'=>'Post',
                'url'=>route('admin.show_data','news_post'),
            ],
            [
                'title'=>'Category',
                'url'=>route('admin.show_data','news_category'),
            ],
            [
                'title'=>'Tag',
                'url'=>route('admin.show_data','news_tag'),
            ],
            [
                'title'=>'Contact',
                'url'=>route('admin.show_data','news_contact'),
            ],
            [
                'title'=>'Subscribe',
                'url'=>route('admin.show_data','news_subscribe'),
            ],
        ]
    ];

    return $filter;

});
