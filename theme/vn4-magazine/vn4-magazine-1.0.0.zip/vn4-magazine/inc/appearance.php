<?php

register_nav_menus([
    'header'=>'Nav Header',
]);

register_sidebar([
    'sidebar-primary-1'=>['title'=>'Primary Sidebar 1','description'=>'Sidebar Right of Home page, category, post detail.'],
    'sidebar-primary-2'=>['title'=>'Primary Sidebar 2','description'=>'Sidebar Right of Home page, category, post detail.'],
    'sidebar-footer-1'=>['title'=>'Sidebar Footer 1','description'=>'Sidebar Footer column 1'],
    'sidebar-footer-2'=>['title'=>'Sidebar Footer 2','description'=>'Sidebar Footer column 2'],
	'sidebar-footer-3'=>['title'=>'Sidebar Footer 3','description'=>'Sidebar Footer column 3'],
]);

return [
	'wiget-info'=>[
		'title'=>'Website Info (Theme maganews)',
		'description'=>'Insert a custom paragraph with an image on top',
		'fields'=>[
			'image'=>[
				'title'=>'Image',
				'view'=>'image',
			],
			'content'=>[
				'title'=>'Content',
				'view'=>'textarea',
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet Info';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-social-network'=>[
		'title'=>'Social Network (Theme maganews)',
		'description'=>'Insert social network icons defined in theme options',
		'fields'=>[
			
		],
	 	'show'=>function($data){
	 		return 'Wighet Social';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-subscribe'=>[
		'title'=>'Subscribe (Theme maganews)',
		'description'=>'Create from subscribe to receive news',
		'fields'=>[
			'placeholder'=>[
				'title'=>'Placeholder',
				'view'=>'text',
			],
			'label-button'=>[
				'title'=>'Lable Button',
				'view'=>'text',
			],
		],
	 	'show'=>function($data){
	 		return 'Wighet Subscribe';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-list-post'=>[
		'title'=>'List Post (Theme maganews)',
		'description'=>'Create custom post lists',
		'fields'=>[
			'post'=>[
				'title'=>'Post',
				'view'=>'relationship_manytomany',
				'object'=>'news_post',
				'type'=>'many_record',
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet List Post';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-slider-list-post'=>[
		'title'=>'List Post Slider 1(Theme maganews)',
		'description'=>'Create custom post lists',
		'fields'=>[
			'post'=>[
				'title'=>'Post',
				'view'=>'relationship_manytomany',
				'object'=>'news_post',
				'type'=>'many_record',
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet List Post';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-slider-list-post-2'=>[
		'title'=>'List Post Slider 2(Theme maganews)',
		'description'=>'Create custom post lists',
		'fields'=>[
			'post'=>[
				'title'=>'Post',
				'view'=>'relationship_manytomany',
				'object'=>'news_post',
				'type'=>'many_record',
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet List Post';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-images'=>[
		'title'=>'Images (Theme maganews)',
		'description'=>'Create custom image lists',
		'fields'=>[
			'images'=>[
				'title'=>'Image',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'title','view'=>'text'],
					'link'=>['title'=>'Link','view'=>'text'],
					'image'=>['title'=>'Image','view'=>'image','thumbnail'=>[ 'normal'=>['title'=>'Normal','type'=>1,'width'=>106,'height'=>106] ]],
				],
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet Images';
	 		// return $data->get_data('content');
      	}
	],
	'wiget-status'=>[
		'title'=>'Status Social (Theme maganews)',
		'description'=>'Customize statuses from social networks',
		'fields'=>[
			'list-status'=>[
				'title'=>'List Status',
				'view'=>'repeater',
				'sub_fields'=>[
					
					'content'=>[
						'title'=>'Content',
						'view'=>'textarea',
					],
					'avatar'=>[
						'title'=>'avatar',
						'view'=>'image',
						'width'=>74,
						'height'=>74,
					],
				]
			]
		],
	 	'show'=>function($data){
	 		return 'Wighet Status Social';
	 		// return $data->get_data('content');
      	}
	],
	'widget-corona'=>[
		'title'=>'Show Report Covid-19',
		'description'=>'Create Report covid-12',
		'fields'=>[
			
		],
		'show'=>function($data){
	 		return 'Wighet Report Covid-19';
	 		// return $data->get_data('content');
      	}
	]
];