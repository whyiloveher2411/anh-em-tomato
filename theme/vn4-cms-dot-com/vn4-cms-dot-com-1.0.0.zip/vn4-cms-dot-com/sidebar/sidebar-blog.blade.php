@foreach($widgets as $widget)
	<div class="sidebar-item">
		<h4>
			{!!$widget->title!!}
		</h4>
		<div class="content">
			{!!$widget->html!!}
		</div>
	</div>
@endforeach