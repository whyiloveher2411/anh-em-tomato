@extends(theme_extends())
<?php 
    $active_success = session('active_success');

    if( !$active_success ){
        return vn4_redirect(route('page','login'));
    }

 ?>
@section('content')
<style type="text/css">
	.form-swith h2{
		text-align: center;
	}
	.form-swith button{
		width: 100%;
		background-color: #28c;
		color: white;
	}
</style>
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">@__t('Verify account')</h1>
                        <h2 class="page-description">@__t('Please verify your account before continuing.')</h2>.
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

<div id="content" style="background: white;">
    <div class="container">


        <div class="row">

            
            <div class=" col-md-offset-3 col-md-6">
	            <h2>@__t('Account verification successful')</h2>
                <p>@__t('We will redirect you to the login page and you may continue.')</p>
                <a href="{!!route('page','login')!!}" class="button small blue">@__t('Return to the login page')</a>
            </div>
        </div>
    </div>
</div>
@stop
