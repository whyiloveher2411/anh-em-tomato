<?php 
	$user = check_login_frontend(null,function(){
		return false;
	});

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Vn4CMS Auth License</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
			font-family: arial;
			box-sizing: border-box;
		}
		textarea,input{
		    display: block;
		    margin: 11px auto;
		    width: 100%;
		    border: 1px solid #dedede;
		    height: 32px;
		    padding: 0 10px;
		    border-radius: 4px;
		    resize: none;
		}
		textarea,input:not(.submit){
	        background-color: #f6f7f8;
		}
		textarea{
			padding: 10px;
			height: 100px;
		}
	</style>
</head>
<body>
	<div id="content">
	</div>
	<script type="text/javascript" src="@theme_asset()js/jquery.min.js"></script>
	<script type="text/javascript">
		var objParent = window.opener;

		if( objParent ){

			$.ajax({
				url: '{!!route('post',['vn4cms-auth-license','index'])!!}',
				dataType: 'html',
				type: 'POST',
				data:{
					_token: '{!!csrf_token()!!}',
				},
				success:function(html){
					$('#content').html('<br><p style="text-align: center;"><img src="{!!get_media(theme_options('general','logo'))!!}" style="max-height: 150px;"></p><br>'+html);
				}			
			});


			$(document).on('click','.submit',function(){

				var username = $('#username').val();
				var password = $('#password').val();

				if( !username || !password ){
					alert('@__t('Please enter the login information')');
					return;
				}

				$.ajax({
					url: '{!!route('post',['vn4cms-auth-license','post'])!!}',
					type: 'POST',
					data:{
						_token: '{!!csrf_token()!!}',
						username: username,
						password: password,
					},
					success:function(result){
						if( result.message ){
							alert(result.message);
						}
						
						if( result.success ){
							$('#content').html('<br><p style="text-align: center;"><img src="{!!get_media(theme_options('general','logo'))!!}" style="max-height: 150px;"></p><br>'+result.data);
						}	
											
						if( result.error ){
							return ;
						}
					}			
				});

			});

		}else{
			$('body').html('');
		}

	</script>
</body>
</html>