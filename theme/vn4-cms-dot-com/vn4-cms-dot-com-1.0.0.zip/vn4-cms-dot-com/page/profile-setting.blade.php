<?php 
	$user = check_login_frontend(null,function(){
		return false;
	});
	if( !$user ) return vn4_redirect(route('page','login'));
 ?>
 @extends(theme_extends())

<?php 

	$post = $user;
    title_head($post->name); 

    $reviews = $post->related('cms_product_review','cms_user',['count'=>true]);
    $product_type = get_posts('cms_product_type',10);

    add_body_class('marketplace');
 ?>
@section('content')

<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="row main">
            <div class="col-md-3">

                {!!get_particle('particle.nav-profile',['active'=>'profile-setting','post'=>$post, 'reviews'=>$reviews,'product_type'=>$product_type])!!}

            </div>
            <div class="col-md-9 main-list" style="border-left: 1px solid #ecf0f1;padding-left: 0;">
            
                <br><br>

                @if (Session::has('success'))
                    <h2 style="padding: 0 15px;color: green;">{!!Session::get('success')!!}</h2>
                @endif
                @if ($errors->any())
                    <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                               <p style="padding: 0 15px;color:red;">{!! $error !!}</p>
                            @endforeach
                    </div>
                @endif


                <form method="POST" action="{!!route('post',['account','edit'])!!}" id="formsubmit">
                    <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                    <div class="col-md-6">
                        <div class="">
                            <h4 style="font-weight:300;">@__t('Name')</h4>
                            <input type="text" style="line-height: 40px;height: 40px;" value="{!!$user->name!!}" name="fullname" required="required"  class="form-control" >
                        </div>
                        <br>
                        <div class="">
                            <h4 style="font-weight:300;">@__t('A new password')</h4>
                            <input type="password" style="line-height: 40px;height: 40px;" value="" name="newpassword" id="newpassword" class="form-control" >
                        </div>


                    </div>

                    <div class="col-md-6">
                        <div class="">
                            <h4 style="font-weight:300;">@__t('Email')</h4>
                            <input style="border: none;box-shadow: none;line-height: 40px;height: 40px;" type="text" value="{!!$user->title!!}" readonly="readonly" class="form-control" >
                        </div>
                        <br>
                        <div class="">
                            <h4 style="font-weight:300;">@__t('Confirm new password')</h4>
                            <input type="password" style="line-height: 40px;height: 40px;" value="" name="confirmpassword" id="confirmpassword"  class="form-control" >
                        </div>
                    </div>
                    <div class="col-md-6">
                        <br>
                        <input type="submit" name="change_profile" class="btn btn-primary blue" value="@__t('Save changes')">
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">
        
    $('#formsubmit').submit(function(event){

        if( $('#newpassword').val() ){

            if($('#newpassword').val().length <= 8 || $('#newpassword').val().length > 255 ){
                alert('@__t('Password must be between 8 and 255 characters')');
                event.preventDefault();
                return false;
            }
            if($('#newpassword').val() != $('#confirmpassword').val()){
                alert('@__t('Confirm password does not match')');
                event.preventDefault();
                return false;
            }

        }
        


    });

    </script>
@stop