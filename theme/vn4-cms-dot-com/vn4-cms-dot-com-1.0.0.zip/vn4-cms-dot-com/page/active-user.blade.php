@extends(theme_extends())
<?php 
    $user = session('user_frontend');

    if( !$user || $user->active ){
        return vn4_redirect(route('page','login'));
    }

 ?>
@section('content')
<style type="text/css">
	.form-swith h2{
		text-align: center;
	}
	.form-swith button{
		width: 100%;
		background-color: #28c;
		color: white;
	}
</style>
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">@__t('Verify account')</h1>
                        <h2 class="page-description">@__t('Please verify your account before continuing.')</h2>.
                    	<a href="javascript:window.history.back()" class="button small blue">@__t('Back')</a>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

<div id="content" style="background: white;">
    <div class="container">


        <div class="row">

            
            <div class=" col-md-offset-3 col-md-6">
                <form class="form-swith" id="form-send-email-active">
                    <input type="hidden" name="form-type" value="validate-email">
                    <h2>@__t('I have not received email')</h2>
                    <p>@__t('We will send you another confirmation email.')</p>
                    <button type="submit" class="button small blue">@__t('Send verify code')</button>
                </form>
            </div>
        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">
         $('.form-swith').submit(function(event){
            event.preventDefault();
            var data = $(this).serializeArray();
            show_message('@__t('Please wait a second')');
            data.push({name:'_token',value: '{!!csrf_token()!!}'});
            $.ajax({
                url:"{!!route('post',['account','validate-email'])!!}",
                type:"POST",
                dataType:"Json",
                data:data,
                success:function(result){
                    if( result.message ){
                        alert(result.message);
                    }

                    if( result.redirect ){
                        window.location.reload(result.redirect);
                    }

                    hide_message();
                }
            });
        });
    </script>
@stop