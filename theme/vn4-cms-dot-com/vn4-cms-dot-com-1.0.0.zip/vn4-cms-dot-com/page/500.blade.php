@extends(theme_extends())

@section('content')
	
	<h1>500 Internal Server Error</h1>
	
@stop