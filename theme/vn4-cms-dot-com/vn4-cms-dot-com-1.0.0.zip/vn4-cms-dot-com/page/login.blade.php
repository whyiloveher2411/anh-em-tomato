@extends(theme_extends())
<?php 
    $user = check_login_frontend();
    
    $r = request();

    $id = $r->get('payment');
    
    $version = get_post('cms_product_version',$id);

    $product = null;

    $product_type = null;

    if( $version ){
        $product = $version->relationship('product');
    }

    if( $product ){

        $product_type = $product->relationship('product_type');

        if( $product->price ){
            title_head(__t('Pay'));
        }

        if(  $user && (!$product->price || $product->cms_user === $user->id ) ){
            $product = null;
        }

    }
 ?>
@section('content')
<style type="text/css">
    .form-swith h2{
        text-align: center;
    }
    .form-swith button{
        width: 100%;
        background-color: #28c;
        color: white;
    }
</style>
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">

                        @if( $product && $product->price )
                        <h1 class="page-title" style="margin-bottom: 15px;">@__t('Pay')</h1>
                        <h2 class="page-description">@__t('Some of our products require you to pay before using. To ensure that you have never purchased this product, please log in or register before proceeding with payment.')</h2>.
                        @else
                        <h1 class="page-title">@__t('Login')</h1>
                        <h2 class="page-description">@__t('Some functions on the website require login, please login before using')</h2>.
                        @endif
                            <a href="javascript:window.history.back()" class="button small blue">@__t('Black')</a>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

<div id="content" style="background: white;">
    <div class="container">


        <div class="row">

            
            <div class=" col-md-offset-3 col-md-6">
                @if($user)
                        <form class="form-swith" id="form-login" style="padding: 20px;background: whitesmoke;border-radius: 4px;">
                            <input type="hidden" name="form-type" value="logout">
                            <input type="hidden" name="url" class="url_post" value="{!!route('post',['account','logout'])!!}">

                            <h2><a href="{!!route('page','profile')!!}">@__t('Go to the profile page')</a></h2>

                            <h2>@__t('Or')</h2>

                              <button type="submit" name="login" value="1" class="button small blue">@__t('Logout')</button>

                                
                        </form>
                @else
                        <form class="form-swith" id="form-login" style="padding: 20px;background: whitesmoke;border-radius: 4px;">
                            <input type="hidden" name="form-type" value="login">
                            <input type="hidden" name="url" class="url_post" value="{!!route('post',['account','login'])!!}">

                            <h2>@__t('Login')</h2>

                                <div class="form-group">
                                    <input type="email" name="email" class="">
                                    <label>@__t('Email')</label>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" class="">
                                    <label>@__t('Password')</label>
                                </div>
                              
                              <button type="submit" name="login" value="1" class="button small blue">@__t('Login')</button>

                              <ul class="login-helpers">
                                <li class="login-helper-item">@__t('Do you already have an account?') <a href="#" class="change-form" data-form="form-sign-up">@__t('Sign up')</a></li>
                                <li class="login-helper-item"><a href="#" class="change-form" data-form="form-forgot-password">@__t('Forgot password')</a></li>
                            </ul>

                        </form>

                        <form class="form-swith" id="form-forgot-password" style="padding: 20px;background: whitesmoke;border-radius: 4px;display: none;">
                            <input type="hidden" name="form-type" value="forgot-password">
                            <input type="hidden" name="url" class="url_post" value="{!!route('post',['account','forgot-password'])!!}">

                            <h2>@__t('Forgot password')</h2>
                            <p>@__t('Enter the email address that verified your user account and we will send you a password reset link.')</p>
                            <div class="form-group">
                                <input type="text" class="" name="email">
                                <label>@__t('Email')</label>
                            </div>
                            <button type="submit" class="button small blue">@__t('Get a new password')</button>

                              <ul class="login-helpers">
                                <li class="login-helper-item"><a href="#" class="change-form" data-form="form-login">← @__t('Back to the login page')</a></li>
                            </ul>

                        </form>

                        <form class="form-swith" id="form-sign-up" style="padding: 20px;background: whitesmoke;border-radius: 4px;display: none;">
                            <input type="hidden" name="form-type" value="sign-up">
                            <input type="hidden" name="url" class="url_post" value="{!!route('post',['account','sign-up'])!!}">

                            <h2>@__t('Sign up')</h2>
                            <div class="form-group">
                                <input type="text" class="" name="fullname">
                                <label>@__t('Name')</label>
                            </div>
                            <div class="form-group">
                                <input type="email" class="" name="email">
                                <label>@__t('Email')</label>
                            </div>
                            <div class="form-group">
                                <input type="password" class="" name="password">
                                <label>@__t('Password')</label>
                            </div>
                            <div class="form-group form-check">
                                <input type="checkbox" class="form-check-input" name="send_email_promotion" id="" style="display: inline-block;width: auto;margin: 5px 5px 5px 10px;"> @__t('Send me product updates, announcements, and offers.')
                              </div>
                            <button type="submit" class="button small blue">@__t('Sign up')</button>

                              <ul class="login-helpers">
                                <li class="login-helper-item"><a href="#" class="change-form" data-form="form-login">@__t('Do you already have an account?')</a></li>
                            </ul>

                        </form>
                @endif

            </div>

            @if( $product )
            <div class="col-md-3">

                <div style="border: 1px solid #e1e8ed;border-radius: 3px;" class="sidebar-is-fixed">
                    <h3 style="font-weight: bold;display: block;padding: 10px;border-bottom: 1px solid #e1e8ed;margin: 0;line-height: 36px;">@__t('Order Summary')</h3>
                    <div style="padding: 10px; font-size: 16px;color: #4c4c4c;border-bottom: 1px solid #e1e8ed;color: #4c4c4c;line-height: 36px;">
                        <div style="line-height: 19px;color: #b7b7b7;">{!!$product_type->title!!}</div>
                        <a href="{!!get_permalinks($product)!!}" target="_blank">{!!$product->title!!}</a> 
                        <span style="float: right;">{!!$product->price!!}</span>

                    </div>
                    <div style="padding: 10px;line-height: 36px;">@__t('Total:') <span style="float: right;">{!!$product->price!!}</span></div>
                </div>

                

            </div>


            
            @endif
           

        </div>

        @if( $product )
            @if( $user && check_user_buy_product( $user, $product ) )
                <form method="POST" action="{!!route('post',['download','index','id'=>$version->id])!!}">

                <p style="margin-top: 25px;text-align: center;"><span style="color: #ce0000;">@__t('Note: </span> You have purchased this product before, so you can download it now')

                    <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                    <input type="submit" class="btn btn-primary blue" name="download" value="@__t('here')">


                @__t('or see in') <a href="{!!route('page','profile')!!}">@__t('Profile page')</a>.

                </p>
                </form>
                
            @else
            <?php 
                $price = $product->price;
                $price = (int) filter_var($price, FILTER_SANITIZE_NUMBER_INT);
             ?>
            <div class="row" style="clear: both;margin-top: 15px;">
                <div class="col-md-12" style="margin-top: 15px;">
                    

                    <?php 
                        $payment = theme_options('payment-content');

                        $payment_content = $payment['content']??'';

                        $payment_content = strtr($payment_content,[
                            '##user##'=>$user->title??'email',
                            '##product_type##'=>$product_type->title,
                            '##product##'=>$product->title,
                            '##product_id##'=>$product->id,
                            '##money##'=>number_format($price*23000),
                            '##profile##'=>route('page','profile'),
                        ]);
                     ?>


                    {!!$payment_content!!}
                        
                </div>

                @forif($payment['bank-list'] as $p)
                <div class="col-md-6" style="margin-top: 15px;">
                    <div style="border: 1px solid #e1e8ed;border-radius: 3px;padding: 15px;">
                        <div style="display: inline-block;">
                            <div><a href="" style="font-size: 18px;">{!!$p['bank']!!}</a></div>
                            <div style="margin: 15px 0;color: red;font-size: 24px;">{!!$p['number_account']!!}</div>
                            <div style="margin: 15px 0;font-size: 24px;">{!!$p['name_account']!!}</div>
                            <div>@__t('Branch:') {!!$p['branch']!!}</div>
                        </div>
                        <img style="height: 110px;float: right;" src="{!!get_media($p['image'])!!}">
                    </div>
                </div>
                @endforif
            </div>
            @endif
        @endif

    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">

        $('.change-form').click(function(event){
            event.preventDefault();

            $('.form-swith').hide();
            $('#'+$(this).data('form')).show();
        });

        $('form :input').change(function(){
            if($(this).val().trim()){
                $(this).addClass('valid')
            }else{
                $(this).removeClass('valid')
            }
        });

        $('.form-swith').submit(function(event){
            event.preventDefault();
            show_message('@__t('Please wait a moment')');
            var data = $(this).serializeArray();
            data.push({name:'_token',value: '{!!csrf_token()!!}'});
            url = $(this).find('.url_post').val();

            $.ajax({
                url:url,
                type:"POST",
                dataType:"Json",
                data:data,
                success:function(result){
                    if( result.message ){
                        alert(result.message);
                    }

                    if( result.redirect ){
                        window.location.href = result.redirect;
                    }

                    if( result.reload ){
                        window.location.reload(result.reload);
                    }

                    hide_message();
                }
            });
        });
    </script>
@stop