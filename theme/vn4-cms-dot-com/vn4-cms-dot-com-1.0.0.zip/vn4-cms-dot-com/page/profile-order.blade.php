<?php 
	$user = check_login_frontend(null,function(){
		return false;
	});

	if( !$user ) return vn4_redirect(route('page','login'));



 ?>
 @extends(theme_extends())

<?php 
	$post = $user;
    title_head($post->name); 
    $product_type = get_posts('cms_product_type',10);

    add_body_class('marketplace');
    $showProduct = false;

    $product_order = $post->related('cms_order','cms_user');
    $reviews = $user->related('cms_product_review','cms_user',['count'=>10,'paginate'=>'page']);

 ?>
@section('content')
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="row main">
            <div class="col-md-3">

                {!!get_particle('particle.nav-profile',['active'=>'profile-order','post'=>$post, 'reviews'=>count($reviews),'product_type'=>$product_type])!!}

                
            </div>
            <div class="col-md-9 main-list" style="border-left: 1px solid #ecf0f1;padding-left: 0;">

                <!-- Tabs -->
                <div class="tabs js-tabs" style="padding-top: 30px;padding-left: 30px;border-top: 1px solid #ecf0f1;">

                    @if( isset($product_order[0]) )
                         <?php 
                            $showProduct = true;
                          ?>
                          
                        <h4 class="tab-title">
                            @__t('Order')
                        </h4>
                        <div class="tab-content">
                            <div class="list row">
                            @foreach($product_order as $p)
                                <?php  
                                    $product = $p->relationship('product');
                                    $type = $product->relationship('product_type');
                                    $product_order_review[$product->id] = ['product'=>$product,'type'=>$type];
                                ?>

                                <div class="item col-md-12">
                                    {!!get_particle('particle.template-order-'.$type->template_product,['post'=>$product])!!}
                                </div>
                            @endforeach
                            </div>
                        </div>
                    @endif

                    @if( isset($reviews[0]) )
                    <?php 
                            $showProduct = true;
                          ?>
                          
                        <h4 class="tab-title">
                            @__t('Reviews')
                        </h4>
                        <div class="tab-content">
                            <div class="list">

                            <table class="tb-v tb-review">
                             @forelse($reviews as $r)
                                 <?php 
                                     if( !isset($product_order_review[$r->product]['product']) ){
                                        continue;  
                                     }
                                    $author = json_decode($r->cms_user_detail);
                                  ?>
                                <tr>
                                    <th><img style="width: 50px;margin-top: 10px;" src="https://iupac.org/wp-content/uploads/2018/05/default-avatar.png"></th>
                                    <td>
                                        <div class="gray">
                                            <strong>[{!!$product_order_review[$r->product]['type']->title!!}] {!!$product_order_review[$r->product]['product']->title!!}</strong>
                                        </div>
                                        <div class="header-top">
                                            <ul class="skill-level" style="display: inline-block;float: left;">
                                                @for($i = 0; $i < $r->rating; $i ++ )
                                                <li><span class="fa fa-star"></span></li>
                                                @endfor

                                                @for($i = $r->rating; $i < 5; $i++)
                                                <li><span class="fa fa-star-o"></span></li>
                                                @endfor
                                            </ul>
                                            <a href="{!!get_permalinks($r)!!}" style="line-height: 36px;padding: 10px;">{!!$r->title!!}</a>
                                        </div>
                                        
                                        @if( $author )
                                        <div class="header-bottom">
                                            <a href="{!!get_permalinks($author)!!}">{!!$author->name!!}</a> <span>{!!get_date($r->created_at)!!}</span>
                                        </div>
                                        @endif

                                         <div>
                                            
                                            <i class="fa fa-users gray" aria-hidden="true"></i>&nbsp;{!!$r->count_voice!!}&nbsp;&nbsp;&nbsp;<i class="fa fa-commenting gray" aria-hidden="true"></i>&nbsp;{!!$r->count_reply!!}

                                        </div>

                                        <div class="review-content">
                                            {!!$r->message!!}
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <div class="col-md-12">
                                    <p style="text-align: center;">@__t('This product has not been rated.')</p>
                                </div>
                                @endforelse
                            </table>
                            </div>
                        </div>
                    @endif

                    @if( !$showProduct )
                    <h4 class="tab-title">
                        @__t('Order')
                    </h4>
                    <div class="tab-content">
                        <p style="text-align: center;">@__t('Product not found')</p>
                    </div>
                    @endif

                    
                </div>

                


            </div>

        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">
        $('body').on('click','.accordion-title',function(t) {
            t.preventDefault();
            var n = $(this),
                i = n.closest(".accordion-item"),
                a = $(this).parent().find('.accordion-description');
            $(this).closest('.js-accordion').find('.accordion-item.active').not(i).removeClass("active");$(this).closest('.js-accordion').find('.accordion-description.active').not(a).stop().slideUp().removeClass("active");
            a.hasClass("active") ? (i.removeClass("active"), a.stop().slideUp().removeClass("active")) : (i.addClass("active"), a.stop().slideDown().addClass("active"));
        });

        var hash = window.location.href.substring(window.location.href.indexOf("#")+1);
        @if( Request::has('review') )
            setTimeout(function() {
                $('.steps li:nth-child('+(($('.tabs .tab-content[data-id="reviews"]').index() + 1)/2 )+') a').trigger('click');
            }, 1);
        @else


        if( $('.tabs .tab-content[data-id="'+hash+'"]') ){

            setTimeout(function() {
                $('.steps li:nth-child('+(($('.tabs .tab-content[data-id="'+hash+'"]').index() + 1)/2 )+') a').trigger('click');
            }, 1);
        }

        @endif


    </script>
@stop