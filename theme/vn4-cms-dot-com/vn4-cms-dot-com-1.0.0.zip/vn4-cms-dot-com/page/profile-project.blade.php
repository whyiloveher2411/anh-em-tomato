<?php 
	$user = check_login_frontend(null,function(){
		return false;
	});
	if( !$user ) return vn4_redirect(route('page','login'));
 ?>

 @extends(theme_extends())



<?php 

	$post = $user;

    title_head($post->name); 

    $reviews = $post->related('cms_product_review','cms_user',['count'=>true]);

    $product_type = get_posts('cms_product_type',10);

    add_body_class('marketplace');

    $projects = $post->related('cms_project','cms_user');

    $project_detail_id = Request::get('project_detail',$projects[0]->id??0);
 ?>

@section('content')

<style type="text/css">
    .list-project{

    }
    .list-project .item{
        padding: 10px;
    }
    .list-project .item.active,.list-project .item:hover{
        background: #f3f3f3;
        cursor: pointer;
    }
    .list-project .item .name{
        margin: 0;
        font-weight: bold;
    }
    .list-project .item a{
        font-size: 13px;
    }

    .list-product{

    }
    .list-product .item{

    }
</style>

<div class="header-back header-back-simple header-back-small header-holder">
    
</div>

<div id="content">

    <div class="container">

        <div class="row main">

            <div class="col-md-3">
                {!!get_particle('particle.nav-profile',['active'=>'profile-project','post'=>$post, 'reviews'=>$reviews,'product_type'=>$product_type])!!}
            </div>

            <div class="col-md-9 main-list" style="border-left: 1px solid #ecf0f1;padding-left: 0;">

                <h1 class="page-title">Project Manager</h1>

                <div class="col-md-3 list-project">
                        <h3>List project</h3>
                    @forelse($projects as $p)
                        
                   <div class="item @if( $project_detail_id == $p->id ) active <?php $project_detail = $p;  ?> @endif ">
                        <p class="name"><a href="?project_detail={!!$p->id!!}">{!!$p->title!!}</a></p>
                        <a href="{!!$p->url!!}" target="_blank">{!!$p->url!!}</a>
                   </div> 
                    @empty

                    <p>@__t('Project not found.')</p>

                    @endforelse

                    <form method="POST" class="ajax" action="{!!route('post',['account','create-project'])!!}">
                        <br>
                        <br>
                        <h3>Create project</h3>
                        <label style="margin-bottom: 10px;">
                            Name
                            <input name="title" type="text" value="" class="form-control">
                        </label>
                         <label style="margin-bottom: 10px;">
                            URL
                            <input name="url" type="text" value="" class="form-control">
                        </label>
                        <input type="submit" class="btn btn-primary" name="create_project" value="@__t('Create Project')">
                   </form>

                </div>


                @if( isset($project_detail) )

                    <?php 
                        $products = $project_detail->relationship('product');
                     ?>
                    <form method="POST" action="{!!route('post',['account','reset-api-tokens'])!!}">
                    <div class="col-md-9">

                        <h3>@__t('Basic information')</h3>

                        <p>@__t('Renewing the API token will invalidate all previous project and build copyrights. Proceed with caution.')</p>


                            <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                            <label>

                                Name
                                <input type="text" value="{{$project_detail->title}}" class="form-control">
                            </label>

                             <label>

                                URL
                                <input type="text" value="{{$project_detail->url}}" class="form-control">
                            </label>
                            <br>
                            <br>
                            <div class="list-product">



                                     <h4 class="">
                                        @__t('Products')
                                    </h4>
                                    <div class="tab-content">
                                         <div class="list row">
                                            @forelse($products as $product)
                                                <?php  
                                                    $type = $product->relationship('product_type');
                                                    $product_order_review[$product->id] = ['product'=>$product,'type'=>$type];
                                                ?>

                                                <div class="item col-md-12">
                                                    {!!get_particle('particle.template-order-'.$type->template_product,['post'=>$product])!!}
                                                </div>
                                            @empty
                                                <h2 style="text-align: center;width: 100%;margin: 0;">@__t('Product Not Found.')</h2>
                                            @endforelse
                                            </div>
                                    </div>

                            </div>
                            <div class="" style="margin-top: 15px;">

                                <h4 class="input-label">API Secret</h4>

                                <input type="text" value="{!!$project_detail->api_key!!}" readonly="readonly" class="form-control" >

                            </div>

                            <br>

                            <div class="">

                                <h4 class="input-label">API Token</h4>

                                <textarea style="border: none;box-shadow: none;resize: none;" rows="4" readonly="readonly" class="form-control" >{!!$project_detail->api_token!!}</textarea>

                            </div>

                            <br>

                    </div>
                    </form>
                @endif


            </div>



        </div>

    </div>

</div>

@stop



@section('js')

    <script type="text/javascript">


    </script>

@stop