@extends(theme_extends())
<?php 
	$blogsOptions = theme_options('blogs',['title'=>'','description'=>'','background'=>'','sidebar'=>'']);
 ?>
@section('content')
<style type="text/css">
	.form-swith h2{
		text-align: center;
	}
	.form-swith button{
		width: 100%;
		background-color: #28c;
		color: white;
	}
</style>
<div class="header-back header-back-simple header-back-small" style="background-image: url({!!get_media($blogsOptions['background'])!!})">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">Thanh toán</h1>
                        <h2 class="page-description">Vui lòng thanh toán trước khi download.</h2>.

                        	<a href="javascript:window.history.back()" class="button small blue">Quay lại</a>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

<div id="content" style="background: white;">
    <div class="container">

        <div class="row">

            

        </div>
        <div class="row">
            <div class=" col-md-offset-3 col-md-6">

            	<?php 
            		check_login_frontend(function($user){
            			?>
            			<form class="form-swith" id="form-login" style="padding: 20px;background: whitesmoke;border-radius: 4px;">
							<input type="hidden" name="form-type" value="logout">
							<h2>Đăng xuất</h2>
							  <button type="submit" name="login" value="1" class="button small blue">Đăng xuất</button>
						</form>
            			<?php
            		},function(){
            			?>
        				<form class="form-swith" id="form-login" style="padding: 20px;background: whitesmoke;border-radius: 4px;">
							<input type="hidden" name="form-type" value="login">
							<h2>Đăng nhập</h2>

								<div class="form-group">
	                                <input type="email" name="email" class="">
	                                <label>Email</label>
	                            </div>
	                            <div class="form-group">
	                                <input type="password" name="password" class="">
	                                <label>Password</label>
	                            </div>
							  <div class="form-group form-check">
							    <input type="checkbox" class="form-check-input" name="remember" id="exampleCheck1" style="display: inline-block;width: auto;margin: 5px 5px 5px 10px;"> Remember me.
							  </div>
							  <button type="submit" name="login" value="1" class="button small blue">Đăng nhập</button>

							  <ul class="login-helpers">
								<li class="login-helper-item">Don't have an account? <a href="#" class="change-form" data-form="form-sign-up">Sign Up.</a></li>
								<li class="login-helper-item"><a href="#" class="change-form" data-form="form-forgot-password">Forgot your password</a></li>
							</ul>

						</form>

						<form class="form-swith" id="form-forgot-password" style="padding: 20px;background: whitesmoke;border-radius: 4px;display: none;">
							<input type="hidden" name="form-type" value="forgot-password">
							<h2>Quên mật khẩu</h2>
							<p>Enter your user account's verified email address and we will send you a password reset link.</p>
							<div class="form-group">
	                            <input type="text" class="" name="email">
	                            <label>Email</label>
	                        </div>
						  	<button type="submit" class="button small blue">Get new password</button>

							  <ul class="login-helpers">
								<li class="login-helper-item"><a href="#" class="change-form" data-form="form-login">← Back to Login</a></li>
							</ul>

						</form>

						<form class="form-swith" id="form-sign-up" style="padding: 20px;background: whitesmoke;border-radius: 4px;display: none;">
							<input type="hidden" name="form-type" value="sign-up">

							<h2>Đăng ký</h2>
							<div class="form-group">
	                            <input type="text" class="" name="fullname">
	                            <label>Full name</label>
	                        </div>
	                        <div class="form-group">
	                            <input type="email" class="" name="email">
	                            <label>Email</label>
	                        </div>
	                        <div class="form-group">
	                            <input type="password" class="" name="password">
	                            <label>Password</label>
	                        </div>
	                        <div class="form-group form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1" style="display: inline-block;width: auto;margin: 5px 5px 5px 10px;"> Send me occasional product updates, announcements, and offers.
							  </div>
						  	<button type="submit" class="button small blue">Đăng ký</button>

							  <ul class="login-helpers">
								<li class="login-helper-item"><a href="#" class="change-form" data-form="form-login">Already have an account?</a></li>
							</ul>

						</form>
            			<?php
            		});
            	 ?>
					

            </div>

            <!-- <div class="col-md-offset-3 col-md-6">

					<form>

						<h2>Đăng ký</h2>

					 	<div class="form-group">
                            <input type="text" class="">
                            <label>First name</label>
                        </div>

                        <div class="form-group">
                            <input type="text" class="">
                            <label>Last name</label>
                        </div>

                        <div class="form-group">
                            <input type="text" class="">
                            <label>Email</label>
                        </div>

                        <div class="form-group">
                            <input type="text" class="">
                            <label>Password</label>
                        </div>

                        <div class="form-group">
                            <input type="text" class="">
                            <label>Confirm Password</label>
                        </div>


						  <button type="submit" class="btn btn-primary">Register</button>
					</form>

            </div>
 -->
           

        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">

    	$('.change-form').click(function(event){
    		event.preventDefault();

    		$('.form-swith').hide();
    		$('#'+$(this).data('form')).show();
    	});

    	$('form :input').change(function(){
            if($(this).val().trim()){
                $(this).addClass('valid')
            }else{
                $(this).removeClass('valid')
            }
        });

        $('.form-swith').submit(function(event){
    		event.preventDefault();
    		var data = $(this).serializeArray();
    		data.push({name:'_token',value: '{!!csrf_token()!!}'});
        	$.ajax({
        		url:"{!!route('post-login')!!}",
        		type:"POST",
        		dataType:"Json",
        		data:data,
        		success:function(result){
        			if( result.message ){
        				alert(result.message);
        			}

        			if( result.redirect ){
        				window.location.reload(result.redirect);
        			}
        		}
        	});
        });
    </script>
@stop