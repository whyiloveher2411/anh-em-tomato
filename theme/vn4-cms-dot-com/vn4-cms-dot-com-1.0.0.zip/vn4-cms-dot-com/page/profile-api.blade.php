<?php 

	$user = check_login_frontend(null,function(){

		return false;

	});

    

	if( !$user ) return vn4_redirect(route('page','login'));

 ?>

 @extends(theme_extends())



<?php 



	$post = $user;

    title_head($post->name); 

    $reviews = $post->related('cms_product_review','cms_user',['count'=>true]);

    $product_type = get_posts('cms_product_type',10);

    

    add_body_class('marketplace');

 ?>

@section('content')

<div class="header-back header-back-simple header-back-small header-holder">
    
</div>

<div id="content">

    <div class="container">

        <div class="row main">

            <div class="col-md-3">
                {!!get_particle('particle.nav-profile',['active'=>'profile-api','post'=>$post, 'reviews'=>$reviews,'product_type'=>$product_type])!!}
            </div>

            <div class="col-md-9 main-list" style="border-left: 1px solid #ecf0f1;padding-left: 0;">

                <h1 class="page-title">API Manager</h1>

                <div class="col-md-6">
                    
                    <div class="">

                        <h4 class="input-label">@__t('API Secret')</h4>

                        <input type="text" value="{!!$user->api_key!!}" readonly="readonly" class="form-control" >

                    </div>

                    <br>

                    <div class="">

                        <h4 class="input-label">@__t('API Token')</h4>

                        <textarea style="border: none;box-shadow: none;" rows="6" readonly="readonly" class="form-control" >{!!$user->api_token!!}</textarea>

                    </div>



                </div>

                <div class="col-md-6">

                    <h3>@__t('Refresh API tokens')</h3>

                    <p>@__t('Renewing the API token will invalidate all previous project and build copyrights. Proceed with caution.')</p>

                    <form method="POST" action="{!!route('post',['account','reset-api-tokens'])!!}">

                        <input type="hidden" name="_token" value="{!!csrf_token()!!}">

                        <input type="submit" class="btn btn-primary" name="resettoken" value="@__t('Refresh API tokens')">

                    </form>

                </div>
            </div>
        </div>

    </div>

</div>

@stop



@section('js')

    <script type="text/javascript">

        





    </script>

@stop