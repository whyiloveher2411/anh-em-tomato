<footer class="js-footer-is-fixed footer-is-fixed">
    <div class="footer-extended">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="footer-extended-container">
                        <div class="row">
                            {!!vn4_nav_menu('footer','nav-footer-extended', ['container_class'=>'menu sf-menu js-menu'])!!}
                            <div class="col-md-4 col-sm-4 col-xs-8">
                                <div class="footer-extended-menu">
                                    <h5 class="footer-extended-menu-title">@__t('Subscribe To Newslatter')</h5>
                                    <ul class="socials-footer">
                                        <?php 
                                            $theme_options = theme_options('social-network','items');
                                         ?>
                                         @forif($theme_options as $t)
                                         <li>
                                            <a href="{!!$t['link']!!}" target="_blank" class="socials-footer-link"><i class="fa {!!$t['icon']!!}"></i></a>
                                        </li>
                                         @endforif
                                    </ul>
                                    <div class="subscribe-form-block-footer">
                                        <form id="subscribe-form" action="{!!route('post',['subscribe','post'])!!}" >
                                            <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                                            <input type="text" name="email" id="subscribe-email-footer" class="subscribe-input-footer" placeholder="@__t('Email')">
                                            <button class="subscribe-button-footer">
                                                Subscribe
                                                <i class="fa fa-angle-right"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <p class="text-footer">@__t('Send us a question:') <a href="mailto:{!!$email_support = theme_options('general','email-support')!!}" target="_top">{!!$email_support!!}</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="footer-logo-wrapper">
                        <a href="#" class="logo-image "><img src="{!!get_media(theme_options('general','logo'))!!}" alt="logo"></a>
                        <p class="slogan">
                            {!!theme_options('general','logan')!!}
                        </p>
                    </div>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <div class="footer-wrapper">
                        <span class="scroll-top js-scroll-top"><i class="fa fa-angle-up"></i></span>
                        <div class="docs-version js-docs-version">
                            <span class="docs-current-version js-docs-current-version">v1.0</span>
                        </div>
                        {!!vn4_nav_menu('footer-policy','nav-footer-policy')!!}
                        <p class="copyright helper right">
                            @__t('<a href="#">Vn4CMS</a>, All rights reserved. 2020 ©')
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>