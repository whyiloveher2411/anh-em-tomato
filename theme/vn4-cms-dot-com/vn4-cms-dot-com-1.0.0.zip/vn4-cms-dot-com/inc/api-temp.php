<?php

Route::any('notify',function(){

	$request = request();

	if( !$request->isMethod('POST') ){
		die('Error');
	}

	$key = "vn4cms_api";
	$access_token = $request->get('access_token');


	try {

		$decoded = (array) \Firebase\JWT\JWT::decode($access_token, $key, array('HS256'));

		$user = get_post('cms_user',$decoded['id']);

		if( !$user || $user->status !== 'publish' ){
			return response()->json([

				'error'=>[
					'type'=>'message',
					'error_type'=>'UserNotFoundException',
					'error_message'=>'User not found',
					'code'=>58,
					'message'=>'License information is incorrect, please reinstall <a href="##setting##">here</a>',
					'acction_script'=> 'window.parent.show_message({title:"Warning",color: "#CE812E", icon: "fa-key", content:"License information is incorrect, please reinstall <a href=\"##setting##\"><strong>here</strong></a>"}); setTimeout (function(){ if( window.parent.location.pathname.indexOf("page/setting") == -1 ){ var r = confirm("Please set license information before using, Do you want to go to license setting page?");if (r == true) {window.parent.location.href = "##setting##";} }},5000);',
					'name'=>'System Vn4CMS',
					'color'=>'#db4437',
					'place'=>['notify','dashboard'],
					'route'=>[
						'setting'=>['admin.page',['page'=>'setting','vn4-tab-left-'=>'license']]
					]
				]
			]);
		}


	} catch (Exception $e) {
		return response()->json([
			'error'=>[
				'type'=>'message',
				'error_type'=>str_replace('Firebase\JWT\\', '', get_class($e)),
				'error_message'=>$e->getMessage(),
				'code'=>$e->getline(),
				'message'=>'License information is incorrect, please reinstall <a href="##setting##">here</a>',
				'acction_script'=> 'window.parent.show_message({title:"Warning",color: "#CE812E", icon: "fa-key", content:"License information is incorrect, please reinstall <a href=\"##setting##\"><strong>here</strong></a>"}); setTimeout (function(){ if( window.parent.location.pathname.indexOf("page/setting") == -1 ){ var r = confirm("Please set license information before using, Do you want to go to license setting page?");if (r == true) {window.parent.location.href = "##setting##";} }},5000);',
				'name'=>'System Vn4CMS',
				'color'=>'#db4437',
				'place'=>['notify','dashboard'],
				'route'=>[
					'setting'=>['admin.page',['page'=>'setting','vn4-tab-left-'=>'license']]
				]
			]
		]);
	}


	// $order =  $user->related('')
	// $payload = array(
	// 	'type'=>'message',
	// 	'error_type'=>'dfsdf',
	// 	'error_message'=>'sdfsdfsdf',
	// 	'code'=>'sdfsdfsd',
	// 	'message'=>'Thông tin bản quyền không dúng, vui lòng cài đặt lại <a href="##setting##">tại đây</a>',
	// 	'acction_script'=> 'setTimeout (function(){ if( window.parent.location.pathname.indexOf("page/setting") == -1 ){ var r = confirm("Thông tin bản quyền không dúng, Bạn có muốn đến trang cài đặt bản quyền không?");if (r == true) {window.parent.location.href = "##setting##";} }},1000);',
	// 	'name'=>'System Vn4CMS',
	// 	'color'=>'#db4437',
	// 	'place'=>['notify','dashboard'],
	// 	'route'=>[
	// 		'setting'=>['admin.page',['page'=>'setting','vn4-tab-left-'=>'license']]
	// 	]
	// );

	// *
	//  * IMPORTANT:
	//  * You must specify supported algorithms for your application. See
	//  * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
	//  * for a list of spec-compliant algorithms.
	 
	// $jwt = \Firebase\JWT\JWT::encode($payload, $key);
	// dd($jwt);
	
	// dd($decoded);

	
	// $order = $user->related('cms_order','cms_user',['count'=>1,'callback'=>function($q){
	// 	return $q->where('cms','["1"]');
	// }]);
	// // dd(isset($order[0]));
	// if( !isset($order[0]) ){

	// 	return response()->json([

	// 		'error'=>[
	// 			'type'=>'message',
	// 			'error_type'=>'UserNotBuyCMS',
	// 			'error_message'=>'User not Buy Cms',
	// 			'code'=>58,
	// 			'message'=>'Vui lòng mua bản quyền Vn4CMS trước khi sử dụng, vui lòng kiểm tra lại tại đây <a href="'.route('page','profile').'">tại đây</a>',
	// 			'acction_script'=> 'setTimeout (function(){ if( window.parent.location.pathname.indexOf("page/setting") == -1 ){ var r = confirm("Vui lòng mua bản quyền Vn4CMS trước khi sử dụng.\r\nBạn có muốn đến trang cài đặt bản quyền không?");if (r == true) {window.parent.location.href = "##setting##";} }},1000);',
	// 			'name'=>'System Vn4CMS',
	// 			'color'=>'#db4437',
	// 			'place'=>['notify','dashboard'],
	// 			'route'=>[
	// 				'setting'=>['admin.page',['page'=>'setting','vn4-tab-left-'=>'license']]
	// 			]
	// 		]
	// 	]);
	// }


	$notify = get_posts('cms_notify',[
		'count'=>10,
		'select'=>['message_type','message','color','name','avatar','place','route','version']
	]);

	$result = [];

	foreach ($notify as $key => $value) {

		$temp = [];


		$temp['id'] = $value->id;
		$temp['color'] = $value->color;
		$temp['message'] = $value->message;
		$temp['name'] = $value->name;
		$temp['version'] = $value->version;
		$temp['place'] = json_decode($value->place);
		$temp['avatar'] = get_media($value->avatar);
		$temp['type'] = $value->message_type;

		$route = json_decode($value->route,true);

		if( isset($route[0]) ) {

			$routeTemp = [];

			foreach ($route as $key2 => $value2) {
				$param_temp = [];

				foreach ($value2['route-param'] as $key3 => $value3) {
					$param_temp[$value3['key']] = $value3['value'];
				}

				$routeTemp[$value2['key']] = [$value2['route-name'],$param_temp];

			}

			$temp['route'] = $routeTemp;

		}

		$result[] = $temp;
	}

	$message_account = 'License information belongs to the account <a target="_blank" href="'.route('page','profile').'">'.$user->title.'</a>. If you have any questions, please contact Vn4CMS team <a href="https://vn4cms.com/en/page/contacts" target="_blank">here</a>.';

	$result[] = [
		'type'=>'message',
		'message'=>$message_account,
		'name'=>'System Vn4CMS',
		// 'avatar'=>'https://www.gravatar.com/avatar/'.md5( strtolower( trim( $user->title ) ) ).'?&s=150',
		'place'=>['notify','dashboard']
	];


	$product_code = json_decode($request->get('product'),true);

	if( !$product_code ) $product_code = [];
	// return $product_code;
	$product = get_posts('cms_product',['count'=>100,'callback'=>function($q) use ($product_code) {
		return $q->whereIn('title',array_keys($product_code));
	}]);
	// return $product;
	$order =  $user->related('cms_order','cms_user',['callback'=>function($q) use ($product) {
		return $q->whereIn('product',$product->pluck(Vn4Model::$id));
	}])->groupBy('product');
	// return response()->json($order);

	$product = $product->groupBy(Vn4Model::$id);

	$notify = [];

	$message_version = [];

	// if( count($product) !== count($order) ){ 

	$message = '';

	foreach ($product as $id => $p) {

		if( $p[0]->price && !isset($order[$id]) && $p[0]->cms_user != $user->id){
			$message .= '<a target="_blank" href="'.get_permalinks($p[0]).'">'.$p[0]->title.'</a>, ';

			$message_version[] = [
				'type'=>'message',
				'product'=>$p[0]->title,
				'message_plugin'=>'Vui lòng thanh toán sản phẩm trước khi sử dụng. xem thêm <a target="_blank" href="'.get_permalinks($p[0]).'">tại đây</a>',
				'name'=>'System Vn4CMS',
				'color'=>'red',
				'place'=>['notify','dashboard']
			];

		}

		$version = $p[0]->related('cms_product_version','product');
		// return $version;
		if( isset($version[0]) && isset($product_code[$p[0]->title]) && $version[0]->title !== $product_code[$p[0]->title]) {
			$message_version[] = [
				'type'=>'message',
				'product'=>$p[0]->title,
				'message'=>'<a target="_blank" href="'.get_permalinks($p[0]).'">'.$p[0]->title.' ['.$version[0]->title.']:</a> '.$version[0]->message_to_update_user,
				'message_plugin'=>$version[0]->message_to_update_user.'. Xem chi tiết <a target="_blank" href="'.get_permalinks($p[0]).'">tại đây</a>',
				'name'=>'System Vn4CMS',
				'color'=>'red',
				'place'=>['notify','dashboard']
			];
		}
	}

	if( $message ){

		$message = 'Các sản phẩm bạn chưa mua bản quyền: '.$message.' Vui lòng thanh toán Trước khi sử dụng.';

		$message_license_script = str_replace('"', '\"', $message_account.'<hr>'.$message.'<hr> <small><a target="_blank" href="'.route('page','help').'">Xem hướng dẫn</a></small>');

		$result[] = [
			'type'=>'message',
			'message'=>$message,
			'name'=>'System Vn4CMS',
			'color'=>'red',
			'acction_script'=> 'setTimeout (function(){ window.parent.show_message("'.$message_license_script.'"); },2000);',
			// 'avatar'=>'https://www.gravatar.com/avatar/'.md5( strtolower( trim( $user->title ) ) ).'?&s=150',
			'place'=>['notify','dashboard']
		];

	}
	

	$result = array_merge($result,$message_version);


	// }


	return response()->json($result);
});
