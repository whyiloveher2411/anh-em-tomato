<?php
return [
	'general'=>[
		'title'=>'Tổng quan',
		'fields'=>[
			'logo'=>['title'=>'Logo','view'=>'image'],
			'logan'=>['title'=>'Logan'],
			'email-support'=>['title'=>'Email Support'],
		]
	],
	'payment-content'=>[
		'title'=>'Nội dung thanh toán',
		'fields'=>[
			'content'=>[
				'title'=>'Content',
				'view'=>'editor',
			],
			'bank-list'=>[
				'title'=>'Ngân hàng',
				'view'=>'repeater',
				'sub_fields'=>[
					'bank'=>['title'=>'Bank'],
					'number_account'=>['title'=>'Số Tài khoản'],
					'name_account'=>['title'=>'Tên tài khoản'],
					'branch'=>['title'=>'Chi nhánh'],
					'image'=>['title'=>'Logo','view'=>'image'],
				],
			]
		]
	],
	'blogs'=>[
		'title'=>'Trang blogs',
		'fields'=>[
			'title'=>['title'=>'Title','view'=>'text'],
			'description'=>['title'=>'Description','view'=>'textarea'],
			'background'=>['title'=>'Background','view'=>'image'],
			'sidebar'=>['title'=>'Sidebar','view'=>'menu'],
		]
	],
	'document'=>[
		'title'=>'Trang Document',
		'fields'=>[
			'sidebar'=>['title'=>'Sidebar','view'=>'menu'],
		]
	],
	'social-network'=>[
		'title'=>'Social Network',
		'fields'=>[
			'items'=>[
				'title'=>'Items',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title'],
					'icon'=>['title'=>'Class icon (fontawesome)'],
					'link'=>['title'=>'Link']
				]
			]
		]
	]
];