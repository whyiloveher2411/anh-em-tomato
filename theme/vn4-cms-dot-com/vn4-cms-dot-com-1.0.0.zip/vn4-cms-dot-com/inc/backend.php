<?php


add_sidebar_admin(function() {

    $filter['cms'] = [
        'title'=>'CMS.com',
        'icon'=>'fa-themeisle',
        'position'=>100,
        'submenu'=>[
            [
                'title'=>'Blog',
                'submenu'=>[
                    ['title'=>'Post','url'=>route('admin.show_data','cms_blog')],
                    ['title'=>'Category','url'=>route('admin.show_data','cms_blog_category')],
                    ['title'=>'Tag','url'=>route('admin.show_data','cms_blog_tag')],
                ]
            ],
            [
                'title'=>'User',
                'url'=>route('admin.show_data','cms_user')
            ],
            [
                'title'=>'Product',
                'submenu'=>[
                    ['title'=>'Product','url'=>route('admin.show_data','cms_product')],
                    ['title'=>'Product Type','url'=>route('admin.show_data','cms_product_type')],
                    ['title'=>'Category','url'=>route('admin.show_data','cms_product_category')],
                    ['title'=>'Tag','url'=>route('admin.show_data','cms_product_tag')],
                    ['title'=>'Version','url'=>route('admin.show_data','cms_product_version')],
                    ['title'=>'Review','url'=>route('admin.show_data','cms_product_review')],
                    ['title'=>'Comment','url'=>route('admin.show_data','cms_comment')],
                    ['title'=>'Order','url'=>route('admin.show_data','cms_order')],
                    ['title'=>'Project','url'=>route('admin.show_data','cms_project')],
                ]
            ],
            [
                'title'=>'Document',
                'submenu'=>[
                    ['title'=>'Document','url'=>route('admin.show_data','cms_document')],
                    ['title'=>'Category','url'=>route('admin.show_data','cms_document_category')],
                ]
            ],
            [
                'title'=>'Notify',
                'url'=>route('admin.create_and_show_data','cms_notify'),
            ],
            [
                'title'=>'Contact',
                'url'=>route('admin.show_data','cms_contact'),
            ],
            [
                'title'=>'Subscribe',
                'url'=>route('admin.show_data','cms_subscribe'),
            ],


        ]
    ];

    return $filter;

});

