<?php 


register_sidebar([
    'sidebar-left'=>['title'=>'Sidebar Left','description'=>'Vùng hiển thị những thông tin bên trái nội dung chính'],
    'sidebar-righ'=>['title'=>'Sidebar Right','description'=>'Vùng hiển thị những thông tin bên phải nội dung chính'],
]);

register_nav_menus([
    'header'=>'Nav Header',
    'footer'=>'Nav Footer',
    'footer-policy'=>'Nav Footer Policy',
]);

add_action('item-menu',function($param){
    if( !isset($param['menulabel']) ) $param['menulabel'] = '';
    ?>
    <div class="form-group">
        <label class="control-label col-xs-12 in-url">Menu Label (EX: Hot, New)
            <input type="text" class="form-control" name="menulabel" value="<?php echo e($param['menulabel']); ?>" placeholder="">
        </label>
    </div>
    <?php
});