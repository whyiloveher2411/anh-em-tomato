<?php
function check_login_frontend($callback = null, $callback2 = null){

	if( $user = session('user_frontend') ){

		if( $callback ){
			return $callback($user);
		}

		if( $user->active ){
			return $user;
		}else{
			return vn4_redirect(route('page','active-user'));
		}

	}

	if( $callback2 ){
		return $callback2();
	}

	return false;
	
}

function check_user_buy_product($user, $product){

	$orders = $user->related('cms_order','cms_user',['count'=>1,'callback'=>function($q) use ($product){
				return $q->where('product',$product->id);
			}]);

	return isset($orders[0]);

}