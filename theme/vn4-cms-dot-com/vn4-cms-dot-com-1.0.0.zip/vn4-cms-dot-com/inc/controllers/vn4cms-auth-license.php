<?php

if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'index'=>function($r){
		return '<h1 style="text-align: center;">Login</h1><div style="text-align: center;margin-top: 35px;width: 320px;margin: 35px auto;"><input type="username" id="username" placeholder="Username" name="username"><input type="password" id="password" name="password"><input type="submit" class="submit" name="Submit" value="Submit"></div>';
	},
	'post'=>function($r){
		

		$email = $r->get('username');

		$user = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) { return $q->where('title',$email); }]);

		if( !isset($user[0]) ){
			return response()->json(['error'=>true, 'message'=>__t('Email or password is incorrect')]);
		}

		if( !Hash::check( $r->get('password') , $user[0]->password) ){
			return response()->json(['error'=>true, 'message'=>__t('Email or password is incorrect')]);
		}


		return response()->json( [
			'success'=>true,
			'data'=>'<h1 style="text-align: center;">Login</h1><div style="text-align: center;margin-top: 35px;width: 320px;margin: 35px auto;"><p style="text-align: left;color: #8a8a8a;">Secret Key</p><input style="margin-top:5px;" value="'.$user[0]->api_key.'"><p style="text-align: left;color: #8a8a8a;">Token</p><textarea style="margin-top:5px;">'.$user[0]->api_token.'</textarea></div>'
		]);

	}
];