<?php
return [
	'confirm_verification'=>function($r){
		
		$email = $r->get('email');		
		$token = $r->get('token');

		$users = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email, $token){
			return $q->where('title',$email)->where('api_token',$token);
		}]);

		if( isset($users[0]) ){

			$user = $users[0];

			if( $user->active ){
				return redirect()->route('page','profile');
			}else{
				$user->active = '["1"]';
				$user->save();
				$r->session()->forget('user_frontend');

				$r->session()->flash('active_success', 'Xác nhận Email thành công, Chúng tôi sẽ chuyển hướng bạn đến trang đăng nhập và bạn có thể tiếp tục.');

				return redirect()->route('page','active-user-success');
			}
		}

		return redirect()->route('page','login');
	},

	'forgot-password'=>function($r){

		$email = $r->get('email');		
		$token = $r->get('token');
		$key = $r->get('key');

		if( !$email || !$token || !$key ){
			return redirect()->route('page','login');
		}

		$users = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email, $token){
			return $q->where('title',$email)->where('api_token',$token);
		}]);

		if( isset($users[0]) ){

			$user = $users[0];

			$keyUser = $user->getMeta('code_forgot_password');

			if( $key !== $keyUser ){
				return redirect()->route('page','login');
			}

			return theme_view('particle.forgot-password');

		}

		return redirect()->route('page','login');
	}
];