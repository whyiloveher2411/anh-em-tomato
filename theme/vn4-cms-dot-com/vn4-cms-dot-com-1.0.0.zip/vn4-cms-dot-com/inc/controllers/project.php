<?php

return [
	'add'=>function($r){

		return check_login_frontend(function($user) use ($r){


			$product = get_post('cms_product',$r->get('product'));

			if( $product ){
				$projects = $user->related('cms_project','cms_user');

				return response()->json( 
					[
					'html'=>get_particle('particle.popup.popup-add-to-project',['projects'=>$projects, 'product'=>$product])
					]
				);
			}

			return response()->json(['message'=>'Product not found.']);

			

		},function(){
			// return response()->json(['message'=>'Error.']);
		});
		
	},
	'add-product-to-project'=>function($r){

		return check_login_frontend(function($user) use ($r){


			$product = get_post('cms_product',$r->get('product'));
			$project = get_post('cms_project',$r->get('project'));

			if( $project->cms_user != $user->id ){
				return response()->json(['message'=>'The project is not owned by you.']);
			}

			

			if( $product ){

				if( $project->relationship('product',['count'=>true,'callback'=>function($q) use ($product) {
					$q->where('id',$product->id);
				}])){
					return response()->json(['message'=>'You\'ve already added this product to this project, please choose another one.']);
				}

				DB::table('vn4_cms_project_cms_product')->insert([
					'post_id'=>$project->id,
					'tag_id'=>$product->id,
					'field'=>'product',
					'type'=>'cms_product',
				]);

				$project->product = json_encode($project->relationship('product',['select'=>[Vn4Model::$id, 'title', 'slug' ]]));
				$project->save();

				return response()->json(['message'=>'Add Product Success.','action'=>'document.getElementsByClassName(\'popup\')[0].remove()']);

			}

			return response()->json(['message'=>'Product not found.']);

			

		},function(){
			return response()->json(['message'=>'Please login before add product.']);
		});

	}
];