<?php

if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'index'=>function($r){
		$id = $r->get('id');

		$version = get_post('cms_product_version',$id);

		if( !$version ){
			return redirect()->back();
		}

		$product = $version->relationship('product');
		$type = $product->relationship('product_type');

		//Chỉ những sản phẩm có phí mới kiểm tra xem đã mua chưa
		if( $product->price ){

			$user = check_login_frontend();

			if( !$user ) return redirect(route('page',['page'=>'login','payment'=>$version->id]));

			//Sản phẩm không phải người này tạo thì tìm sản phẩm trong order
			//Nếu user chưa mua thì trả về trang login với trạng thái payment
			//Ngược lại cho download bình thường
			if(  $product->cms_user != $user->id && !check_user_buy_product($user, $product) ){
				return redirect(route('page',['page'=>'login','payment'=>$version->id]));
			}

		}

		
		// dd('Cho phep download');
		$url = $version->link_zip;

		// $url = 'http://dev.dna.vn/cms_dev2/public/uploads/json-file.zip';
		// $url = 'https://doc-10-54-docs.googleusercontent.com/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/k6lnovspr4pmjoogoj48653e95go865h/1578384000000/09887797948662264686/*/0B_WQ1wLRqPioOTE3RDZkSEVrWms?e=download';

		$filename = $type->slug.'-'.$product->slug.'-'.$version->title.'.zip';

		$pathToFile = cms_path('public','uploads/temp/'.$filename);

		if (!file_exists(dirname($pathToFile))) {
		    mkdir(dirname($pathToFile), 0777, true);
		}

		if( !file_exists($pathToFile) ){
			$fh = fopen($pathToFile, 'w');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url); 
			curl_setopt($ch, CURLOPT_FILE, $fh); 
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // this will follow redirects
			curl_exec($ch);
			curl_close($ch);
			fclose($fh);
		}

		$headers = array(
	      'Content-Type: application/zip',
	      'Content-Transfer-Encoding: Binary',
	      'Content-length: '.filesize($pathToFile),
	    );

		$product->download_count = $product->download_count + 1;
		$product->save();

		Cache::forget('getPostBySlug_'.$product->type.'##slug##'.$product->slug);

		return Response::download($pathToFile, $filename, $headers);
	}
];