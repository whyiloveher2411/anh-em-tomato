<?php

return [
	'index'=>function($r){
		$r->session()->forget('user_frontend');

		return redirect()->route('page','login');
	}
];