<?php
if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'index'=>function($r){
		return check_login_frontend(function($user) use ($r){

			$id = $r->get('id');
			$message = $r->get('message');
			$message = substr($message, 0, 600);


			$review = get_post('cms_product_review',$id);

			if( !$review ){
				return response()->json(['message'=>__t('Reviews not found.')]);
			}

			$product = $review->relationship('product');

	        if( $product->cms_user !== $user->id && $product->price && !isset( $user->related('cms_order','cms_user',['callback'=>function($q) use ($product){ return $q->where('product',$product->id); }])[0] ) ){
				return response()->json(['message'=>__t('For products with a fee, you can only comment when you have purchased or used the product.')]);
	        }

			$comment = Vn4Model::createPost('cms_comment',['title'=>$user->name.' Comment '.$product->title,'content'=>$message,'cms_user'=>$user->id,'cms_user_detail'=>json_encode(['title'=>$user->title,'name'=>$user->name,'slug'=>$user->slug,'id'=>$user->id,'type'=>'cms_user']) ,'cms_product_review'=>$id]);

			if( $comment ){
				return response()->json(['reload'=>true, 'message'=>__t('Comment successful !.')]);
			}

			return response()->json(['error'=>true,'message'=>__t('Comment failed !.')]);

		},function(){

			return response()->json(['error'=>true,'message'=>__t('Please login before comment!')]);

		});
	}
];
