<?php
if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'index'=>function($r){

		$data = $r->only('fullname','email','subject','message');

			$validate = Validator::make($data, [
	            'fullname'=>'required|max:255','email'=>'required|email|max:255','subject'=>'required','message'=>'required'
	        ],['required' => __t(':attribute is a required field.'),'email'=>__t('Please enter correct email format'),'min'=>__t(':attribute Minimum of 8 characters.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

	        if( $validate->fails() ){
	        	$errors = $validate->errors();
	        	return redirect()->back()->withErrors($errors->getMessages());;
	        }

	        $contact = Vn4Model::createPost('cms_contact',['title'=>$data['fullname'],'email'=>$data['email'],'subject'=>$data['subject'],'message'=>$data['message']]);

	        if($contact){
				return response()->json(['message'=>__t('Send contact successful. Thanking you!'),'redirect'=>route('page','contact')]);
	        }

			return response()->json(['message'=>__t('Failed to send contact.'),'redirect'=>route('page','contact').'#content']);


	}
];