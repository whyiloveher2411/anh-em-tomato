<?php

if( $r->isMethod('GET') ) return redirect()->route('index');

return [
	
	//Đămg nhập
	'login'=>function($r){

		$email = strtolower( $r->get('email') );

		$user = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) { return $q->where('title',$email); }]);

		if( !isset($user[0]) ){
			return response()->json(['message'=>__t('Email or password is incorrect')]);
		}

		if( !Hash::check( $r->get('password') , $user[0]->password) ){
			return response()->json(['message'=>__t('Email or password is incorrect')]);
		}
		session(['user_frontend' => $user[0]]);

		return response()->json(['redirect'=>route('page','login'), 'reload'=>route('page','login').'#content']);

	},

	//Đăng xuất
	'logout'=>function($r){

		$r->session()->forget('user_frontend');

		return response()->json(['redirect'=>route('page','login'), 'reload'=>route('page','login')]);

	},

	//Đăng ký
	'sign-up'=>function($r){
		// dd($r->all());
		$email = strtolower( $r->get('email') );

		$fullname = $r->get('fullname');

		$password = $r->get('password');

		if( isset(get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) { return $q->where('title',$email); }])[0]) ){
			return response()->json(['message'=>__t('Email already exists, please choose another email or forget your password if you don\'t remember your password.')]);
		}

		$send_email_promotion = $r->has('send_email_promotion')?'["1"]':'';

		$user = Vn4Model::createPost('cms_user',['name'=>$fullname,'slug'=>registerSlug($fullname),'title'=>$email, 'send_email_promotion'=>$send_email_promotion,'password'=>Hash::make($password)]);

		$key = "vn4cms_api";

		$api_key = str_random(32);

		$payload = array(
			"key" => $api_key,
		    "email" => $user->title,
		    "id" => $user->id,
		);

		$user->api_key = $api_key;
		$user->api_token = \Firebase\JWT\JWT::encode($payload, $key);

		$user->save();

		Mail::send('default.emails.dynamic', ['content' => get_particle('emails.email-verify',['link'=>route('post',['emails','confirm_verification','email'=>$user->title,'token'=>$user->api_token]),'email'=>$user->title])], function($message) use ($user) {
            $message->from('vn4cms.contact@gmail.com', 'Vn4CMS');
            $message->to($user->title, $user->name)->subject(__t('[Vn4CMS] Verify email address.'));
        });

		session(['user_frontend' => $user]);

		return response()->json(['message'=>__t('Sign Up Success. We have sent you an email, please verify before continuing.'),'redirect'=>route('page','active-user').'#content']);

	},

	//Kiểm tra email đã tồn tại không
	'validate-email'=>function($r){

		$user = session('user_frontend');

		if( $user ){
			if( $user->active ){
				return response()->json(['message'=>__t('User has been authenticated')]);
			}

			Mail::send('default.emails.dynamic', ['content' => get_particle('emails.email-verify',['link'=>route('post',['emails','confirm_verification','email'=>$user->title,'token'=>$user->api_token]),'email'=>$user->title])], function($message) use ($user) {
	            $message->from('vn4cms.contact@gmail.com', 'Vn4CMS');
	            $message->to($user->title, $user->name)->subject(__t('[Vn4CMS] Verify email address.'));
	        });

			return response()->json(['message'=>__t('Send email successful, please check email.')]);
		}

		return response()->json(['redirect'=>route('page','login')]);
	},

	//Quên mật khẩu
	'forgot-password'=>function($r){

		$email = strtolower( $r->get('email') );

		$user = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) {
			return $q->where('title',$email);
		}]);

		if( isset($user[0]) ){

			$user = $user[0];

			$code = str_random(10);

			$user->updateMeta('code_forgot_password',$code);

			Mail::send('default.emails.dynamic', ['content' => get_particle('emails.email-forgot-password',['link'=>route('post',['emails','forgot-password','email'=>$user->title,'token'=>$user->api_token,'key'=>$code]),'email'=>$user->title])], function($message) use ($user) {
	            $message->from('vn4cms.contact@gmail.com', 'Vn4CMS');
	            $message->to($user->title, $user->name)->subject(__t('[Vn4CMS] Reset Password.'));
	        });


			return response()->json(['message'=>__t('Send email successful, please check email.')]);

		}

		return response()->json(['message'=>__t('Search returned no results. Please try again with other information.')]);

	},

	//Đặt lại pass quên mật khẩu
	'new-password'=>function($r){

		$email = strtolower( $r->get('email') );		
		$token = $r->get('token');
		$key = $r->get('key');

		if( !$email || !$token || !$key ){
			return response()->json(['message'=>__t('Error of unknown password change information.')]);
		}

		$users = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email, $token){
			return $q->where('title',$email)->where('api_token',$token);
		}]);

		if( isset($users[0]) ){

			$user = $users[0];

			$keyUser = $user->getMeta('code_forgot_password');

			if( $key !== $keyUser ){
				return response()->json(['message'=>__t('Error of unknown password change information.')]);
			}


			$validate = Validator::make(['newpassword'=>$r->get('newpassword')], [
	            'newpassword'=>'required|min:8|max:255'
	        ],['min'=>__t(':attribute Minimum of 8 characters.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

	        if( $validate->fails() ){
	        	$errors = $validate->errors();
				return response()->json(['message'=>$errors->getMessages()]);
	        }


        	$user->password = Hash::make($r->get('newpassword'));
	        $user->save();	
			$user->updateMeta('code_forgot_password',str_random(20));

			return response()->json(['message'=>__t('Password reset successfully!'),'redirect'=>route('page','login')]);
			

		}

		return response()->json(['message'=>__t('Error of unknown password change information.')]);
	},

	//Chỉnh sử user
	'edit'=>function($r){

		return check_login_frontend(function($user) use ($r){

			$data = $r->only('fullname','newpassword');

			$validate = Validator::make($data, [
	            'fullname'=>'required|max:255','password'=>'min:8|max:255'
	        ],['required' => __t(':attribute is a required field.'),'min'=>__t(':attribute Minimum of 8 characters.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

	        if( $validate->fails() ){
	        	$errors = $validate->errors();
	        	return redirect()->back()->withErrors($errors->getMessages());;
	        }

	        $user->name = $data['fullname'];

	        if( $data['newpassword'] ){
	        	$user->password = Hash::make($data['newpassword']);
	        }

	        $user->save();	

	        return redirect()->back()->with(['success'=>__t('Update successful!')] );

		});	

	},

	//Làm mới token
	'reset-api-tokens'=>function($r){

		return check_login_frontend(function($user){

			$key = "vn4cms_api";

			$api_key = str_random(32);
			$payload = array(
				"key" => $api_key,
			    "email" => $user->title,
			    "id" => $user->id,
			);

			$user->api_key = $api_key;
			$user->api_token = \Firebase\JWT\JWT::encode($payload, $key);

			$user->save();

			return redirect()->back();

		});

	},


	//Create project
	'create-project'=>function($r){

		return check_login_frontend(function($user) use ($r){
			$data = $r->only('title','url');

			$validate = Validator::make($data, [
	            'title'=>'required|max:255','url'=>'required|max:255'
	        ],['required' => __t(':attribute is a required field.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

		 	if( $validate->fails() ){
	        	$errors = $validate->errors();
				return response()->json(['message'=>$errors->getMessages()]);
	        }

	        if (!filter_var($data['url'], FILTER_VALIDATE_URL)) { 
				return response()->json(['message'=>__t('Please enter the correct url format!')]);
			}

			$project = Vn4Model::createPost('cms_project',['title'=>$data['title'],'url'=>$data['url'],'cms_user'=>$user->id]);

			if( $project ){

				$key = "vn4cms_api";

				$api_key = str_random(32);

				$payload = array(
					'project_id'=>$project->id,
					'project_name'=>$project->title,
					'project_url'=>$project->url,
					"key" => $api_key,
				);

				$project->api_key = $api_key;
				$project->api_token = \Firebase\JWT\JWT::encode($payload, $key);

				$project->save();

				return response()->json(['message'=>__t('Create project success'),'redirect'=>route('page',['page'=>'profile-project','project_detail'=>$project->id])]);

			}	

			return response()->json(['message'=>__t('Project creation failed.')]);

		},function(){

			return response()->json(['message'=>__t('Please login before create project!')]);

		});



	}
	
];