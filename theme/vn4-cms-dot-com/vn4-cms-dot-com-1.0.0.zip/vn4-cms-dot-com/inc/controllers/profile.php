<?php

if( $r->isMethod('GET') ) return redirect()->route('index');
return [

	'edit'=>function($r){

		return check_login_frontend(function($user) use ($r){

			$data = $r->only('fullname','newpassword');

			$validate = Validator::make($data, [
	            'fullname'=>'required|max:255','password'=>'min:8|max:255'
	        ],['required' => __t(':attribute is a required field.'),'min'=>__t(':attribute Minimum of 8 characters.'),'max'=>__t(':attribute Maximum of 255 characters.')]);

	        if( $validate->fails() ){
	        	$errors = $validate->errors();
	        	return redirect()->back()->withErrors($errors->getMessages());;
	        }

	        $user->name = $data['fullname'];

	        if( $data['newpassword'] ){
	        	$user->password = Hash::make($data['newpassword']);
	        }

	        $user->save();	

	        return redirect()->back()->with(['success'=>'Update Data success!'] );

		});	

	},
	'reset-api-tokens'=>function($r){

		return check_login_frontend(function($user){

			$key = "vn4cms_api";

			$api_key = str_random(32);
			$payload = array(
				"key" => $api_key,
			    "email" => $user->title,
			    "id" => $user->id,
			);

			$user->api_key = $api_key;
			$user->api_token = \Firebase\JWT\JWT::encode($payload, $key);

			$user->save();

			return redirect()->back();

		});

	}

];