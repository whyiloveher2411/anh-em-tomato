<?php
if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	
	'index'=>function($r){

		return check_login_frontend(function($user) use ($r){

			$type = $r->get('type');
			$id = $r->get('id');

			$rating = $r->get('rating');

			if( $rating > 5 ) $rating = 5;

			if( $rating < 0 ) $rating = 0;

			$title = $r->get('title');
			$title = substr($title, 0, 80);
			$message = $r->get('message');
			$message = substr($message, 0, 600);

			$product = get_post('cms_product',$id);

			if( !$product ){
				return response()->json(['message'=>__t('Product not found.')]);
			}

			if( $product->cms_user == $user->id ){
				return response()->json(['message'=>__t('You cannot evaluate products created by yourself.')]);
	        }

	        if( $product->price && !isset( $user->related('cms_order','cms_user',['callback'=>function($q) use ($product){ return $q->where('product',$product->id); }])[0] ) ){
				return response()->json(['message'=>__t('For products with a fee, you are only evaluated when you have purchased or used the product.')]);
	        }

	        $review = $user->related('cms_product_review','cms_user',['count'=>true,'callback'=>function($q) use ($id) {
	                                        return $q->where('product',$id);
	                                    }]);

	        if( $review ){
				return response()->json(['message'=>__t('You have already rated this product.')]);
			}

			$review = Vn4Model::createPost('cms_product_review',['title'=>$title,'rating'=>$rating,'message'=>$message,'cms_user'=>$user->id,'cms_user_detail'=>json_encode(['title'=>$user->title,'name'=>$user->name,'slug'=>$user->slug,'id'=>$user->id,'type'=>'cms_user']) ,'product'=>$id]);

			if( $review ){
				return response()->json(['redirect'=>get_permalinks($product).'#reviews', 'message'=>__t('Review success.')]);
			}

			return response()->json(['error'=>true,'message'=>__t('Evaluation failed.')]);

		},function(){

			return response()->json(['error'=>true,'message'=>__t('Please login before rating')]);

		});

	}

];