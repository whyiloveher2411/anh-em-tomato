<?php
if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'index'=>function($r){
		$form = $r->get('form-type');

		$email = $r->get('email');

		if( $form === 'sign-up' ){

			$fullname = $r->get('fullname');
			$password = $r->get('password');

			if( isset(get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) { return $q->where('title',$email); }])[0]) ){
				return response()->json(['message'=>'Email đã tồn tại, vui lòng chọn email khác hoặc quên mật khẩu.']);
			}

			$user = Vn4Model::createPost('cms_user',['name'=>$fullname,'slug'=>registerSlug($fullname),'title'=>$email,'password'=>Hash::make($password)]);

			$key = "vn4cms_api";

			$api_key = str_random(32);
			$payload = array(
				"key" => $api_key,
			    "email" => $user->title,
			    "id" => $user->id,
			);

			$user->api_key = $api_key;
			$user->api_token = \Firebase\JWT\JWT::encode($payload, $key);

			$user->save();


			return response()->json(['message'=>'Đăng ký thành công','redirect'=>route('page','login').'#content']);

		}elseif( $form === 'login' ){

			$user = get_posts('cms_user',['count'=>1,'callback'=>function($q) use ($email) { return $q->where('title',$email); }]);

			if( !isset($user[0]) ){
				return response()->json(['message'=>'Email hoặc password không đúng']);
			}

			if( !Hash::check( $r->get('password') , $user[0]->password) ){
				return response()->json(['message'=>'Email hoặc password không đúng']);
			}
			session(['user_frontend' => $user[0]]);

			return response()->json(['redirect'=>route('page','login').'#content']);

		}elseif( $form === 'logout' ){
			$r->session()->forget('user_frontend');

			return response()->json(['redirect'=>route('page','login').'#content']);
		}

		return response()->json(['message'=>'Error']);
	}
];