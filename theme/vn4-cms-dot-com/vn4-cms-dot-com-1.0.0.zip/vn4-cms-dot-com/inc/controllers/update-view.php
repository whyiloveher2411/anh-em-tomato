<?php 

return [
	'product'=>function($r){

		$plugins = get_posts('cms_product',10000);

		foreach ($plugins as $key => $value) {

			$rating = $value->related('cms_product_review','product',['count'=>100000]);

			$value->rating_count = $rating->count();
			$value->rate = $rating->avg('rating')??0;

			$value->save();

			Cache::forget('getPostBySlug_'.$value->type.'##slug##'.$value->slug);

		}


		$reviews = get_posts('cms_product_review',10000);
		
		foreach ($reviews as $review) {

			$comment = $review->related('cms_comment','cms_product_review');

			if( !isset($comment[0]) ){
				$count_voice = 1;
				$count_reply = 0;
			}else{
				$users = $comment->groupBy('cms_user');

				if( isset($users[$review->cms_user]) ){
					$count_voice = count($users);
				}else{
					$count_voice = count($users) + 1;
				}

				$count_reply = count($comment);
			}

			$review->count_voice = $count_voice;
			$review->count_reply = $count_reply;
			$review->save();
		}
		die('Done');
	},

	'user'=>function($r){

		$plugins = get_posts('cms_product',10000)->groupBy('cms_user');

		foreach ($plugins as $userID => $products) {
			
			$user = get_post('cms_user',$userID);

			if( $user ){	

				$reviews = get_posts('cms_product_review',['count'=>100000,'callback'=>function($q) use ($products){
					return $q->whereIn('product',$products->pluck(Vn4Model::$id));
				}]);

				$user->rating_count = $reviews->avg('rating');

				$user->save();

				Cache::forget('getPostBySlug_'.$user->type.'##slug##'.$user->slug);
			}

		}

		die('Done');

	}
];