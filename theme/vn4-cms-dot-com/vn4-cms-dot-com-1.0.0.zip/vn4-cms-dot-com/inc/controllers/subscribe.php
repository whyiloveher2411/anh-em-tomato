<?php
if( $r->isMethod('GET') ) return redirect()->route('index');
return [
	'post'=>function($r){
		$subscribe = $r->get('email');

		if( !$subscribe ){
			return response()->json(['message'=>__t('Please enter email')]);
		}

		$checkSubscribe = get_posts('cms_subscribe',['count'=>1,'callback'=>function($q) use ($subscribe) {
			return $q->where('title',$subscribe);
		}]);

		if( isset($checkSubscribe[0]) ){
			return response()->json(['message'=>__t('This email has been registered before, please choose another email.')]);
		}

		$user = Vn4Model::createPost('cms_subscribe',['title'=>$subscribe]);

		return response()->json(['message'=>__t('Sign Up Success!')]);

	}
];