<?php
return [

	'page.home'=> [
		'title'=>'Home Page',
		'fields'=>[
			'banner'=>[
				'title'=>'Banner',
				'view'=>'group',
				'sub_fields'=>[
					'title'=>[
						'title'=>'Title'
					],
					'description'=>[
						'title'=>'Description',
						'view'=>'textarea'
					],
					'background'=>[
						'title'=>'Background',
						'view'=>'image'
					]
				]
			],
			'section'=>[
				'title'=>'Section',
				'view'=>'flexible',
				'templates'=>[
					'promo-1'=>[
						'title'=>'Promo #1 (Features)',
						'items'=>[
							'title'=>[
								'title'=>'Title'
							],
							'description'=>[
								'title'=>'Description',
								'view'=>'textarea',
							],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'layout'=>'block',
								'sub_fields'=>[
									'title'=>['title'=>'Title'],
									'description'=>['title'=>'Description','view'=>'textarea'],
									'icon'=>['title'=>'Icon']
								]
							]
						]
					],
					'promo-2'=>[
						'title'=>'Promo #2 (Give it a try)',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'label-button'=>['title'=>'Label Button'],
							'link'=>['title'=>'Link'],
							'image'=>['title'=>'Image','view'=>'image']
						]
					],
					'promo-3'=>[
						'title'=>'Promo #3 (Logan)',
						'layout'=>'block',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'label-button'=>['title'=>'Label Button'],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'sub_fields'=>[
									'title'=>['title'=>'title'],
									'description'=>['title'=>'Description','view'=>'textarea'],
									'link'=>['title'=>'Link'],
									'image'=>['title'=>'Image','view'=>'image']
								]
							],
						]
					],
					'promo-4'=>[
						'title'=>'Promo #4 (Video)',
						'items'=>[
							'background'=>['title'=>'Background','view'=>'image'],
							'link'=>['title'=>'Link'],
						]
					],
					'promo-5'=>[
						'title'=>'Promo #5 (Our Plans)',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'layout'=>'block',
								'sub_fields'=>[
									'title'=>['title'=>'Title'],
									'price'=>['title'=>'Price'],
									'contens'=>[
										'title'=>'Contens',
										'view'=>'repeater',
										'sub_fields'=>[
											'title'=>['title'=>'Title']
										]
									]
								]
							],
						]
					],
					'promo-6'=>[
						'title'=>'Promo #6 (My Team)',
						'items'=>[
							'title'=>['title'=>'Title'],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'sub_fields'=>[
									'name'=>['title'=>'Name'],
									'description'=>['title'=>'Description','view'=>'textarea'],
									'avatar'=>['title'=>'Avatar','view'=>'image']
								]
							],
						]
					],
					'promo-7'=>[
						'title'=>'Promo #7 (Brand)',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'layout'=>'block',
								'sub_fields'=>[
									'title'=>['title'=>'Title'],
									'logo'=>['title'=>'Logo','view'=>'image'],
									'link'=>['title'=>'Link'],
								]
							],
						]
					],
					'promo-8'=>[
						'title'=>'Promo #8 (Get Free)',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'label-button'=>['title'=>'Label Button'],
							'link'=>['title'=>'Link','view'=>'link'],
						]
					],
					'promo-9'=>[
						'title'=>'Promo #9 (FAQ)',
						'layout'=>'block',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'label-button'=>['title'=>'Label Button'],
							'link'=>['title'=>'Link','view'=>'link'],
							'items'=>[
								'title'=>'Items',
								'view'=>'repeater',
								'sub_fields'=>[
									'title'=>['title'=>'Title'],
									'description'=>['title'=>'Description','view'=>'textarea'],
								]
							],
						]
					],
				]
			],
		]
	],
	'page.blogs'=>[
		'title'=>'Blogs Page',
		'fields'=>[
			'title'=>[
				'title'=>'Title',
			],
			'description'=>[
				'title'=>'Description',
				'view'=>'textarea'
			],
			'background'=>[
				'title'=>'Background',
				'view'=>'image'
			],
			'sidebar'=>[
				'title'=>'Sidebar',
				'view'=>'menu',
			]
		]
	],
	
	'page'=>[
		'templates'=>['features','about','faq'],
		'title'=>'Banner',
		'fields'=>[
			'banner_title'=>['title'=>'Title'],
			'banner_description'=>['title'=>'Description','view'=>'textarea']
		]
	],
	'page.faq'=>[
		'title'=>'FAQ Page',
		'fields'=>[
			'category'=>[
				'title'=>'Category',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title'],
					'qa'=>[
						'title'=>'Question And Anwser',
						'view'=>'repeater',
						'sub_fields'=>[
							'question'=>['title'=>'Question'],
							'anwser'=>['title'=>'Anwser','view'=>'textarea'],
						]
					]
				]
			],
		]
	],
	'page.features'=>[
		'title'=>'Features',
		'fields'=>[
			'features'=>[
				'title'=>'Features',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title'],
					'description'=>['title'=>'Description','view'=>'textarea'],
					'link'=>['title'=>'Link','view'=>'link']
				]
			],
		]
	],
	'page.contact'=>[
		'title'=>'Contacts Info',
		'fields'=>[
			'contacts-info'=>[
				'title'=>'Contacts Info',
				'view'=>'repeater',
				'sub_fields'=>[
					'title'=>['title'=>'Title'],
					'description'=>['title'=>'Description','view'=>'textarea'],
					'emails'=>['title'=>'Emails','view'=>'repeater','sub_fields'=>['email'=>['title'=>'Email']]]
				]
			],
		]
	],
	'page.about'=>[
		'title'=>'About',
		'fields'=>[
			'section'=>[
				'title'=>'Section',
				'view'=>'flexible',
				'templates'=>[
					'our-vision'=>[
						'title'=>'Our vision',
						'items'=>[
							'title'=>['title'=>'Title'],
							'content'=>['title'=>'Content','view'=>'textarea'],
						]
					],
					'what-we-do'=>[
						'title'=>'What we do',
						'items'=>[
							'title'=>['title'=>'Title'],
							'content'=>['title'=>'Content','view'=>'repeater','sub_fields'=>['title'=>['title'=>'Title'],'description'=>['title'=>'Description','view'=>'textarea'],'image'=>['title'=>'Image','view'=>'image','width'=>555,'height'=>485]]],
						]
					],
					'our-team'=>[
						'title'=>'Our Team',
						'layout'=>'block',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'content'=>['title'=>'Content','view'=>'repeater','sub_fields'=>['name'=>['title'=>'Name'],'description'=>['title'=>'Description','view'=>'textarea'],'avatar'=>['title'=>'Avatar','view'=>'image']]],
						]
					],
					'brands'=>[
						'title'=>'Brands',
						'items'=>[
							'title'=>['title'=>'Title'],
							'description'=>['title'=>'Description','view'=>'textarea'],
							'content'=>['title'=>'Content','view'=>'repeater','sub_fields'=>['name'=>['title'=>'Name'],'logo'=>['title'=>'Logo','view'=>'image']]],
						]
					]
					
				]
			],
		]
	]
	// 'page.home'=>[
	// 	'title'=>[
	// 		'title'=>'Title'
	// 	],
	// 	'description'=>[
	// 		'title'=>'Description',
	// 		'view'=>'textarea'
	// 	]
	// ],
	// 'page.template-demo'=>[
	// 	'title'=>[
	// 		'title'=>'Title Template Demo'
	// 	]
	// ]
	
];