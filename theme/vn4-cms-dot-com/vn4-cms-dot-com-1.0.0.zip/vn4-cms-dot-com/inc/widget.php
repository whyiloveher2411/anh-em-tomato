<?php
// return [
// 	'wiget-theme'=>[
// 		'title'=>'Widget By Vn4CMS',
// 		'description'=>'Widget Create By Theme Vn4CMS dot Com',
// 		'fields'=>[
// 			'content'=>[
// 				'title'=>'Content',
// 				'view'=>'editor',
// 			]
// 		],
// 	 	'show'=>function($data){
// 	 		return $data->get_data('content');
//       	}
// 	]
// ];