<?php

return [
	'theme'=>['title'=>'Theme','callback'=>function( $searchArray, $searchString ) use ($plugin){
		return [
			[
				'title_type'=>'Theme',
				'title'=>'Update Reviews Product',
				'link'=>route('post',['update-view','reviews']),
			],
			[
				'title_type'=>'Theme',
				'title'=>'Update Rating Product',
				'link'=>route('post',['update-view','index']),
			],
		];
		

	}]
];