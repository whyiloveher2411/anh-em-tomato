@extends(theme_extends())

<?php 
	title_head('Home');
 ?>

@section('content')
<div class="header-back header-back-default header-back-full-page js-full-page">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info helper center">
                        <h1 class="page-title">Learn. Create. Impress.</h1>
                        <h2 class="page-description">We are not looking for perfection, we started from there</h2>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

 <div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Promo Title -->
                <div class="promo-title-wrapper helper pt60">
                    <h3 class="promo-title" data-icon="">
                        Features
                    </h3>
                    <p class="promo-description">
                        Hệ thống chức năng được chỉnh sửa phù hợp với từng loại website blogs, Ecommerce, landing page, campaign, giới thiệu công ty,... hệ thống plugin đa dạng, chỉnh sữa dễ dàng.
                    </p>
                </div>
                <!-- End of Promo Title -->
                <div class="row">
                    <div class="col-md-6">
                        <!-- Box -->
                        <div class="box box-small-icon-alt">
                            <i class="pe-7s-plugin box-icon"></i>
                            <h4 class="box-title">Plugin</h4>
                            <p class="box-description">Hệ thống chia thành nhiều chức năng với cấu trúc đơn giản, dễ dàng trong chỉnh sữa và mở rộng sau này.</p>
                        </div>
                        <!-- End of Box -->
                    </div>
                    <div class="col-md-6">
                        <!-- Box -->
                        <div class="box box-small-icon-alt">
                            <i class="pe-7s-help1 box-icon"></i>
                            <h4 class="box-title">Support 24/7</h4>
                            <p class="box-description">Hệ thống support sẽ được update liên tục 24/7. Bất kì lỗi nào của website sẽ được sữa chữa sớm nhất và update lại cho hệ thống của khách hàng.</p>
                        </div>
                        <!-- End of Box -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <!-- Box -->
                        <div class="box box-small-icon-alt">
                            <i class="pe-7s-tools box-icon"></i>
                            <h4 class="box-title">Customization</h4>
                            <p class="box-description">Người dùng túy ý chỉnh sữa phù hợp với nhu cầu từng khách hàng, nếu có yêu cầu thêm đừng ngần ngại liên hệ với chúng tôi.</p>
                        </div>
                        <!-- End of Box -->
                    </div>
                    <div class="col-md-6">
                        <!-- Box -->
                        <div class="box box-small-icon-alt">
                            <i class="pe-7s-cup box-icon"></i>
                            <h4 class="box-title">Premium</h4>
                            <p class="box-description">Với gói dịch vụ cao cấp, hệ thống sẽ miễn phí hoàn toàn plugin cài thêm mà khách hàng không cần phải trả thêm bất kì khoản phí nào.</p>
                        </div>
                        <!-- End of Box -->
                    </div>
                </div>
                <!--  Promo Title
               <div class="promo-title-wrapper ">
                   <h3 class="promo-title" data-icon="">
                       How it works
                   </h3>
                   <p class="promo-description">
                       Fugit impedit ea eveniet ullam distinctio et quisquam nam laudantium nemo cumque consequuntur magni quis unde voluptates velit temporibus, blanditiis, laboriosam minima.
                   </p>
               </div>
               End of Promo Title
               <div class="row">
                   <div class="col-md-2"></div>
                   <div class="col-md-8 col-sm-12">
                       <div class="code-highlight ">
                           <span class="js-copy-to-clipboard copy-code">copy</span>
                           <pre class=" language-javascript"><code class=" js-code language-javascript"><span class="token keyword">var</span> InteractiveSteps <span class="token operator">=</span> <span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">{</span>
                <span class="token keyword">var</span> steps <span class="token operator">=</span> <span class="token function">$</span><span class="token punctuation">(</span><span class="token string">'.js-steps-interactive'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
               
                steps<span class="token punctuation">.</span><span class="token function">each</span><span class="token punctuation">(</span><span class="token keyword">function</span><span class="token punctuation">(</span><span class="token punctuation">)</span> <span class="token punctuation">{</span>
                    <span class="token keyword">var</span> step <span class="token operator">=</span> <span class="token function">$</span><span class="token punctuation">(</span><span class="token keyword">this</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
                    <span class="token keyword">var</span> config <span class="token operator">=</span> config <span class="token operator">=</span> <span class="token punctuation">{</span>
                        headerTag<span class="token punctuation">:</span> <span class="token string">"h4"</span><span class="token punctuation">,</span>
                        transitionEffect<span class="token punctuation">:</span> <span class="token string">"fade"</span><span class="token punctuation">,</span>
                        labels<span class="token punctuation">:</span> <span class="token punctuation">{</span>
                            current<span class="token punctuation">:</span> <span class="token string">''</span>
                        <span class="token punctuation">}</span>
                    <span class="token punctuation">}</span>
                    <span class="token keyword">var</span> userConfig <span class="token operator">=</span> step<span class="token punctuation">.</span><span class="token function">data</span><span class="token punctuation">(</span><span class="token string">'config'</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
               
                    $<span class="token punctuation">.</span><span class="token function">extend</span><span class="token punctuation">(</span><span class="token keyword">true</span><span class="token punctuation">,</span> config<span class="token punctuation">,</span> userConfig<span class="token punctuation">)</span><span class="token punctuation">;</span>
                    steps<span class="token punctuation">.</span><span class="token function">steps</span><span class="token punctuation">(</span>config<span class="token punctuation">)</span><span class="token punctuation">;</span>
                <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
               <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
               </code></pre>
                       </div>
                   </div>
               </div> -->
            </div>
        </div>
    </div>
    <div class="background-gradient-grey">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Promo Title -->
                    <div class="promo-title-wrapper ">
                        <h3 class="promo-title" data-icon="">
                            Give it a try
                        </h3>
                        <p class="promo-description">
                            Đăng ký để dùng thử sản phẩm, trãi nghiệm những tính năng mà chúng tôi đưa ra cho bạn hoàn toàn miễn phí. Sẵn sàng update lên bản trả phí mà không cần phải update lại thông tin đã config.
                        </p>
                    </div>
                    <!-- End of Promo Title -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="helper center mb60">
                        <a href="#" class="btn-open-purchase reguest-demo-button button blue stroke rounded button-icon button-icon-right">
                            request demo
                            <i class="fa fa-angle-right"></i>
                        </a>
                    </div>
                    <div class="helper center pb60">
                        <img src="@theme_asset()img/4.png" class="image remove-border" alt="macbook and a clock">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Promo Title -->
                <div class="promo-title-wrapper ">
                    <h3 class="promo-title" data-icon="">
                        We are not looking for perfection, we started from there
                    </h3>
                    <p class="promo-description">
                        Always bring the best for the user, Beautiful designs, powerful features, and the freedom to build anything you want.
                    </p>
                </div>
                <!-- End of Promo Title -->
                <!-- Featured Boxes -->
                <ul class="featured-boxes">
                    <li class="featured-boxes-item">
                        <img src="@theme_asset()img/7.png" class="featured-boxes-item-ico" alt="featured-boxes image">
                        <h5 class="featured-boxes-item-pretitle">more</h5>
                        <h4 class="featured-boxes-item-title">Flexibility</h4>
                        <p class="featured-boxes-item-description">Linh động với từng loại website, linh động với túi tiền mà không lo sợ thếu chức năng hoặc không có người support khi gặp sự cố</p>
                        <a href="#" class="featured-boxes-item-button button blue stroke rounded">
                            Learn more
                        </a>
                    </li>
                    <li class="featured-boxes-item">
                        <img src="@theme_asset()img/8.png" class="featured-boxes-item-ico" alt="featured-boxes image">
                        <h5 class="featured-boxes-item-pretitle">more</h5>
                        <h4 class="featured-boxes-item-title">Simplicity</h4>
                        <p class="featured-boxes-item-description">Đơn giản và hiệu quả, luôn luôn thay đổi để bắt kịp xu thế công nghệ. Đơn giản cho người muốn học và nắm bắt hệ thống.</p>
                        <a href="#" class="featured-boxes-item-button button blue stroke rounded">
                            Learn more
                        </a>
                    </li>
                    <li class="featured-boxes-item">
                        <img src="@theme_asset()img/9.png" class="featured-boxes-item-ico" alt="featured-boxes image">
                        <h5 class="featured-boxes-item-pretitle">less</h5>
                        <h4 class="featured-boxes-item-title">Confusion</h4>
                        <p class="featured-boxes-item-description">Sự thành công của bạn là niềm động lực giúp chúng tôi thay đổi sản phẩm từng ngày với hệ thống plugin đa dạng và ngày càng mở rộng.</p>
                        <a href="#" class="featured-boxes-item-button button blue stroke rounded">
                            Learn more
                        </a>
                    </li>
                </ul>
                <!-- End of Featured Boxes -->
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <!-- Video section -->
                <div class="video-section video-section-fullwidth ">
                    <img src="@theme_asset()img/play-dark.png" alt="" class="video-section-button-img js-video-trigger" data-video="&lt;iframe src=&quot;https://player.vimeo.com/video/37760134?autoplay=1&quot; width=&quot;500&quot; height=&quot;510&quot; frameborder=&quot;0&quot; webkitallowfullscreen mozallowfullscreen allowfullscreen&gt;&lt;/iframe&gt;">
                </div>
                <!-- Endd  of Video section -->
                <!-- Video Trigger Modal -->
                <div class="js-video-trigger-modal video-trigger-modal">
                    <div class="js-video-trigger-modal-content video-trigger-modal-content"></div>
                </div>
                <!-- End of Video Trigger Modal -->
            </div>
        </div>
    </div>
    <div class="container section-our-plan">
        <div class="row">
            <div class="col-md-12">
                <!-- Promo Title -->
                <div class="promo-title-wrapper ">
                    <h3 class="promo-title" data-icon="">
                        Our Plans
                    </h3>
                    <p class="promo-description">
                        Chúng tôi cũng cấp các gói dịch vụ phù hợp với từng loại yêu cầu và túi tiền của bạn. Nếu bạn có bất kì yêu cầu gì thêm, xin vui lòng liên hệ với chung tôi bằng form bên dưới, chúng tôi sẽ liên lạc với bạn trong thời gian sớm nhất.
                    </p>
                </div>
                <!-- End of Promo Title -->
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <!-- Price List -->
                        <div class="price-list">
                            <h3 class="price-list-title">Free</h3>
                            <p class="price-list-price">$0<span class="price-list-price-units">/mo</span></p>
                            <ul class="price-list-features">
                                <li class="price-list-feature-item ">
                                    Đầy đủ chức năng VN4CMS
                                </li>
                                <li class="price-list-feature-item ">
                                    Sử dụng sub domain của vn4cms
                                </li>
                                <li class="price-list-feature-item ">
                                    Cài đặt plugin miễn phí
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                            </ul>
                            <a href="#" class="price-list-button">Select Plan</a>
                        </div>
                        <!-- End of Price List -->
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <!-- Price List -->
                        <div class="price-list">
                            <h3 class="price-list-title">Standard</h3>
                            <p class="price-list-price">$10<span class="price-list-price-units">/mo</span></p>
                            <ul class="price-list-features">
                                <li class="price-list-feature-item ">
                                    Đầy đủ chức năng VN4CMS
                                </li>
                                <li class="price-list-feature-item ">
                                    Sử dụng domain riêng của khách hàng
                                </li>
                                <li class="price-list-feature-item ">
                                    Hosting lưu trữ 2GB+
                                </li>
                                <li class="price-list-feature-item ">
                                    Cài đặt đầy đủ plugin khi mới bắt đầu
                                </li>
                                <li class="price-list-feature-item ">
                                    Hỗ trợ cài đặt ban đầu
                                </li>
                                <li class="price-list-feature-item ">
                                    Support 2h/Tháng
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                                <li class="price-list-feature-item feature-is-disabled">
                                </li>
                            </ul>
                            <a href="#" class="price-list-button">Select Plan</a>
                        </div>
                        <!-- End of Price List -->
                    </div>
                    <div class="col-md-4 col-sm-6 col-sm-offset-3 col-md-offset-0">
                        <!-- Price List -->
                        <div class="price-list">
                            <h3 class="price-list-title">Pro</h3>
                            <p class="price-list-price">$29<span class="price-list-price-units">/mo</span></p>
                            <ul class="price-list-features">
                                <li class="price-list-feature-item ">
                                    Đầy đủ chức năng VN4CMS
                                </li>
                                <li class="price-list-feature-item ">
                                    Sử dụng domain riêng của khách hàng
                                </li>
                                <li class="price-list-feature-item ">
                                    Hosting lưu trữ 5GB+
                                </li>
                                <li class="price-list-feature-item ">
                                    Cài đặt đầy đủ plugin khi mới bắt đầu
                                </li>
                                <li class="price-list-feature-item ">
                                    Miễn phí tất cả plugin cài đặt thêm
                                </li>
                                <li class="price-list-feature-item ">
                                    Hỗ trợ cài đặt ban đầu
                                </li>
                                <li class="price-list-feature-item ">
                                    Hỗ trợ cập nhật nội dung 6 tháng
                                </li>
                                <li class="price-list-feature-item ">
                                    Training
                                </li>
                                <li class="price-list-feature-item ">
                                    Support 24/7
                                </li>
                            </ul>
                            <a href="#" class="price-list-button">Select Plan</a>
                        </div>
                        <!-- End of Price List -->
                    </div>
                </div>
                <!-- Promo Title -->
                <div class="promo-title-wrapper ">
                    <h3 class="promo-title" data-icon="">
                        CoFounders
                    </h3>
                    <!-- <p class="promo-description">
                        Reiciendis quasi ipsum, expedita soluta hic, minima voluptates deserunt odio temporibus obcaecati amet, culpa vel. Beatae, quisquam!
                    </p> -->
                </div>
                <!-- End of Promo Title -->
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <!-- Testimonials -->
                        <div class="testimonial">
                            <div class="testimonial-photo-wrapper">
                                <img src="@theme_asset()img/quan.jpg" class="testimonial-photo" alt="Person&#39;s Photo">
                            </div>
                            <h4 class="testimonial-name">Đặng Thuyền Quân</h4>
                            <p class="testimonial-text">Lập trình viên, lập trình và phát triển hệ thống. Marketing định hướng và lập kế hoạch.</p>
                        </div>
                        <!-- End of Testimonials -->
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <!-- Testimonials -->
                        <div class="testimonial">
                            <div class="testimonial-photo-wrapper">
                                <img src="@theme_asset()img/vuong.jpg" class="testimonial-photo" alt="Person&#39;s Photo">
                            </div>
                            <h4 class="testimonial-name">Đặng Thuyền Vương</h4>
                            <p class="testimonial-text">Lập trình viên website + mobile, UX/UI. Marketing định hướng và lập kế hoạch.</p>
                        </div>
                        <!-- End of Testimonials -->
                    </div>
                </div>
                <!-- Promo Title -->
                <div class="promo-title-wrapper ">
                    <h3 class="promo-title" data-icon="">
                        Brands using my services
                    </h3>
                    <p class="promo-description">
                        Cám ơn những khách hàng đã sử dụng dịch vụ của chúng tôi. Hệ thống của chúng tôi luôn lấy sự hài lòng của khách hàng làm trọng tâm cho sự thay đổi và phát triển sau này.
                    </p>
                </div>
                <!-- End of Promo Title -->
                <!-- Brands -->
                <ul class="brands ">
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/bluestone.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/dna.svg" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/hanwalife.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/kewpie.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/shinhan.svg" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/vivo.svg" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/tuongan.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/yakult.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/kymco.png" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/betrimex.svg" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                    <li class="brand-item">
                        <a href="#" class="brand-item-link">
                            <img src="@theme_asset()img/brand/puma.svg" class="brand-item-image" alt="brand logo">
                        </a>
                    </li>
                </ul>
                <!-- End of Brands -->
            </div>
        </div>
    </div>
    <!-- Call to Action -->
    <div class="call-to-action helper mt60">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="call-to-action-title">
                        Got a minute? Join us, it's free!
                    </h3>
                    <p class="call-to-action-description">
                        Dùng thử sản phẩm để trãi nghiệm và đưa ra quyết định làm việc chuyên nghiệp với VN4CMS
                    </p>
                    <div class="call-to-action-buttons">
                        <a href="#" class="call-to-action-button">Get Started</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End of Call to Action -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Promo Title -->
                <div class="promo-title-wrapper promo-title-no-icon">
                    <h3 class="promo-title" data-icon="">
                        FAQ
                    </h3>
                    <p class="promo-description">
                        Những câu hỏi thường gặp mà mọi người thường mắc phải. Nếu bạn có bất cứ câu hỏi nào khác lạ, đừng ngại ngần mà đặt câu hỏi với chung tôi. Chúng tôi sẽ trả lời bạn trong thời gian sớm nhất có thể.
                    </p>
                </div>
                <!-- End of Promo Title -->
                <div class="row">
                    <div class="col-md-4">
                        <!-- FAQ Grid -->
                        <div class="faq-grid">
                            <h4 class="faq-grid-question">How do install VN4CMS</h4>
                            <p class="faq-grid-answer">Bạn có thể tải bản trực tiếp từ website rồi tiến hành config từ website, mọi việc rất đơn giản.</p>
                        </div>
                        <!-- End of FAQ Grid -->
                    </div>
                    <div class="col-md-4">
                        <!-- FAQ Grid -->
                        <div class="faq-grid">
                            <h4 class="faq-grid-question">How do I request a feature?</h4>
                            <p class="faq-grid-answer">Bạn có thể chọn lựa plugin có sẵn trực tiếp từ marketplace có phí hoặc không có phí, đối với dịch vụ PRO bạn hoàn toàn có thể yên tâm cài đặt mà không cần tốn thêm bất kì khoản phí nào. Đối với feature chúng tôi chưa có, bạn có thể liên hệ với chúng tôi để đặt yêu cầu riêng.</p>
                        </div>
                        <!-- End of FAQ Grid -->
                    </div>
                    <div class="col-md-4">
                        <!-- FAQ Grid -->
                        <div class="faq-grid">
                            <h4 class="faq-grid-question">How do I update?</h4>
                            <p class="faq-grid-answer">Bạn có thể vào CMS vào mục update và nhấn vào nút update, hệ thống sẽ tự động update code mới nhất cho hệ thống của bạn.</p>
                        </div>
                        <!-- End of FAQ Grid -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="helper center">
                            <a href="#" class="faq-grid-show-more">View all <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
	
@stop