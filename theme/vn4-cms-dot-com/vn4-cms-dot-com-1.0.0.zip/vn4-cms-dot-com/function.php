<?php
register_post_type(function($list_post_type){

	$add_object = [];
	
	$add_object[] = [
			'cms_blog_category',
	    	1,
			[
		    'table'=>'cms_blog_category',
		    'title'=> __('CMS Blog Category'),
		    'slug'=>'blog-category',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
		        'parent' => [
		            'title'=>__('Parent'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>false,
		            'object'=>'cms_blog_category',
		            'fields_related'=>['title'],
		            'note'=>'Chuyên mục khác với thẻ, bạn có thể sử dụng nhiều cấp chuyên mục. Ví dụ: Trong chuyên mục nhạc, bạn có chuyên mục con là nhạc Pop, nhạc Jazz. Việc này hoàn toàn là tùy theo ý bạn.',
		        ],
			]
		]
	];


	$add_object[] =  [
			'cms_blog_tag',
	    	1,
	    	[
		    'table'=>'cms_blog_tag',
		    'title'=> __('CMS Blog Tag'),
		    'slug'=>'blog-tag',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		    ]
	    ],
	];

	$add_object[] = [
			'cms_blog',
	    	1,
			[
		    'table'=>'cms_blog',
		    'title'=> __('CMS Blog'),
		    'slug'=>'blog',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
		        'content' => [
		            'title'=>__('Content'),
		            'view' =>'editor',
		            'show_data'=>false,
		            'required'=>true,
		        ],
		        'cms_user'=>[
		        	'title'=>'Author',
		        	'view'=>'relationship_onetomany',
		        	'type'=>'many_record',
		        	'object'=>'cms_user',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		            'show_data'=>false,
		        ],
		         'category' => [
		            'title'=>__('Category'),
		            'view' =>'relationship_manytomany',
		            'show_data'=>true,
		            'object'=>'cms_blog_category',
		            'advance'=>'right',
		        ],
		        'tag' => [
		            'title'=>__('Tag'),
		            'view' =>'relationship_manytomany',
		            'type'=>'tags',
		            'show_data'=>true,
		            'object'=>'cms_blog_tag',
		            'advance'=>'right',
		        ],
		        'image' => [
		            'title'=>__('Featured Image'),
		            'view' =>'image',
		            'required'=>true,
		            'show_data'=>false,
		            'advance'=>'right',
		            'note'=>'featured image is the way it appears on your website'
		        ],
		    ],
		]
	];



	// Author
	$add_object[] = [
			'cms_user',
	    	1,
			[
		    'table'=>'cms_user',
		    'slug'=>'account',
		    'title'=> __t('CMS User'),
		    'fields'=>[
		        'title'=>[
		            'title'=>'Email',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'name'=>[
		            'title'=>'name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'name',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description'=>[
		        	'title'=>'Description',
		        	'view'=>'textarea',
		        	'show_data'=>false,
		        ],
		        'password'=>[
		            'title'=>'Password',
		            'view'=>'password',
		        	'show_data'=>false,
		        ],
		        'active'=>[
		        	'title'=>'Active',
		        	'view'=>'true_false',
		        ],
		        'send_email_promotion'=>[
		        	'title'=>'Send Email When Promotion',
		        	'view'=>'true_false',
		        ],
		        'rating_count' => [
		            'title'=>'Rating Count',
		            'view' =>'number',
		            'step_size'=>0.1,
		            'show_data'=>false,
		        ],
		        'api_key'=>[
		        	'title'=>'Api Key',
		        	'show_data'=>false,
		        ],
		        'api_token'=>[
		        	'title'=>'Api Token',
		        	'view'=>'textarea',
		        	'show_data'=>false,
		        ],
		        'avatar' => [
		            'title'=>'Avatar',
		            'view' =>'image',
		            'show_data'=>false,
		            'advance'=>'right',
		        ],
		        'website' => [
		            'title'=>'Website',
		            'view' =>'text',
		            'show_data'=>false,
		        ],
			]
		]
	];

	//Plugin
	$add_object[] = [
			'cms_product_category',
	    	1,
			[
		    'table'=>'cms_product_category',
		    'title'=> __('CMS Product Category'),
		    'slug'=>'product-category',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
		        'product' => [
		            'title'=>'Product',
		            'view' =>'relationship_manytomany_show',
		            'object'=>'cms_product',
		            'advance'=>'right',
		            'field'=>'category',
		        	'express'=>function($post){
		        		return $post->title.' - '.get_date($post->created_at);
		        	},
		            'show_data'=>false,
		        ],
			]
		]
	];


	$add_object[] =  [
			'cms_product_tag',
	    	1,
	    	[
		    'table'=>'cms_product_category',
		    'title'=> __('CMS Product Tag'),
		    'slug'=>'product-tag',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		    ]
	    ],
	];

	$add_object[] = [
			'cms_product_type',
	    	1,
			[
		    'table'=>'cms_product_type',
		    'title'=> __('CMS Product Type'),
		    'slug'=>'product-type',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'banner_title'=>['title'=>'Title Banner','show_data'=>false],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
		        'product' => [
		            'title'=>'Product',
		            'view' =>'relationship_onetomany_show',
		            'object'=>'cms_product',
		            'field'=>'product_type',
		        	'express'=>function($post){
		        		return $post->title.' - '.get_date($post->created_at);
		        	},
		            'show_data'=>false,
		        ],
		        'template_product' => [
		            'title'=>'Template Product',
		            'view' =>'select',
		            'advance'=>'right',
		            'list_option'=>['theme'=>'Theme','plugin'=>'Plugin'],
		        ],
			]
		]
	];

	$add_object[] = [
			'cms_product',
	    	1,
			[
		    'table'=>'cms_product',
		    'title'=> __('CMS Product'),
		    'slug'=>'product',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description'=>[
		        	'title'=>'Description',
		        	'view'=>'textarea',
		            'show_data'=>false,
		        ],
		        'price' => [
		            'title'=>'Price',
		            'view' =>'text',
		            'live_edit'=>true,
		        ],
		        'rate' => [
		            'title'=>'Rate',
		            'view' =>'number',
		            'step_size'=>0.1,
		            'show_data'=>false,
		        ],
		        'rating_count' => [
		            'title'=>'Rating Count',
		            'view' =>'number',
		            'step_size'=>0.1,
		            'show_data'=>false,
		        ],
		        'download_count' => [
		            'title'=>'Download Count',
		            'view' =>'number',
		            'step_size'=>0.1,
		            'show_data'=>false,
		        ],
		        'detail'=>[
		        	'title'=>'Detail',
		        	'view'=>'editor',
		            'show_data'=>false,
		        ],
		        'installation'=>[
		        	'title'=>'Installation',
		        	'view'=>'editor',
		            'show_data'=>false,
		        ],
		        'development'=>[
		        	'title'=>'Development',
		        	'view'=>'editor',
		            'show_data'=>false,
		        ],
		        'faq'=>[
		        	'title'=>'FAQ',
		        	'view'=>'repeater',
		        	'sub_fields'=>[
		            	'question'=>['title'=>'Question','view'=>'textarea'],
		            	'answer'=>['title'=>'Answer','view'=>'editor'],
					],
		            'show_data'=>false,
		        ],
		        'product_type' => [
		            'title'=>__t('Product Type'),
		            'view' =>'relationship_onetomany',
		            'object'=>'cms_product_type',
		            'type'=>'many_record',
		            'advance'=>'right',
		            'show_data'=>true,
		        ],
		        'category' => [
		            'title'=>__('Category'),
		            'view' =>'relationship_manytomany',
		            'object'=>'cms_product_category',
		            'type'=>'many_record',
		            'advance'=>'right',
		            'show_data'=>true,
		        ],
		        'tag' => [
		            'title'=>__('Tag'),
		            'view' =>'relationship_manytomany',
		            'type'=>'tags',
		            'object'=>'cms_product_tag',
		            'advance'=>'right',
		            'show_data'=>true,
		        ],
		        'cms_user'=>[
		        	'title'=>'Author',
		        	'view'=>'relationship_onetomany',
		        	'type'=>'many_record',
		        	'object'=>'cms_user',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		        ],
	      	  	'thumbnail'=>[
		        	'title'=>'Thumbnail',
		        	'view'=>'image',
		        	'advance'=>'right',
		        ],
		        'cms_product_version'=>[
		        	'title'=>'Version',
		        	'view'=>'relationship_onetomany_show',
		        	'object'=>'cms_product_version',
		        	'express'=>function($post){
		        		return $post->title.' - '.get_date($post->created_at);
		        	},
		        	'field'=>'product',
		        	'advance'=>'right',
		            'show_data'=>false,
		        ],
		        'cms_product_review'=>[
		        	'title'=>'Review',
		        	'view'=>'relationship_onetomany_show',
		        	'object'=>'cms_product_review',
		        	'express'=>['rating','title'],
		        	'field'=>'product',
		        	'advance'=>'right',
		            'show_data'=>false,
		        ],
			],
			'tabs'=>[
		        'genarel'=>[ 'title'=>'Genarel', 'fields'=>['title','slug','description'] ],
		        'content'=>['title'=>'Content','fields'=>['price','rate','rating_count','download_count']],
		        'detail'=>[ 'title'=>'Detail', 'fields'=>['detail']],
		        'installation'=>[ 'title'=>'Installation', 'fields'=>['installation']],
		        'development'=>[ 'title'=>'Development', 'fields'=>['development']],
		        'faq'=>[ 'title'=>'FAQ', 'fields'=>['faq']],
		    ]
		]
	];
	$add_object[] = [
			'cms_product_version',
	    	1,
			[
		    'table'=>'cms_product_version',
		    'title'=> __('CMS Product Version'),
		    'slug'=>'product-version',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Version',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'description'=>[
		        	'title'=>'Description',
		        	'view'=>'textarea',
		        ],
		        'content'=>[
		        	'title'=>'Content',
		        	'view'=>'editor',
		        ],
		        'message_to_update_user'=>[
		        	'title'=>'Message To Update User',
		        	'view'=>'textarea',
		        ],
		        'link_zip'=>[
		        	'title'=>'Link Zip',
		        	'view'=>'input',
		        ],
		        'product' => [
		            'title'=>__('Product'),
		            'view' =>'relationship_onetomany',
		            'fields_related'=>['title'],
		            'type'=>'many_record',
		            'show_data'=>true,
		            'object'=>'cms_product',
		            'advance'=>'right',
		        ],
			]
		]
	];

	$add_object[] = [
			'cms_product_review',
	    	1,
			[
		    'table'=>'cms_product_review',
		    'title'=> __('CMS Product Review'),
		    'slug'=>'product-review',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'rating'=>[
		        	'title'=>'Rating',
		        	'view'=>'number',
		        ],
		        'count_voice'=>[
		        	'title'=>'Count Voice',
		        	'view'=>'number',
		        ],
		        'count_reply'=>[
		        	'title'=>'Count Reply',
		        	'view'=>'number',
		        ],
		        'message'=>[
		        	'title'=>'Message',
		        	'view'=>'textarea',
		        ],
		        'cms_user'=>[
		        	'title'=>'Author',
		        	'view'=>'relationship_onetomany',
		        	'object'=>'cms_user',
		            'type'=>'many_record',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		        ],
		        'product' => [
		            'title'=>__('Plugin'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'cms_product',
		            'type'=>'many_record',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];


	$add_object[] = [
			'cms_comment',
	    	1,
			[
		    'table'=>'cms_comment',
		    'title'=> 'CMS Comment',
		    'slug'=>'comment',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'content'=>[
		        	'title'=>'Content',
		        	'view'=>'editor',
		        	'show_data'=>false,
		        ],
		        'cms_user' => [
		            'title'=>'Author',
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'cms_user',
		            'type'=>'many_record',
		            'fields_related'=>['name'],
		            'advance'=>'right',
		        ],
		        'cms_product_review' => [
		            'title'=>'CMS Product review',
		            'view' =>'relationship_onetomany',
		            'fields_related'=>['title'],
		            'show_data'=>true,
		            'type'=>'many_record',
		            'object'=>'cms_product_review',
		            'advance'=>'right',
		        ],
			]
		]
	];
	#Order

	$add_object[] = [
			'cms_order',
	    	1,
			[
		    'table'=>'cms_order',
		    'title'=> __('CMS Order'),
		    'slug'=>'order',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'code'=>[
		        	'title'=>'Code',
		        ],
		        'price'=>[
		        	'title'=>'Price',
		        ],
		        'cms_user'=>[
		        	'title'=>'Author',
		        	'view'=>'relationship_onetomany',
		        	'object'=>'cms_user',
		        	'type'=>'many_record',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		        ],
		        'product' => [
		            'title'=>'Product',
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'cms_product',
		            'type'=>'many_record',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];


	#Order

	$add_object[] = [
			'cms_project',
	    	1,
			[
		    'table'=>'cms_project',
		    'title'=> __('CMS Project'),
		    'slug'=>'order',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'url'=>[
		        	'title'=>'URL',
		        ],
		        'api_key'=>[
		        	'title'=>'Api Key',
		        	'show_data'=>false,
		        ],
		        'api_token'=>[
		        	'title'=>'Api Token',
		        	'view'=>'textarea',
		        	'show_data'=>false,
		        ],
		        'cms_user'=>[
		        	'title'=>'Author',
		        	'view'=>'relationship_onetomany',
		        	'object'=>'cms_user',
		        	'type'=>'many_record',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		        ],
		        'product' => [
		            'title'=>'Product',
		            'view' =>'relationship_manytomany',
		            'show_data'=>true,
		            'object'=>'cms_product',
		            'type'=>'many_record',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];
	

	

	$add_object[] = [
			'cms_document_category',
	    	1,
			[
		    'table'=>'cms_document_category',
		    'title'=> __('CMS Document Category'),
		    'public_view'=>true,
		    'slug'=>'document-category',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
			]
		]
	];
	
	$add_object[] = [
			'cms_document',
	    	1,
			[
		    'table'=>'cms_document',
		    'title'=> 'CMS Document',
		    'slug'=>'document',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'description'=>[
		        	'title'=>'Description',
		        	'view'=>'textarea',
		            'show_data'=>false,
		        ],
		        'content'=>[
		        	'title'=>'Content',
		        	'view'=>'flexible',
		        	'show_data'=>false,
		        	'templates'=>[
		        		'text'=>[
		        			'title'=>'Content',
		        			'layout'=>'block',
		        			'items'=>[
		        				'title'=>['title'=>'Title','view'=>'text'],
		        				'content'=>['title'=>'Content','view'=>'editor'],
		        			]
		        		],
		        		'has-child'=>[
		        			'title'=>'Has Child',
		        			'layout'=>'block',
		        			'items'=>[
		        				'title'=>['title'=>'Title','view'=>'text'],
		        				'description'=>['title'=>'Description','view'=>'editor'],
		        				'multiple'=>['title'=>'Active multiple Item','view'=>'true_false'],
		        				'child'=>[
		        					'title'=>'Child',
		        					'view'=>'repeater',
				        			'sub_fields'=>[
				        				'title'=>['title'=>'Title','view'=>'text'],
				        				'content'=>['title'=>'Content','view'=>'editor'],
				        			]
		        				]
			        			
		        			]
		        		]
		        	],
		        ],
		        'category' => [
		            'title'=>__('Category'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'cms_document_category',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];

	$add_object[] = [
			'cms_notify',
	    	1,
			[
		    'table'=>'cms_notify',
		    'title'=> 'CMS Notify',
		    'slug'=>'notify',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		        ],
		        'message_type'=>[
		        	'title'=>'Type',
		        	'view'=>'group-type',
		        	'list_group'=>[
		        		'message'=>[],
		        		'version'=>['version']
		        	]
		        ],
		        'version'=>[
		        	'title'=>'Version',
		        ],
		        'message'=>[
		        	'title'=>'Message',
		        	'view'=>'editor',
		        	'show_data'=>false,
		        ],
		        'color'=>[
		        	'title'=>'Color'
		        ],
		        'name' => [
		            'title'=>'Name',
		            'view' =>'text',
		        ],
		        'avatar'=>[
		        	'title'=>'Avatar',
		        	'view'=>'image'
		        ],
		        'place' => [
		            'title'=>'Place',
		        	'view'=>'select',
		        	'multiple'=>true,
		        	'list_option'=>['notify'=>'Notify','dashboard'=>'Dashboard']
		        ],
		        'route' => [
		            'title'=>'Route',
		        	'view'=>'repeater',
		        	'show_data'=>false,
		        	'layout'=>'block',
		        	'sub_fields'=>[
		        		'key'=>['title'=>'Key'],
		        		'route-name'=>['title'=>'Route Name'],
		        		'route-param'=>[
		        			'title'=>'Route Param',
		        			'view'=>'repeater',
		        			'sub_fields'=>[
		        				'key'=>['title'=>'Key'],
		        				'value'=>['title'=>'Value'],
		        			]
		        		]
		        	]
		        ],
			]
		]
	];

	$add_object[] = [
			'cms_contact',
	    	1,
			[
		    'table'=>'cms_contact',
		    'title'=> 'CMS Contact',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		        ],
		        'email'=>[
		        	'title'=>'Email',
		        ],
		        'subject'=>[
		        	'title'=>'Subject',
		        ],
		        'message'=>[
		        	'title'=>'Message'
		        ],
			]
		]
	];


	$add_object[] = [
			'cms_subscribe',
	    	1,
			[
		    'table'=>'cms_subscribe',
		    'title'=> 'CMS Subscribe',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Email',
		            'view'=>'text',
		        ],
			]
		]
	];

	return $add_object;

});


if( is_admin() ){

	include __DIR__.'/inc/backend.php';

}else{

	include __DIR__.'/inc/frontend.php';

}