@if( $paginator)
<?php
// config
$link_limit = 4; // maximum number of links (a little bit inaccurate, but will be ok for now)
$request = request();

$paginator->setPath(Request::url());

$page = 'page';

if( isset($paginator->pageName_custom) ){
    $page = $paginator->pageName_custom;
}

$half_total_links = floor($link_limit / 2);

?>

@if ($paginator->lastPage() > 1)

    <div class="pagination">
        
        <?php 

            $currentPage = $paginator->currentPage();

            $input = $request->except($page);

            $param = '';

            foreach ($input as $key => $value) {
                if( is_string($value) ){
                    $param .= '&'.$key.'='.$value;
                }
            }

         ?>

        @if($currentPage == 1)
                <a href="javascript:void(0)">@__('«')</a>
        @else
                <a rel="prev" href="{!!$paginator->url($currentPage - 1).$param!!}">@__('«')</a>
        @endif

         <?php $result = ''; ?>
        @for ($i = 1; $i <= $paginator->lastPage(); $i++)
            <?php
            $from = $currentPage - $half_total_links;
            $to = $currentPage + $half_total_links;
            if ($currentPage < $half_total_links) {
               $to += $half_total_links - $currentPage;
            }
            if ($paginator->lastPage() - $currentPage < $half_total_links) {
                $from -= $half_total_links - ($paginator->lastPage() - $currentPage) - 1;
            }

            ?>
            @if ($from < $i && $i < $to)
                
                <?php 

                    if($currentPage == $i){
                        $result = $result.'<a class="active" href="javascript:void(0)">'.$i.'</a>';
                    }else{

                        if($currentPage > $i){
                            $rel = 'rel="prev"';
                        }else{
                            $rel = 'rel="next"';
                        }
                        $result = $result.'<a '.$rel.' href="'.$paginator->url($i).$param.'">'.$i.'</a>';
                    }
               ?>
                
            @endif
        @endfor
        @if($from > 2)
                <a rel="prev" href="{!!$paginator->url(1).$param!!}">1</a>
                <a href="javascript:void(0)">...</a>
        @else
            @for($i = 1; $i<= $from; $i++)
                <a rel="prev" href="{!!$paginator->url($i).$param!!}">{!!$i!!}</a>
            @endfor
        @endif
        {!!$result!!}
        @if($paginator->lastPage() - $to > 1)
                <a href="javascript:void(0)">...</a>
                <a rel="next" href="{!! $paginator->url($paginator->lastPage()).$param !!}">{!!$paginator->lastPage()!!}</a>
        @else
            @for($i = $to; $i<= $paginator->lastPage(); $i++)
                <a rel="next" href="{!!$paginator->url($i).$param!!}">{!!$i!!}</a>
            @endfor
        @endif
        
        @if($currentPage == $paginator->lastPage())
                <a href="javascript:void(0)">@__('»')</a>
        @else

                <a rel="next" href="{!!$paginator->url($currentPage +1).$param!!}"> @__('»')</a>
        @endif

    </div>
       
@endif
@endif