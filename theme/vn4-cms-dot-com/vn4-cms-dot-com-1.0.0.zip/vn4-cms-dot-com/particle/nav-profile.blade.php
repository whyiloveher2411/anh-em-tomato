<?php 

    $active = $active??'profile';

 ?>
<style>
    
    .thumbnail{
        margin:  0 auto;
    }
    .thumbnail img{
        width: 150px;
        border-radius: 50%;
        box-shadow: 0 0 2px black;
    }
    .user-info{
        text-align: center;
    }
    .email{
        color: gray;
        margin: 0;
    }
    .page-info-simple .page-title{
        font-size: 16px;
        margin-bottom: 0px;
        line-height: 27px;
        font-weight: bold;
    }
    .form-control{
        border: none;
        box-shadow: none;
        line-height: 40px;
        height: 40px;
        border: 1px solid #d8d8d8;
    }
    .input-label{
        font-size: 15px;
    }
    .page-title{
        padding: 10px 15px;
        font-size: 20px;
        font-weight: bold;
        margin-bottom: 30px;
    }
</style>
<div class="page-info page-info-simple" style="display: flex;align-items: center;flex-direction: column;">

    <div class="thumbnail">

        <img src="@theme_asset()img/avatar-default.jpg">

    </div>

   

    <div class="user-info">
        <h1 class="page-title">{!!$post->name!!}</h1>

        <p class="description">{!!$post->description!!}</p>

    </div>

    

</div>



<div class="rate-warper">

    <div class="rate" style="--star: {!!$user->rating_count??0!!};"></div> 

</div>



<div class="" style="margin-top: 30px;display: flex;">



    <div  style="text-align: center;flex:1;">

        <p style="margin-bottom: 5px;font-size: 22px;color: #798D8D;">{!!$reviews!!}</p>

        <span>@__t('Reviews')</span>

    </div>



    @foreach($product_type as $type)

    <?php 

        if( !isset($productTemp[$type->id]) ){
            $productTemp[$type->id] = $type->related('cms_product','product_type',['count'=>true,'callback'=>function($q) use($post){
                return $q->where('cms_user',$post->id);
            }]);
        }

     ?>

    <div  style="text-align: center;flex:1;border-left: 1px solid #ecf0f1;">

        <p style="margin-bottom: 5px;font-size: 22px;color: #798D8D;">{!!$productTemp[$type->id]!!}</p>

        <span>{!!$type->title!!}</span>

    </div>


    @endforeach





</div>







<div class="info-item pad-tbt" style="margin-top: 35px;border-top: 1px solid #ecf0f1;">

    <i class="fa fa-calendar" aria-hidden="true"></i> @__t('Registration date') {!!get_date($post->created_at)!!}

</div>



@if( !isset($notme) )
<div class="info-item pad-tbt" >

    <a href="{!!route('page','profile')!!}" @if($active === 'profile') class="active" @endif>

   <i class="fa fa-user" aria-hidden="true"></i> @__t('Profile')

   </a>

</div>

<div class="info-item pad-tbt" >

    <a href="{!!route('page','profile-setting')!!}" @if($active === 'profile-setting') class="active" @endif>

    <i class="fa fa-cogs" aria-hidden="true"></i> @__t('Setting')

    </a>

</div>

<div class="info-item pad-tbt" >

    <a href="{!!route('page','profile-order')!!}" @if($active === 'profile-order') class="active" @endif>

    <i class="fa fa-cart-plus" aria-hidden="true"></i> @__t('Order')

    </a>

</div>



<div class="info-item pad-tbt" >

    <a href="{!!route('page','profile-api')!!}" @if($active === 'profile-api') class="active" @endif>

    <i class="fa fa-share-alt" aria-hidden="true"></i> @__t('Api')

    </a>

</div>
@endif