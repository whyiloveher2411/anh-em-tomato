@extends(theme_extends())

@section('content')
<style type="text/css">
	.form-swith h2{
		text-align: center;
	}
	.form-swith button{
		width: 100%;
		background-color: #28c;
		color: white;
	}
</style>
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">@__t('Login page')</h1>
                        <h2 class="page-description">@__t('Some functions on the website require login, please login before using')</h2>.
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

<div id="content" style="background: white;">
    <div class="container">
        <div class="row">
            <div class=" col-md-offset-3 col-md-6">
				<form class="form-swith" id="form-login" style="padding: 20px;background: whitesmoke;border-radius: 4px;">
					<input type="hidden" name="form-type" value="login">
                    <input type="hidden" name="email" value="{!!Request::get('email')!!}">
                    <input type="hidden" name="token" value="{!!Request::get('token')!!}">
                    <input type="hidden" name="key" value="{!!Request::get('key')!!}">
                    
					<h2>@__t('Reset Password')</h2>
						<div class="form-group">
                            <input type="password" value="" name="newpassword" required="required" id="newpassword" class="form-control">
                            <label>@__t('A new password')</label>
                        </div>
                        <div class="form-group">
                            <input type="password" value="" name="confirmpassword" required="required" id="confirmpassword" class="form-control">
                            <label>@__t('Confirm new password')</label>
                        </div>
					  <button type="submit" name="login" value="1" class="button small blue">@__t('Change the password')</button>
				</form>
            </div>
        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">

    	$('.change-form').click(function(event){
    		event.preventDefault();

    		$('.form-swith').hide();
    		$('#'+$(this).data('form')).show();
    	});

    	$('form :input').change(function(){
            if($(this).val().trim()){
                $(this).addClass('valid')
            }else{
                $(this).removeClass('valid')
            }
        });

        $('.form-swith').submit(function(event){
            event.preventDefault();

            if( $('#newpassword').val() ){

                if($('#newpassword').val().length <= 8 || $('#newpassword').val().length > 255 ){
                    alert('@__t('Password must be between 8 and 255 characters')');
                    event.preventDefault();
                    return false;
                }
                if($('#newpassword').val() != $('#confirmpassword').val()){
                    alert('@__t('Confirm password does not match')');
                    event.preventDefault();
                    return false;
                }

                show_message('@__t('Please wait a second')');
                var data = $(this).serializeArray();
                data.push({name:'_token',value: '{!!csrf_token()!!}'});
                $.ajax({
                    url:"{!!route('post',['account','new-password'])!!}",
                    type:"POST",
                    dataType:"Json",
                    data:data,
                    success:function(result){
                        if( result.message ){
                            alert(result.message);
                        }

                        if( result.redirect ){
                            window.location.reload(result.redirect);
                        }

                        hide_message();
                    }
                });
            }

    		
        });
    </script>
@stop