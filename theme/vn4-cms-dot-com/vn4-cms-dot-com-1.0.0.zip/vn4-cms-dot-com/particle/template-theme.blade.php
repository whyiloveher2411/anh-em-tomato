<?php 
    $link = get_permalinks($post);
?>

<div class="wrap wrap-theme">
    <div class="cover">
        <a href="{!!$link!!}"><img src="{!!get_media($post->thumbnail,'https://via.placeholder.com/360x170','listting')!!}" alt=""></a>

        <span class="price">{!!$post->price??__t('Free')!!}</span>
    </div>

    <div style="clear: both;"></div>
   
    <div class="info-bottom">
        <a href="#" class="item-info bd-r">{!!$post->title!!}</a>
        <a href="#" class="item-info">{!!number_format($post->download_count)!!} @__t('Download')</a>
    </div>

</div>