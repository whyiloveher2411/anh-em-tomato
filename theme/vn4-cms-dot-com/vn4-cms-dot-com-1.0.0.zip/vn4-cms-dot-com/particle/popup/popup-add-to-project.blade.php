<div class="popup">
	<div class="popup-warper">
		<div class="popup-header">
			Add to Project
			<i class="fa fa-times" onclick="document.getElementsByClassName('popup')[0].remove()"></i>
		</div>
		<div class="popup-content">
			Projects let you group plugins and themes to simplify the development and deployment process across multiple servers. Learn more.
			<form class="ajax" method="POST" action="{!!route('post',['controller'=>'project','method'=>'add-product-to-project'])!!}">
				<input type="hidden" name="product" value="{!!$product->id!!}">
				<select class="form-control" name="project" style="margin: 20px 0;">

					@foreach($projects as $p)
					<option value="{!!$p->id!!}">{!!$p->title!!}</option>
					@endforeach

				</select>

				<button type="submit" class="btn btn-primary" style="height: 38px;display: inline-block;line-height: 38px;">@__t('Add to project')</button>

				<span class="btn btn-default" style="height: 38px;display: inline-block;line-height: 38px;" onclick="document.getElementsByClassName('popup')[0].remove()">Cancel</span>
			</form>
		</div>
	</div>
</div>