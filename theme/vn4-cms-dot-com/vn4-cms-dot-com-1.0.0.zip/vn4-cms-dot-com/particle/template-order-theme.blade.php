 <?php 
	$author = json_decode($post->cms_user_detail,true);
	$link = get_permalinks($post);
?>

 <div class="wrap wrap-theme wrap-theme-order">
	<div style="width: 100%;padding: 0 10px;">
        <div class="cover">
            <a href="{!!$link!!}"><img src="{!!get_media($post->thumbnail,'https://via.placeholder.com/360x180','listting')!!}" alt=""></a>
        </div>
        <div class="info">
            <a href="{!!$link!!}"><div class="name">[Theme] {!!$post->title!!} ({!!$post->price??__t('Free')!!})</div></a>
            <div class="bottom">
                <div class="left">
                    <div class="rate" style="--star: {!!$post->rate!!};width: 96px;"></div>
                    <div class="description">{!!$post->description!!}</div>
                </div>
                <div class="right">
                    <!-- <div class="btn">Preview</div> -->
                    <!-- <div class="btn green">Install</div> -->
                </div>
            </div>

             @if($author)
            <a href="{!!get_permalinks($author)!!}"><div class="author">@__t('By') {!!$author['title']!!}</div></a>
            @endif
        </div>
    </div>

	<div class="pull-right" style="margin: 0 10px;">

		<?php 
        	$version = $post->related('cms_product_version','product',['count'=>1]);
         ?>
         @if( isset($version[0]) )

         <form method="POST" action="{!!route('post',['download','index','id'=>$version[0]->id])!!}">
            <input type="hidden" name="_token" value="{!!csrf_token()!!}">
            <input type="submit" name="download" value="@__t('Download')" style="display: inline-block;float: right;margin: 5px 5px 0 0;" class="button small blue">
        </form>
		@endif

        <a href="{!!$link!!}#reviews" style="display: inline-block;float: right;margin-top: 5px;" class="button small blue">@__t('Reviews')</a>
        
    </div>

</div>