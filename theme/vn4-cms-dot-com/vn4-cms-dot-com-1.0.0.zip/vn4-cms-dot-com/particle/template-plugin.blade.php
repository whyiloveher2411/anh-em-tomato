 <?php 
    $link = get_permalinks($post);
 ?>

<div class="wrap wrap-plugin">
    <div class="pd10">
        <div class="cover">
            <a href="{!!$link!!}"><img src="{!!get_media($post->thumbnail,'https://via.placeholder.com/128x128')!!}" alt=""></a>
            <div class="price">{!!$post->price??__t('Free')!!}&nbsp;</div>
        </div>
        <div class="info">
            <a href="{!!$link!!}"><div class="name">{!!$post->title!!}</div></a>
            <div class="bottom">
                <div class="left">
                    <div class="rate" style="--star: {!!$post->rate!!};width: 96px;"></div>
                    <div class="description">{!!$post->description!!}</div>
                    <!-- <div class="sale">{!!number_format($post->download_count)!!} installations</div> -->
                </div>
                <div class="right">
                    <!-- <div class="btn">Preview</div> -->
                    <!-- <div class="btn green">Install</div> -->
                </div>
            </div>
            
        </div>
    </div>
    <div style="clear: both;"></div>
    <div class="info-bottom">
        <a href="#" class="item-info bd-r">{!!number_format($post->rating_count)!!} @__t('Reviews')</a>
        <span class="item-info">{!!number_format($post->download_count)!!} @__t('Download')</span>
    </div>
</div>