 <div class="rate-warper">
    <div class="rate" style="--star: {!!$post->rate!!};"></div>
</div>

<div class="row" style="margin-top: 30px;">

    <div class="col-xs-6" style="text-align: center;border-right: 1px solid #ecf0f1;">
        <p style="margin-bottom: 5px;font-size: 22px;color: #798D8D;">{!!number_format($post->rating_count)!!}</p>
        <span>@__t('Reviews')</span>
    </div>
    <div class="col-xs-6" style="text-align: center;">
        <p style="margin-bottom: 5px;font-size: 22px;color: #798D8D;">{!!number_format($post->download_count)!!}</p>
        <span>@__t('Setting')</span>
    </div>

</div>


<div class="p-d-r" style="">
    <div class="product-price">{!!$post->price?$post->price:__t('Free')!!}</div>

     @if(isset($version[0]))

    <form method="POST" action="{!!route('post',['download','index','id'=>$version[0]->id])!!}">
        <input type="hidden" name="_token" value="{!!csrf_token()!!}">
        <input type="submit" name="download" value="@__t('Download')" class="btn-download">
    </form>

    @else
        <span class="btn-download">@__t('Not update')</span>
    @endif

</div>

<div class="info-item">
    <i class="fa fa-calendar" aria-hidden="true"></i> @__('Added on') {!!get_date($post->created_at)!!}
</div>

 @if(isset($version[0]))

<div class="info-item">
    <i class="fa fa-pencil " aria-hidden="true"></i> @__t('Last updated') {!!get_date($version[0]->created_at)!!}
</div>

 <div class="info-item">
    <i class="fa fa-code-fork" aria-hidden="true"></i> @__t('Current version:') <a href="{!!get_permalinks($version[0])!!}">{!!$version[0]->title!!}</a>
</div>
@endif


<div class="info-item">
    <i class="fa fa-user" aria-hidden="true"></i> @__t('Created by') <a href="{!!get_permalinks($author)!!}">{!!$author['name']!!}</a>
</div>

 <div class="info-item">
    <i class="fa fa-paper-plane" aria-hidden="true"></i> @__t('Product type:') <a href="{!!get_permalinks($product_type)!!}"><strong>{!!$product_type->title!!}</strong></a>
</div>

@if( $categories )
<div class="info-item">
    <label style="font-weight: bold;">@__t('Categories')</label>

    <div>
        @foreach($categories as $c)
        <a class="cat-item" href="{!!get_permalinks($c)!!}">{!!$c->title!!}</a>
        @endforeach
    </div>
</div>
@endif