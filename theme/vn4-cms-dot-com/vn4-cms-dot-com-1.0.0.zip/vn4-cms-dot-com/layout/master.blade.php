<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<?php 
		vn4_head();
	 ?>

    <link rel="stylesheet" href="@theme_asset()css/style.min.css">
    <link rel="stylesheet" href="@theme_asset()css/custom.css">
    <!-- <script src="@theme_asset()js/modernizr.js"></script> -->

	@yield('css')
	<style type="text/css">
		.header-holder{
			padding: 0;
			height: 100px;
		}
		.marketplace .main .main-list .list .item .wrap img{
			max-height: 180px;
		}
		.rate-warper .rate{
			float: none;
			display: block;
			margin: 0 auto;
		}
		.popup{
		    display: block;
		    position: fixed;
		    top: 0;
		    left: 0;
		    right: 0;
		    bottom: 0;
		    background: rgba(0, 0, 0, 0.7);
		    z-index: 9999;
		}
		.popup-warper{
			width: 600px;
		    max-width: 100%;
		    position: absolute;
		    background: white;
		    top: 50%;
		    left: 50%;
		    transform: translate(-50%, -50%);
		}
		.popup-header{
			padding: 20px 15px 20px 35px;
		    border-bottom: 1px solid #DBDFE1;
		    min-height: 21.42857143px;
		    font-size: 23px;
		    color: #1F3F50;
		}
		.popup-content{
		    padding: 35px;
			line-height: 25px;
		}
		.popup .fa-times{
		    float: right;
		 	font-size: 15px;
		}
	</style>
</head>
<body {!!get_body_class()!!}>

	<div class="page js-page ">
        <div class="header header-over large">
		  <?php the_header(); ?>
        </div>
		@yield('content')

		<?php the_footer(); ?>
	</div>


    <div class="message-warpper">
        <h3 class="message">Message</h3>
    </div>

    

 	<script src="@theme_asset()js/rollbar.min.js" async=""></script>
	<script src="@theme_asset()js/all.js"></script>
	<script src="@theme_asset()js/custom.js"></script>
	<script src="@theme_asset()js/lib/extension.js"></script>
	<script>
	$(window).load(function() {

		$('.btn-add-project').on('shown.bs.modal', function () {
		  $('#myInput').trigger('focus')
		});

	    let $popupPurchase = $('.popup-purchase').popup({
	        $open: $('.btn-open-purchase'),
	        open: () => {
	            $tabPurcharse.next(0);
	            $('.process-number .number-list .item').removeClass('active').eq(0).addClass('active')
	        }
	    });

	    let $tabPurcharse = $('.popup-purchase .process-number .content').tab({
	        change: ({current}) => {
	            $('.process-number .number-list .item:eq('+current+')').addClass('active')
	        }
	    });
	    

	    $('.popup-purchase .tab1 .price-list-button').click((e) => {
	        e.stopPropagation();
	        e.preventDefault();
	        $tabPurcharse.next()
	        
	        // $('.process-number .content >*').css({display:'none'}).eq(1).css({display:'block'})
	    });

	    $('.popup-purchase .btn-register').click((e) => {
	        e.stopPropagation();
	        e.preventDefault();
	        $tabPurcharse.next()
	        
	        // $('.process-number .content >*').css({display:'none'}).eq(1).css({display:'block'})
	    });

	    $('.section-our-plan .price-list-button').on('click', function(e){
	        e.preventDefault();
	        $popupPurchase.open()
	        $tabPurcharse.next(1)
	    });

	    $('.tab2 input').change(function(){
	        if($(this).val().trim()){
	            $(this).addClass('valid')
	        }else{
	            $(this).removeClass('valid')
	        }
	    });

	    $(document).on('click','.btn-add-project',function(){

	    	$.ajax({

	    		url: '{!!route('post',['controller'=>'project','method'=>'add'])!!}',
	    		dataType:'Json',
	    		type:'POST',
	    		data:{
	    			_token: '{!!csrf_token()!!}',
	    			product: $(this).data('id'),
	    		},
	    		success:function(result){
	    			if( result.message ){
	    				alert(result.message);
	    			}

	    			if( result.action ){
	    				eval(result.action);
	    			}

	    			if( result.html ){
	    				$('body').append(result.html);
	    			}
	    		}
	    	})

	    });
        

         $(document).on('submit','form.ajax',function(event){

	        event.preventDefault();
	        var data = $(this).serializeArray();
	        data.push({name:'_token',value: '{!!csrf_token()!!}'});
	        url = $(this).attr('action');

	        $.ajax({
	            url:url,
	            type:"POST",
	            dataType:"Json",
	            data:data,
	            success:function(result){
	                if( result.message ){
	                    alert(result.message);
	                }

	                if( result.redirect ){
	                    window.location.href = result.redirect;
	                }

	                if( result.reload ){
	                    window.location.reload(result.reload);
	                }

	                hide_message();
	            }
	        });
	    });

	});
	function show_message(message = ''){
        $('.message-warpper .message').html(message);
        $('html').addClass('show-message');
    }

    function hide_message(){
        $('html').removeClass('show-message');
    }
	</script>

	 @yield('js')
</body>
</html>