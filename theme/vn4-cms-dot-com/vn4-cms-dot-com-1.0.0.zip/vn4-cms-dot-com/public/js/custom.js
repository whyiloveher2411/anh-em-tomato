$(document).ready(function() {
	let $header = $('.header'),
		$window 	= $(window);
	$window.scroll(function() {
		if($window.scrollTop() > 100){
			$header.addClass('fixed')
		}else{
			$header.removeClass("fixed")
		}
	})



	$('#subscribe-form').submit(function(){

		event.preventDefault();

		if( !$('#subscribe-email-footer').val() ){
			alert('Please Enter Your Email!');
			return;
		}

		var data = $(this).serializeArray();

		$.ajax({
			url:$(this).attr('action'),
			type:"POST",
			dataType:"Json",
			data:data,
			success:function(result){
				if( result.message ){
					alert(result.message);
				}
				if( result.redirect ){
					window.location.reload(result.redirect);
				}
			}
		});

	});



});