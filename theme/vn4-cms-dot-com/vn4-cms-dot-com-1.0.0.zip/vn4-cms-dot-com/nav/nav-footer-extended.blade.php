@foreach($menu as $index => $m)


<div class="col-md-2 col-sm-2 col-xs-4">
    <div class="footer-extended-menu">
        <h5 class="footer-extended-menu-title">{!!$m['label']!!}</h5>
        <ul class="footer-extended-menu-list">
            @foreach($m['children'] as $m2)
            <li><a {!!$m2['attrtitle']!!}>{!!$m2['label']!!}</a></li>
            @endforeach
        </ul>
    </div>
</div>
@if( $index ===2)
<div class="clearfix visible-xs-block"></div>
@endif
@endforeach