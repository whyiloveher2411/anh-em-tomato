<ul class="menu-vertical js-menu-vertical tendina">
	@foreach($menu as $index => $m)

		@if( isset($m['children'][0]) ) 
			<li class="sub has-children">
				<a href="javascript:void(0)">{!!$m['label']!!}</a>
				<ul class="children" style="display: none;">

					@foreach($m['children'] as $index2 => $m2)
						<li><a {!!$m2['attrtitle']!!}>{!!$m2['label']!!}</a></li>
					@endforeach
				</ul>
			</li>
		@else
			<li class=""><a {!!$m['attrtitle']!!}>{!!$m['label']!!}</a></li>
		@endif

	
	@endforeach
</ul>
