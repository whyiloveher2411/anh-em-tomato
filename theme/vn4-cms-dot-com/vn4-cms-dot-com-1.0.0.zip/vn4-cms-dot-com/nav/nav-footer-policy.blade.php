<ul class="footer-menu helper right">
	@foreach($menu as $index => $m)
    <li>  <a {!!$m['attrtitle']!!}>{!!$m['label']!!}</a> </li>
	@endforeach
</ul>

