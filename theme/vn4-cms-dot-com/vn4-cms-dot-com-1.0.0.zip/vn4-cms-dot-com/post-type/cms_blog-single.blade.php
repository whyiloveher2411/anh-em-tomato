<div class="col-md-6 col-sm-6">
    <div class="blog-grid">
        <div class="blog-grid-image">
            <a href="{!!$link = get_permalinks($post)!!}">
                <span class="blog-grid-image-over"></span>
                <img src="{!!get_media($post->image)!!}" class="" alt="article image">
            </a>
        </div>
        <h3 class="blog-grid-title">
            <a href="{!!$link!!}">{!!$post->title!!}</a>
        </h3>
        <p class="blog-grid-excerpt">
            {!!$post->description!!}
        </p>
        <div class="blog-grid-meta">
            <span class="blog-grid-date">{!!get_date($post->created_at)!!}</span>
             <?php 
                $author = $post->relationship('cms_user');
             ?>

             @if( $author )
            <span class="blog-grid-author">@__t('By') <a href="{!!get_permalinks($author)!!}">{!!$author->name!!}</a></span>
            @endif
        </div>
    </div>
</div>