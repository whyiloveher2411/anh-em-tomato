<?php 
    $products = $post->related('cms_product','product_type',['paginate'=>'page','count'=>12]);

    add_body_class('marketplace');
 ?>

@extends(theme_extends())

@section('content')

@if($post->banner_title)
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">{!!$post->banner_title!!}</h1>
                        <h2 class="page-description">{!!$post->description!!}</h2>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>

@else
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
@endif

<div id="content">
    <div class="container-fluid">
            <!-- <form>
        
        <div class="search-top">
            <input type="search" name="q" autocomplete="false">
            <button class="btn btn-search btn-info">Search</button>
        </div>
            </form> -->

        <p class="note-found">{!! strtr(__t('Found <b>##number##</b> product'),['##number##'=>$products->total()])!!}</p>
        <div class="main row">
            <div class="categories col-md-3">
                <div class="cat">
                    <div class="list">

                        <?php 
                            $categories = get_posts('cms_product_category',[]);
                         ?>
                        <a href="{!!route('page','product')!!}" class="item active">@__t('All of the category')</a>
                         @foreach($categories as $c)
                        <a href="{!!get_permalinks($c)!!}?filter={!!$post->id!!}" class="item">{!!$c->title!!}</a>
                        @endforeach

                    </div>
                </div>
            </div>
            <div class="main-list col-md-9">
                <div class="list row">

                     @forelse($products  as  $p)
                    <div class="item col-md-4">
                        {!!get_particle('particle.template-'.$post->template_product,['post'=>$p])!!}
                    </div>

                    @empty
                    <h3 style="text-align: center;width: 100%;">@__t('Product not found')</h3>
                    @endforelse

                    
                </div>

                {!!get_paginate($products)!!}
            </div>
        </div>
    </div>
</div>
@stop