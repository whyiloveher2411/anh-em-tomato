@extends(theme_extends())
<?php 
// Blogs
    $blogsOptions = theme_options('blogs',['title'=>'','description'=>'','background'=>'','sidebar'=>'']);

    $blogs = $post->related('cms_blog','category',['count'=>6,'paginate'=>'page']);

    $tags = get_posts('cms_blog_tag',['count'=>10,'order'=>['count_cms_blog_tag','desc']]);
    
 ?>
@section('content')

<style>
    .pagination {
      display: inline-block;
    }

    .pagination a {
      color: black;
      float: left;
      padding: 8px 16px;
      text-decoration: none;
      transition: background-color .3s;
      border: 1px solid #ddd;
      margin: 0 4px;
    }

    .pagination a.active {
      background-color: #4CAF50;
      color: white;
      border: 1px solid #4CAF50;
    }

    .pagination a:hover:not(.active) {background-color: #ddd;}
</style>
<!-- Header Back -->
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">{!!$blogsOptions['title']!!}</h1>
                        <h2 class="page-description">{!!$blogsOptions['description']!!}</h2>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Header Back -->
<div id="content">
    <div class="container">
        <div class="layout with-right-sidebar js-layout">
            <div class="row">
                <div class="col-md-9">
                    <div class="main-content">
                        <!-- Blog Page -->
                        <div class="blog">
                            <div class="row">
                                @forelse($blogs as $p)
                                    {!!get_single_post($p)!!}
                                @empty
                                    <h2 style="text-align: center;">@__t('Articles Not Found.')</h2>
                                @endforelse
                            </div>
                        
                            {!!get_paginate($blogs,'paginate')!!}
                        </div>
                        <!-- End of Blog Page -->
                    </div>
                </div>
                <div class="col-md-3 hidden-sm hidden-xs">
                    <div class="sidebar js-sidebar-fixed">
                        <!-- Vertical Menu -->
                        <nav class="menu-vertical-wrapper">
                            {!!vn4_nav_menu_db($blogsOptions['sidebar'],null,['container_class'=>'menu-vertical  js-menu-vertical'])!!}
                        </nav>
                        
                        <div class="widget">
                            <h3 class="widget-title">@__t('Maybe you are interested')</h3>
                            <!-- Tags -->
                            <ul class="tags">
                                @foreach($tags as $t)
                                <li class="tag-item"><a href="{!!get_permalinks($t)!!}">{!!$t->title!!}</a></li>
                                @endforeach
                            </ul>
                            <!-- End of Tags -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop