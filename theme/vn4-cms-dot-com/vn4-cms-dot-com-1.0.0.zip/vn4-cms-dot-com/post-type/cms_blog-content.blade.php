@extends(theme_extends())

<?php 
// Blogs
    $blogsOptions = theme_options('blogs',['title'=>'','description'=>'','background'=>'','sidebar'=>'']);

    $tags = get_posts('cms_blog_tag',['count'=>10,'order'=>['count_cms_blog_tag','desc']]);
    
    $tagPost = $post->relationship('tag');
 ?>

@section('content')
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="layout with-right-sidebar js-layout">
            <div class="row">
                <div class="col-md-9">
                    <div class="main-content">
                        <!-- Article -->
                        <article class="article">
                            <!-- Article Title -->
                            <h2 class="article-title">
                                {!!$post->title!!}
                            </h2>
                            <!-- End of Article Title -->
                            <!-- Article Meta -->
                            <ul class="article-meta">
                                <li>
                                    <span class="article-meta-date article-meta-item">{!!get_date($post->created_at)!!}</span>
                                </li>

                                <?php 
                                    $author = $post->relationship('cms_user');
                                 ?>
                                 @if( $author )
                                <li>
                                    <span class="article-meta-author article-meta-item"><a href="{!!get_permalinks($author)!!}">{!!$author->name!!}</a></span>
                                </li>
                                @endif


                               <!--  <li>
                                    <span class="article-meta-category article-meta-item"><a href="blog-grid.html">Startups</a></span>
                                </li>
                                <li>
                                    <span class="article-meta-views article-meta-item">966</span>
                                </li>
                                <li>
                                    <span class="article-meta-likes article-meta-item">15</span>
                                </li>
                                <li>
                                    <span class="article-meta-comments article-meta-item"><a href="#" class="js-scroll-to" data-target="#article-comments" data-speed="600">50</a></span>
                                </li> -->
                            </ul>

                           
                           
                            <div class="article-content">
                                 {!!get_content($post->content)!!}
                                <!-- Article Tags -->
                                <div class="article-tags">
                                    Tags:
                                    @foreach($tagPost as $t)
                                    <a class="article-tag" href="{!!get_permalinks($t)!!}">{!!$t->title!!}</a>
                                    @endforeach
                                </div>
                                <!-- End of Article Tags -->
                                <!-- Social Share -->
                              <!--   <div class="social-likes social-share">
                                    <div class="facebook" title="Share link on Facebook">Facebook</div>
                                    <div class="twitter" title="Share link on Twitter">Twitter</div>
                                    <div class="plusone" title="Share link on Google+">Google+</div>
                                </div> -->
                                <!-- End of Social Share -->
                            </div>
                            
                            <?php 
                                $list_post = get_posts('cms_blog',['count'=>5,'callback'=>function($q) use ($post) {
                                    return $q->inRandomOrder()->where('id','!=',$post->id)->whereRaw('id in (SELECT post_id FROM `vn4_cms_blog_cms_blog_tag` WHERE tag_id in (SELECT tag_id FROM `vn4_cms_blog_cms_blog_tag` WHERE `post_id` = '.$post->id.'))');
                                }]);
                             ?>

                             @if( isset($list_post[0]) )
                            <div class="article-widget">
                                <h3 class="article-widget-title">
                                    Related articles
                                </h3>
                                <ul class="article-related-articles">
                                    @foreach($list_post as $p)
                                    <li><a href="{!!get_permalinks($p)!!}">{!!$p->title!!}</a></li>
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                            <!-- End of Article Widget Related Article -->
                        </article>
                        <!-- End of Article -->
                    </div>
                </div>
                <div class="col-md-3 hidden-sm hidden-xs">
                    <div class="sidebar js-sidebar-fixed">
                        <!-- Vertical Menu -->
                        <nav class="menu-vertical-wrapper">
                            {!!vn4_nav_menu_db($blogsOptions['sidebar'],null,['container_class'=>'menu-vertical  js-menu-vertical'])!!}
                        </nav>
                        

                        <div class="widget">
                            <h3 class="widget-title">@__t('Maybe you are interested')</h3>
                            <!-- Tags -->
                            <ul class="tags">
                                @foreach($tags as $t)
                                <li class="tag-item"><a href="{!!get_permalinks($t)!!}">{!!$t->title!!}</a></li>
                                @endforeach
                            </ul>
                            <!-- End of Tags -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@stop