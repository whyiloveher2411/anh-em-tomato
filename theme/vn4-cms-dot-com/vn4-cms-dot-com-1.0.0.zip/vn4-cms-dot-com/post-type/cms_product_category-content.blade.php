@extends(theme_extends())
<?php

    $type = Request::get('filter');

    $urlFilter = '';

    if( $type && $type = get_post('cms_product_type',$type) ){
        $products = $post->related('cms_product','category',['paginate'=>'page','count'=>12,'callback'=>function($q) use ($type){
            return $q->where('product_type',$type->id);
        }]);

        $urlFilter = '?filter='.$type->id;
    }else{
        $products = $post->related('cms_product','category',['paginate'=>'page','count'=>12]);
    }

    add_body_class('marketplace');
 ?>
@section('content')
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container-fluid">
           <!--  <form>
                <div class="search-top">
                    <input type="search" name="q" autocomplete="false">
                    <button class="btn btn-search btn-info">Search</button>
                </div>
            </form> -->

        <p class="note-found">{!! strtr(__t('Found <b>##number##</b> Sản phẩm'),['##number##'=>$products->total()])!!}</p>
        <div class="main row">
            <div class="categories col-md-3">
                <div class="cat">
                    <div class="list">

                        <?php 
                            $categories = get_posts('cms_product_category',[]);
                         ?>
                         @if($type)
                        <a href="{!!get_permalinks($type)!!}" class="item">@__t('All of the category')</a>
                        @endif
                         @foreach($categories as $c)
                        <a href="{!!get_permalinks($c),$urlFilter!!}" class="item @if($c->id === $post->id) active @endif">{!!$c->title!!}</a>
                        @endforeach

                    </div>
                </div>
            </div>
            <div class="main-list col-md-9">
                <div class="list row">

                    
                    @forelse($products  as  $p)
                    <div class="item col-md-4">
                        <?php 
                            $product_type = $p->relationship('product_type');
                         ?>

                        @if( $product_type )
                            {!!get_particle('particle.template-'.$product_type->template_product,['post'=>$p])!!}
                        @endif

                    </div>

                    @empty
                    <h3 style="text-align: center;width: 100%;">@__t('Product not found')</h3>
                    @endforelse

                </div>

                {!!get_paginate($products)!!}
            </div>
        </div>
    </div>
</div>
@stop