@extends(theme_extends())
<?php

 ?>
@section('content')
<!-- End of Header Back -->
<style type="text/css">
    a:active, a:hover, a:focus{
      text-decoration: none;
    }
    .bs-docs-sidenav *{
        list-style: none;
        box-sizing: border-box;
    }
    .bs-docs-sidenav a{
        font-size: 12px;
        font-size: 13px;
        font-weight: 500;
        color: #767676;
        line-height: 19px;
        display: block;
        padding: 3px 0 0 20px;
        border-left: 2px solid transparent;
    }
    .bs-docs-sidenav li>ul{
        display: none;
    }
    .bs-docs-sidenav li>a.active + ul{
        display: block;
    }
    .bs-docs-sidenav li li a{
        padding: 3px 0 0 30px;
    }
    .bs-docs-sidenav ul{
        margin: 0;
    }
    .bs-docs-sidenav .active, .bs-docs-sidenav a:hover{
        color: #563d7c;
        background-color: transparent;
        border-left: 2px solid #563d7c;
    }
    .main-content ul.neo-header, .main-content ul.neo-header ul{
        list-style: none;
    }
    .neo-header .multi-li li{
      display: inline-block;
      width: 32%;
    }

    h2.neo, h3.neo{
        padding-top: 15px;
        font-weight: bold;
        /*border-top: 1px solid #dedede;*/
    }
    .neo.multi-li{
      font-size: 16px;
    }
    .main-content ul.neo-header a{
        color: #090910;
        font-weight: bold;
        font-size: .99em;
    }
    .main-content .neo>a:before{
        content: "#\00a0\00a0";
        display: inline-block;
        color: #ff2d20;
    }
    .main-content .neo a{
        color: #090910;
    }
    .main-content ul.neo-header li li a{
        font-weight: normal;
    }
    .main-content h2{
        margin-top: 50px;
    }
    .main-content h3{
        margin-top: 15px;
        font-size: 20px;
    }
    .description{
        font-size: 18px;
        line-height: 30px;
        color: black;
        margin-top: 45px;
        display: block;
        max-height: initial;
    }
    .image{
        border: none;
    }
    figcaption{
        text-align: center;
        margin: 5px;
        font-size: 14px;
    }
    figure{
        margin-bottom: 20px;
        text-align: center;
    }
    figure img{
        border-radius: 3px;
        cursor: pointer;
        width: auto;
        height: auto;
        max-height: 100%;
        max-width: 100%;
    }
    


    .mySlides {display: none}

    /* Slideshow container */
 

    /* Next & previous buttons */
    .prev, .next {
      cursor: pointer;
      position: absolute;
      top: 50%;
      width: auto;
      padding: 16px;
      margin-top: -22px;
      color: white;
      font-weight: bold;
      font-size: 18px;
      transition: 0.6s ease;
      border-radius: 0 3px 3px 0;
      user-select: none;
      transform: translateX(-50px);
    }

    /* Position the "next button" to the right */
    .next {
      right: 0;
      border-radius: 3px 0 0 3px;
      transform: translateX(50px);
    }

    /* On hover, add a black background color with a little bit see-through */
    .prev:hover, .next:hover {
      background-color: rgba(0,0,0,0.8);
    }

    /* Caption text */
    .text {
      color: #f2f2f2;
      font-size: 15px;
      padding: 8px 12px;
      position: absolute;
      bottom: -27px;
      width: 100%;
      text-align: center;
      background: hsla(0, 0%, 0%, 0.75);
    }

    /* Number text (1/3 etc) */
    .numbertext {
      color: #f2f2f2;
      font-size: 12px;
      padding: 8px 12px;
      position: absolute;
      top: -30px;
    }

    /* The dots/bullets/indicators */
    .dot {
      cursor: pointer;
      height: 15px;
      width: 15px;
      margin: 0 2px;
      background-color: #bbb;
      border-radius: 50%;
      display: inline-block;
      transition: background-color 0.6s ease;
    }

    .dot.active, .dot:hover {
        background-color: #0e0e0e;
        border: 1px solid white;
    }

    /* Fading animation */
    .fade {
      -webkit-animation-name: fade;
      -webkit-animation-duration: .5s;
      animation-name: fade;
      animation-duration: .5s;
    }

    @-webkit-keyframes fade {
      from {opacity: .4} 
      to {opacity: 1}
    }

    @keyframes fade {
      from {opacity: .4} 
      to {opacity: 1}
    }

    /* On smaller screens, decrease text size */
    @media only screen and (max-width: 300px) {
      .prev, .next,.text {font-size: 11px}
    }
    .slider{
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 99;
        overflow: hidden;
    }
    .slideshow-container{
        max-width: 100%;
        max-height: 100%;
        width: auto;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%);
    }
    .dots{
        position: absolute;
        width: 100%;
        bottom: 14px;
    }
    .hide-slider{
        text-align: right;
        color: white;
        position: absolute;
        padding: 10px;
        cursor: pointer;
        right: 10px;
        top: 10px;
        border-radius: 50%;
        line-height: 18px;
        width: 38px;
    }
    .hide-slider:hover{
        background: rgba(0, 0, 0, 0.7);
    }
  /*  .main-content img{
        display: block;
        margin: 0 auto;
    }*/
</style>
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="layout with-left-sidebar js-layout">
            <div class="row">
                <div class="col-md-3 hidden-sm hidden-xs">
                    <div class="sidebar js-sidebar-fixed">
                        <!-- Vertical Menu -->
                        <nav class="menu-vertical-wrapper" id="menu-document">
                            {!!vn4_nav_menu_db(theme_options('document','sidebar'),'nav-document')!!}
                        </nav>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="main-content">
                        <h1>{!!$post->title!!}</h1>

                        <?php 
                            $content = json_decode($post->content,true);
                         ?>
                         <br>
                         <ul class="neo-header">
                             @forswitch($content as $c)
                                @is('text')

                                    @if( $c['title'] )
                                    <li class="neo"><a href="#{!!str_slug($c['title'])!!}">{!!$c['title']!!}</a></li>
                                    @endif

                                @endis
                                @is('has-child')
                                    <li class="neo">
                                        <a href="#{!!str_slug($c['title'])!!}">{!!$c['title']!!}</a>
                                        <ul class="{!! isset($c['multiple']) && $c['multiple']?'multi-li':''!!}">

                                        @forif($c['child'] as $d)
                                             <li class="neo"><a href="#{!!str_slug($d['title'])!!}">{!!$d['title']!!}</a></li>
                                        @endforif
                                        </ul>
                                    </li>
                                @endis
                             @endforswitch
                         </ul>

                         <p class="description">{!!$post->description!!}</p>
                         @forswitch($content as $c)
                            @is('text')
                                @if( $c['title'] )
                                <h2 class="neo"><a href="javascript:void(0)" id="{!!str_slug($c['title'])!!}">{!!$c['title']!!}</a></h2>
                                @endif
                               {!!get_content($c['content'])!!}
                            @endis
                            @is('has-child')
                                <h2 class="neo"><a href="javascript:void(0)" id="{!!str_slug($c['title'])!!}">{!!$c['title']!!}</a></h2>
                                {!!$c['description']!!}

                                <?php 
                                    $class =  isset($c['multiple']) && $c['multiple']?'multi-li':'';
                                 ?>
                                @forif($c['child'] as $d)
                                    <h3 class="neo {!!$class!!}"><a href="javascript:void(0)" id="{!!str_slug($d['title'])!!}">{!!$d['title']!!}</a></h3>
                                    {!!get_content($d['content'])!!}
                                @endforif
                            @endis
                         @endforswitch

                    </div>
                    <br>
                    <br>
                    <br>
                    <h2>@__t('Documents you may be interested.')</h2>
                    <?php 
                      $documents = get_posts('cms_document',['count'=>5, 'callback'=>function($q) use ($post){
                        return $q->where('category',$post->category)->where(Vn4Model::$id,'!=',$post->id)->inRandomOrder();
                      }]);
                     ?>

                     @if( isset($documents[0]) )
                     @foreach( $documents as $d)
                     <div>
                       <h3 style="font-size: 15px;"><a href="{!!get_permalinks($d)!!}">{!!$d->title!!}</a></h3>
                     </div>
                     @endforeach
                     @endif
                </div>
                
            </div>
        </div>
    </div>
</div>

<div class="slider">
    <div class="hide-slider">&#9932;</div>
    <div class="slideshow-container">

        
        
    </div>
    <br>
    <div class="dots" style="text-align:center">
    </div>
</div>
@stop


@section('js')
    <script type="text/javascript">
        $(window).load(function(){

            $('#menu-document a[href="'+window.location.origin + window.location.pathname +'"]').closest('li').addClass('selected').closest('li.sub').addClass('selected').find('.children').show();

             window.scrollTo(window.scrollX, window.scrollY +1);
             window.scrollTo(window.scrollX, window.scrollY -1);

             var length = $('.main-content img').length;
             max_height = window.innerHeight - 100;

             $('.main-content img').each(function(index, el){
                $('.slideshow-container').append('<div class="mySlides fade"><div class="numbertext">'+(index + 1)+' / '+length+'</div><img src="'+$(el).attr('src')+'" style="max-height:'+max_height+'px;">  <div class="text">'+$(this).closest('figure').text()+'</div></div>');
                $('.dots').append('<span class="dot" onclick="currentSlide('+(index + 1)+')"></span> ');

             });

              $('.slideshow-container').append('<a class="prev" onclick="plusSlides(-1)">&#10094;</a><a class="next" onclick="plusSlides(1)">&#10095;</a>');
            
            $('.main-content figure img').click(function(){
                currentSlide( $('.main-content figure img').index( this ) + 1);
                $('.slider').show();
            });

            $('.hide-slider').click(function(event){
                $('.slider').hide();
            });
            window.plusSlides = function(n) {
                event.stopPropagation();
              showSlides(slideIndex += n);
            }

            window.currentSlide = function(n) {
                event.stopPropagation();
              showSlides(slideIndex = n);
            }

            window.showSlides = function(n) {
                event.stopPropagation();
              var i;
              var slides = $('.mySlides');
              var dots = $('.dot');



              if( slides.length ){

                if (n > slides.length) {slideIndex = 1}    

                if (n < 1) {slideIndex = slides.length}

                  slides.css({'display':'none'});
                  dots.removeClass('active');

                  $(slides[slideIndex-1]).css({'display':'block'});
                  $(dots[slideIndex-1]).addClass('active');

                  // var slideIndex = 1;
                  // showSlides(slideIndex);
                
              }

              
            }


        });
    </script>
@stop