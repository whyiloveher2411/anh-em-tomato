@extends(theme_extends())
<?php 
// Features
    add_body_class('functional');
 ?>
@section('content')

        <div class="header-back header-back-simple header-back-small">
            <div class="header-back-container">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Page Info -->
                            <div class="page-info page-info-simple">
                                <h1 class="page-title">{!!$post->banner_title!!}</h1>
                                <h2 class="page-description">{!!$post->banner_description!!}</h2>
                            </div>
                            <!-- End Page Info -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Header Back -->
        <div id="content">
            <div class="container">
                <div class="layout with-right-sidebar js-layout">
                    <div class="row" style="    display: flex;flex-wrap: wrap;">

                        <?php 
                            $features = $post->features;
                         ?>

                         @forif($features as $f)
                            @if(!$f['delete'])
                            <div class="col-md-4 function-item card card-body border hover-shadow-8 text-default">
                               <div class="function-item-warp">
                                    <h5>{!!$f['title']!!}</h5>
                                    <p>{!!$f['description']!!}</p>

                                    @if( $link = get_link($f['link']) )
                                    <a class="function-item-footer" href="{!!$link!!}"><small class="text-primary">@__t('Explore more') <i class="fa fa-angle-right small-3 pl-1"></i></small></a>
                                    @endif

                                </div> 
                            </div>
                            @endif
                        @endforif
                    </div>
                </div>
            </div>
        </div>
@stop
    