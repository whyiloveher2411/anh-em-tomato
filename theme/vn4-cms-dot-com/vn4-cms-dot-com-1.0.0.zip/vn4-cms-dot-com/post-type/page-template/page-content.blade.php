@extends(theme_extends())
<?php 
// Default
 ?>
 @section('css')
 <style type="text/css">
     .contacts-input{
        border-top: 1px solid #cbd3dd;
        border-right: 1px solid #cbd3dd;
        border-left: 1px solid #cbd3dd;
        padding-top: 10px;
        padding-left: 12px;
     }
     .contacts-label{
        margin-bottom: 0;
     }
 </style>
 @stop
@section('content')

        <div class="header-back header-back-simple header-back-small">
            <div class="header-back-container">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Page Info -->
                            <div class="page-info page-info-simple">
                                <h1 class="page-title">{!!$post->title!!}</h1>
                                <h2 class="page-description">{!!$post->description!!}</h2>
                            </div>
                            <!-- End Page Info -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- End of Header Back -->
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Contacts -->
                        <div class="article-content">
                            {!!$post->content!!}
                        </div>
                        <!-- End of Contacts -->
                    </div>
                </div>
            </div>
        </div>
@stop
