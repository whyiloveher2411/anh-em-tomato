@extends(theme_extends())
<?php 
// Contacts
 ?>
 @section('css')
 <style type="text/css">
     .contacts-input{
        border-top: 1px solid #cbd3dd;
        border-right: 1px solid #cbd3dd;
        border-left: 1px solid #cbd3dd;
        padding-top: 10px;
        padding-left: 12px;
     }
     .contacts-label{
        margin-bottom: 0;
     }
 </style>
 @stop
@section('content')

        <div class="header-back header-back-simple header-back-small">
            <div class="header-back-container">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Page Info -->
                            <div class="page-info page-info-simple">
                                <h1 class="page-title">{!!$post->title!!}</h1>
                                <h2 class="page-description">{!!$post->description!!}</h2>
                            </div>
                            <!-- End Page Info -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- End of Header Back -->
        <div id="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <!-- Contacts -->
                        <div class="contacts">
                            @if (Session::has('success'))
                                <div class="contacts-success js-contacts-success"><i class="pe-7s-check"></i>@__t('Your message has been sent successfully. <br> Thank you!')</div>
                            @endif
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                        @foreach ($errors->all() as $error)
                                           <p style="padding: 0 15px;color:red;">{!! $error !!}</p>
                                        @endforeach
                                </div>
                            @endif


                            <!-- Success Modal -->
                            
                            <!-- End of Success Modal -->
                            <form action="{!!route('post',['contact','index'])!!}" method="POST" id="form-contact">
                                <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                                <ul class="contacts-inputs">
                                    <li class="contacts-item">
                                        <label for="full-name" class="contacts-label">@__t('Name')</label>
                                        <!-- This input is required -->
                                        <input type="text" name="fullname" id="full-name" class="contacts-input form-control" data-validation="required">
                                    </li>
                                    <li class="contacts-item">
                                        <label for="email" class="contacts-label">@__t('Email')</label>
                                        <!-- This input should be filled with a valid email and it's required -->
                                        <input type="text" name="email" id="email" class="contacts-input form-control" data-validation="required email">
                                    </li>
                                    <li class="contacts-item">
                                        <label for="country" class="contacts-label">@__t('Subject')</label>
                                        <!-- This input is optional -->
                                        <select name="subject" id="" class="contacts-input form-control">
                                            <option value="Liên hệ công việc">@__t('Contact for work')</option>
                                            <option value="Đặt câu hỏi">@__t('Make a question')</option>
                                        </select>
                                    </li>
                                    <li class="contacts-item">
                                        <label for="message" class="contacts-label">@__t('Message')</label>
                                        <!-- This input is required -->
                                        <textarea id="message" name="message" class="contacts-input form-control" data-validation="required"></textarea>
                                    </li>
                                </ul>
                                <button type="submit" class="button blue full">@__t('Send contact')</button>
                            </form>
                        </div>
                        <!-- End of Contacts -->
                    </div>
                    <div class="col-md-5">
                        <!-- Contacts info -->
                        <div class="contacts-info">

                            <?php 
                                $contact_info = $post->{'contacts-info'};
                             ?>

                             @forif($contact_info as $info)
                             <h4 class="contacts-info-title">
                                {!!$info['title']!!}
                            </h4>
                            <p class="contacts-info-description">
                                {!!$info['description']!!}
                            </p>
                            <div class="contacts-info-data">
                                @forif($info['emails'] as $email)
                                <a href="mailto:{!!$email['email']!!}">{!!$email['email']!!}</a>
                                @endforif
                            </div>
                             @endforif

                        </div>
                        <!-- End of Contacts info -->
                    </div>
                </div>
            </div>
        </div>
@stop

@section('js')
<script type="text/javascript">
    $.validate({form:$('#form-contact'),onSuccess:function(){


            let $this = $('#form-contact');

            $.ajax({
                url: $this.attr('action'),
                type:'POST',
                dataType:'Json',
                data:$this.serializeArray(),
                success:function(data){
                    if(data.message){
                        alert(data.message);
                    }

                    if( data.redirect ){
                        window.location.href = data.redirect;
                        window.location.reload();
                    }
                }
            });

            return false;
        }});
</script>
@stop