@extends(theme_extends())
<?php 
// Blogs
    $blogsOptions = theme_options('blogs',['title'=>'','description'=>'','background'=>'','sidebar'=>'']);
 ?>
@section('content')
<!-- Header Back -->
<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">{!!$blogsOptions['title']!!}</h1>
                        <h2 class="page-description">{!!$blogsOptions['description']!!}</h2>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Header Back -->
<div id="content">
    <div class="container">
        <div class="layout with-right-sidebar js-layout">
            <div class="row">
                <div class="col-md-9">
                    <div class="main-content">
                        <!-- Blog Page -->
                        <div class="blog">
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/5.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Consectetur adipisicing elit. Neque earum beatae ex est numquam!</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Reiciendis inventore culpa quo pariatur minima, voluptates hic eum vitae harum architecto similique, ipsa nam unde recusandae placeat assumenda! Repudiandae dolores.
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/6.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Ducimus iusto aperiam placeat sint reiciendis velit, id saepe nobis!</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Distinctio dolorem odit deleniti omnis voluptate porro non saepe excepturi dicta fugit incidunt unde ipsa ab mollitia at architecto, modi illum cumque.
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/4.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Molestias nam assumenda vero tenetur, libero sed distinctio in. Quibusdam!</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Quo quia praesentium unde voluptate porro hic ea rerum consectetur ducimus maiores, quos non veritatis ipsam aliquid. Corporis veritatis, illo repudiandae praesentium?
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/2.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Ea dolore quaerat aut deleniti illo sed ratione, ipsam debitis.</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Praesentium beatae aliquam quia eligendi omnis vel tenetur tempore? Unde reiciendis exercitationem dolor repudiandae quam repellendus assumenda maxime labore, a fugiat id.
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/1.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Consectetur adipisicing elit. Neque earum beatae ex est numquam!</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Veritatis quia provident, magnam nobis id, adipisci laudantium. Dolor error minima, fuga. Enim, perspiciatis praesentium distinctio reiciendis. Recusandae culpa aut odit.
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <!-- Blog Grid -->
                                    <div class="blog-grid">
                                        <div class="blog-grid-image">
                                            <a href="article.html">
                                                <span class="blog-grid-image-over"></span>
                                                <img src="@theme_asset()img/blog/3.jpg" class="" alt="article image">
                                            </a>
                                        </div>
                                        <h3 class="blog-grid-title">
                                            <a href="article.html">Ducimus iusto aperiam placeat sint reiciendis velit, id saepe nobis!</a>
                                        </h3>
                                        <p class="blog-grid-excerpt">
                                            Recusandae beatae iste numquam ea neque adipisci, error quis aut illo magni unde aliquid vero mollitia fugit repudiandae, cupiditate! Aspernatur, quos, enim.
                                        </p>
                                        <div class="blog-grid-meta">
                                            <span class="blog-grid-date">October 28, 2015</span>
                                            <span class="blog-grid-author">by <a href="#">John Doe</a></span>
                                        </div>
                                    </div>
                                    <!-- End of Blog Grid -->
                                </div>
                            </div>
                        </div>
                        <!-- End of Blog Page -->
                    </div>
                </div>
                <div class="col-md-3 hidden-sm hidden-xs">
                    <div class="sidebar js-sidebar-fixed">
                        <!-- Vertical Menu -->
                        <nav class="menu-vertical-wrapper">
                            {!!vn4_nav_menu_db($blogsOptions['sidebar'],null,['container_class'=>'menu-vertical  js-menu-vertical'])!!}
                        </nav>
                        
                        <div class="widget">
                            <h3 class="widget-title">Tags</h3>
                            <!-- Tags -->
                            <ul class="tags">
                                <li class="tag-item"><a href="#">html</a></li>
                                <li class="tag-item"><a href="#">css</a></li>
                                <li class="tag-item"><a href="#">javascript</a></li>
                                <li class="tag-item"><a href="#">jquery</a></li>
                                <li class="tag-item"><a href="#">less</a></li>
                                <li class="tag-item"><a href="#">sass</a></li>
                                <li class="tag-item"><a href="#">haml</a></li>
                                <li class="tag-item"><a href="#">gulp</a></li>
                            </ul>
                            <!-- End of Tags -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop