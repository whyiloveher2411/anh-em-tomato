@extends(theme_extends())
<?php 
// About
    add_body_class('functional');

    // $plugin = App\Model\CMSBlogTag::getPosts(['count'=>1]);

    // dd($plugin[0]->CMSBlogs()A);
 ?>
@section('content')

        <div class="header-back header-back-simple header-back-small">
            <div class="header-back-container">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Page Info -->
                            <div class="page-info page-info-simple">
                                <h1 class="page-title">{!!$post->banner_title!!}</h1>
                                <h2 class="page-description">{!!$post->banner_description!!}</h2>
                            </div>
                            <!-- End Page Info -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End of Header Back -->
        <div id="content">
            <div class="container">
            <?php 
                $section = $post->section;
             ?>
                @forswitch($section as $s)
                    @is('our-vision')
                    <div class="promo-title-wrapper helper pt60">
                        <h3 class="promo-title" data-icon="">
                            {!!$s['title']!!}
                        </h3>
                        <p class="promo-description">
                            {!!$s['content']!!}
                        </p>
                    </div>
                    @endis
                    @is('what-we-do')
                    <div class="promo-title-wrapper helper pt60">
                        <h3 class="promo-title" data-icon="" style="text-align: left;font-weight: bold;">
                             {!!$s['title']!!}
                        </h3>
                        <div class="row">

                            @foreach($s['content'] as $c)
                            @if(!$c['delete'])
                            <div class="col-xs-6 service-item">
                                <div class="service-item-warp">
                                    <img src="{!!get_media($c['image'])!!}">
                                    <div class="content-service">
                                        <h4>{!!$c['title']!!}</h4>
                                        <p>{!!$c['description']!!}</p>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @endforeach
                        </div>
                    </div>
                    @endis
                    @is('our-team')
                    <div class="promo-title-wrapper helper pt60">
                        <div class="row">
                            <h3 class="col-md-4 promo-title" style="text-align: left;font-weight: bold;">
                                {!!$s['title']!!}
                            </h3>
                            <p class="col-md-8">
                                {!!$s['description']!!}
                            </p>
                        </div>
                        <br>
                        <br>
                        <br>
                        <div class="row">
                        @foreach($s['content'] as $c)
                            <div class="col-md-6 col-sm-6">
                                <!-- Testimonials -->
                                <div class="testimonial">
                                    <div class="testimonial-photo-wrapper">
                                        <img src="{!!get_media($c['avatar'])!!}" class="testimonial-photo" alt="Person's Photo">
                                    </div>
                                    <h4 class="testimonial-name">{!!$c['name']!!}</h4>
                                    <p class="testimonial-text">{!!$c['description']!!}</p>
                                </div>
                                <!-- End of Testimonials -->
                            </div>
                        @endforeach
                        </div>
                    </div>
                    @endis
                    @is('brands')
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Promo Title -->
                            <div class="promo-title-wrapper ">
                                <h3 class="promo-title" data-icon="">
                                    {!!$s['title']!!}
                                </h3>
                                <p class="promo-description">
                                   {!!$s['description']!!}
                                </p>
                            </div>
                            <!-- End of Promo Title -->
                            <!-- Brands -->
                            <ul class="brands ">
                            @foreach($s['content'] as $c)
                                <li class="brand-item">
                                    <a href="#" class="brand-item-link">
                                        <img src="{!!get_media($c['logo'])!!}" class="brand-item-image" alt="brand logo">
                                    </a>
                                </li>
                            @endforeach
                            </ul>
                        </div>
                    </div>
                    @endis
                @endforswitch
            </div>
        </div>
@stop
    