<?php   
    // Home Page

    $banner = $post->banner;

    $section = $post->section;
 ?>



@extends(theme_extends())

@section('content')

@if($banner)

 <div class="header-back header-back-default header-back-full-page js-full-page" style="background-image: url({!!get_media($banner['background'])!!});">

    <div class="header-back-container">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <!-- Page Info -->

                    <div class="page-info helper center">

                        <h1 class="page-title">{!!$banner['title']!!}</h1>

                        <h2 class="page-description">{!!$banner['description']!!}</h2>

                    </div>

                    <!-- End Page Info -->

                </div>

            </div>

        </div>

    </div>

</div>

@endif





 <div id="content">

@forswitch($section as $i => $s)
    @is('promo-1')

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <!-- Promo Title -->

                <div class="promo-title-wrapper helper pt60">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <p class="promo-description">

                        {!!$s['description']!!}

                    </p>

                </div>

                <!-- End of Promo Title -->

                <div class="row" style="display: flex;display: -webkit-flex;flex-wrap: wrap;">



                    @forif($s['items'] as $i)

                    <div class="col-md-6">

                        <!-- Box -->

                        <div class="box box-small-icon-alt">

                            <i class="{!!$i['icon']!!}"></i>

                            <h4 class="box-title">{!!$i['title']!!}</h4>

                            <p class="box-description">{!!$i['description']!!}</p>

                        </div>

                        <!-- End of Box -->

                    </div>

                    @endforif



                </div>

                

            </div>

        </div>

    </div>

    @endis

    @is('promo-2')

    <div class="background-gradient-grey">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <!-- Promo Title -->

                    <div class="promo-title-wrapper ">

                        <h3 class="promo-title" data-icon="">

                            {!!$s['title']!!}

                        </h3>

                        <p class="promo-description">

                            {!!$s['description']!!}

                        </p>

                    </div>

                    <!-- End of Promo Title -->

                </div>

            </div>

        </div>

        <div class="container-fluid">

            <div class="row">

                <div class="col-md-12">

                    <div class="helper center mb60">

                        <a href="{!!$s['link']!!}" class="btn-open-purchase reguest-demo-button button blue stroke rounded button-icon button-icon-right">

                            {!!$s['label-button']!!}

                            <i class="fa fa-angle-right"></i>

                        </a>

                    </div>

                    <div class="helper center pb60">

                        <img src="{!!get_media($s['image'])!!}" class="image remove-border" alt="macbook and a clock">

                    </div>

                </div>

            </div>

        </div>

    </div>

    @endis

    @is('promo-3')

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <!-- Promo Title -->

                <div class="promo-title-wrapper ">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <p class="promo-description">

                        {!!$s['description']!!}

                    </p>

                </div>

                <!-- End of Promo Title -->

                <!-- Featured Boxes -->

                <ul class="featured-boxes">



                    @forif($s['items'] as $i)

                    <li class="featured-boxes-item">

                        <img src="{!!get_media($i['image'])!!}" class="featured-boxes-item-ico" alt="featured-boxes image">

                        <h4 class="featured-boxes-item-title">{!!$i['title']!!}</h4>

                        <p class="featured-boxes-item-description">{!!$i['description']!!}</p>

                        @if($i['link'])
                        <a href="{!!$i['link']!!}" class="featured-boxes-item-button button blue stroke rounded">
                            @__t('Explore more')
                        </a>
                        @endif

                    </li>

                    @endforif

                   

                </ul>

                <!-- End of Featured Boxes -->

            </div>

        </div>

    </div>

    @endis

    @is('promo-4')

    <div class="container-fluid">

        <div class="row">

            <div class="col-md-12">

                <!-- Video section -->

                <div class="video-section video-section-fullwidth ">

                    <img src="{!!get_media($s['background'])!!}" alt="" class="video-section-button-img js-video-trigger" data-video="&lt;iframe src=&quot;{!!$s['video']!!}&quot; width=&quot;500&quot; height=&quot;510&quot; frameborder=&quot;0&quot; webkitallowfullscreen mozallowfullscreen allowfullscreen&gt;&lt;/iframe&gt;">

                </div>

                <!-- Endd  of Video section -->

                <!-- Video Trigger Modal -->

                <div class="js-video-trigger-modal video-trigger-modal">

                    <div class="js-video-trigger-modal-content video-trigger-modal-content"></div>

                </div>

                <!-- End of Video Trigger Modal -->

            </div>

        </div>

    </div>

    @endis

    @is('promo-5')

    <div class="container section-our-plan">

        <div class="row">

            <div class="col-md-12">

                <!-- Promo Title -->

                <div class="promo-title-wrapper ">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <p class="promo-description">

                       {!!$s['description']!!}

                    </p>

                </div>

                <!-- End of Promo Title -->

                <div class="row">



                    @forif($s['items'] as $i)

                    <div class="col-md-4 col-sm-6">

                        <!-- Price List -->

                        <div class="price-list">

                            <h3 class="price-list-title">{!!$i['title']!!}</h3>

                            <p class="price-list-price">{!!$i['price']!!}</span></p>

                            <ul class="price-list-features">



                                @forif($i['contens'] as $c)

                                <li class="price-list-feature-item ">

                                    {!!$c['title']!!}

                                </li>

                                @endforif

                             

                            </ul>

                            <a href="#" class="price-list-button">@__t('Choose a plan')</a>

                        </div>

                        <!-- End of Price List -->

                    </div>

                    @endforif

                   

                </div>

            </div>

        </div>

    </div>

    @endis

    @is('promo-6')

    <div class="container section-our-plan">

        <div class="row">

            <div class="col-md-12">

                 <!-- Promo Title -->

                <div class="promo-title-wrapper ">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <!-- <p class="promo-description">

                        Reiciendis quasi ipsum, expedita soluta hic, minima voluptates deserunt odio temporibus obcaecati amet, culpa vel. Beatae, quisquam!

                    </p> -->

                </div>

                <!-- End of Promo Title -->

                <div class="row">



                    @forif($s['items'] as $i)

                    <div class="col-md-6 col-sm-6">

                        <!-- Testimonials -->

                        <div class="testimonial">

                            <div class="testimonial-photo-wrapper">

                                <img src="{!!get_media($i['avatar'])!!}" class="testimonial-photo" alt="Person&#39;s Photo">

                            </div>

                            <h4 class="testimonial-name">{!!$i['name']!!}</h4>

                            <p class="testimonial-text">{!!$i['description']!!}</p>

                        </div>

                        <!-- End of Testimonials -->

                    </div>

                    @endforif



                </div>

            </div>

        </div>

    </div>

    @endis

    @is('promo-7')

    <div class="container section-our-plan">

        <div class="row">

            <div class="col-md-12">

                <!-- Promo Title -->

                <div class="promo-title-wrapper ">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <p class="promo-description">

                       {!!$s['description']!!}

                    </p>

                </div>

                <!-- End of Promo Title -->

                <!-- Brands -->

                <ul class="brands ">



                    @forif($s['items'] as $i)

                    <li class="brand-item">

                        <a href="#" class="brand-item-link">

                            <img src="{!!get_media($i['logo'])!!}" class="brand-item-image" alt="brand logo">

                        </a>

                    </li>

                    @endforif



                </ul>

            </div>

        </div>

    </div>

    @endis

    @is('promo-8')

    <!-- Call to Action -->

    <div class="call-to-action helper mt60">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <h3 class="call-to-action-title">

                        {!!$s['title']!!}

                    </h3>

                    <p class="call-to-action-description">

                       {!!$s['description']!!}

                    </p>

                    <div class="call-to-action-buttons">

                        <a href="{!!get_link($s['link'])!!}" class="call-to-action-button">{!!$s['label-button']!!}</a>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- End of Call to Action -->

    @endis

    @is('promo-9')

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <!-- Promo Title -->

                <div class="promo-title-wrapper promo-title-no-icon">

                    <h3 class="promo-title" data-icon="">

                        {!!$s['title']!!}

                    </h3>

                    <p class="promo-description">

                        {!!$s['description']!!}

                    </p>

                </div>

                <!-- End of Promo Title -->

                <div class="row">



                    @forif($s['items'] as $i)

                    <div class="col-md-4">

                        <!-- FAQ Grid -->

                        <div class="faq-grid">

                            <h4 class="faq-grid-question">{!!$i['title']!!}</h4>

                            <p class="faq-grid-answer">{!!$i['description']!!}</p>

                        </div>

                        <!-- End of FAQ Grid -->

                    </div>

                    @endforif

                    

                </div>

                <div class="row">

                    <div class="col-md-12">

                        <div class="helper center">

                            <a href="{!!get_link($s['link'])!!}" class="faq-grid-show-more">{!!$s['label-button']!!} <i class="fa fa-angle-right"></i></a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    @endis
@endforswitch
</div>

@stop