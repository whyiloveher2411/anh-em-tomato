@extends(theme_extends())
<?php 
// FAQ
    add_body_class('functional');
 ?>
@section('content')

<div class="header-back header-back-simple header-back-small">
    <div class="header-back-container">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Page Info -->
                    <div class="page-info page-info-simple">
                        <h1 class="page-title">{!!$post->banner_title!!}</h1>
                        <h2 class="page-description">{!!$post->banner_description!!}</h2>
                    </div>
                    <!-- End Page Info -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End of Header Back -->

<div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <!-- Category Info -->

                <?php 
                    $category = $post->category;
                 ?>

                 @forif($category as $f)
                <div class="category-info helper pt0" id="instant-search">
                    <h3 class="category-title">
                      {!!$f['title']!!}
                    </h3>
                </div>
                <!-- Faq -->

                <ul class="faq js-faq" id="my-faq">
                  @forif($f['qa'] as $f2)
                    <li class="faq-item">
                        <h4 class="faq-question">
                          {!!$f2['question']!!}
                        </h4>
                        <div class="faq-answer">
                            {!!$f2['anwser']!!}
                        </div>
                    </li>
                    @endforif
                </ul>
                @endforif


                 
                

              
            </div>
        </div>
    </div>
</div>
@stop
