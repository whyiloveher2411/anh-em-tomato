@extends(theme_extends())
<?php 
    header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");

    $detailVersion = $post;

    $post = $detailVersion->relationship('product');
    $product_type = $post->relationship('product_type');
    $version = $post->related('cms_product_version','product',['count'=>1]);
    $categories = json_decode($post->category);

    $author = json_decode($post->cms_user_detail,true);

 ?>
@section('content')
<style type="text/css">
    .pagination {
        margin-top: 25px;
        padding-left: 0;
        list-style: none;
        border-radius: .25rem;
        text-align: right;
    }
    .pagination li{
        box-sizing: border-box;
        display: inline-block;
    }
    .pagination a {
        position: relative;
        display: block;
        padding: .5rem .75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #007bff;
        background-color: #fff;
        border: 1px solid #dee2e6;
    }
    .pagination .active a {
        z-index: 1;
        color: #fff;
        background-color: #0084BA;
        border-color: #0084BA;
    }
    .has-error .checkbox, .has-error .checkbox-inline, .has-error .control-label, .has-error .form-control-feedback, .has-error .help-block, .has-error .radio, .has-error .radio-inline, .has-error.checkbox label, .has-error.checkbox-inline label, .has-error.radio label, .has-error.radio-inline label{
        bottom: -18px;
        font-size: 12px;
    }
    .product-support{
        border-left: 5px solid #f06723;
    }
    .tb-v td, .tb-v th{
        padding-bottom: 20px;
    }
    .product-support th{
        position: relative;
        padding-top: 25px;
    }
    .product-support td{
        padding-top: 30px;
    }
    .product-support th:before{
        content: "@__t('Support')";
        display: inline-block;
        padding: 5px 10px;
        background: #f06723;
        color: white;
        position: absolute;
        top: -2px;
        left: -5px;
        white-space: nowrap;  
       
    }
    .contacts-item{
        margin-bottom: 10px;
    }
    form .skill-level li:hover{
        cursor: pointer;
    }
    
</style>
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                {!!get_particle('particle.nav-product',['post'=>$post,'author'=>$author, 'product_type'=>$product_type,'categories'=>$categories,'version'=>$version])!!}
            </div>
            <div class="col-md-9" style="border-left: 1px solid #ecf0f1;padding-left: 0;">
                <div class="page-info page-info-simple" style="padding-left: 30px;">
                    <div class="thumbnail" style="float: left;margin-right: 20px;height: 150px;">
                        <img src="{!!get_media($post->thumbnail)!!}">
                    </div>
                    @if(isset($version[0]))
                    <form method="POST" action="{!!route('post',['download','index','id'=>$version[0]->id])!!}">
                        <input type="hidden" name="_token" value="{!!csrf_token()!!}">
                        <input type="submit" name="download" value="@__t('Download')" style="display: inline-block;float: right;margin-top: 10px;" class="button small blue">
                    </form>
                    @endif
                    <h1 class="page-title" style="font-size: 40px;margin-bottom: 0px;line-height: 42px;"><a href="{!!get_permalinks($post)!!}">{!!$post->title!!}</a></h1>
                    
                    <p>{!!$post->description!!}</p>
                    <div style="clear: both;"></div>
                    
                </div>

                <hr>

                <div style="padding: 30px;">
                    {!!$detailVersion->content!!}
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">


        $(':input, textarea').change(function(){
            if($(this).val().trim()){
                $(this).addClass('valid')
            }else{
                $(this).removeClass('valid')
            }
        });


        $.validate({form:$('#form-review'),onSuccess:function(){


            let $this = $('#form-review');

            $.ajax({
                url: $this.attr('action'),
                type:'POST',
                dataType:'Json',
                data:$this.serializeArray(),
                success:function(data){
                    if(data.message){
                        alert(data.message);
                    }
                    if( data.reload ){
                        window.location.reload();
                    }
                    if( data.redirect ){
                        window.location.href = data.redirect;
                        window.location.reload();
                    }
                }
            });

            return false;
        }});


    </script>
@stop