 @extends(theme_extends())

<?php
    title_head($post->name); 

    $reviews = $post->related('cms_product_review','cms_user',['count'=>true]);

    $product_type = get_posts('cms_product_type',10);

    $showProduct = false;

    $productTemp = [];
    $productCount = [];

    foreach($product_type as $type){
        $productTemp[$type->id] = $type->related('cms_product','product_type',['callback'=>function($q) use($post){
            return $q->where('cms_user',$post->id);
        }]);

        if( isset($productTemp[$type->id][0]) ) $showProduct = true;

        $productCount[$type->id] = count($productTemp[$type->id]);
    }


    add_body_class('marketplace');
 ?>
@section('content')
<div class="header-back header-back-simple header-back-small header-holder">
    
</div>
<div id="content">
    <div class="container">
        <div class="row main">
            <div class="col-md-3">

                {!!get_particle('particle.nav-profile',['active'=>'profile','post'=>$post, 'reviews'=>$reviews,'product_type'=>$product_type, 'productTemp'=>$productCount,'notme'=>true])!!}



            </div>
            <div class="col-md-9 main-list" style="border-left: 1px solid #ecf0f1;padding-left: 0;">

                <!-- Tabs -->
                <div class="tabs js-tabs" style="padding-top: 30px;padding-left: 30px;border-top: 1px solid #ecf0f1;">

                    @foreach($product_type as $type)
                        @if( isset($productTemp[$type->id][0]) )
                        <h4 class="tab-title">
                            {!!$type->title!!}
                        </h4>
                        <div class="tab-content">
                            <div class="list row">
                                @foreach( $productTemp[$type->id]  as  $p)
                                <div class="item col-md-6">
                                    {!!get_particle('particle.template-'.$type->template_product,['post'=>$p])!!}
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endif
                    @endforeach

                    @if( !$showProduct )

                    <div class="tab-content">
                        <p style="text-align: center;">@__t('Product not found')</p>
                    </div>
                    @endif
                </div>
            </div>

        </div>
    </div>
</div>
@stop

@section('js')
    <script type="text/javascript">
        $('body').on('click','.accordion-title',function(t) {
            t.preventDefault();
            var n = $(this),
                i = n.closest(".accordion-item"),
                a = $(this).parent().find('.accordion-description');
            $(this).closest('.js-accordion').find('.accordion-item.active').not(i).removeClass("active");$(this).closest('.js-accordion').find('.accordion-description.active').not(a).stop().slideUp().removeClass("active");
            a.hasClass("active") ? (i.removeClass("active"), a.stop().slideUp().removeClass("active")) : (i.addClass("active"), a.stop().slideDown().addClass("active"));
        });

        var hash = window.location.href.substring(window.location.href.indexOf("#")+1);
        @if( Request::has('review') )
            setTimeout(function() {
                $('.steps li:nth-child('+(($('.tabs .tab-content[data-id="reviews"]').index() + 1)/2 )+') a').trigger('click');
            }, 1);
        @else


        if( $('.tabs .tab-content[data-id="'+hash+'"]') ){

            setTimeout(function() {
                $('.steps li:nth-child('+(($('.tabs .tab-content[data-id="'+hash+'"]').index() + 1)/2 )+') a').trigger('click');
            }, 1);
        }

        @endif


    </script>
@stop