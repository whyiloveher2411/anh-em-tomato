<div class="container">
    <div class="row">
        <div class="col-md-12" style="position: absolute;right: 0;text-align: right;top: 0; padding-right: 30px;">
        <?php 
            check_login_frontend(function($user){
                ?>
                <a href="{!!route('page','profile')!!}" style="line-height: 40px;">@__t('Hello') {!!$user->name!!}</a> | <a href="{!!route('post',['logout','index'])!!}" style="line-height: 40px;">@__t('Logout')</a>
                <?php
            },function(){
                ?>
                <a href="{!!route('page','login')!!}" style="line-height: 40px;">@__t('Login')</a>
                <?php
            });
         ?>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-5">
            <a href="{!!route('index')!!}" class="logo-image"><img src="{!!get_media(theme_options('general','logo'))!!}" alt="logo"></a>
            <?php 

                if( function_exists('the_languages') ){
                    $languages = the_languages();

                    if( count($languages) > 1 ){
                        $lang_current = App::getLocale();
                        $language_default = language_default();
                        ?>
                        <div class="languages  js-languages">
                        <span class="language-active js-language-active">{!!$languages[$lang_current]['lang_name']??$language_default['lang_name']!!} <i class="fa fa-angle-down"></i></span>
                            <ul class="languages-list js-languages-list" style="z-index:6;">
                            @foreach( $languages as $l )
                                <li><a href="{!!$l['url'].(http_build_query(Request::all())?'?'.http_build_query(Request::all()):'')!!}">{!!$l['lang_name']!!}</a></li>
                            @endforeach
                            </ul>
                        </div>
                        <?php
                    }
                }

             ?>
        </div>
        <div class="col-md-9 col-sm-6 col-xs-7">
            <nav class="right helper">
                {!!vn4_nav_menu('header','nav-header', ['container_class'=>'menu sf-menu js-menu'])!!}
            </nav>
        </div>
    </div>
</div>
