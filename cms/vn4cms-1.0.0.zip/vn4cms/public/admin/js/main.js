var isInIframe = (window.location != window.parent.location) ? true : false;

function show_loading(message = 'Loading') {

    if (message) {
        $('.popup-loadding .content span').text(message);
    }
    $('html').addClass('show-popup');
}

function show_message( message = 'Message' ) {
    if( message.title ){
        var d = new Date();
        var n = d.getTime();

        $('body').append('<div class="session-message session-message-'+n+' fadeIn"><div class="warpper" style="background-color:'+message.color+';"><div class="session-message-icon-wrapper"><i class="fa '+message.icon+'"></i></div><div class="session-message-body"><div class="session-message-title">'+message.title+'<div></div></div><div class="lobibox-notify-msg">'+message.content+'</div></div><i class="fa fa-times session-message-icon-close" aria-hidden="true"></i><div class="progress-bar"></div></div></div>');

        $(".session-message .progress-bar").animate({
            width: "100%"
        }, 10000, function() {
            $('.session-message-'+n+'').addClass('fadeInDown');
        });
    }else{
        if (message) {
            $('.vn4-message h4').html(message);
        }
        $('html').addClass('show-message');
    }
    

}

function hide_message() {
    $('html').removeClass('show-message');
}

$(document).on('click','.hide_message',function(){
    hide_message();
});

function hide_loading() {
    $('html').removeClass('show-popup');
}

function vn4_ajax(arg) {
    var url = window.location.href,
        dataType = 'Json',
        type = 'POST',
        data = {};
    if (arg['url']) {
        url = arg['url'];
    }

    if (arg['type']) {
        type = arg['type'];
    }

    if (arg['dataType']) {
        dataType = arg['dataType'];
    }

    data._token = $('#laravel-token').val();

    if (arg['data']) {

        for (var attrname in arg['data']) {
            data[attrname] = arg['data'][attrname];
        }

    }

    $.ajax({
            url: url,
            type: type,
            dataType: dataType,
            data: data,
            cache: false,
            beforeSend: function() {
                if (arg['show_loading']) {
                    show_loading();
                }
            },
            success: function(data) {

                if (arg['callback']) {
                    arg['callback'](data);
                }

                if (arg['default_handling'] == undefined || arg['default_handling']) {

                    if (data.url_redirect) {
                        window.location.href = data.url_redirect;
                    }

                    if( data.message ){
                        if (typeof data.message === 'string') {
                            alert(data.message);
                        }else{
                            show_message(data.message)
                        }
                    }
                    
                    if (data.reload) {
                        location.reload();
                    }


                    if (data.append) {
                        htmls = data.append;
                        for (i = 0; i < htmls.length; i++) {
                            $(htmls[i].selector).append(htmls[i].html);
                        }
                    }

                }
            },
            error: function(data) {
                if (arg['error_callback']) {
                    arg['error_callback'](data);
                }
            }

        }).fail(function(data) {

            if (arg['fail_callback']) {
                arg['fail_callback'](data);
            }

            console.log('vn4_ajax fail');
        })
        .always(function() {
            if (arg['show_loading']) {
                hide_loading();
            }
        });

}

$('body').on('click', '.ajax', function() {
    vn4_ajax({
        url: $(this).data('url'),
    });
});



function search($this) {
    $('.form-search .sub-menu').css({
        'display': 'block',
        'opacity': 1
    });
    $('.form-search .sub-menu').html('<p>...</p>');
    vn4_ajax({
        url: $this.data('url'),
        data: {
            search: $this.val()
        },
        callback: function(result) {
            if (result.data.length) {
                let warpper = $('.form-search .sub-menu ');

                warpper.empty();

                for (var i = 0; i < result.data.length; i++) {
                    warpper.append('<a href="' + result.data[i].link + '"><strong>[' + result.data[i].title_type + ']</strong> ' + result.data[i].title + '</a>');
                }

                warpper.append('<a style="text-align: center;border-top: 1px solid;line-height: 28px;" href="' + result.learn_more.link + '"><strong></strong> ' + result.learn_more.title + '</a>');
            } else {
                $('.form-search .sub-menu ').html('<p>Nothing</p>');
                 $('.form-search .sub-menu ').append('<a style="text-align: center;border-top: 1px solid;line-height: 28px;" href="' + result.learn_more.link + '"><strong></strong> ' + result.learn_more.title + '</a>');

            }


        }
    });
}

$(document).on('click','#inputSearch',function() {
    $('.form-search .sub-menu').css({
        'display': 'block',
        'opacity': 1
    });
});
$('#inputSearch').focusout(function() {
    // setTimeout(function() {
    $('.form-search .sub-menu').fadeTo(500, 0, function() {
        $('.form-search .sub-menu').hide();
    });
    // }, 1000);

});

$('body').on('click', '.form-search .fa', function(event) {
    search($('#inputSearch'));
});

$('body').on('keydown', '#inputSearch', function(event) {

    var keyCode = event.keyCode;

    if (keyCode == 13) {


        if ($('.form-search .sub-menu a.active').length) {

            if( ctrlDown ){
                window.open($('.form-search .sub-menu a.active').attr('href'));
                return;
            }

            window.location.href = $('.form-search .sub-menu a.active').attr('href');
            return;
        }

        search($(this));
    } else if (keyCode == 40) {
        event.preventDefault();
        if ($('.form-search .sub-menu a.active').length) {
            $('.form-search .sub-menu a.active').removeClass('active').next('a').addClass('active');
        } else {
            $('.form-search .sub-menu a:eq(0)').addClass('active');
        }
    } else if (keyCode == 38) {
        event.preventDefault();
        if ($('.form-search .sub-menu a.active').length) {
            $('.form-search .sub-menu a.active').removeClass('active').prev('a').addClass('active');
        } else {
            $('.form-search .sub-menu a:last-child').addClass('active');
        }
    } else if (keyCode != 17) {
        $('.form-search .sub-menu a.active').removeClass('active');
    }


});

if (!isInIframe) {

    var is_admin_page = document.getElementById("is_link_admin_vn4_cms");

    if (is_admin_page) {


        $(window).on("beforeunload", function() {
            if (window._formHasChanged && !window.submitted) {
                var message = "Are you sure? You didn't finish the form!",
                    e = e || window.event;
                if (e) {
                    e.returnValue = message;
                }
                return message;
            }
        });

        $(document).on('change', 'form', function() {
            window._formHasChanged = true;
        });

        $("form").submit(function() {
            window.submitted = true;
        });

        // $(document).on('submit','form')

        function loadScript(url, callback) {

            var script = document.createElement("script")
            script.type = "text/javascript";

            if (script.readyState) { //IE
                script.onreadystatechange = function() {
                    if (script.readyState == "loaded" ||
                        script.readyState == "complete") {
                        script.onreadystatechange = null;
                        callback();
                    }
                };
            } else { //Others
                script.onload = function() {
                    callback();
                };
            }

            script.src = url;
            document.getElementsByTagName("head")[0].appendChild(script);
        }



        $('body').on('click', '.onAjax', function(event) {

            event.preventDefault();
            event.stopPropagation();

            $url = $(this).data('url');

            vn4_ajax({
                'url': $url
            });
        });



        var CURRENT_URL = window.location.href.split('?')[0],
            $BODY = $('body'),
            $MENU_TOGGLE = $('.menu_toggle'),
            $SIDEBAR_MENU = $('#sidebar-menu'),
            $SIDEBAR_FOOTER = $('.sidebar-footer'),
            $LEFT_COL = $('.left_col'),
            $RIGHT_COL = $('.right_col'),
            $NAV_MENU = $('.nav_menu'),
            $FOOTER = $('footer');

        function resizeIframe(obj) {
            obj.style.height = obj.contentWindow.document.body.offsetHeight + 'px';
            hide_loading();
        }
        // Sidebar

        $(window).load(function() {
            setTimeout(function() {
                $('.data-iframe').each(function(index, el) {
                    $(el).append('<iframe style="width:100%;float:left;" onload="resizeIframe(this)" seamless frameborder="0" scrolling="no" src="' + $(el).data('url') + '"></iframe><div class="clearfix"></div>');
                });
            }, 10);
        });

        $(document).ready(function() {
            // TODO: This is some kind of easy fix, maybe we can improve this
            var setContentHeight = function() {
                // reset height

                $left_height = $('.left_col').height();

                $window_height = $(window).height();
                if ($left_height > $window_height) {
                    $RIGHT_COL.css('min-height', $left_height);
                } else {
                    $RIGHT_COL.css('min-height', $window_height);
                }



                // var bodyHeight = $BODY.outerHeight(),
                //     footerHeight = $BODY.hasClass('footer_fixed') ? 0 : $FOOTER.height(),
                //     leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
                //     contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

                // // normalize content
                // contentHeight -= $NAV_MENU.height() + footerHeight;

                // $RIGHT_COL.css('min-height', bodyHeight);
            };
            // $SIDEBAR_MENU.find('a').hover(function() {

            //     var $li = $(this).parent();
            //     // prevent closing menu if we are on child menu
            //     if (!$li.parent().is('.child_menu')) {
            //         $SIDEBAR_MENU.find('li').removeClass('active active-sm');
            //         $SIDEBAR_MENU.find('li ul').slideUp();
            //     }

            //     $li.addClass('active');

            //     $('ul:first', $li).slideDown(function() {
            //         setContentHeight();
            //     });
            // }, function() {
            //     var $li = $(this).parent();
            //      $li.removeClass('active active-sm');
            //     $('ul:first', $li).slideUp(function() {
            //         setContentHeight();
            //     });

            // });
            $SIDEBAR_MENU.find('a').on('click', function(ev) {

                var $li = $(this).parent();

                if ($li.is('.active')) {
                    $li.removeClass('active active-sm');
                    $('ul:first', $li).slideUp(function() {
                        setContentHeight();
                    });
                } else {
                    // prevent closing menu if we are on child menu
                    if (!$li.parent().is('.child_menu')) {
                        $SIDEBAR_MENU.find('li').removeClass('active active-sm');
                        $SIDEBAR_MENU.find('li ul').slideUp();
                    }

                    $li.addClass('active');

                    $('ul:first', $li).slideDown(function() {
                        setContentHeight();
                    });
                }
            });

            // toggle small or large menu
            $MENU_TOGGLE.on('click', function() {
                if ($BODY.hasClass('nav-md')) {
                    $SIDEBAR_MENU.find('li.active ul').hide();
                    $SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
                } else {
                    $SIDEBAR_MENU.find('li.active-sm ul').show();
                    $SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
                }

                $BODY.toggleClass('nav-md nav-sm');

                setContentHeight();
            });

            // check active menu
            $SIDEBAR_MENU.find('a[href="' + CURRENT_URL + '"]').parent('li').addClass('current-page');

            $SIDEBAR_MENU.find('a:not(.menu_toggle)').filter(function() {
                return this.href == CURRENT_URL || $(this).hasClass('current-link');
            }).parent('li').addClass('current-page').parents('ul').show(0, function() {
                setContentHeight();
            }).parent().addClass('active');

            // recompute content when resizing
            $(window).smartresize(function() {
                setContentHeight();
            });


            setContentHeight();

            // fixed sidebar
            if ($.fn.mCustomScrollbar) {
                $('.menu_fixed').mCustomScrollbar({
                    autoHideScrollbar: true,
                    theme: 'minimal',
                    mouseWheel: {
                        preventDefault: true
                    }
                });
            }
        });
        // /Sidebar

        // Panel toolbox
        $(document).ready(function() {
            $(document).on('click', '.x_panel .collapse-link', function(event) {
                event.stopPropagation();
                event.preventDefault();
                var $BOX_PANEL = $(this).closest('.x_panel'),
                    $ICON = $(this).find('i'),
                    $BOX_CONTENT = $BOX_PANEL.find('.x_content:first');

                // fix for some div with hardcoded fix class

                $BOX_CONTENT.slideToggle(200);
                // if ($BOX_PANEL.attr('style')) {

                // 	$BOX_CONTENT.slideToggle(200, function(){
                // 		$BOX_PANEL.removeAttr('style');
                // 	});


                // } else {
                // 	$BOX_CONTENT.slideToggle(200); 

                // 	$BOX_PANEL.css({'height':'auto','padding-bottom':'0' });  

                // }

                $ICON.toggleClass('fa-chevron-up fa-chevron-down');
            });

            $(document).on('click','.close-link',function() {
                var $BOX_PANEL = $(this).closest('.x_panel');

                $BOX_PANEL.remove();
            });
        });
        // /Panel toolbox

        // Tooltip
        // $(document).ready(function() {
        // 	$('[data-toggle="tooltip"]').tooltip({
        // 		container: 'body'
        // 	});
        // });
        // /Tooltip

        // Progressbar
        if ($(".progress .progress-bar")[0]) {
            $('.progress .progress-bar').progressbar();
        }
        // /Progressbar

        // Switchery
        $(document).ready(function() {
            if ($(".js-switch")[0]) {
                var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
                elems.forEach(function(html) {
                    var switchery = new Switchery(html, {
                        color: '#26B99A'
                    });
                });
            }
        });
        // /Switchery

        // iCheck
        $(document).ready(function() {
            if ($("input.flat")[0]) {
                $(document).ready(function() {
                    $('input.flat').iCheck({
                        checkboxClass: 'icheckbox_flat-green',
                        radioClass: 'iradio_flat-green'
                    });
                });
            }
        });
        // /iCheck

        // Table
        $('table input').on('ifChecked', function() {
            checkState = '';
            $(this).parent().parent().parent().addClass('selected');
            countChecked();
        });
        $('table input').on('ifUnchecked', function() {
            checkState = '';
            $(this).parent().parent().parent().removeClass('selected');
            countChecked();
        });

        var checkState = '';

        $('.bulk_action input').on('ifChecked', function() {
            checkState = '';
            $(this).parent().parent().parent().addClass('selected');
            countChecked();
        });
        $('.bulk_action input').on('ifUnchecked', function() {
            checkState = '';
            $(this).parent().parent().parent().removeClass('selected');
            countChecked();
        });
        $('.bulk_action input#check-all').on('ifChecked', function() {
            checkState = 'all';
            countChecked();
        });
        $('.bulk_action input#check-all').on('ifUnchecked', function() {
            checkState = 'none';
            countChecked();
        });

        function countChecked() {
            if (checkState === 'all') {
                $(".bulk_action input[name='table_records']").iCheck('check');
            }
            if (checkState === 'none') {
                $(".bulk_action input[name='table_records']").iCheck('uncheck');
            }

            var checkCount = $(".bulk_action input[name='table_records']:checked").length;

            if (checkCount) {
                $('.column-title').hide();
                $('.bulk-actions').show();
                $('.action-cnt').html(checkCount + ' Records Selected');
            } else {
                $('.column-title').show();
                $('.bulk-actions').hide();
            }
        }

        // Accordion
        $(document).ready(function() {
            $(".expand").on("click", function() {
                $(this).next().slideToggle(200);
                $expand = $(this).find(">:first-child");

                if ($expand.text() == "+") {
                    $expand.text("-");
                } else {
                    $expand.text("+");
                }
            });
        });

        // NProgress
        if (typeof NProgress != 'undefined') {
            $(document).ready(function() {
                NProgress.start();
            });

            $(window).load(function() {
                NProgress.done();
            });
        }
        /**
         * Resize function without multiple trigger
         * 
         * Usage:
         * $(window).smartresize(function(){  
         *     // code here
         * });
         */
        (function($, sr) {
            // debouncing function from John Hann
            // http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
            var debounce = function(func, threshold, execAsap) {
                var timeout;

                return function debounced() {
                    var obj = this,
                        args = arguments;

                    function delayed() {
                        if (!execAsap)
                            func.apply(obj, args);
                        timeout = null;
                    }

                    if (timeout)
                        clearTimeout(timeout);
                    else if (execAsap)
                        func.apply(obj, args);

                    timeout = setTimeout(delayed, threshold || 100);
                };
            };

            // smartresize 
            jQuery.fn[sr] = function(fn) {
                return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr);
            };

        })(jQuery, 'smartresize');



        function replaceUrlParam(url, paramName, paramValue) {
            if (paramValue == null)
                paramValue = '';
            var pattern = new RegExp('\\b(' + paramName + '=).*?(&|$)');
            if (url.search(pattern) >= 0) {
                return url.replace(pattern, '$1' + paramValue + '$2');
            }
            return url + (url.indexOf('?') > 0 ? '&' : '?') + paramName + '=' + paramValue;
        }

        function removeParam(key, sourceURL) {
            var rtn = sourceURL.split("?")[0],
                param,
                params_arr = [],
                queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
            if (queryString !== "") {
                params_arr = queryString.split("&");
                for (var i = params_arr.length - 1; i >= 0; i -= 1) {
                    param = params_arr[i].split("=")[0];
                    if (param === key) {
                        params_arr.splice(i, 1);
                    }
                }
                rtn = rtn + "?" + params_arr.join("&");
            }
            return rtn;
        }

        function url_value(url, k) {

            var params = url.split('?');
            if (params[1]) {
                params = params[1].split('&');
                for (var i = 0; i < params.length; i++) {
                    var temp = params[i].split('=');
                    var key = temp[0];
                    var value = temp[1];

                    if (k == key) {
                        return value;
                    }

                }

                return null;

            }

            return null;

        }


        function get_val_checkbox(select) {
            return list_object = $(select + ':checked').map(function(index, el) {
                return $(el).val();
            }).get();

        }


        $(document).on('click','#backUrl',function() {
            window.history.back();
        });


        function clickIconTopnav() {
            $('.topnav').toggleClass('responsive');
        }

        $(document).on('click','.iconbacktotop',function(e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 700);
        });

        WebFontConfig = {
            google: {
                families: ['Roboto::latin,latin-ext']
            }
        };

        $(document).on('click','.trigger_fullscreen',function(event) {
            if ((document.fullScreenElement && document.fullScreenElement !== null) ||
                (!document.mozFullScreen && !document.webkitIsFullScreen)) {
                if (document.documentElement.requestFullScreen) {
                    document.documentElement.requestFullScreen();
                } else if (document.documentElement.mozRequestFullScreen) {
                    document.documentElement.mozRequestFullScreen();
                } else if (document.documentElement.webkitRequestFullScreen) {
                    document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
                }
            } else {
                if (document.cancelFullScreen) {
                    document.cancelFullScreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitCancelFullScreen) {
                    document.webkitCancelFullScreen();
                }
            }
        });

        $('body').on('click','.session-message-icon-close, .warpper',function(event) {
            $(this).closest('.session-message').addClass('fadeInDown');
        });



        $(".session-message .progress-bar").animate({
            width: "100%"
        }, 10000, function() {
            $('.session-message').addClass('fadeInDown');
        });



        $(document).on('click', '.not-href', function(event) {
            event.preventDefault();
        });

        $(document).on('click','.btn-open-toggle',function(event) {
            $($(this).attr('data-toggle')).slideDown('fast');
            $(this).css({
                display: 'none'
            });
        });

        $(document).on('click','.cancel-open-toggle',function(event) {
            $(this).closest('.warpper-toggle').slideUp('fast');
            $($(this).attr('data-toggle')).css({
                display: 'inline'
            });
        });

        $(document).on('click','.screen-warp-button button',function(event) {


            $('.screen-warp-button button.active:not(#' + $(this).attr('id') + ')').removeClass('active');

            $(this).toggleClass('active');

            $('#screen-meta .screen-meta-warp.active').removeClass('active').slideUp('fast');

            if ($(this).hasClass('active')) {
                $('#screen-meta .screen-meta-warp.' + $(this).attr('aria-controls')).addClass('active').slideToggle('fast');
            }

        });


        $(document).on('click','.contextual-help-tabs li a',function(event) {
            $('.contextual-help-tabs li.active').removeClass('active');
            $(this).closest('li').addClass('active');

            $('.contextual-help-tabs-wrap .active').removeClass('active');
            $('.contextual-help-tabs-wrap .' + $(this).attr('aria-controls').trim()).addClass('active');
        });

        //tabs
        $(document).on('click', '.vn4_tabs_left  .menu-left li a', function(event) {

            event.preventDefault();
            window.history.pushState("object or string", "Page", replaceUrlParam(window.location.href, 'vn4-tab-left-' + ($(this).closest('.vn4_tabs_left').data('id')), $(this).attr('aria-controls')));
            if ($(this).hasClass('new-link')) {
                window.location.reload();
                return;
            }

            $(this).closest('.vn4_tabs_left').find('.menu-left li.active').removeClass('active');
            $(this).closest('li').addClass('active');

            $(this).closest('.vn4_tabs_left').find('>.content-right>.tab.active').removeClass('active');
            $(this).closest('.vn4_tabs_left').find('>.content-right>.tab.content-tab-' + $(this).attr('aria-controls').trim()).addClass('active');

        });

        $(document).on('click', '.vn4_tabs_top .menu-top a', function(event) {

            event.preventDefault();
            if ($(this).hasClass('drop-menu')) {
                return;
            }
            window.history.pushState("object or string", "Page", replaceUrlParam(window.location.href, 'vn4-tab-top-' + ($(this).closest('.vn4_tabs_top').data('id')), $(this).attr('aria-controls')));

            if ($(this).hasClass('new-link')) {
                window.location.reload();
                return;
            }

            $(this).closest('.menu-top').find('a.active').removeClass('active');

            $(this).addClass('active');

            if ($(this).closest('div').hasClass('dropdown')) {
                $(this).closest('div').find('>a').addClass('active');
            }

            if ($(this).attr('aria-controls')) {
                $(this).closest('.vn4_tabs_top').find('>.content-bottom>.active').removeClass('active');
                $(this).closest('.vn4_tabs_top').find('>.content-bottom>.tab-content-' + $(this).attr('aria-controls').trim()).addClass('active');
            }

        });

        $('body').on('click', '.open-loading', function() {
            show_loading();
        });
        
        var ctrlDown = false,shiftDown = false,altDown = false,
            ctrlKey = 17,
            altKey = 18,
            cmdKey = 91,
            shiftkey = 16,
            dkey = 68,
            vKey = 86,
            pkey = 80,
            fkey = 70,
            cKey = 67;
            position = 0;

        $(window).keydown(function(e) {
        	// alert(e.keyCode);
        	if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
        	if (e.keyCode == altKey) altDown = true;
        	if( e.keyCode == shiftkey ) shiftDown = true;
        	// if( altDown && e.keyCode == fkey ){
        	// 	$('.quan_table_filter input[type=search]').focus();
        	// 	e.preventDefault();
         //  		e.stopPropagation();
        	// }

        	// if( altDown && e.keyCode == dkey ){
        	// 	$('#vn4debug').trigger('click');

        	// 	if( $('#vn4debug').hasClass('active') ){
        	// 	 $('html,body').animate({ scrollTop: 0 }, 'fast');
        	// 	}
        	// 	e.preventDefault();
         //  		e.stopPropagation();
        	// }

        	//keypress F
        	if( ctrlDown && e.keyCode == 70 ){
        		$('#inputSearch').focus();
        		$('.form-search .sub-menu').css({
			        'display': 'block',
			        'opacity': 1
			    });
        		e.preventDefault();
          		e.stopPropagation();
        	}

        	// if( ctrlDown && shiftDown && e.keyCode == pkey ){


        	// 	template = '<div id="popup-info-theme" class="modal fade in" role="dialog" style="display: block;"><div class="modal-dialog" style="left: 50%;transform: translate(-50%,0%);margin: 0;max-width:1100px;width:auto;padding:10px;padding-top: 40px;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">×</button><h4 class="modal-title theme-name">Eleven</h4></div><div class="modal-body"><div class="col-sm-6 col-xs-12"><img class="img-theme" src="http://vn4cms.com/cms/resources/views/theme/eleven/screenshot.png" alt=""></div><div class="col-sm-6 col-xs-12 theme-detail"><p class="name"><span class="theme-name" style="font-size: 33px;color: #000;">Eleven</span> Phiên bản: <span class="version">1.0</span></p><p class="author">By <a class="theme-author" href="dangthuyenquan@gmail.com">Quân Đặng</a></p><p class="theme-description" style="color:#797979;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><hr><p class="tags"><strong style="color: #444">Thẻ:</strong> <span class="theme-tags">vn4 theme</span></p></div><div class="clearfix"></div></div><div class="modal-footer" style="text-align: center;"><button type="submit" name="general_client_theme" value="eleven" class="vn4-active-theme vn4-btn vn4-btn-blue" style="display: none;"><i class="fa fa-user"> </i> Kích hoạt </button><button type="button" class="vn4-btn vn4-btn-red delete-theme" value="eleven" style="display: none;"> <i class="fa fa-trash"> </i> Xóa</button><button type="button" class="vn4-btn" data-dismiss="modal">Close</button></div></div></div></div>';
        	// 	$('body').append(template);
        	// 	e.preventDefault();
         //  		e.stopPropagation();
        	// }

        });

        $(window).keyup(function(e) {
        	// console.log(e.keyCode);
             if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;
             if (e.keyCode == shiftkey ) shiftDown = false;
             if (e.keyCode == altKey ) altDown = false;



        });

        // editor.on('keydown', function(e) {
        //     if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
        //     if( e.keyCode == vKey &&  ctrlDown ){
        //       e.preventDefault();
        //       e.stopPropagation();
        //     }
        // });

        // editor.on('keyup', function(e) {
        //      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;

        // });

        // editor.on('keypress',function(e){
        //   console.log(e);
        // });

      $('[data-toggle="tooltip"]').tooltip();

        $(window).load(function(){
                //Begin: repeater
                var script = document.createElement('script');
                script.onload = function () {
                   $( ".input-repeater .list-input" ).sortable({
                    handle:'.x_title',
                    stop:function(event, ui){
                        ui.item.attr('style','');
                    },
                    start:function(event,ui){
                        ui.placeholder.height(ui.item.height() - 4);
                    },
                    update: function(event, ui) {
                        udpateNumberPositionRepeater($(ui.item[0]).closest('.input-repeater'));
                    },
                   });
                };

                window.udpateNumberPositionRepeater  = function(parent){
                    if( parent.find('>.list-input>.repeater-item').length > 0 ){
                        parent.find('>.input-clear-data').remove();
                        parent.find('>.list-input>.repeater-item').each(function(index2, el2) {
                            $(el2).find('>.x_panel>.x_title>h2>.number_position').text(index2 + 1+'. ');
                        });
                        parent.find('>.add-box-repeater-warpper').hide();
                    }else{
                        parent.append('<input type="hidden" value="" class="input-clear-data" name="'+parent.data('name')+'">');
                        parent.find('>.add-box-repeater-warpper').show();
                    }
                    $( ".input-repeater .list-input" ).sortable({
                        handle:'.x_title',
                        stop:function(event, ui){
                            ui.item.attr('style','');
                        },
                        update: function(event, ui) {
                            udpateNumberPositionRepeater($(ui.item[0]).closest('.input-repeater'));
                        },
                        start:function(event,ui){
                            event.stopPropagation();
                            ui.placeholder.height(ui.item.height() - 4);
                            // ui.placeholder.height(ui.item.height());
                        }
                   });

                    parent.find(':input').eq(0).trigger('change');

                }


                script.src = $('meta[name="domain"]').attr('content')+'/admin/js/jquery-ui.min.js';

                document.head.appendChild(script);

                $(document).on('click','.input-repeater>.list-input>.repeater-item>.x_panel>.x_title',function(event){
                    event.stopPropagation();
                    $(this).find('.collapse-link').trigger('click');

                });
                $(document).on('click','.input-repeater>.list-input>.repeater-item>.x_panel>.x_title>.panel_toolbox>li>a>.fa-trash-o',function(event){

                    event.stopPropagation();
                    $(this).closest('.x_title').toggleClass('btn-danger');

                    if( $(this).closest('.x_title').hasClass('btn-danger') ){
                        $(this).closest('.x_panel').find('>.x_content .input-trash:first-child').val(1).trigger('change');
                    }else{
                        $(this).closest('.x_panel').find('>.x_content .input-trash:first-child').val(0).trigger('change');

                    }

                });
                $(document).on('click','.input-repeater>.list-input>.repeater-item>.x_panel>.x_title>ul>li>a>.fa-times',function(event){
                    event.stopPropagation();

                    var r = confirm("Are you sure!");

                    if (r == true) {

                        var $parent = $(this).closest('.input-repeater');
                        $(this).closest('.repeater-item').remove();

                        udpateNumberPositionRepeater($parent);
                    }
                });

                window.input_repeater_update_class_title_item = function(){
                    $('.input-repeater .x_panel').each(function(index,el){
                        $(el).find(':input:not(.input-trash):first').addClass('change_title_item_input_repeater');
                    });
                };
                input_repeater_update_class_title_item();

                $('.change_title_item_input_repeater').each(function(index,el){

                    if( $( el ).val() ){ 
                        $(el).closest('.x_panel').find('>.x_title>h2>.title').text($(el).val());
                    }
                });

                $(document).on('keyup','.change_title_item_input_repeater',function(){
                    $(this).closest('.x_panel').find('>.x_title>h2>.title').text($(this).val());
                });

                $(document).on('change','.change_title_item_input_repeater',function(){
                    $(this).closest('.x_panel').find('>.x_title>h2>.title').text($(this).val());
                });

                $(document).on('click', '.input-repeater .add-group-item', function(event) {
                    event.preventDefault();

                    var max = $(this).closest('.input-repeater').data('max'), count = $(this).closest('.input-repeater').find('>.x_panel').length;

                    if( max && parseInt(count) >= parseInt(max)  ){
                        alert('Đã đủ số lượng.'); return;
                    }
                    
                    var element = $($('#'+$(this).data('template')).html());

                    element.find('.x_content').css({'display':'block'});

                    element.find('textarea.editor-content').attr('id','___change__id__group__input__'+$('textarea.editor-content').length);
                    element.find(':input:not(.input-trash):first').addClass('change_title_item_input_repeater');

                    $(this).parent().find('>.list-input').append(element);

                    udpateNumberPositionRepeater($(this).closest('.input-repeater'));
                });
                window._group_input_open = function(){

                    $('.input-repeater .x_content:has(.input-group-new)').css({display:'block'});
                };

                _group_input_open();

                $(document).on('click','.add-box-repeater-warpper',function(event){
                    event.stopPropagation();
                    $(this).closest('.input-repeater').find('>.add-group-item').trigger('click');
                });


                function change_name_repeater_input(){
                    $('.validate-repeater').remove();
                    $('.input-repeater').each(function(index, el) {
                        $(el).find('>.list-input>.repeater-item>.x_panel').each(function(index2, el2) {
                            $(el2).find('[name]').each(function(index3, el3) {
                                $(el3).attr('name',($(el3).attr('name')).replace(/index/, index2 ));
                            });
                        });
                    });
                    $('.input-repeater').each(function(){

                        var min = parseInt($(this).data('min')), max = parseInt($(this).data('max')), count = parseInt($(this).find('.x_panel').length);

                        if( min > count || count > max ){
                            $(this).append('<span class="not-validate validate-repeater"></span>');
                            event.preventDefault();
                        }

                    });
                }
                $('form:not(.form-rel)').submit(function(){
                    change_name_repeater_input();
                });
                $('.right_col').on('change',':input',function(){
                    change_name_repeater_input();
                });

                setTimeout(function() {
                    change_name_repeater_input();
                }, 10);
                

                $('.right_col').on('focus',':input',function(){
                    change_name_repeater_input();
                });
                // End: Repeater


                //Begin: flexible

                var script = document.createElement('script');
                script.onload = function () {
                   $( ".input-flexible .list-box" ).sortable({
                    handle:'.flexible-title',
                    stop:function(event, ui){
                        ui.item.attr('style','');
                    },
                    update: function(event, ui) {
                        udpateNumberPositionFlexible($(ui.item[0]).closest('.input-flexible'));
                    },
                   });
                };

                function udpateNumberPositionFlexible(parent){

                    if( parent.find('>.list-box>.flexible-item').length > 0 ){
                        parent.find('>.list-box>.flexible-item').each(function(index2, el2) {
                            $(el2).find('>.x_panel>.x_title>.number_position').text(index2 + 1+'. ');
                        });
                        parent.find('>.add-box-flexible-warpper').hide();
                    }else{
                        parent.find('>.add-box-flexible-warpper').show();
                    }
                    
                    parent.find(':input').eq(0).trigger('change');
                }


                script.src = $('meta[name="domain"]').attr('content')+'/admin/js/jquery-ui.min.js';

                document.head.appendChild(script);

                $(document).on('click','.input-flexible>.list-box>.flexible-item>.x_panel>.x_title',function(event){
                    event.stopPropagation();
                    $(this).find('.collapse-link').trigger('click');
                });

                function change_name_flexible_input(){
                    $('.validate-flexible').remove();
                    $('.input-flexible').each(function(index, el) {
                        $(el).find('>.list-box>.flexible-item>.x_panel').each(function(index2, el2) {
                            $(el2).find('[name]').each(function(index3, el3) {
                                $(el3).attr('name',($(el3).attr('name')).replace(/index/, index2 ));
                            });
                        });
                    });
                    $('.input-flexible').each(function(){

                        var min = parseInt($(this).data('min')), max = parseInt($(this).data('max')), count = parseInt($(this).find('.x_panel').length);

                        if( min > count || count > max ){
                            $(this).append('<span class="not-validate validate-flexible"></span>');
                            event.preventDefault();
                        }

                    });
                }
                $('.right_col').on('change',':input',function(){
                    change_name_flexible_input();
                });

                setTimeout(function() {
                    change_name_flexible_input();
                }, 10);
                

                $('form:not(.form-rel)').submit(function(){
                    change_name_flexible_input();
                });
                $('.right_col').on('focus',':input',function(){
                    change_name_flexible_input();
                });

                $(document).on('click','.input-flexible>.list-box>.flexible-item>.x_panel>.x_title>.panel_toolbox>li>a>.fa-trash-o',function(event){
                    event.stopPropagation();
                    $(this).closest('.x_title').toggleClass('btn-danger');

                    if( $(this).closest('.x_title').hasClass('btn-danger') ){
                        $(this).closest('.x_panel').find('>.x_content>.input-trash').val(1).trigger('change');
                    }else{
                        $(this).closest('.x_panel').find('>.x_content>.input-trash').val(0).trigger('change');
                    }
                });
                $(document).on('click','.input-flexible>.list-box>.flexible-item>.x_panel>.x_title>ul>li>a>.fa-times',function(event){

                    event.stopPropagation();

                    var r = confirm("Are you sure!");

                    if (r == true) {

                        var $parent = $(this).closest('.input-flexible');
                        $(this).closest('.flexible-item').remove();

                        udpateNumberPositionFlexible($parent);
                    }
                    
                });

                window.input_flexible_update_class_title_item = function(){
                    $('.input-flexible .x_panel').each(function(index,el){
                        $(el).find(':input:not(.input-trash):not(.flexible-type):first').addClass('change_title_item_input_flexible');
                    });
                };
                input_flexible_update_class_title_item();

                $('.change_title_item_input_flexible').each(function(index,el){

                    if( $( el ).val() ){ 
                        let element = $(el).closest('.x_panel');
                        element.find('>.x_title>.title-flexible-item').text($(el).val());
                    }
                });

                $(document).on('keyup','.change_title_item_input_flexible',function(){
                    $(this).closest('.x_panel').find('>.x_title>.title-flexible-item').text($(this).val());
                });

                $(document).on('click','.add-box-flexible-warpper',function(event){
                    event.stopPropagation();
                    $(this).closest('.input-flexible').find('.dropup').addClass('open');
                });
                $(document).on('click', '.input-flexible>.dropup>.dropdown-menu>li>a', function(event) {

                    event.preventDefault();

                    var max = $(this).closest('.input-flexible').data('max'), count = $(this).closest('.input-flexible').find('.x_panel').length;

                    if( max && parseInt(count) >= parseInt(max)  ){
                        alert('Đã đủ số lượng.'); return;
                    }
                    var element = $($('#script-template-flexible-'+ $(this).closest('.dropdown-menu').data('field')+'-'+$(this).data('field')).html());

                    element.find('.x_content').css({'display':'block'}).closest('.flexible-item').append('<div class="clearfix"></div>');

                    element.find(':input:not(.input-trash):not(.flexible-type):first').addClass('change_title_item_input_flexible');

                    // element.find('textarea.editor-content').attr('id','___change__id__group__input__'+$('textarea.editor-content').length);
                    // element.find('input:first-child').addClass('change_title_item_group_input');

                    $(this).closest('.input-flexible').find('>.list-box').append(element);

                    udpateNumberPositionFlexible($(this).closest('.input-flexible'));
                    
                });
                //End: flexible


                // Asset File
                $('body').on('click', '.button_add_file_tiny ', function(event) {

                    window._data_validate_img = $(this).data();

                    event.preventDefault();

                    $(this).addClass('chose-file-active');
                    $('#filemanager_file_chose').val('');
                    $('.modal-wapper-add-file').show().addClass('input-file-active');

                });

                $('.input_file_asset').each(function(i,el){
                    if( $(el).val() ){

                        var obj = JSON.parse($(el).val());

                        if( obj ){
                            var extension = obj.type_file,
                                file_name = obj.file_name;

                            if( obj.type_link == 'local' ){
                                file_url = $('meta[name="domain"]').attr('content')+ '/'+obj.link;
                            }else{
                                file_url = obj.link;
                            }
                                

                            if ( obj.is_image ) {
                                $(el).parent().find('.preview_file').attr('href',file_url).html('<img style="margin:5px 0;display: block;" src="'+file_url+'" >'+file_name).show();
                            } else{
                                 $(el).parent().find('.preview_file').attr('href',file_url).html('<img style="margin:5px 0;display: block;" src="'+$('meta[name="domain"]').attr('content')+'/'+'filemanager/filemanager/img/ico/'+extension+'.jpg" >'+file_name).show();
                            }

                        }

                    }
                });

                $('body').on('change','.name_file_preview',function(){

                    var warpper = $(this).closest('.input-file'),
                        link_file = warpper.find('.preview_file').attr('href'),
                        name_file_preview = $(this).val();

                    var value = {'name':name_file_preview,'link':link_file};
                    value = JSON.stringify(value);
                    warpper.find('textarea').val(value);

                });

                $('body').on('click', '#add-file-btn-ok', function(event) {

                    event.preventDefault();
                    
                    if( $('#filemanager_file_chose').val() ){
                        var file_url = $('#filemanager_file_chose').val();

                        var extension = file_url.split('.').pop(),
                            file_name = decodeURIComponent(file_url).split('/').pop(),
                            is_image = file_name.match(/\.(jpg|jpeg|png|gif)$/);

                        if ( is_image ) {
                            $('.input-file:has(.chose-file-active)').find('.preview_file').attr('href',file_url).html('<img style="margin:5px 0;display: block;" src="'+file_url+'" >'+file_name).show();
                        } else{
                             $('.input-file:has(.chose-file-active)').find('.preview_file').attr('href',file_url).html('<img style="margin:5px 0;display: block;" src="'+$('meta[name="domain"]').attr('content')+'/'+'filemanager/filemanager/img/ico/'+extension+'.jpg" >'+file_name).show();
                        }

                        var comp = new RegExp(location.host);

                        if( comp.test( file_url ) ){
                            var value = {link:file_url.substring(file_url.indexOf("uploads")),type_link:'local',type_file:extension,'file_name':file_name,'is_image':is_image};
                        }else{
                            var value = {link:file_url,type_link:'external',type_file:extension,'file_name':file_name,'is_image':is_image};
                        }


                        
                    }else{
                        $('.input-file:has(.chose-file-active)').find('.preview_file').attr('href',$('#filemanager_file_chose').val()).hide();

                        var value = '';
                    }

                    value = JSON.stringify(value);
                    warpper = $('.input-file:has(.chose-file-active)').find('textarea').val(value);

                    $('.input-file .chose-file-active').removeClass('chose-file-active');

                    $('.modal-wapper-add-file').hide();

                });
                $('body').on('click', '#add-file-btn-cancel, .add-file-btn-close', function(event) {
                    event.preventDefault();
                    $('.modal-wapper-add-file').hide().removeClass('input-file-active');

                });

                window.filemanager_title_file = function(){
                    return 'Insert/Edit File';
                }
                // End Asset File


                // Begin Image
                window.is_url  = function(str) {
                   var regexp = /^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
                   return regexp.test(str);
                }
                
                //Multiple Image
                var script = document.createElement('script');
                script.onload = function () {
                   $( ".multi-able .image_preview" ).sortable({
                        stop:function(event, ui){
                            ui.item.attr('style','');
                        },
                        update: function(event, ui) {
                            upload_input_image_multi($(this).closest('.multi-able'));
                        },
                        create:function(event, ui){
                            // fortmatImageMulti();
                        }

                  });
                };

                script.src = $('meta[name="domain"]').attr('content')+'/admin/js/jquery-ui.min.js';

                document.head.appendChild(script);

                window.show_form_image_multiable = function(){

                     $('.input-image-warpper.multi-able').each(function(index,el){
                        var json = JSON.parse($(el).find('textarea.image-result').val());
                        element = $(el).find('.image_preview ');
                        element.empty();
                        if( Array.isArray(json) ){
                            for (var j = 0; j < json.length; j++) {
                                // if( json.images[j].type_link == 'local' ){
                                //  link = "{!!url('/')!!}/"+json.images[j].link;
                                // }else{
                                //  link = json.images[j].link;
                                // }

                                if( !is_url(json[j].link) ){
                                    link = $('meta[name="domain"]').attr('content') + "/"+json[j].link;
                                }else{
                                    link = json[j].link;
                                }

                                element.append('<div class="item-image-resutl"><img src="'+link+'" class="type-image-'+json[j].type_link+'" alt=""><span class="stt">'+(j + 1)+'</span></div>')
                            };
                        }else{
                            if( json != null ){

                                if( !is_url(json.link) ){
                                    link =  $('meta[name="domain"]').attr('content') + "/"+json.link;
                                }else{
                                    link = json.link;
                                }

                                element.append('<div class="item-image-resutl"><img src="'+link+'" class="type-image-'+json.type_link+'" alt=""><span class="stt">1</span></div>')
                            }
                        }
                    });

                }
                show_form_image_multiable();

               

                //End Multiple Image


                window.after_chose_image_filemanager = function(field_id){

                    if( !window._data_validate_img.multi ){
                        var url=jQuery('#'+field_id).val();

                         validate_image( url , window._data_validate_img, function($result){

                            if( !$result ){

                                $('#'+field_id).val('');
                                $('#filemanager-wapper').fadeIn();  
                                
                            }else{
                                if( !window._data_validate_img.multi ){
                                    $('#filemanager-wapper').fadeOut();
                                }else{
                                    return url;
                                }
                            }

                         } );
                    }
                };


                window._data_validate_img = false;

                $('body').on('click', '.button_add_img_tiny ', function(event) {

                    window._data_validate_img = $(this).data();
                    event.preventDefault();

                    $('.modal-wapper-add-image').show();
                    $(this).closest('.input-image-warpper').addClass('input-image-active');

                    $('#image_link').val('');
                    $('#image_link').focus();

                });

                function create_thumbnail_image(value, $el){

                    show_loading('Create Thumbnail');

                    $.ajax({
                        url: $('meta[name="url_create_thumbnail"]').attr('content'),
                        type:'POST',
                        dataType:'json',
                        data:{
                            _token:$('#laravel-token').val(),
                            value: value,
                            data: $el.data('thumbnail')
                        },
                        success:function(data){
                            if( data.value ){
                                value = JSON.stringify(data.value);
                                $el.css({'border-radius':'50%'});
                                $el.find('textarea').val(value).trigger('change');
                            }

                            hide_loading();
                        }
                    })

                }

                $('body').on('click', '#add-image-btn-ok', function(event) {

                    event.preventDefault();

                    if( window._data_validate_img.multi ){

                        event.stopPropagation();
                        
                        var value = $('#image_link').val();

                        if( is_url(value) ){
                            value = [value];
                        }else{
                            if( value !== '' ){

                                value = JSON.parse(value);

                            }else{
                                value = [];
                            }
                        }
                        
                        validate_image_multi(value,function(){
                            upload_input_image_multi( $('.input-image-warpper.input-image-active:first') );
                            $('#add-image-btn-cancel').trigger('click');
                            window.__list_image_multi_checked = false;
                            window.__list_image_multi_checked_i = -1;
                            window._is_edit_image = false;
                        });
                        
                    }else{
                        if( is_url($('#image_link').val())  ){

                            $('.modal-wapper-add-image').hide();

                            validate_image( $('#image_link').val() , window._data_validate_img, function($result, $src){

                                if( $result ){

                                    var comp = new RegExp(window.location.hostname);

                                    var value = $src;

                                    if( comp.test( $('#image_link').val() ) ){
                                       value = {'link':value.substring(value.indexOf("uploads")),'type_link':'local'};
                                    }else{
                                       value = {'link':value,'type_link':'external'};
                                    }

                                    if( $('.input-image-warpper.input-image-active:first').data('thumbnail') ){
                                        create_thumbnail_image(value,$('.input-image-warpper.input-image-active:first'));
                                    }

                                    value = JSON.stringify(value);

                                    $('.input-image-warpper.input-image-active:first textarea').val(value).trigger('change');
                                    $('.input-image-warpper.input-image-active:first .image_preview').html('<div class="item-image-resutl"><img src="'+$('#image_link').val()+'" alt=""></div>');

                                    $('.input-image-warpper.input-image-active').removeClass('input-image-active');

                                }else{
                                    $('#image_link').val('');
                                    $('.modal-wapper-add-image').show();
                                }
                            });

                        }else{

                            $('#add-image-btn-cancel').trigger('click');

                        }
                        window._is_edit_image = false;
                    }
                    
                });


                responsive_filemanager_callback_multi  = function(field_id, callback){

                    $('#filemanager-wapper').fadeOut();
                    callback();

                };

                window.validate_image_multi = function(value, callback){

                    if( !window.__list_image_multi_checked ){
                        window.__list_image_multi_checked = [];
                        window.__list_image_multi_checked_i = 0;
                    }

                    if( __list_image_multi_checked_i < value.length ){

                        validate_image(value[__list_image_multi_checked_i], window._data_validate_img, function(result, src){

                            if( result ){
                                __list_image_multi_checked.push(src);
                            }

                            window.__list_image_multi_checked_i ++;

                            validate_image_multi(value,callback);
                        });

                    }else{
                        // console.log(__list_image_multi_checked_i);

                        for( var i = 0 ; i < __list_image_multi_checked.length ; i ++ ){

                            $('.input-image-warpper.input-image-active:first .image_preview .noImageSelected').remove();

                            if( !window._is_edit_image ){
                                $('.input-image-warpper.input-image-active:first .image_preview').append('<div class="item-image-resutl"><img src="'+__list_image_multi_checked[i]+'" alt=""></div>');
                            }else{
                                window._is_edit_image = false;
                                $('.input-image-warpper.input-image-active:first .image_preview .item-image-resutl.active img:first').attr('src',__list_image_multi_checked[i]).closest('.active').removeClass('active');
                            }           

                        }

                        callback();

                        
                    }

                };

                $('body').on('click', '#add-image-btn-cancel, .add-image-btn-close', function(event) {
                    event.preventDefault();
                    $('.modal-wapper-add-image').hide();
                    $('.input-image-warpper.input-image-active:first .image_preview .item-image-resutl.active').removeClass('active');
                    $('.input-image-warpper.input-image-active').removeClass('input-image-active');

                });


                

                // window.is_url  = function(str)
                // {
                //  if( !str.trim() ) return false;

                //   regexp =  /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
                //         if (regexp.test(str))
                //         {
                //           return true;
                //         }
                //         else
                //         {
                //           return false;
                //         }
                // };


                window.upload_input_image_multi  =function( element_warpper ){

                    var listImage = element_warpper.find('.item-image-resutl');

                    var listImageJson = [];

                    var comp = new RegExp( $('meta[name="domain"]').attr('content') );

                    listImage.each(function(index, el) {

                        $(el).find('.stt').remove();
                        $(el).append('<span class="stt" >'+(index + 1)+'</span>');

                        var Url = $(el).find('img').attr('src');

                        if( comp.test( Url ) ){
                            $(el).addClass('local-link');
                           value = {'link':Url.substring(Url.indexOf("uploads")),'type_link':'local'};
                        }else{
                            $(el).addClass('external-link');
                           value = {'link':Url,'type_link':'external'};
                        }


                        listImageJson.push(value);
                    });

                    value = JSON.stringify(listImageJson);

                    element_warpper.find('textarea').val(value).trigger('change');


                };

                

                function edit_img($this){
                    $this.closest('.input-image-warpper').find('.button_add_img_tiny').trigger('click');

                    $('#image_link').val($this.closest('.item-image-resutl').find('img').attr('src'));

                    window._is_edit_image = true;

                    $this.closest('.item-image-resutl').addClass('active');

                    $('.modal-wapper-add-image').show();

                    $this.closest('.input-image-warpper').addClass('input-image-active');
                }

                

                $(document).on("mouseenter", ".item-image-resutl:has(img)", function() {

                    var data_size = $(this).closest('.input-image-warpper').data('size');

                    var url = $(this).find('img').eq(0).attr('src');

                    var $str = '<div class="action-image" style="text-align:right;"><a href="'+url+'" title="'+$('#text-download').val()+'" download><i class="fa fa-cloud-download download" aria-hidden="true"></i></a><i title="'+$('#text-edit').val()+'" class="fa fa-pencil edit-img load-filemanager" data-type="1" data-field-id="image_link" aria-hidden="true"></i><i title="'+$('#text-remove').val()+'" class="fa fa-times remove" aria-hidden="true"></i>';

                    // for (var i = 0; i < data_size.length; i++) {
                    //  $str += '<br><i class="fa" aria-hidden="true">'+i+'</i>';
                    // };

                    $str += '</div>';
                    $(this).append($str);

                }).on("mouseleave", ".item-image-resutl:has(img)", function() {
                    $(this).find('.action-image').remove();
                });

                $('body').on('click', '.noImageSelected', function(event) {
                    event.preventDefault();
                    $(this).closest('.input-image-warpper').find('.load-filemanager').trigger('mouseover');
                    $(this).closest('.input-image-warpper').find('.button_add_img_tiny').trigger('click');
                });

                $('body').on('click','.action-image',function(){
                    event.preventDefault();
                    event.stopPropagation();
                });

                $('body').on("click", ".item-image-resutl .action-image .fa-cloud-download ", function(event) {
                    event.stopPropagation();
                });
                $('body').on("click", ".item-image-resutl .action-image .remove", function(event) {

                    event.stopPropagation();

                    var warpper = $(this).closest('.input-image-warpper');

                    var multi = warpper.find('.button_add_img_tiny').data('multi');

                    $(this).closest('.item-image-resutl').remove();

                    if( multi ){

                        if( warpper.find('.item-image-resutl').length < 1){
                            warpper.find('.image_preview').html('<div class="noImageSelected emptyButton" style="display:block;">No image selected<input type="file" class="filemanager_uploadfile_direct" ></div>');
                        }

                        upload_input_image_multi(warpper);
                    }else{  
                        warpper.find('.image_preview').html('<div class="noImageSelected emptyButton" style="display:block;">No image selected<input type="file" class="filemanager_uploadfile_direct" ></div>');
                        warpper.find('textarea').val('').trigger('change');

                    }

                });

                $('body').on('click', '.edit-img, .default_input_img_result .item-image-resutl', function(event) {

                    event.preventDefault();

                    edit_img($(this));

                });

                $(document).on('change','.filemanager_uploadfile_direct',function(){

                    $this = $(this);
                    $this.closest('.input-image-warpper').addClass('input-image-active');
                    window._data_validate_img = $this.closest('.input-image-warpper').find('.button_add_img_tiny').data();

                    if (this.files && this.files[0]) {

                        for (var i = this.files.length - 1; i >= 0; i--) {

                            var reader = new FileReader();

                            reader.onload = function(e) {
                                $this.closest('.image_preview').append('<div class="image-preview-before-upload"><img src="' + e.target.result +'"><div class="processing"></div></div>');
                            };

                            reader.readAsDataURL(this.files[i]);

                        };
                        
                      }

                    var formData = new FormData();

                    for (var i = $(this)[0].files.length - 1; i >= 0; i--) {
                        formData.append('file['+i+']',$(this)[0].files[i]);
                    };
                    formData.append('_token', $('#laravel-token').val());
                    $.ajax({
                        xhr: function() {
                            var xhr = new window.XMLHttpRequest();

                            xhr.upload.addEventListener("progress", function(evt) {
                              if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total;
                                percentComplete = parseInt(percentComplete * 100);

                                $this.closest('.image_preview').find('.image-preview-before-upload .processing').css({'width':percentComplete+'%'});
                              }
                            }, false);

                            return xhr;
                          },
                        url: $('meta[name="url_filemanagerUploadFileDirect"]').attr('content'),
                        type:'POST',
                        dataType:'json',
                        data:formData,
                        processData: false,
                        contentType: false,
                        beforeSend: function() {
                            var percentVal = '0%';
                            // bar.width(percentVal);
                            // percent.html(percentVal);
                            console.log(percentVal);
                        },
                        uploadProgress: function(event, position, total, percentComplete) {
                           var percentVal = percentComplete + '%';
                            // bar.width(percentVal);
                            // percent.html(percentVal);
                            console.log(percentVal);
                        },
                        // complete: function(xhr) {
                        //  console.log(xhr.responseText);
                        //     // status.html(xhr.responseText);
                        // },
                        success:function(data){
                            $this.val('');
                            $this.closest('.input-image-warpper').find('.image-preview-before-upload').remove();

                            if( _data_validate_img.multi ){

                                validate_image_multi(data.files,function(){
                                    upload_input_image_multi( $('.input-image-warpper.input-image-active:first') );
                                    $('#add-image-btn-cancel').trigger('click');
                                    window.__list_image_multi_checked = false;
                                    window.__list_image_multi_checked_i = -1;
                                    window._is_edit_image = false;
                                });

                            }else{
                                check_image_after_upload_direct(data.files,0);
                            }
                        }

                    });


                });
    
                function check_image_after_upload_direct(files, index){
                    if( index >= files.length ) return;

                    validate_image( files[index] , window._data_validate_img, function($result, $src){

                        if( $result ){

                            var comp = new RegExp($('meta[name="domain"]').attr('content'));

                            var value = $src;

                            if( comp.test( $('#image_link').val() ) ){
                               value = {'link':value.substring(value.indexOf("uploads")),'type_link':'local'};
                            }else{
                               value = {'link':value,'type_link':'external'};
                            }

                            value = JSON.stringify(value);

                            $('.input-image-warpper.input-image-active:first textarea').val(value).trigger('change');
                            $('.input-image-warpper.input-image-active:first .image_preview').html('<div class="item-image-resutl"><img src="'+$src+'" alt=""></div>');

                            $('.input-image-warpper.input-image-active').removeClass('input-image-active');

                        }else{
                            check_image_after_upload_direct(files,index + 1);
                        }
                    });
                }

                window.validate_image = function($src, $param, $callback){

                     var img = new Image;
                     img.src= $src ;

                     img.onload=function(){

                        var str = '';

                        if($param['ratio']){

                            $arryRatio = $param['ratio'].split('x');

                            $ratioResult = Math.round($arryRatio[0]/$arryRatio[1] * 1000) / 1000;                                          

                            if( this.width/this.height != $ratioResult ){
                                str = '     Tỉ lệ hình ảnh không đúng '+$param['ratio']+'\n' ;
                            }

                        }
                        if( $param['width'] && this.width != parseInt($param['width']) ){
                            str = str+'     image width != '+$param['width']+'\n';
                        }
                      

                        if( $param['maxWidth'] && this.width > parseInt($param['maxWidth']) ){
                            str = str + '     image max width < '+ $param['maxWidth'] +'\n';
                        }

                        if( $param['minWidth'] && this.width < parseInt($param['minWidth']) ){
                            str = str + '     image min width > '+$param['minWidth']+'\n';
                        }

                        if( $param['height'] && this.height != parseInt($param['height']) ){
                            str = str + '     image height != '+$param['height']+'\n';
                        }

                        if( $param['maxHeight'] && this.height > parseInt($param['maxHeight']) ){
                            str = str + '     image max height < '+$param['maxHeight']+'\n';
                        }

                        if( $param['minHeight'] && this.height < parseInt($param['minHeight']) ){
                            str = str + '     image min height > '+$param['minHeight']+'\n';
                        }   

                        if(str){
                            alert($src + '\nError Info: \n' + str);
                            $result = false;
                        }else{
                            $result = true;
                        }

                        if( $callback ){
                            $callback($result, $src) ;
                        }

                        $result;

                    };
                };
                // End Image

        });
    }
} else {
    var body = document.getElementsByTagName('body')[0];
    body.style.padding = '0px';
    body.removeChild(document.getElementById('vn4-nav-top-login'))
}