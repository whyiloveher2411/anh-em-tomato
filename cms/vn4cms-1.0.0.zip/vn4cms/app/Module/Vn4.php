<?php namespace App\Module;

class Vn4{

	private static $instance;

	private function  __construct(){}

	public static function getInstance(){
	 	self::$instance = new Trans();
      	return self::$instance;
   	}

   	public static function trans($id, $source_lang = null){

   		return Trans::trans($id, $source_lang);

   	}
}

