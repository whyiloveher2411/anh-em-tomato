<?php namespace App\Module;

class Vn4Widget{

	private $id = '';
	private $name = '';
	private $description = '';
	private $form = '';

	protected $instance = array();

	private $args_construct = '';


	public function __construct($id, $name, array $args = null ){

		$this->id = $id;

		$this->name = $name;

		$this->args_construct = $args;

		$this->form = $args['form'];

		if( isset($args['description']) ){
			$this->description = $args['description'];
		}

		if( isset($args['instance']) && is_array($args['instance']) ){
			$this->instance = $args['instance'];
		}



	}


	public function form( ){

		$this->$form();
		
	}

	public static function update($input){

	}

	public function widget(){
		
	}

	public static function WidgetStatic($class_name, array $widget_instance = array()){

		if( class_exists ($class_name) ){

			$widget = new $class_name();

			$widget->update_instance($widget_instance);

			$widget->widget();

        }
	}

	public function form_widget_html_left(){
		?>
		<div class="col-xs-12 col-md-6 widget-item-warpper  widget-<?php echo $this->id ; ?>" id="widget-id-<?php echo $this->id; ?>">
          
          	<div class="x_panel widget-item">
          		<form method="POST" data-url-update="<?php echo route('admin.update_sidebar',['type'=>'update','widget_class'=>get_class($this)]) ?>" data-url-delete="<?php echo route('admin.update_sidebar',['type'=>'delete','widget_class'=>get_class($this)]) ?>">
          			<input type="text" value="<?php echo get_class($this); ?>" hidden name="widget_name">
		            <div class="x_title">
		              <h2>
		                  <?php echo $this->name; ?>
		              </h2>
		              <ul class="nav navbar-right panel_toolbox">
		                 <li><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		                </li>
		              </ul>
		              <div class="clearfix"></div>
		            </div>
		            <div class="x_content">
		              	
		              	<div class="widget-inside">
		                    <?php $this->form(); ?>
		                </div>

		                <p class="action-widget"><span><a href="#" class="delete-widget-added"><?php echo __('Remove') ?></a> | <a class="close-widget-added" href="#"><?php echo __('Close') ?></a></span>
		               	<button type="submit" class="vn4-btn vn4-btn-blue pull-right btn-save-widget" name="status" value="publish"><?php echo __('Save changes') ?></button>
	           			</p>
		            </div>
          		</form>
          	</div>

          <p class="description-widget"><?php echo $this->description; ?></p>

          <div class="widgets-chooser-item"></div>
        </div>

        <?php

	}

	public function update_instance($input){
		$this->instance = $input;
	}

	public function form_widget_html_right(){
		?>
			<div class="x_panel widget-item">
          		<form method="POST" data-url-update="<?php echo route('admin.update_sidebar',['type'=>'update','widget_class'=>get_class($this)]) ?>" data-url-delete="<?php echo route('admin.update_sidebar',['type'=>'delete','widget_class'=>get_class($this)]) ?>">
          			<input type="text" value="<?php echo get_class($this); ?>" hidden name="widget_name">
		            <div class="x_title">
		              <h2>
		                  <?php echo $this->name; ?>
		              </h2>
		              <ul class="nav navbar-right panel_toolbox">
		                 <li><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		                </li>
		              </ul>
		              <div class="clearfix"></div>
		            </div>
		            <div class="x_content">
		              	
		              	<div class="widget-inside">
		                    <?php $this->form(); ?>
		                </div>

		                <p class="action-widget"><span><a href="#" class="delete-widget-added"><?php echo __('Remove') ?></a> | <a class="close-widget-added" href="#"><?php echo __('Close') ?></a></span>
		               <button type="submit" class="vn4-btn vn4-btn-blue pull-right btn-save-widget" name="status" value="publish"><?php echo __('Save changes') ?></button>
		           		</p>
		            </div>
          		</form>
          	</div>
		<?php
	}

	protected function get_field_value($name){

		if( isset($this->instance[$name]) ){
			return $this->instance[$name];
		}

		return null;

	}
}