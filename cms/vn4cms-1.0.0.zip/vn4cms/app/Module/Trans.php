<?php namespace App\Module;
use App;
class Trans{

	private static $instance;

	private static $list_translated = [];

	private function  __construct(){}

	public static function getInstance(){
	 	self::$instance = new Trans();
      	return self::$instance;
   	}

   	public static function trans($id, $source_lang = null){

			$locale = App::getLocale();

			$file = explode('.', $id);

			$word = array_pop ($file);

			$file_lang = '';

			foreach ($file as $name) {

			$file_lang = $file_lang.'/'.$name;

			}

		  	$file_lang = substr($file_lang, 1);

		  	if($source_lang === null){
		    	$file_lang = 'resources/lang/'.$locale.'/'.$file_lang.'.php';
			}else{
		    	$file_lang = $source_lang.$locale.'/'.$file_lang.'.php';
			}

			if( isset(self::$list_translated[$file_lang][$word]) ){

				return self::$list_translated[$file_lang][$word];

			}else{

		    	self::$list_translated[$file_lang] = include_once($file_lang);


				if( isset(self::$list_translated[$file_lang][$word]) ){
					return self::$list_translated[$file_lang][$word];
				}

			}
		  

		  return $id;

   	}

   	public static function get_list_translated(){
   		return self::$list_translated;
   	}

}
