<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\User;
use Auth;
use Session;
use URL;
use Hash;
use Vn4Model;

class LoginController extends Controller {

    public function index(Request $r){

        include __DIR__.'/../../../../cms/backend.php'; 
        
        if($r->isMethod('GET')){
            return vn4_view(backend_theme('particle.login'));
        }

        if($r->isMethod('POST')){

            $time_login = Vn4Model::firstOrAddnew(vn4_tbpf().'login_time',['ip'=>$r->ip()]);

            $limit_login_count =  setting('security_limit_login_count',false);
            $limit_login_time =  setting('security_limit_login_time',false);

            if( $limit_login_count && $time_login->count > $limit_login_count - 1  ){

                if( time() < $time_login->time ){
                    return response()->json(['message'=>'Bạn đã đăng nhập quá '.$limit_login_count.' lần, Vui lòng chờ '.$limit_login_time.' giây sau']);
                }else{
                    $time_login->count = 0;
                }
            }



            $input = $r->all();

            if( setting('security_active_recapcha_google',false) ){

                $url = 'https://www.google.com/recaptcha/api/siteverify';

                $data = array(
                    'secret' => setting('security_recaptcha_secret'),
                    'response' => $r->get('g-recaptcha-response')
                );
                $options = array(
                    'http' => array (
                        'header'=>'Content-Type: application/x-www-form-urlencoded\r\n'."Content-Length: ".strlen(http_build_query($data))."\r\n",
                        'method' => 'POST',
                        'content' => http_build_query($data)
                    )
                );
                $context  = stream_context_create($options);

                $verify = file_get_contents($url, false, $context);
                $captcha_success=json_decode($verify);

                if ($captcha_success->success === false) {
                    $time_login->count += 1;
                    $time_login->time =  time() + $limit_login_time;

                    $time_login->save();

                     return response()->json(['message'=>'Xác thực capcha websit thất bại.']);
                }

            }

            if( $user = User::where('email',trim($input['username']))->where('status','publish')->first() ){
                
                $rememberme = $r->get('rememberme',false);

                if (Hash::check( $input['password'] , $user->password)) {
                    
                    if( $user->getMeta('active_google_authenticator') ){
                        
                        if( $r->get('google_authenticator') && $secret = $user->getMeta('google_authenticator_secret') ){

                            require cms_path('public','../lib/google-authenticator/Authenticator.php');

                            $Authenticator = new \Authenticator();

                            $checkResult = $Authenticator->verifyCode($secret, $r->get('google_authenticator'), 2);

                            if( !$checkResult ){
                                return response()->json(['message'=>'Mã xác thực không đúng.']);
                            }

                        }else{
                            return response()->json(['active_google_authenticator'=>true]);
                        }

                    }

                }

                if ( Auth::attempt(['email' => $input['username'], 'password' => $input['password']], $rememberme) ){

                    vn4_log('Login',null,null,'info','user/'.Auth::id().'/vn4-'.date('Y-m-d').'.log');

                    $time_login->count = 0;
                    $time_login->time =  0;
                    $time_login->save();

                    $unique_login_time = time().microtime();

                    Auth::user()->updateMeta('unique_login_time',$unique_login_time);

                    // if( Session::has('url_after_login') ){

                    //     return response()->json(['url'=>Session::pull('url_after_login')])->withCookie(cookie('unique_login_time', $unique_login_time));

                    // }

                    if( $r->has('rel') ){
                        return response()->json(['url'=>$r->get('rel')])->withCookie(cookie('unique_login_time', $unique_login_time));
                        // return response()->json(['url'=>$r->get('rel')]);
                    }
                    return response()->json(['url'=>route('admin.index')])->withCookie(cookie('unique_login_time', $unique_login_time));
                    
                }

            }

            $time_login->count += 1;
            $time_login->time =  time() + $limit_login_time;
            $time_login->save();

            if( $limit_login_count && $time_login->count > $limit_login_count - 1  ){
                return response()->json(['message'=>'Bạn đã đăng nhập quá '.$limit_login_count.' lần, Vui lòng chờ '.$limit_login_time.' giây sau','url'=>route('login')]);
            }

            return response()->json(['message'=>'Username hoặc Password không đúng.','time_login'=>$time_login->count]);
        }

        // dd(1);
    }

    public function logout(Request $r){

        use_module(['read_html']);

        vn4_log('Logout',null,null,'info','user/'.Auth::id().'/vn4-'.date('Y-m-d').'.log');

        Auth::logout();

        $string_redirect_back = URL::previous();

        if( strpos( $string_redirect_back, url(setting('security_prefix_link_admin','admin')) ) === false ){
            return redirect()->to($string_redirect_back,301);
        }

        session(['url_after_login'=>$string_redirect_back]);

        return redirect()->route('login');
    }
 
}
