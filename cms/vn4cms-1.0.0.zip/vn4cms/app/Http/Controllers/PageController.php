<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Session;
use File;

use Vn4Model;

class PageController extends Controller {

	public function getPage404(Request $r){
		return errorPage(404,'Page note found');
	}


	public function index(Request $r){

		$action = do_action('index',$r);

		if( $action ){
			return $action;
		}

		title_head(setting('general_description',__('A simple website using Vn4CMS')));

		add_body_class(['index','home']);

  		$theme_option = json_decode(setting('reading_homepage', false),true);

  		if( !isset($theme_option['type']) ) $theme_option = ['type'=>'default','static-page'=>'none','post-type'=>'page','post-id'=>0];

  		$theme = theme_name();

		if( $theme_option['type'] === 'custom' && $page = get_post($theme_option['post-type'],$theme_option['post-id']) ){
			return view_post($page);
		}elseif( $theme_option['type'] === 'static-page' && view()->exists( $view = 'themes.'.$theme.'.page.'.$theme_option['static-page']) ){
			add_body_class(['page',$theme_option['static-page']]);
			return vn4_view($view);
		}

		return vn4_view('themes.'.theme_name().'.index');

	}
	
	public function getPage(Request $r, $page){

		$action_before_page = do_action('getPage',$page);

		if( $action_before_page ) return $action_before_page;

		$theme = theme_name();

		$view = 'themes.'.$theme.'.page.'.$page;

		if( view()->exists( $view ) ){

			add_body_class(['page',$page]);
			
			title_head(ucwords( preg_replace('/-/', ' ', str_slug(str_replace('.blade.php', '', $page)) )  ));

			if(  File::exists( cms_path('resource','views/themes/'.$theme.'/page/'.$page.'-post.php') ) ){
				
               $result = include cms_path('resource','views/themes/'.$theme.'/page/'.$page.'-post.php');

               if( $result !== 1 ) return $result;
            }

			return vn4_view($view);

		}

		return errorPage(404,'Page note found');

	}

	public function anyControllerFrontend(Request $r, $controller, $method){

		$theme = theme_name();

       	$result = include cms_path('resource','views/themes/'.$theme.'/inc/controllers/'.str_slug($controller).'.php');

       	if( $result ){

   		 	if( is_array($result) ){

	            if( isset($result[$method]) ){
       				return $result[$method]($r);
	            }

	            die('Missing method '.$method);

          	}

          	if( $result !== 1 ){
	            return $result;
          	}

       	}

   		die('Missing controller '.$controller);

	}

	public function postDetail(Request $r, $custom_post_slug, $post_slug){
		
		$admin_object = get_admin_object();

		if( isset($GLOBALS['custom_post_slug'][$custom_post_slug]) ){

			if( $post = getPostBySlug($GLOBALS['custom_post_slug'][$custom_post_slug],$post_slug) ){
				$action_before_post_detail = do_action('postDetail',$post, $custom_post_slug, $post_slug);
				
				if( $action_before_post_detail ) return $action_before_post_detail;

				if( $post ){
					if( $post->is_homepage ){
						return vn4_redirect(route('index'),301);
					}
					return view_post($post);
				} 
			}
		}

		return errorPage(404,'Not found post');
	}


}
