<?php add_action('vn4_footer',function() use ($param) { 


	$argType = ['image'=>'1','file'=>'2','video'=>'3'];

	$typeDefault = 'image';

	$field_id = $param['field_id'];

	$url = asset('filemanager/filemanager/dialog.php');
?> 



<div class="modal" id="filemanager-wapper"  role="dialog" style="max-width: 100%;margin-top: 32px;">
  	<div class="modal-dialog" style="max-width: 100%;position: relative;">
	    <div class="modal-content">

	      <div class="modal-header">
	        <button type="button" class="close close-iframe-filemanager">×</button>
	        <h4 class="modal-title" id="filemanager-title">Insert/edit image</h4>
	      </div>
	      <div class="modal-body" id="iframe-filemanager">
			
	      </div>
	  </div><!-- /.modal-dialog -->
	</div>
</div>

<script type="text/javascript">
	
	$('body').on('mouseover click','.load-filemanager',function(event){

		var filemanager_type = $(this).data('type');
		var multi = $(this).data('multi')?'1':'0';

		var url = '<?php echo $url; ?>?type='+ filemanager_type + '&field_id=' + $(this).data('field-id')+'&multi='+multi;

		if( !window._filemanager_type ){
			window._filemanager_type = [];
		}

		$('#iframe-filemanager .filemanager-iframe').hide();

		if( window._filemanager_type.indexOf(url) < 0 ){

			window._filemanager_type.push(url);

			$('#iframe-filemanager').append('<iframe id="iframe-filemanager-'+window._filemanager_type.indexOf(url)+'" class="filemanager-iframe" width="100%" height="100%" src="'+url+'" frameborder="0"></iframe>');
		}else{
			$('#iframe-filemanager #iframe-filemanager-'+window._filemanager_type.indexOf(url)).show();
		}

	});

	$('body').on('click','.open-filemanager',function(event){

		if( $(this).data('title') ){
			$('#filemanager-title').html( window[$(this).data('title')]() );
		}else{
			$('#filemanager-title').html('Insert/edit image');
		}

		var callback = $(this).data('callback');

		if( callback ){
			window._callback_filemanager = callback;
		}else{
			window._callback_filemanager = false;
		}

		$('#filemanager-wapper').fadeIn();
	});


	function responsive_filemanager_callback(field_id){
		
		if( window._callback_filemanager ){
			var callback_string = window._callback_filemanager;
			window[callback_string](field_id);
		}else{
			$('#filemanager-wapper').fadeOut();
		}

	}


	$('body').on('click', '.close-iframe-filemanager', function(event) {
		event.preventDefault();
		$('#filemanager-wapper').fadeOut();
	});

</script>


<?php }, 'module_filemanager',true); ?>

