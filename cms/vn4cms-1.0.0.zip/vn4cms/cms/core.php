<?php
//hook
$r = request();

if( $r->isMethod('POST') ){

	function setEnvironmentValue(array $values)
	{
	    $envFile = app()->environmentFilePath();
	    $str = file_get_contents($envFile);

	    if (count($values) > 0) {
	        foreach ($values as $envKey => $envValue) {

	            $str .= "\n"; 
	            $keyPosition = strpos($str, "{$envKey}=");
	            $endOfLinePosition = strpos($str, "\n", $keyPosition);
	            $oldLine = substr($str, $keyPosition, $endOfLinePosition - $keyPosition);

	            // If key does not exist, add it
	            if (!$keyPosition || !$endOfLinePosition || !$oldLine) {
	                $str .= "{$envKey}={$envValue}\n";
	            } else {
	                $str = str_replace($oldLine, "{$envKey}={$envValue}", $str);
	            }

	        }
	    }

	    $str = substr($str, 0, -1);
	    if (!file_put_contents($envFile, $str)) return false;
	    return true;
	}

	if( $r->has('setting') ){
		
		$GLOBALS['vn4_table_prefix'] = env('TABLE_PREFIX','vn4_');

		function vn4_tbpf(){
			return $GLOBALS['vn4_table_prefix'] ;
		}

		include __DIR__.'/module/check_database_mysql.php';

		$table_user = vn4_tbpf().'user';

		Schema::table($table_user, function($table) use ($table_user) {
			if( !Schema::hasColumn( $table_user, 'permission' ) ){
				$table->text('permission')->after('customize_time')->nullable();
				$table->string('remember_token',255)->after('permission')->nullable();
			}
		});

		DB::table($table_user)->delete();

		DB::table(vn4_tbpf().'user')->insert([
			'email'=>$r->get('email'),
			'slug'=>str_slug($r->get('email')),
			'first_name'=>$r->get('first_name'),
			'last_name'=>$r->get('last_name'),
			'password'=>Hash::make($r->get('admin_password')),
			'type'=>'user',
			'status'=>'publish',
			'permission'=>'category_list, category_create, category_edit, category_publish, category_trash, category_delete, category_restore, category_detail, post_list, post_create, post_edit, post_publish, post_trash, post_delete, post_restore, post_detail, tag_list, tag_create, tag_edit, tag_publish, tag_trash, tag_delete, tag_restore, tag_detail, page_list, page_create, page_edit, page_publish, page_trash, page_delete, page_restore, page_detail, user_list, user_create, user_edit, user_publish, user_trash, user_delete, user_restore, user_detail, appearance_menu_client_edit, appearance_menu_client_delete, appearance-customize_view, appearance-menu_view, appearance-theme_view, appearance-widget_view, entity-relationship_view, environment_view, log_view, many-record_view, media_view, plugin_view, profile_view, restore-database_view, setting_view, static-info-theme_view, theme-options_view, tool-genaral_view, user-new_view, user-role-editor_view, tool_backup-database, tool_check-database, tool_check-version-cms, tool_clear-cache, tool_develop-asset, tool_minify-html, tool_refresh-lang, tool_refresh-views, tool_render-model, tool_tiny-image, tool_tool-genaral, tool_validate-html-in-editor, tool_validate-html-in-tool-page, view_setting, change_setting_license, change_setting_general, change_setting_reading, change_setting_admin_template, change_setting_security, plugin_action',
		]);

		DB::table(vn4_tbpf().'setting')->whereIn('key_word',['security_prefix_link_admin','security_link_login'])->delete();

		DB::table(vn4_tbpf().'setting')->insert([
			[
				'key_word'=>'security_prefix_link_admin',
				'type'=>'setting',
				'content'=>$r->get('backend_url'),
			],
			[
				'key_word'=>'security_link_login',
				'type'=>'setting',
				'content'=>$r->get('login_url'),
			]
		]);

		cache()->flush();
		
		file_put_contents(__DIR__.'/core.php', file_get_contents(__DIR__.'/core_temp.txt'));

		die(json_encode(['success'=>true,'loginpage'=>url('/'.$r->get('backend_url'))]));
	}

	if( $r->has('checkdatabase') ){

		try{
		    $dbh = new pdo( 'mysql:host='.$r->get('mysql_host').':'.$r->get('mysql_port').';dbname='.$r->get('database_name'),
		                    $r->get('mysql_login'),
		                    $r->get('mysql_password'),
		                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));


			setEnvironmentValue([
				'APP_URL'=>url('/').'/',
				'DB_HOST'=>$r->get('mysql_host'),
				'DB_PORT'=>$r->get('mysql_port'),
				'DB_DATABASE'=>$r->get('database_name'),
				'DB_USERNAME'=> $r->get('mysql_login'),
				'DB_PASSWORD'=>$r->get('mysql_password'),
				'TABLE_PREFIX'=>$r->get('table_prefix'),
			]);

		    die(json_encode(array('success' => true)));
		}
		catch(PDOException $ex){
		    die(json_encode(array('error' => true, 'message' => 'Unable to connect')));
		}

	}

}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Install Vn4CMS</title>
	<style type="text/css">
		@import url("https://fonts.googleapis.com/css?family=Lato");
		* {
		  margin: 0;
		  padding: 0;
		  -moz-box-sizing: border-box;
		  -webkit-box-sizing: border-box;
		  box-sizing: border-box;
		}

		body {
		  padding: 20px;
		  text-align: left;
		  font-family: Lato;
		  background: #ecf0f1;
		}

		h1 {
		  font-weight: normal;
		  font-size: 40px;
		  font-weight: normal;
	      text-align: center;
		}
		h1 span {
		  font-size: 13px;
		  display: block;
		  padding-left: 4px;
		}

		.tabs {
		  width: 650px;
		  float: none;
		  list-style: none;
		  position: relative;
		  margin: 10px auto 0 auto;
		  text-align: left;
		}
		.tabs li {
		  float: left;
		  display: block;
		}
		.tabs input[type="radio"] {
		  position: absolute;
		  top: 0;
		  left: -9999px;
		}
		.tabs label {
	   	 pointer-events: none;
		  display: block;
		  padding: 14px 21px;
		  border-radius: 2px 2px 0 0;
		  font-size: 16px;
		  font-weight: normal;
		  background: #d8d8d8;
		  cursor: pointer;
		  position: relative;
		  top: 4px;
		  -moz-transition: all 0.2s ease-in-out;
		  -o-transition: all 0.2s ease-in-out;
		  -webkit-transition: all 0.2s ease-in-out;
		  transition: all 0.2s ease-in-out;
		}
		.tabs label:hover {
		  background: #bdbdbd;
		}
		.tabs .tab-content {
		  z-index: 2;
		  display: none;
		  overflow: hidden;
		  width: 100%;
		  font-size: 17px;
		  line-height: 25px;
		  position: absolute;
		  top: 48px;
		  left: 0;
		  padding-bottom: 100px;
		}
		.tabs .tab-content-child{
		  background: white;
		  padding: 25px;
		}
		.tabs [id^="tab"]:checked + label {
		  top: 0;
		  padding-top: 17px;
		  background: white;
		}
		.tabs [id^="tab"]:checked ~ [id^="tab-content"] {
		  display: block;
		}

		p.link {
		  clear: both;
		  margin: 380px 0 0 15px;
		}
		p.link a {
		  text-transform: uppercase;
		  text-decoration: none;
		  display: inline-block;
		  color: #fff;
		  padding: 5px 10px;
		  margin: 0 5px;
		  background-color: white;
		  -moz-transition: all 0.2s ease-in;
		  -o-transition: all 0.2s ease-in;
		  -webkit-transition: all 0.2s ease-in;
		  transition: all 0.2s ease-in;
		}
		p.link a:hover {
		  background-color: #522764;
		}
		h2{
			font-size: 21px;
    		margin: 20px 0;
    		color: rgb(51, 73, 94);
    		font-weight: normal;
		}
		.database{
    		width: 100%;
    		vertical-align: top;
		}
		.database input, .database select{
			-webkit-transition: none;
		    transition: none;
		    -webkit-box-shadow: none;
		    box-shadow: none;
		    border: 1px solid #e0e0e0;
		    border-radius: 3px;
		    font-family: sans-serif;
		    display: block;
		    width: 100%;
		    height: 34px;
		    padding: 6px 12px;
		    font-size: 14px;
		    line-height: 1.42857143;
		    color: #555;
		    background-color: #fff;
		    background-image: none;
		    border: 1px solid #ccc;
		    border-radius: 3px;
		    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
		    box-shadow: inset 0 1px 1px rgba(0,0,0,0.075);
		    -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
		    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
		}
		.database p{
		    display: block;
		    margin-top: 5px;
		    margin-bottom: 10px;
		    color: #737373;
		    font-family: "Helvetica", sans-serif;
		    font-size: 12px;
		    line-height: 1.42857143;
		    color: #333;
		}
		.database td{
		    vertical-align: baseline;
		}
		.database tr td:first-child{
		    width: 33.33333333%;
		    text-align: right;
		    padding: 10px 10px;
		    font-size: 13px;
		}
		.btn, .btn-primary{

		    padding: 10px 15px;
		    float: right;
		    border: none;
		    background-color: #D2D9DD;
		    color: #576061;
		    position: relative;
		    font-size: 14px;
		    display: inline-block;
		    margin-bottom: 0;
		    font-weight: normal;
		    text-align: center;
		    vertical-align: middle;
		    cursor: pointer;
		    background-image: none;
		    border: 1px solid transparent;
		    white-space: nowrap;
		    padding: 6px 12px;
		    font-size: 14px;
		     line-height: 15px;
		    border-radius: 3px;
	        margin: 2.5px;
		}
		.btn-primary{
			color: #fff;
		    background-color: #428bca;
		    border-color: #357ebd;
		}
		.system-check .item{
			font-size: 14px;
			margin-bottom: 5px;
		}
		.message{
			display: none;
		    position: fixed;
		    top: 0;
		    bottom: 0;
		    right: 0;
		    left: 0;
		    background: rgba(0, 0, 0, 0.67);
		    z-index: 99;
		}
		body.show_message .message{
			display: block;
		}
		#message{
			position: absolute;
		    left: 50%;
		    top: 50%;
		    transform: translate(-50%,-50%);
		    color: white;
		    font-size: 4rem;
		}
	</style>
</head>
<body>
<h1><img src="<?php echo asset('admin/images/vn4cms-logo.png') ?>"> </h1>
<h2 style="text-align: center;">We are not looking for perfection, we start from there.</h2>
	<?php

		define('VN4_MINIMUM_PHP_VERSION_ID', 70200);
		$required = [
			'phpversion'=>[
				'title'=>'PHP version 7.2 or greater required',
				'result'=>function(){
					return PHP_VERSION_ID >= VN4_MINIMUM_PHP_VERSION_ID;
				}
			],
			'sslLibrary'=>[
				'title'=>'OpenSSL PHP Extension is required',
				'result'=>function(){
					return extension_loaded('openssl');
				}
			],
			'pdoLibrary'=>[
				'title'=>'PDO PHP Extension is required',
				'result'=>function(){
					return defined('PDO::ATTR_DRIVER_NAME');
				}
			],
			'mbstringLibrary'=>[
				'title'=>'Mbstring PHP Extension is required',
				'result'=>function(){
					return extension_loaded('mbstring');
				}
			],
			'curlLibrary'=>[
				'title'=>'cURL PHP Extension is required',
				'result'=>function(){
					return function_exists('curl_init') && defined('CURLOPT_FOLLOWLOCATION');
				}
			]
		];

	 ?>
<div>
<ul class="tabs" role="tablist">
    <li>
        <input type="radio" name="tabs" id="tab1" checked />
        <label for="tab1" 
               role="tab" 
               aria-selected="true" 
               aria-controls="panel1" 
               tabindex="0">System Check</label>
        <div id="tab-content1" 
             class="tab-content" 
             role="tabpanel" 
             aria-labelledby="description" 
             aria-hidden="false">
             <div class="tab-content-child">
          	

          	<div class="system-check">

          		<?php 
          			foreach ($required as $key => $value) {
          				?>

          				<div class="item check">

          				<?php
          				if( $value['result']() ){
          				?>	
		      				<svg class="svg-icon check" style="width: 25px;height:25px;float: left;" viewBox="0 0 20 20">
									<path fill="#8da85e" d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z"></path>
								</svg>
						<?php 
						}else{
							?>
			      				<svg class="svg-icon not-check" style="width: 25px;height:25px; float: left;" viewBox="0 0 20 20">
									<path fill="#cc3300" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
								</svg>
						<?php
							}
					 	?>
							<span style="float: left;"><?php echo $value['title']; ?></span>
						</div>
	          			


						<br style="clear: both;" />
          				<?php
          			}
          		 ?>
				<span class="btn btn-next1">Next
					<svg class="svg-icon" style="width:27px;height:18px;float: right;" viewBox="0 0 20 20">
						<path fill="#4691f6" d="M1.729,9.212h14.656l-4.184-4.184c-0.307-0.306-0.307-0.801,0-1.107c0.305-0.306,0.801-0.306,1.106,0
						l5.481,5.482c0.018,0.014,0.037,0.019,0.053,0.034c0.181,0.181,0.242,0.425,0.209,0.66c-0.004,0.038-0.012,0.071-0.021,0.109
						c-0.028,0.098-0.075,0.188-0.143,0.271c-0.021,0.026-0.021,0.061-0.045,0.085c-0.015,0.016-0.034,0.02-0.051,0.033l-5.483,5.483
						c-0.306,0.307-0.802,0.307-1.106,0c-0.307-0.305-0.307-0.801,0-1.105l4.184-4.185H1.729c-0.436,0-0.788-0.353-0.788-0.788
						S1.293,9.212,1.729,9.212z"></path>
					</svg>
				</span>
				<br style="clear: both;" />
          	</div>

          </div>

        </div>
    </li>
  
    <li>
        <input type="radio" name="tabs" id="tab2" />
        <label for="tab2"
               role="tab" 
               aria-selected="false" 
               aria-controls="panel2" 
               tabindex="0">Database</label>
        <div id="tab-content2" 
             class="tab-content"
             role="tabpanel" 
             aria-labelledby="specification" 
             aria-hidden="true">


         	<div class="tab-content-child">
	         <h2>Please prepare an empty database for this installation.</h2>
	         <form id="formDatabase">
	         <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
	         <input type="hidden" name="checkdatabase" value="true">
	         <table class="database">
	         	<tr>
	         		<td>Database Type</td>
	         		<td>
	         			<select name="database_type">
	         				<option value="mysql">Mysql</option>
	         			</select>
	         			<p>Please specify the database driver type for this connection</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>MySQL Host</td>
	         		<td>
	         			<input class="input-required" type="" value="localhost" name="mysql_host">
	         			<p>Specify the hostname for the database connection.</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>MySQL Port</td>
	         		<td>
	         			<input class="input-required" type="number" value="3306" name="mysql_port">
	         			<p>(Optional) Specify a non-default port for the database connection.</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>Database Name</td>
	         		<td>
	         			<input class="input-required" type="" name="database_name">
	         			<p>Specify the name of the empty database.</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>MySQL Login</td>
	         		<td>
	         			<input class="input-required" type="" name="mysql_login">
	         			<p>User with all privileges in the database.</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>MySQL Password</td>
	         		<td>
	         			<input type="" name="mysql_password">
	         			<p>Password for the specified user.</p>
	         		</td>
	         	</tr>
	         	<tr>
	         		<td>Table Prefix</td>
	         		<td>
	         			<input class="input-required" value="vn4_" type="" name="table_prefix">
	         			<p>If you want to run multiple Vn4CMS installations in single database, change this.</p>
	         		</td>
	         	</tr>
	         </table>
	          <br>
          </form>

	         <span class="btn btn-next2">Next
	         	<svg class="svg-icon" style="width:27px;height:18px;float: right;" viewBox="0 0 20 20">
					<path fill="#4691f6" d="M1.729,9.212h14.656l-4.184-4.184c-0.307-0.306-0.307-0.801,0-1.107c0.305-0.306,0.801-0.306,1.106,0
					l5.481,5.482c0.018,0.014,0.037,0.019,0.053,0.034c0.181,0.181,0.242,0.425,0.209,0.66c-0.004,0.038-0.012,0.071-0.021,0.109
					c-0.028,0.098-0.075,0.188-0.143,0.271c-0.021,0.026-0.021,0.061-0.045,0.085c-0.015,0.016-0.034,0.02-0.051,0.033l-5.483,5.483
					c-0.306,0.307-0.802,0.307-1.106,0c-0.307-0.305-0.307-0.801,0-1.105l4.184-4.185H1.729c-0.436,0-0.788-0.353-0.788-0.788
					S1.293,9.212,1.729,9.212z"></path>
				</svg>
	         </span>

	         <span class="btn btn-back" data-tab="tab1">
	         <svg class="svg-icon" style="width:27px;height:18px;float: left;" viewBox="0 0 20 20">
					<path fill="#4691f6" d="M18.271,9.212H3.615l4.184-4.184c0.306-0.306,0.306-0.801,0-1.107c-0.306-0.306-0.801-0.306-1.107,0
					L1.21,9.403C1.194,9.417,1.174,9.421,1.158,9.437c-0.181,0.181-0.242,0.425-0.209,0.66c0.005,0.038,0.012,0.071,0.022,0.109
					c0.028,0.098,0.075,0.188,0.142,0.271c0.021,0.026,0.021,0.061,0.045,0.085c0.015,0.016,0.034,0.02,0.05,0.033l5.484,5.483
					c0.306,0.307,0.801,0.307,1.107,0c0.306-0.305,0.306-0.801,0-1.105l-4.184-4.185h14.656c0.436,0,0.788-0.353,0.788-0.788
					S18.707,9.212,18.271,9.212z"></path>
				</svg>
	         Back</span>

			<br style="clear: both;" />
          	</div>
        </div>
    </li>



    <li>
        <input type="radio" name="tabs" id="tab3" />
        <label for="tab3"
               role="tab" 
               aria-selected="false" 
               aria-controls="panel2" 
               tabindex="0">Administrator</label>
        <div id="tab-content3" 
             class="tab-content"
             role="tabpanel" 
             aria-labelledby="specification" 
             aria-hidden="true">


         	<div class="tab-content-child">
	          <h2>Please specify details for logging in to the Administration Area.</h2>
	          <form id='formAdministrator'>
          		 <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
		         <table class="database " >
		         	<tr>
		         		<td>First Name</td>
		         		<td>
		         			<input type="" class="input-required" name="first_name">
		         		</td>
		         	</tr>
		         	<tr>
		         		<td>Last Name</td>
		         		<td>
		         			<input type="" class="input-required" name="last_name">
		         		</td>
		         	</tr>
		         	<tr>
		         		<td>Email Address</td>
		         		<td>
		         			<input type="email" class="input-required" name="email">
		         		</td>
		         	</tr>
		         	<tr>
		         		<td>Admin Password</td>
		         		<td>
		         			<input type="" class="input-required" id="admin_password" name="admin_password">
		         			<span class="btn generate_password" style="width: 100%;margin-top:5px;">Generate Random Password</span>
		         		</td>
		         	</tr>
		         </table>
		          <br>
	           </form>
	         <span class="btn btn-next3">Next
	         	<svg class="svg-icon" style="width:27px;height:18px;float: right;" viewBox="0 0 20 20">
					<path fill="#4691f6" d="M1.729,9.212h14.656l-4.184-4.184c-0.307-0.306-0.307-0.801,0-1.107c0.305-0.306,0.801-0.306,1.106,0
					l5.481,5.482c0.018,0.014,0.037,0.019,0.053,0.034c0.181,0.181,0.242,0.425,0.209,0.66c-0.004,0.038-0.012,0.071-0.021,0.109
					c-0.028,0.098-0.075,0.188-0.143,0.271c-0.021,0.026-0.021,0.061-0.045,0.085c-0.015,0.016-0.034,0.02-0.051,0.033l-5.483,5.483
					c-0.306,0.307-0.802,0.307-1.106,0c-0.307-0.305-0.307-0.801,0-1.105l4.184-4.185H1.729c-0.436,0-0.788-0.353-0.788-0.788
					S1.293,9.212,1.729,9.212z"></path>
				</svg>
	         </span>

	         <span class="btn btn-back" data-tab="tab2">
	         <svg class="svg-icon" style="width:27px;height:18px;float: left;" viewBox="0 0 20 20">
					<path fill="#4691f6" d="M18.271,9.212H3.615l4.184-4.184c0.306-0.306,0.306-0.801,0-1.107c-0.306-0.306-0.801-0.306-1.107,0
					L1.21,9.403C1.194,9.417,1.174,9.421,1.158,9.437c-0.181,0.181-0.242,0.425-0.209,0.66c0.005,0.038,0.012,0.071,0.022,0.109
					c0.028,0.098,0.075,0.188,0.142,0.271c0.021,0.026,0.021,0.061,0.045,0.085c0.015,0.016,0.034,0.02,0.05,0.033l5.484,5.483
					c0.306,0.307,0.801,0.307,1.107,0c0.306-0.305,0.306-0.801,0-1.105l-4.184-4.185h14.656c0.436,0,0.788-0.353,0.788-0.788
					S18.707,9.212,18.271,9.212z"></path>
				</svg>
	         Back</span>

			<br style="clear: both;" />

          	</div>
        </div>
    </li>



    <li>
        <input type="radio" name="tabs" id="tab4" />
        <label for="tab4"
               role="tab" 
               aria-selected="false" 
               aria-controls="panel4" 
               tabindex="0">Advanced</label>
        <div id="tab-content4" 
             class="tab-content"
             role="tabpanel" 
             aria-labelledby="specification" 
             aria-hidden="true">


         	<div class="tab-content-child">
		          <h2>Provide a custom URL for the Administration Area.</h2>

		          <form id='formAdvanced'>
	          		 <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
	          		 <input type="hidden" name="setting" value="true">
			         <table class="database">
			         	<tr>
			         		<td>Login URL</td>
			         		<td>
			         			<input type="" class="input-required" name="login_url" value="l0gin">
			         		</td>
			         	</tr>
			         	<tr>
			         		<td>Backend URL</td>
			         		<td>
			         			<input type="" class="input-required" name="backend_url" value="adm1n">
			         		</td>
			         	</tr>
			         </table>
			          <br>
		          </form>

	          	<span class="btn-primary btn-next4">Continue
	          		<svg class="svg-icon" style="width:27px;height:18px;float: right;" viewBox="0 0 20 20">
						<path fill="white" d="M1.729,9.212h14.656l-4.184-4.184c-0.307-0.306-0.307-0.801,0-1.107c0.305-0.306,0.801-0.306,1.106,0
						l5.481,5.482c0.018,0.014,0.037,0.019,0.053,0.034c0.181,0.181,0.242,0.425,0.209,0.66c-0.004,0.038-0.012,0.071-0.021,0.109
						c-0.028,0.098-0.075,0.188-0.143,0.271c-0.021,0.026-0.021,0.061-0.045,0.085c-0.015,0.016-0.034,0.02-0.051,0.033l-5.483,5.483
						c-0.306,0.307-0.802,0.307-1.106,0c-0.307-0.305-0.307-0.801,0-1.105l4.184-4.185H1.729c-0.436,0-0.788-0.353-0.788-0.788
						S1.293,9.212,1.729,9.212z"></path>
					</svg>
	          	</span>

		         <span class="btn btn-back" data-tab="tab3">
		         <svg class="svg-icon" style="width:27px;height:18px;float: left;" viewBox="0 0 20 20">
						<path fill="#4691f6" d="M18.271,9.212H3.615l4.184-4.184c0.306-0.306,0.306-0.801,0-1.107c-0.306-0.306-0.801-0.306-1.107,0
						L1.21,9.403C1.194,9.417,1.174,9.421,1.158,9.437c-0.181,0.181-0.242,0.425-0.209,0.66c0.005,0.038,0.012,0.071,0.022,0.109
						c0.028,0.098,0.075,0.188,0.142,0.271c0.021,0.026,0.021,0.061,0.045,0.085c0.015,0.016,0.034,0.02,0.05,0.033l5.484,5.483
						c0.306,0.307,0.801,0.307,1.107,0c0.306-0.305,0.306-0.801,0-1.105l-4.184-4.185h14.656c0.436,0,0.788-0.353,0.788-0.788
						S18.707,9.212,18.271,9.212z"></path>
					</svg>
		         Back</span>

				<br style="clear: both;" />

          	</div>
        </div>
    </li>


     <li>
        <input type="radio" name="tabs" id="tab5" />
        <label for="tab5"
               role="tab" 
               aria-selected="false" 
               aria-controls="panel5" 
               tabindex="0">Finish</label>
        <div id="tab-content5" 
             class="tab-content"
             role="tabpanel" 
             aria-labelledby="specification" 
             aria-hidden="true">


         	<div class="tab-content-child" style="text-align: center;">


         	<h1 style="margin-bottom: 30px;">Install Success</h1>
	          	<a href="<?php echo url('/'); ?>">Go to Home page</a>&nbsp;&nbsp;&nbsp;
	          	<a id="linklogin" href="#">Go to Login page</a>

				<br style="clear: both;" />

          	</div>
        </div>
    </li>


</ul>
</div>
<br style="clear: both;" />


<div class="message">
	<h4 id="message">Loading</h4>	
</div>

<script src="<?php echo asset('/admin/js/jquery-2.2.3.min.js'); ?>"></script>
<script type="text/javascript">

	$('.btn-back').click(function(){
		$('.tabs label[for="'+$(this).data('tab')+'"]').trigger('click');
	});

	$('.btn-next1').click(function(){

		var value = $('.not-check').map(function(){
		      return $(this).closest('.item').find('span').text();
		    }).get();

		if( value.length ){
			alert(value.join("\n"));
			return;
		}

		$('.tabs label[for="tab2"]').trigger('click');


	});

	function show_message(message){
		$('#message').text(message);
		$('body').addClass('show_message');
	}

	function hide_message(){
		$('body').removeClass('show_message');
	}

	$('.btn-next2').click(function(){

		var value = [];

		$('#formDatabase .input-required').each(function(index, el){

			if( !$(el).val() ){
				value.push( $(el).closest('tr').find('td:first-child').text() + ' is required');
			}

		});

		if( value.length ){
			alert(value.join("\n"));
			return;
		}

		var data = $('#formDatabase').serialize();

		show_message('Check Databse.');

		$.ajax({
			type:'POST',
			dataType:'Json',
			data:data,
			success:function(data){
				if( data.success ){
					$('.tabs label[for="tab3"]').trigger('click');
				}

				if( data.error ){
					alert(data.message);
				}
			}
		}).done(function(){
			hide_message();
		});

	});

	$('.generate_password').click(function(){
		var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz!@#$%^&*()_+<>?~";
        var string_length = 24;
        var randomstring = '';
        for (var i=0; i<string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum,rnum+1);
        }

        $('#admin_password').val(randomstring);
	});

	$('.btn-next3').click(function(){

		var value = [];

		$('#formAdministrator .input-required').each(function(index, el){

			if( !$(el).val() ){
				value.push( $(el).closest('tr').find('td:first-child').text() + ' is required' );
			}

		});

		if( value.length ){
			alert(value.join("\n"));
			return;
		}

		$('.tabs label[for="tab4"]').trigger('click');


	});

	$('.btn-next4').click(function(){
		var value = [];

		$('#formAdvanced .input-required').each(function(index, el){

			if( !$(el).val() ){
				value.push( $(el).closest('tr').find('td:first-child').text() + ' is required' );
			}

		});

		if( value.length ){
			alert(value.join("\n"));
			return;
		}

		var data = $('#formDatabase, #formAdministrator, #formAdvanced').serialize();

		show_message('Installing...');

		$.ajax({
			type:'POST',
			dataType:'Json',
			data:data,
			success:function(data){
				if( data.success ){

					$('#linklogin').attr('href',data.loginpage);
					$('.tabs label[for="tab5"]').trigger('click');
				}
			}
		}).done(function(){
			hide_message();
		});

	});
</script>
</body>
</html>
