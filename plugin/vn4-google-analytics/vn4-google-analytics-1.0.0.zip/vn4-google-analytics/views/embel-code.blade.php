@extends(backend_theme('master'))
@section('content')
<?php 
title_head( 'Setting' );
?>

<form method="POST">
      <input type="hidden" value="{!!csrf_token()!!}" name="_token">

    <div class="row">
      
        <div class="col-md-3 col-xs-12">
          <h3>Embel Code</h3>
          <p class="note">Activate google analytics on website.</p>
        </div>
        <div class="col-md-5 col-xs-12" >
            <textarea rows="6" class="form-control" name="code-analytics">{!!$plugin->getMeta('code-analytics')!!}</textarea>
        </div>
    </div>
    <hr>

   <input style="margin-left:10px;" type="submit" class="vn4-btn vn4-btn-blue" name="save-change" value="@__('Save changes')">
</form>



@stop

