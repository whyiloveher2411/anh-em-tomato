<?php
if( ($code = $plugin->getMeta('code-analytics')) && !check_user_agent('bot') ){
	add_action('vn4_footer',function() use ($code){
		echo $code;
	});
}