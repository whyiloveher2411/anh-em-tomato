<?php


if( check_permission('plugin_google_analytics_view_dashboard') ){

	return [
		route('google-analytics.report-item',['folder'=>'dashboard','view'=>'index'])
	];

}