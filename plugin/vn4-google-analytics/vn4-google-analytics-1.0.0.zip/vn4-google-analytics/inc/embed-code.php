<?php

if( $r->isMethod('GET') ){
	return view_plugin($plugin, 'views.embel-code',['plugin'=>$plugin]);
}

if( env('EXPERIENCE_MODE') ){
    return experience_mode();
}

$code = $r->get('code-analytics');

if( !$code ) $code = '';

$plugin->updateMeta('code-analytics',$code);
vn4_create_session_message( __('Success'), __p('Update Embed code Success.',$plugin->key_word), 'success' , true);

return redirect()->back();