<?php

return [
	'analytics'=>['title'=>'Google Analytics','callback'=>function( $searchArray, $searchString ) use ($plugin){

		return [
			[
				'title_type'=>'Analytics',
				'title'=>'Embed Code',
				'link'=>route('google-analytics.embed-code'),
			],
			[
				'title_type'=>'Analytics',
				'title'=>'Setting',
				'link'=>route('google-analytics.setting'),
			],
			[
				'title_type'=>'Analytics',
				'title'=>'Report',
				'link'=>route('google-analytics.report'),
			],
		];
		

	}]
];