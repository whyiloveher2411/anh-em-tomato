<?php

$access_code = $plugin->getMeta('access_token_first');

$webpropertie_id = $access_code['webpropertie_id'];

$access_token = get_access_token($plugin);

return view_plugin($plugin, 'views.report',['plugin'=>$plugin,'access_code'=>$access_code,'webpropertie_id'=>$webpropertie_id,'access_token'=>$access_token]);

