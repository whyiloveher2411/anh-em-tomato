@extends(backend_theme('master'))



@section('content')



<?php 

title_head( 'Setting' );

$access_code = json_decode( $plugin->getMeta('access_token_first'),true );

$webpropertie_id = false;

if( isset($access_code['webpropertie_id']) ){
  $webpropertie_id = $access_code['webpropertie_id'];

}

// dd($access_code);

?>
<style type="text/css">
  .webpropertie_id .selected{
    background: #dedede;
  }
</style>
  <form class="form-setting form-horizontal form-label-left input_mask" id="form_create" method="POST">

    <input type="text" name="_token" value="{!!csrf_token()!!}" hidden>

    <div class="row seo_vn4">

      <div class="col-xs-12 col-md-9">
        
        <div class="vn4_google_analytics" >
          <p>Step 1: get file conffig app (Google console)</p>
          <div class="form-group">
            <div class="row">
              <label class="col-md-2 col-xs-12" style="line-height:28px;" >File App Json</label>
              <div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
                <?php 
                  echo get_field('asset-file',['key'=>'file_app_json','value'=>$plugin->getMeta('file_app_json')]);
                 ?>
              </div>
            </div>
          </div>
        </div>

        @if( isset($access_code['access_code'] ) )
        <div class="vn4_google_analytics  " >
          
          <p class="disable_event">Step 2: Use this link to get your one-time-use access code: <a href="{!!$auth_url!!}" onclick="return !window.open(this.href, 'Google Auth', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=640, height=580, top='+(window.screen.height/2-290)+', left='+(window.screen.width/2-320))"  style="color:red;text-decoration:underline;">Get Access Code.</a></p>

          <div class="form-group">
            <div class="row">
              <label class="col-md-2 col-xs-12 disable_even" style="line-height:28px;" >Access Code:</label>
              <div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
                <input value="{!!$access_code['access_code']!!}" type="text" class="form-control col-md-7 col-xs-12 disable_event">
              </div>
            </div>
          </div>
          <div class="row">
            <label class="col-md-2 col-xs-12 disable_even" style="line-height:28px;" >Access Token:</label>
            <div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
              <input value="{!!$access_code['access_token']!!}" type="text" class="form-control col-md-7 col-xs-12 disable_event">
              <button name="clear_authorization" style="margin-top: 15px;" value="1" class="vn4-btn" >Clear Authorization</button>
            </div>
          </div>

           <div class="row" style="margin-top: 15px;">
            <label class="col-md-2 col-xs-12 disable_even" style="line-height:28px;" >Select View:</label>
            <div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">

              <select class="form-control col-md-7 col-xs-12 webpropertie_id" name="webpropertie_id">
                  @foreach($accounts['items'] as $ac)
                  <optgroup label="{!!$ac['name']!!}">
                     @foreach($ac['webproperties']['items'] as $web)
                     @if( isset($web['defaultProfileId']) )
                      <option @if( $webpropertie_id === $web['defaultProfileId']) selected="selected" class="selected" @endif value="{!!$web['defaultProfileId']!!}">{!!$web['name']!!}</option>
                     @endif
                     @endforeach
                  </optgroup>
                  @endforeach
              </select>
                
            </div>
          </div>

        </div>
        @elseif( $plugin->getMeta('file_app_json') )
        
        <div class="vn4_google_analytics" >
          <p>Step 2: Use this link to get your one-time-use access code: <a href="{!!$auth_url!!}" onclick="return !window.open(this.href, 'Google Auth', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=640, height=580, top='+(window.screen.height/2-290)+', left='+(window.screen.width/2-320))"  style="color:red;text-decoration:underline;">Get Access Code.</a></p>
          <div class="form-group">
            <div class="row">
              <label class="col-md-2 col-xs-12" style="line-height:28px;" >Access Code:</label>
              <div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
                <input name="access_code" value="" type="text" id="access_code" class="form-control col-md-7 col-xs-12">
              </div>
            </div>
          </div>
        </div>
        @endif


      </div>

      <div class="col-xs-12 col-md-3">

        <?php 

          vn4_panel('Action',function(){

            echo '<button class="vn4-btn vn4-btn-blue">Save changes</button>';

          });

         ?>

        

      </div>

    </div>

  </form>

@stop

