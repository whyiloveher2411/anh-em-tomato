<?php 
function thousandsCurrencyFormat($num) {
  if($num>1000) {
        $x = round($num);
        $x_number_format = number_format($x);
        $x_array = explode(',', $x_number_format);
        $x_parts = array('k', 'm', 'b', 't');
        $x_count_parts = count($x_array) - 1;
        $x_display = $x;
        $x_display = $x_array[0] . ((int) $x_array[1][0] !== 0 ? '.' . $x_array[1][0] : '');
        $x_display .= $x_parts[$x_count_parts - 1];
        return $x_display;
  }
  return $num;
}
// dd(thousandsCurrencyFormat(3205000));
    $start_date = $r->get('start-date',date('Y-m-d', strtotime(' -7 day')));
    $end_date = $r->get('end-date',date('Y-m-d', strtotime(' -1 day')));
    $start_date2 = $r->get('start-date',date('Y-m-d', strtotime(' -14 day')));
    $end_date2 = $r->get('end-date',date('Y-m-d', strtotime(' -8 day')));
    $start_date_now1 = date('Y-m-d');
    $hour1 = date('H');
    if( $hour1 > 0 ){
		$start_date_now2 = $start_date_now1;
    	$hour2 = $hour1*1 - 1;
    }else{
	 	$start_date_now2 = date('Y-m-d', strtotime(' -1 day'));
    	$hour2 = 23;
    }
    if( $hour2*1 < 10 ) $hour2 = '0'.$hour2;
    // dd(file_post_contents_curl('https://analyticsreporting.googleapis.com/v4/reports:batchGet',['access_token'=>$access_token]));
    $dataGoogle = multiple_threads_request([
    	
    	'card1_total'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration'],
    		[],
    		$access_token, $start_date, $end_date
    		),
    	'card2_total'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration'],
    		[],
    		$access_token, $start_date2, $end_date2
    		),
    	'card1'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration'],
    		['ga:date'],
    		$access_token, $start_date, $end_date
    		),
    	'card2'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:users,ga:sessions,ga:bounceRate,ga:avgSessionDuration'],
    		['ga:date'],
    		$access_token, $start_date2, $end_date2
    		),
    	'realtime'=>'https://www.googleapis.com/analytics/v3/data/realtime?ids=ga:'.$webpropertie_id.'&dimensions=rt:pagePath&metrics=rt:activeUsers&sort=-rt:activeUsers&order=-rt:activeUsers&max-results=5&access_token='.$access_token,
    	'pageview30_1'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga', $webpropertie_id, ['ga:pageviews'],['ga:minute'],$access_token, $start_date_now1, $start_date_now1,['filters'=>'ga:hour=='.$hour1] ),
    	'pageview30_2'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga', $webpropertie_id, ['ga:pageviews'],['ga:minute'],$access_token, $start_date_now2, $start_date_now2,['filters'=>'ga:hour=='.$hour2] ),
    	'user_channel'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:sessions'],
    		['ga:channelGrouping,ga:date'],
    		$access_token, $start_date, $end_date
    		),
    	'session_country'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:sessions'],
    		['ga:country'],
    		$access_token, $start_date, $end_date,['sort'=>'-ga:sessions']
    		),
    	'path_pageview'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:pageviews,ga:pageValue'],
    		['ga:landingPagePath'],
    		$access_token, $start_date, $end_date,['sort'=>'-ga:pageviews','max-results'=>10]
    		),


    	'active_users_1day'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:1dayUsers'],
    		['ga:date'],
    		$access_token, $start_date, $end_date,[]
    		),
    	'active_users_7day'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:7dayUsers'],
    		['ga:date'],
    		$access_token, $start_date, $end_date,[]
    		),
    	'active_users_30day'=>get_url_google_analytics('https://www.googleapis.com/analytics/v3/data/ga',
    		$webpropertie_id, ['ga:30dayUsers'],
    		['ga:date'],
    		$access_token, $start_date, $end_date,[]
    		),
    	
    ]);
    // dd($dataGoogle);
    $traffic_channel = [];
    foreach ($dataGoogle['user_channel']['rows'] as $k => $v) {
    	$traffic_channel[$v[1]][$v[0]] = $v[2];
    }
    foreach ($traffic_channel as $k => $v) {
    	if( !isset($v['Organic Search']) ) $traffic_channel[$k]['Organic Search'] = 0;
    	if( !isset($v['Direct']) ) $traffic_channel[$k]['Direct'] = 'null';
    	if( !isset($v['Paid Search']) ) $traffic_channel[$k]['Paid Search'] = 0;
    	if( !isset($v['Referral']) ) $traffic_channel[$k]['Referral'] = 0;
    	if( !isset($v['Social']) ) $traffic_channel[$k]['Social'] = 0;
    	if( !isset($v['Display']) ) $traffic_channel[$k]['Display'] = 0;
    	if( !isset($v['(Other)']) ) $traffic_channel[$k]['(Other)'] = 0;
    	 $traffic_channel[$k]['(Other)'] += $traffic_channel[$k]['Display'] + $traffic_channel[$k]['Social'];
    }
    // dd($traffic_channel);
    $dataPageView30M = [];
    $index = 0;
    if( isset($dataGoogle['pageview30_1']['rows']) ){
	    $count = count($dataGoogle['pageview30_1']['rows']) - 1;
	    for ($i=$count; $i >= 0 ; $i--) { 
	    	
	    	if( $index > 29 ){
	    		break;
	    	}
	    	$dataPageView30M[$index.' mins ago'] = $dataGoogle['pageview30_1']['rows'][$i][1];
	    	$index ++;
	    }
    }
    if( $index < 31 ){
	    $count = count($dataGoogle['pageview30_2']['rows']) - 1;
		for ($i=$count; $i >= 0 ; $i--) { 
	    	
	    	if( $index > 29 ){
	    		break;
	    	}
	    	$dataPageView30M[$index.' mins ago'] = $dataGoogle['pageview30_2']['rows'][$i][1];
	    	$index ++;
	    }
	}
 ?>
<style type="text/css">
	*{
		margin: 0;
		padding: 0;
		text-decoration: none;
		outline: none;
		box-sizing: border-box;
		font-family: 'Roboto',sans-serif;
	}
	body{
		background: #f8f9fa;
	}
	.section-card{
		display: flex;
		flex-wrap: wrap;
		justify-content: left;
	}
	.card{
		color: rgba(0,0,0,0.87);
	    border-radius: 2px;
	    flex-direction: column;
	    margin: 0 8px;
	}
	.card .outer-title{
		height: 18px;
	    margin: 20px 0 20px 8px;
	    color: #4a4a4a;
		font-family: 'Roboto',sans-serif;
	    letter-spacing: 0;
	}
	.tab-group{
		height: 120px;
	}
	.tab-item{
	    min-width: 94px;
	    padding: 20px 24px 16px;
	    display: inline-block;
	    float: left;
		border-top: 4px solid white;
		cursor: pointer;
	}
	.tab-item .title{
	    color: rgba(0,0,0,0.54);
		font-family: 'Roboto',sans-serif;
	    letter-spacing: 0;
	    margin-bottom: 18px;
	    font-size: 13px;
		display: block;
	}
	.uppercase{
		text-transform: uppercase;
	}
	.tab-item .number{
	    color: rgba(0,0,0,0.87);
		font-family: 'Roboto',sans-serif;
	    letter-spacing: 0;
	    margin-bottom: 10px;
	    display: block;
	    font-weight: normal;
	}
	.tab-item .present{
		font-size: 12px;
	}
	.tab-item.active .title{
		font-weight: bold;
	}
	.tab-item.active{
		border-top: 4px solid  #4285f4;
	}
	.tab-item .present svg{
		width: 10px;
    	height: 9px;
	}
	.card .card-content{
		height: 500px;
	    box-shadow: 0 1px 3px 0 rgba(0,0,0,.2), 0 1px 1px 0 rgba(0,0,0,.14), 0 2px 1px -1px rgba(0,0,0,.12);
	    background: white;
	}
	.card-content.realtime{
		background-color: #4285f4;
		padding: 24px 24px 0;
	}
	.card-656{
		width: 656px;
	}
	.card-488{
		width: 488px;
	}
	.card-320{
		width: 320px;
	}
	
	.tab-group .decrease, .tab-sessions .decrease, .tab-time .decrease, .tab-bounceRate .increase, .chart-users .google-visualization-tooltip-item .present.decrease, .chart-sessions .google-visualization-tooltip-item .present.decrease, .chart-time .google-visualization-tooltip-item .present.decrease, .chart-bounceRate .google-visualization-tooltip-item .present.increase {
	    color: #db4437 !important; 
	    /*Màu đỏ*/
	}
	.tab-group .increase, .tab-sessions .increase, .tab-time .increase, .tab-bounceRate .decrease, .chart-users .google-visualization-tooltip-item .present.increase, .chart-sessions .google-visualization-tooltip-item .present.increase, .chart-time .google-visualization-tooltip-item .present.increase, .chart-bounceRate .google-visualization-tooltip-item .present.decrease {
	    color: #0f9d58 !important;
	    /*Màu Xanh*/
	}
	.tab-group .decrease svg, .tab-sessions .decrease svg, .tab-time .decrease svg, .tab-bounceRate .increase svg, .chart-users .google-visualization-tooltip-item .present.decrease svg, .chart-sessions .google-visualization-tooltip-item .present.decrease svg, .chart-time .google-visualization-tooltip-item .present.decrease svg, .chart-bounceRate .google-visualization-tooltip-item .present.increase svg{
	    color: #db4437 !important; 
	    fill: #db4437 !important;
	    /*Màu đỏ*/
	}
	.tab-group .increase svg, .tab-sessions .increase svg, .tab-time .increase svg, .tab-bounceRate .decrease svg, .chart-users .google-visualization-tooltip-item .present.increase svg, .chart-sessions .google-visualization-tooltip-item .present.increase svg, .chart-time .google-visualization-tooltip-item .present.increase svg, .chart-bounceRate .google-visualization-tooltip-item .present.decrease svg{
	    color: #0f9d58 !important;
	    fill: #0f9d58 !important;
	    /*Màu Xanh*/
	}
	table.table-chart{
		width: 100%;
		margin-top: 20px;
	}
	table.table-chart thead td{
		padding: 5px;
		font-size: 12px;
	}
	table.table-chart.color-white thead td{
		color: rgba(255,255,255,0.8);
	}
	table.table-chart.color-white td{
		color: white;
	}
	table.table-chart td{
		padding: 5px;
		color: rgba(0, 0, 0, 0.87);
		font-size: 13px;
		height: 29px;
		border-bottom: 1px solid rgba(255, 255, 255, 0.2);
	}
	table.table-chart td:nth-child(2), table.table-chart td:nth-child(3){
		text-align: right;
	}
	.google-visualization-tooltip .google-visualization-tooltip-item{
		white-space: nowrap;
		margin: 3px 0;
	}
	.google-visualization-tooltip .google-visualization-tooltip-item:first-child, .google-visualization-tooltip .google-visualization-tooltip-item:last-child{
		margin: 3px 0;
		/*display: none;*/
	}
	#chart_30 .google-visualization-tooltip .google-visualization-tooltip-item span{
		font-size: 12px !important;
		color: #545454 !important;
	}
	#chart_30 .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) span{
		font-size: 18px !important;
		/*display: none;*/
	}
	#chart_30 .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2){
		margin: 10px 0px !important;
	}
	
	#char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2), #char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) strong, #char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) .present{
		font-size: 12px !important;
	}
	#char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) span{
		font-weight: normal !important;
	}
	#char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2), #char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) strong, #char_audience .google-visualization-tooltip .google-visualization-tooltip-item:nth-child(2) .present{
		font-weight: bold !important;
	}
	#char_audience .google-visualization-tooltip-item svg{
		width: 10px;
    	height: 9px;
	}
	#chart_location{
		/*pointer-events:  none;*/
	}
	/*#chart_location text{
		fill: #9e9e9e !important;
		font-size: 13px;
	}*/
	#chart_location svg>g>g>g:nth-child(3) rect{
		display: none;
	}
	#char_acquisition svg>g>g>g>rect[fill="#3367d6"]{
	    stroke: #3367d6;
		stroke-width: 2px;
	}
	#char_acquisition svg>g>g>g>rect[fill="#4285f4"]{
	    stroke: #4285f4;
		stroke-width: 2px;
	}
	#char_acquisition svg>g>g>g>rect[fill="#72a4f7"]{
	    stroke: #72a4f7;
		stroke-width: 2px;
	}
	#char_acquisition svg>g>g>g>rect[fill="#d0e0fc"]{
	    stroke: #d0e0fc;
		stroke-width: 2px;
	}
	#char_acquisition svg>g>g>g>rect[fill="#a0c2f9"]{
	    stroke: #a0c2f9;
		stroke-width: 2px;
	}
	.item-h{
		border-radius: 5px;
		padding: 10px;
	}
	.item-h:hover{
		cursor: pointer;
		background: #f1f3f4;
	}
</style>
 <section class="section-card">
 	
 	<div class="card card-656 card-audience">
 		<div class="outer-title">
      		Google Analytics Home
 		</div>
 		<div class="card-content">
 			<div class="tab-group" >
	 			<div class="tab-item active" data-key="ga:users" data-chart="chart-users">
	 				<span class="title">Users</span>
	 				<span class="number uppercase">{!!thousandsCurrencyFormat($dataGoogle['card1_total']['totalsForAllResults']['ga:users'])!!}</span>
	 				<?php 
 						$present = 100 - $dataGoogle['card1_total']['totalsForAllResults']['ga:users'] * 100 / $dataGoogle['card2_total']['totalsForAllResults']['ga:users'];
 					 ?>
	 					 @if( $dataGoogle['card1_total']['totalsForAllResults']['ga:users'] > $dataGoogle['card2_total']['totalsForAllResults']['ga:users'] )
	 					 <span class="present increase">
							<svg id="metric-table-increase-delta-arrow_cache67" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(-2, -3)">
							      <polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon>
							    </g>
						  </svg>
	 					 @else
	 					<span class="present decrease">
							<svg id="metric-table-decrease-delta-arrow_cache64" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(3, 4.5)">
							      <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon>
							    </g>
						  	</svg>
	 					 @endif
	 					
						  {!!number_format(abs($present),1)!!}%
	 				</span>
	 			</div>
	 			<div class="tab-item tab-sessions" data-key="ga:sessions" data-chart="chart-sessions">
	 				<span class="title">Sessions</span>
	 				<span class="number uppercase">{!!thousandsCurrencyFormat($dataGoogle['card1_total']['totalsForAllResults']['ga:sessions'])!!}</span>
	 				<?php 
 						$present = 100 - $dataGoogle['card1_total']['totalsForAllResults']['ga:sessions'] * 100 / $dataGoogle['card2_total']['totalsForAllResults']['ga:sessions'];
 					 ?>
	 					 @if( $dataGoogle['card1_total']['totalsForAllResults']['ga:sessions'] > $dataGoogle['card2_total']['totalsForAllResults']['ga:sessions'] )
	 					<span class="present increase">
							<svg id="metric-table-increase-delta-arrow_cache67" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(-2, -3)">
							      <polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon>
							    </g>
						  </svg>
	 					 @else
	 					<span class="present decrease">
							<svg id="metric-table-decrease-delta-arrow_cache64" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(3, 4.5)">
							      <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon>
							    </g>
						  	</svg>
	 					 @endif
	 					
						  {!!number_format(abs($present),1)!!}%
	 				</span>
	 			</div>
	 			<div class="tab-item tab-bounceRate" data-key="ga:bounceRate" data-chart="chart-bounceRate">
	 				<span class="title">Bounce Rate</span>
	 				<span class="number">{!!number_format($dataGoogle['card1_total']['totalsForAllResults']['ga:bounceRate'],2)!!}%</span>
	 				<?php 
 						$present = 100 - $dataGoogle['card1_total']['totalsForAllResults']['ga:bounceRate'] * 100 / $dataGoogle['card2_total']['totalsForAllResults']['ga:bounceRate'];
 					 ?>
	 					 @if( $dataGoogle['card1_total']['totalsForAllResults']['ga:bounceRate'] > $dataGoogle['card2_total']['totalsForAllResults']['ga:bounceRate'] )
	 					<span class="present increase">
							<svg id="metric-table-increase-delta-arrow_cache67" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(-2, -3)">
							      <polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon>
							    </g>
						  </svg>
	 					 @else
	 					<span class="present decrease">
							<svg id="metric-table-decrease-delta-arrow_cache64" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(3, 4.5)">
							      <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon>
							    </g>
						  	</svg>
	 					 @endif
	 					
						  {!!number_format(abs($present),1)!!}%
	 				</span>
	 			</div>
	 			<div class="tab-item tab-time" data-key="ga:avgSessionDuration" data-chart="chart-time">
	 				<?php 
						$time = number_format($dataGoogle['card1_total']['totalsForAllResults']['ga:avgSessionDuration']);
						$hours = floor($time / 3600);
						$mins = floor($time / 60 % 60);
						$secs = floor($time % 60);
						$timeFormat = sprintf('%02dm %02ds',$mins, $secs);
					 ?>
	 				<span class="title">Session Duration</span>
	 				<span class="number">{!!$timeFormat!!}</span>
	 				<?php 
 						$present = 100 - $dataGoogle['card1_total']['totalsForAllResults']['ga:avgSessionDuration'] * 100 / $dataGoogle['card2_total']['totalsForAllResults']['ga:avgSessionDuration'];
 					 ?>
	 					 @if( $dataGoogle['card1_total']['totalsForAllResults']['ga:avgSessionDuration'] > $dataGoogle['card2_total']['totalsForAllResults']['ga:avgSessionDuration'] )
	 					<span class="present increase">
							<svg id="metric-table-increase-delta-arrow_cache67" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(-2, -3)">
							      <polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon>
							    </g>
						  </svg>
	 					 @else
	 					<span class="present decrease">
							<svg id="metric-table-decrease-delta-arrow_cache64" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false">
							    <g transform="translate(3, 4.5)">
							      <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon>
							    </g>
						  	</svg>
	 					 @endif
	 					
						  {!!number_format(abs($present),1)!!}%
	 				</span>
	 			</div>
	 		</div>	
	 		<div style="padding: 0 24px;">
	 			<div id="char_audience" class="chart-users">
		 			
		 		</div>
	 		</div>
	 		
 		</div>
 	</div>
 	<div class="card card-320">
 		<div class="outer-title"></div>
 		<div class="card-content realtime">
 			<div class="realtime-1" style="color: #fff; font: 400 14px/10px 'Roboto',sans-serif; letter-spacing: 0;">Active Users right now</div>
 			<div class="realtime-2" style="color: #fff;font: 300 50px 'Roboto',sans-serif;letter-spacing: 0;margin-top: 13px;">{!!$dataGoogle['realtime']['totalsForAllResults']['rt:activeUsers']!!}</div>
 			<div class="realtime-3" style="border-bottom: 1px solid rgba(255,255,255,0.18);padding-bottom: 4px;  color: rgba(255,255,255,0.8);font: 400 12px 'Roboto',sans-serif;letter-spacing: -0.06px;">Page views per minute</div>
 			<div id="chart_30">
	 			
	 		</div>
	 		<table class="table-chart color-white">
	 			<thead>
	 				<tr>
	 					<td>Top Active Pages</td>
	 					<td style="width: 78px;">Active Users</td>
	 				</tr>
	 			</thead>
	 			<tbody>
	 				@foreach($dataGoogle['realtime']['rows'] as $v)
	 				<?php 
	 					$path = $v[0];
						if( strlen($path) > 31 ){
							$path = mb_substr($path, 0,14).'...'.mb_substr($path, -14);
						}
	 				 ?>
					<tr>
						<td>{!!$path!!}</td>
						<td>{!!$v[1]!!}</td>
					</tr>
	 				@endforeach
	 			</tbody>
	 		</table>
 		</div>
 	</div>
 	<div class="card card-320">
 		<div class="outer-title"></div>
 		<div class="card-content">
 			
 		</div>
 	</div>
 	<div class="card card-656 card-traffic">
 		<div class="outer-title">
      		How do you acquire users?
 		</div>
 		<div class="card-content">
 			<div class="tab-group" >
	 			<div class="tab-item active" data-key="ga:users" data-chart="chart-users">
	 				<span class="title">Traffic Channel</span>
	 			</div>
	 			<div class="tab-item tab-sessions" data-key="ga:sessions" data-chart="chart-sessions">
	 				<span class="title">Source / Medium</span>
	 			</div>
	 			<div class="tab-item tab-bounceRate" data-key="ga:bounceRate" data-chart="chart-bounceRate">
	 				<span class="title">Referrals</span>
	 			</div>
	 		</div>	
	 		<div style="padding: 0 24px;">
	 			<div id="char_acquisition" style="height: 310px;width: 100%;">
		 			
		 		</div>
	 		</div>
	 		
 		</div>
 	</div>
 	<div class="card card-320">
 		<div class="outer-title">Where are your users?</div>
 		<div class="card-content" style="padding: 24px;">
 			<div>Sessions by country</div>
 			<div id="chart_country" style="height: 206px;width: 100%;">
		 			
	 		</div>
	 		<div id="chart_location" style="height: 179px;width: 100%;">
		 			
	 		</div>
 		</div>
 	</div>
 	<div class="card card-320">
 		<div class="outer-title">When do your users visit?</div>
 		<div class="card-content">
 			
 		</div>
 	</div>
 	<div class="card card-488">
 		<div class="outer-title">What pages do your users visit?</div>
 		<div class="card-content" style="padding: 24px 24px 0;height:390px;">
 			<table class="table-chart" style="margin:0;">
	 			<thead>
	 				<tr style="padding: 12px 5px;">
	 					<td style="color:rgba(0,0,0,0.54);font-size:14px;">Page</td>
	 					<td style="width: 77px;color:rgba(0,0,0,0.54);font-size:14px;">Pageviews</td>
	 					<td style="width: 83px;color:rgba(0,0,0,0.54);font-size:14px;">Page Value</td>
	 				</tr>
	 			</thead>
	 			<tbody>
	 				@foreach($dataGoogle['path_pageview']['rows'] as $v)
	 				<?php 
	 					$path = $v[0];
						if( strlen($path) > 43 ){
							$path = mb_substr($path, 0,20).'...'.mb_substr($path, -20);
						}
	 				 ?>
					<tr>
						<td>{!!$path!!}</td>
						<td>{!!number_format($v[1])!!}</td>
						<td>${!!number_format($v[2],2)!!}</td>
					</tr>
	 				@endforeach
	 			</tbody>
	 		</table>
 		</div>
 	</div>
 	<div class="card card-488">
 		<div class="outer-title">How are your active users trending over time?</div>
 		<div class="card-content" style="height:390px;padding: 24px 24px 0;">
 			<dir style="color: rgba(0,0,0,0.54);">Active Users</dir>

 			<div style="display: flex;align-items: center;">
 				<div id="chart_active_user" style="display: inline-block;height: 280px;width: 353px;">
			 			
		 		</div>

		 		<?php 
		 			$end = count( $dataGoogle['active_users_30day']['rows'] ) - 1;
		 		 ?>
		 		<div style="width: 88px;text-align: center;">
		 			<div class="item-h"> 
		 				<div style="color: rgba(0,0,0,0.54);font-size: 12px;letter-spacing: 0;align-items: center;margin-bottom: 12px;"><span style="display: inline-block;width: 6px;height: 6px;background: #4285f4;border-radius: 50%;"></span>  &nbsp;30 Days</div>
		 				<div style="color: rgba(0,0,0,0.87);font-size:16px;letter-spacing: 0;">{!!thousandsCurrencyFormat($dataGoogle['active_users_30day']['rows'][$end][1])!!}</div>
		 			</div>

		 			<div class="item-h" style="margin: 10px 0;"> 
		 				<div style="color: rgba(0,0,0,0.54);font-size: 12px;letter-spacing: 0;align-items: center;margin-bottom: 12px;"><span style="display: inline-block;width: 6px;height: 6px;background: #45a5f5;border-radius: 50%;"></span>  &nbsp;7 Days</div>
		 				<div style="color: rgba(0,0,0,0.87);font-size:16px;letter-spacing: 0;">{!!thousandsCurrencyFormat($dataGoogle['active_users_7day']['rows'][$end][1])!!}</div>
		 			</div>

		 			<div class="item-h"> 
		 				<div style="color: rgba(0,0,0,0.54);font-size: 12px;letter-spacing: 0;align-items: center;margin-bottom: 12px;"><span style="display: inline-block;width: 6px;height: 6px;background: #93d5ed;border-radius: 50%;"></span>  &nbsp;1 Day</div>
		 				<div style="color: rgba(0,0,0,0.87);font-size:16px;letter-spacing: 0;">{!!thousandsCurrencyFormat($dataGoogle['active_users_1day']['rows'][$end][1])!!}</div>
		 			</div>
		 		</div>
 			</div>
 			
	 		
 		</div>
 	</div>
 	<div class="card card-320">
 		<div class="outer-title">What are your top devices?</div>
 		<div class="card-content" style="height:390px;">
 			
 		</div>
 	</div>
	

	<div class="card card-488">
 		<div class="outer-title">How well do you retain users?</div>
 		<div class="card-content" style="height:390px;">
 			
 		</div>
 	</div>

 	<div class="card card-488">
 		<div class="outer-title">How are you performing against goals?</div>
 		<div class="card-content" style="height:390px;">
 			
 		</div>
 	</div>
 	<div style="clear: both;padding:10px;width: 100%;"></div>
 </section>



<script type="text/javascript">
	window.data_audience = {'ga:users':{title:'Users',data:[]},'ga:sessions':{title:'Sessions',data:[]},'ga:bounceRate':{title:'Bounce Rate',data:[]},'ga:avgSessionDuration':{title:'Avg. Session Duration',data:[]}};
	@foreach($dataGoogle['card1']['rows'] as $k => $v)
	<?php 
		$present = number_format(abs( 100 - $v[1] * 100 / $dataGoogle['card2']['rows'][$k][1] ),1).'%<span>';
		 if( $v[1] > $dataGoogle['card2']['rows'][$k][1] ){
		 	$icon = '<span class="present increase"><svg id="metric-table-increase-delta-arrow_cache67" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(-2, -3)"><polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon> </g></svg> ';
		 }else{
		 	$icon = '<span class="present decrease"><svg id="metric-table-decrease-delta-arrow_cache64" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(3, 4.5)"> <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon></g></svg>&nbsp;';
		 }
     ?>
    	data_audience['ga:users'].data.push([{v:new Date('{!!date("M d, Y", strtotime($v[0]))!!}'),f:''},  {!!$v[1]!!}, '{!!date("D d M", strtotime($v[0])),' vs ',date("D d M", strtotime($dataGoogle['card2']['rows'][$k][0]))!!}' ,{!!$dataGoogle['card2']['rows'][$k][1]!!}, 
		    '<strong>{!!number_format($v[1]),'\<\/strong>&nbsp;&nbsp;',$icon,$present!!}']);
    <?php 
		$present = number_format(abs( 100 - $v[2] * 100 / $dataGoogle['card2']['rows'][$k][2] ),1).'%<span>';
		 if( $v[2] > $dataGoogle['card2']['rows'][$k][2] ){
		 	$icon = '<span class="present increase"><svg id="metric-table-increase-delta-arrow_cache67" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(-2, -3)"><polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon> </g></svg> ';
		 }else{
		 	$icon = '<span class="present decrease"><svg id="metric-table-decrease-delta-arrow_cache64" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(3, 4.5)"> <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon></g></svg>&nbsp;';
		 }
     ?>
    	data_audience['ga:sessions'].data.push([{v:new Date('{!!date("M d, Y", strtotime($v[0]))!!}'),f:''},  {!!$v[2]!!}, '{!!date("D d M", strtotime($v[0])),' vs ',date("D d M", strtotime($dataGoogle['card2']['rows'][$k][0]))!!}' ,{!!$dataGoogle['card2']['rows'][$k][2]!!}, 
		    '<strong>{!!number_format($v[2]),'\<\/strong>&nbsp;&nbsp;',$icon,$present!!}']);
    <?php 
		$present = number_format(abs( 100 - $v[3] * 100 / $dataGoogle['card2']['rows'][$k][3] ),1).'%<span>';
		 if( $v[3] > $dataGoogle['card2']['rows'][$k][3] ){
		 	$icon = '<span class="present increase"><svg id="metric-table-increase-delta-arrow_cache67" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(-2, -3)"><polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon> </g></svg> ';
		 }else{
		 	$icon = '<span class="present decrease"><svg id="metric-table-decrease-delta-arrow_cache64" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(3, 4.5)"> <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon></g></svg>&nbsp;';
		 }
     ?>
    	data_audience['ga:bounceRate'].data.push([{v:new Date('{!!date("M d, Y", strtotime($v[0]))!!}'),f:''},  {!!number_format($v[3],2)!!}, '{!!date("D d M", strtotime($v[0])),' vs ',date("D d M", strtotime($dataGoogle['card2']['rows'][$k][0]))!!}' ,{!!$dataGoogle['card2']['rows'][$k][3]!!}, 
		    '<strong>{!!number_format($v[3],2),'\<\/strong>%&nbsp;&nbsp;',$icon,$present!!}']);
    <?php 
		$present = number_format(abs( 100 - $v[4] * 100 / $dataGoogle['card2']['rows'][$k][4] ),1).'%<span>';
		 if( $v[4] > $dataGoogle['card2']['rows'][$k][4] ){
		 	$icon = '<span class="present increase"><svg id="metric-table-increase-delta-arrow_cache67" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(-2, -3)"><polygon points="5.65 3 2.5 6.26454545 4.8625 6.26454545 4.8625 12 6.4375 12 6.4375 6.26454545 8.8 6.26454545"></polygon> </g></svg> ';
		 }else{
		 	$icon = '<span class="present decrease"><svg id="metric-table-decrease-delta-arrow_cache64" class="" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg" fit="" height="100%" width="100%" preserveAspectRatio="xMidYMid meet" focusable="false"><g transform="translate(3, 4.5)"> <polygon transform="rotate(-180)" points="0 -4.5 -3.15 -1.2354545 -0.7875 -1.2354545 -0.7875 4.5 0.7875 4.5 0.7875 -1.2354545 3.15 -1.2354545"></polygon></g></svg>&nbsp;';
		 }
     ?>
    	data_audience['ga:avgSessionDuration'].data.push([{v:new Date('{!!date("M d, Y", strtotime($v[0]))!!}'),f:''},  {!!$v[4]!!}, '{!!date("D d M", strtotime($v[0])),' vs ',date("D d M", strtotime($dataGoogle['card2']['rows'][$k][0]))!!}' ,{!!$dataGoogle['card2']['rows'][$k][4]!!}, 
		    '<strong>{!!number_format($v[4]),'\<\/strong>&nbsp;&nbsp;',$icon,$present!!}']);
    @endforeach
    window.data_audience_current = 'ga:users';
	google.charts.load('current', {'packages':['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	  function drawChart() {
	  	// console.log(dataGA);
	  	var data = new google.visualization.DataTable();
	  	 	data.addColumn('date','Date');
		    data.addColumn('number', '');
		    data.addColumn({type: 'string', role: 'tooltip'});
		    data.addColumn('number', data_audience[data_audience_current].title);
		    data.addColumn({type: 'string', role: 'tooltip', p: {html: true}});
		    data.addRows( data_audience[data_audience_current].data);
	    var options = {
	      title: '',
	      colors:['rgb(66, 133, 244)','rgb(101, 152, 239)'],
		  chartArea:{left:0,right:4},
		  tooltip:{isHtml:true,showColorCode:false},
		  pointSize:4,
		  lineWidth:2,
		  height:300,
		  series: {
			1: { lineDashStyle: [4, 2]},
		  },
		  crosshair: {orientation: 'vertical', trigger: 'focus' , color: '#f1f1f1'},
		  focusTarget:'category',
		  pointsVisible:false,
	      hAxis: {title: '', format:'MMM d',textStyle:{fontSize:12}, baselineColor: 'none',gridlines: {count:4, color: 'transparent'}},
	      vAxis: { textPosition: 'in',format:'short', textStyle: { fontName: 'arial',fontSize:12}, minValue: 0,baselineColor: 'none',gridlines: {count:3,color: '#f1f1f1'}},
	      // legend: {position: 'top'},
	    };
		var chart = new google.visualization.LineChart(document.getElementById('char_audience'));
	    chart.draw(data, options);


    	 var data = new google.visualization.DataTable();
	  	 	data.addColumn('string','mins ago');
	  	 	data.addColumn('number','Page Views');
	  	 	data.addColumn({type: 'string', role: 'tooltip'});
		    data.addRows([
		    	<?php 
		        	$dataPageView30M = array_reverse($dataPageView30M);
		         ?>
		        @foreach($dataPageView30M as $k => $v)
		        ['{!!$k!!}',{!!$v!!},'{!!$k!!}\n{!!$v!!}\nPage Views'],
		        @endforeach
		    ]);
	      var options = {
	        title: "",
	        colors: ['#8eb6f9'],
	        width: '100%',
	        height: '100',
			tooltip:{isHtml:true,showColorCode:false},
	        bar: {groupWidth: '8'},
	        hAxis: {title: '',textPosition: 'none',baselineColor: 'none',gridlines: {count:0, color: 'transparent'}},
	      	vAxis: { textPosition: 'none',  minValue: 0,baselineColor: 'none',gridlines: {count:0,color: 'transparent'}},
	      	backgroundColor:'#4285f4',
	        chartArea:{left:1,right:-1,height:100},
	        legend: { position: 'none' },
	      };

	      var chart = new google.visualization.ColumnChart(document.getElementById('chart_30'));
	      chart.draw(data, options);


	      var data = google.visualization.arrayToDataTable([
	        [{type:'date',label:'Genre'}, 'Organic Search', 'Direct', 'Paid Search', 'Referral','Other'],
	        @foreach($traffic_channel as $d => $v)
	        [{v:new Date('{!!date("M d, Y", strtotime($d))!!}'),f:'{!!date("D d M", strtotime($d))!!}'}, {!!$v['Organic Search']!!}, {!!$v['Direct']!!}, {!!$v['Paid Search']!!}, {!!$v['Referral']!!},{!!$v['(Other)']!!}],
	        @endforeach
	      ]);
	      var options = {
	        title: "",
	        colors: ['#3367d6','#4285f4','#72a4f7','#a0c2f9','#d0e0fc'],
	        width: '100%',
	        height: '310',
	        isStacked: true,
		  	focusTarget:'category',
			tooltip:{isHtml:true,showColorCode:false},
	        bar: {groupWidth: '93%'},
	        chartArea:{left:1,right:-1,height:250},
	        hAxis: {gridlines: {color: 'transparent'}},
	      	vAxis: { textPosition: 'none',  minValue: 0,baselineColor: 'none',gridlines: {count:0,color: 'transparent'}},
	        legend: { position: 'none' },
	      };

	      var chart = new google.visualization.ColumnChart(document.getElementById('char_acquisition'));
	      chart.draw(data, options);


	      var data = google.visualization.arrayToDataTable([
	          ['Country', 'Sessions'],
	           @foreach($dataGoogle['session_country']['rows'] as $k => $v)
			    ['{!!$v[0]!!}',  {!!$v[1]!!}],
		      	@endforeach
	        ]);
	        var options = {
	        	colorAxis: {minValue:0, colors: ['rgb(207, 225, 241)', 'rgb(47, 94, 196)']},
	          	legend:'none',
		        height: '100%',
	          	magnifyingGlass: {enable: true, zoomFactor: 5.0},
	        };
	        var chart = new google.visualization.GeoChart(document.getElementById('chart_country'));
	        chart.draw(data, options);


		      var data = google.visualization.arrayToDataTable([
		        ['Country', 'Sessions',{role:'tooltip'}],
	         	@foreach($dataGoogle['session_country']['rows'] as $k => $v)
	         	@if( $k > 5) @break @endif
			    ['{!!$v[0]!!}',{!!number_format($v[1] * 100 / $dataGoogle['session_country']['totalsForAllResults']['ga:sessions'],2)!!}, "SESSIONS\n{!!$v[0],' ',number_format($v[1] * 100 / $dataGoogle['session_country']['totalsForAllResults']['ga:sessions'],2)!!}%"],
		      	@endforeach
		      ]);
		      var formatter = new google.visualization.NumberFormat({pattern: '#%'});
				// format column 1 of the DataTable
				formatter.format(data, 1);
		      var options = {
		        title: "",
		        width: '100%',
		        height: '100%',
		     //    tooltip: {
			    //      trigger: 'none'
			    // },
			    bars: 'horizontal',
	        	chartArea:{right:15,top:0,bottom:15},
		        colors:['rgb(66, 133, 244)'],
	        	bar: {groupWidth: '65%'},
          		hAxis: {minValue: 0,format:"#'%'",gridlines:{count:4,color:'#ebebeb'}},
          		vAxis:{gridlines:{color:'#ebebeb'},textStyle:{fontSize:13,color:'#9e9e9e'}},
		        legend: { position: 'none' },
		      };
		      var chart = new google.visualization.BarChart(document.getElementById('chart_location'));
		      chart.draw(data, options);



        var data = google.visualization.arrayToDataTable([
	      [{type: 'date', label: 'Date'}, {type:'number',label:'Daily'}, {type:'number',label:'Weekly'}, {type:'number',label:'Monthly'}],
	      @foreach($dataGoogle['active_users_1day']['rows'] as $k => $v)
	      [{v:new Date('{!!date("M d, Y", strtotime($v[0]))!!}'),f:'{!!date("l, F d, Y", strtotime($v[0]))!!}'},  {!!$v[1]!!}, {!!$dataGoogle['active_users_7day']['rows'][$k][1]!!}, {!!$dataGoogle['active_users_30day']['rows'][$k][1]!!}],
	      @endforeach
	    ]);

	    options = {
	      title: '',
	      colors:['#93d5ed','#45a5f5','#4285f4'],
		  chartArea:{left:15,right:15},
		  tooltip:{showColorCode:true},
		  pointSize:6,
		  lineWidth:2,
		  pointsVisible:false,
		  height:300,
		  focusTarget:'category',
			series: {
	          0: {
	              areaOpacity: 0
	          }
	        },
	        crosshair: {orientation: 'vertical', trigger: 'focus' , color: '#f1f1f1'},
	      hAxis: {title: '', format:'MMM dd, yyyy', gridlines: {count:4, color: 'transparent'}},
	      vAxis: { textPosition: 'in',  minValue: 0,gridlines: {count:2,color: '#f1f1f1'}},
	      // legend: {position: 'top'},
	    };

		var chart = new google.visualization.LineChart(document.getElementById('chart_active_user'));
	    chart.draw(data, options);
  	}
  	
        
  	$('.card-audience .tab-item').click(function(){
  		if( !$(this).hasClass('active') ){
  			$('#char_audience').attr('class',$(this).data('chart'));
  			$('.card-audience .tab-item').removeClass('active');
  			$(this).addClass('active');
  			google.charts.load('current', {'packages':['corechart']});
    		window.data_audience_current = $(this).data('key');
			google.charts.setOnLoadCallback(drawChart);
  		}
  	});
</script>