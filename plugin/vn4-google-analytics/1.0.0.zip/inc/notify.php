<?php 

return [
	[
		'type'=>'message',
		'message'=>'Hello notify from plugin',
		'color'=>'green',
		'place'=>[
			'notify','dashboard'
		]
	]
];