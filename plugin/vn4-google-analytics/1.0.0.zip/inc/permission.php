<?php
return [
	[
		'group'=>'plugin.google-analytics',
		'title_group'=>'Plugin Google Analytics',
		'key'=>'plugin_google_analytics_setting',
		'title'=>'Google Analytics: Setting',
	],
	[
		'group'=>'plugin.google-analytics',
		'key'=>'plugin_google_analytics_view_report',
		'title'=>'Google Analytics: View Report',
	],
	[
		'group'=>'plugin.google-analytics',
		'key'=>'plugin_google_analytics_view_dashboard',
		'title'=>'Google Analytics: View Report Dashboard',
	],
	
];

// check permission
// check_permission('plugin_demo_permission')
