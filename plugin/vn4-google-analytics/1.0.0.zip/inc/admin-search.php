<?php

return [
	'analytics'=>['title'=>'Google Analytics','callback'=>function( $searchArray, $searchString ) use ($plugin){

		return [
			[
				'title_type'=>'Analytics',
				'title'=>'Cài đặt',
				'link'=>route('google-analytics.setting'),
			],
			[
				'title_type'=>'Analytics',
				'title'=>'Report',
				'link'=>route('google-analytics.report'),
			],
		];
		

	}]
];