<?php

// echo file_post_contents_curl('https://www.googleapis.com/oauth2/v4/token',['client_id'=>'953611323656-1i8fp71d9dnreqcp4ms97am2oeen7u5m.apps.googleusercontent.com','client_secret'=>'BufG4cwIFDJ7Fff7hnkpM0_k','refresh_token'=>'1//0edsxc0lY92JsCgYIARAAGA4SNwF-L9IrdfQ4rPP_C3G_lMwtrsd0kOyNemvAVTuQQxWT4O15uwSrDtnASf0D4S_x2eVEbW7j-_o','grant_type'=>'refresh_token']);

	// die();

	

require_once cms_path('public','../lib/google-client/vendor/autoload.php');



// Create the client object and set the authorization configuration

$client = new Google_Client(['access_type'=>'offline']);



// from the client_secrets.json you downloaded from the Developers Console.

$client->setAuthConfig($file_congig);



// Handle authorization flow from the server.

$client->addScope(Google_Service_Analytics::ANALYTICS_READONLY);



if( $r->isMethod('GET') ){



	$access_code = json_decode( $plugin->getMeta('access_token_first'),true );



	$data = ['plugin'=>$plugin];



	if( isset($access_code['access_code']) ){



		$data['auth_url'] = '';

		$data['accounts'] = json_decode(file_get_contents(__DIR__.'/accounts.json'),true);





	}else{

		$auth_url = $client->createAuthUrl();

		$data['auth_url'] = filter_var($auth_url, FILTER_SANITIZE_URL);

	}

	



	return view_plugin($plugin, 'views.setting',$data);

}



if( $r->isMethod('POST') ){

	// dd($r->all());

	if( $r->get('clear_authorization') ){



		$plugin->updateMeta('access_token_first','');

		vn4_create_session_message('Success',__p('Clear Authorization Success',$plugin->key_word),'success');




	}elseif( $r->get('access_code') ){



		$client->authenticate($r->get('access_code'));



		$access_token = $client->getAccessToken();



		if( isset($access_token['refresh_token']) ){



			$access_token['access_code'] = $r->get('access_code');



			$plugin->updateMeta('access_token_first',$access_token);



			$access_token = $access_token['access_token'];



          	$accounts = json_decode(file_get_contents_curl('https://www.googleapis.com/analytics/v3/management/accounts?access_token='.$access_token),true);



			foreach($accounts['items'] as $key => $ac){



				$accounts['items'][$key]['webproperties'] = json_decode(file_get_contents_curl($ac['childLink']['href'].'?access_token='.$access_token),true);



			}



			file_put_contents(__DIR__.'/accounts.json', json_encode($accounts));



			vn4_create_session_message('Success',__p('Get Access Token Success',$plugin->key_word),'success');



		}else{

			vn4_create_session_message('Success',__p('Get Access Token Error',$plugin->key_word),'error');

		}



	}elseif ( $r->get('webpropertie_id') ) {

		

		$access_code = json_decode($plugin->getMeta('access_token_first'),true);



		$access_code['webpropertie_id'] = $r->get('webpropertie_id');



		$plugin->updateMeta('access_token_first',$access_code);



		vn4_create_session_message('Success',__p('Update View Success',$plugin->key_word),'success');

	}elseif( $r->get('file_app_json') ){


		copy(get_media($r->get('file_app_json')),__DIR__.'/client_secret_app.json');
		// dd(1);
		// $file = json_decode($r->get('file_app_json'),true);

		// dd($r->get('file_app_json'));
		$plugin->updateMeta('file_app_json',$r->get('file_app_json'));
		vn4_create_session_message('Success',__p('Update File Success',$plugin->key_word),'success');
	}

	





}



return redirect()->route('google-analytics.setting');