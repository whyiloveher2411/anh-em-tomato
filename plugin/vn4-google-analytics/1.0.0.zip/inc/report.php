<?php

$access_code = json_decode( $plugin->getMeta('access_token_first'),true );

$webpropertie_id = $access_code['webpropertie_id'];

$access_token = get_access_token($plugin);

return view_plugin($plugin, 'views.report',['plugin'=>$plugin,'access_code'=>$access_code,'webpropertie_id'=>$webpropertie_id,'access_token'=>$access_token]);

