<?php



add_sidebar_admin(function() use ($plugin) {



	$sidebar_seo_vn4[] = [

		'title'=>'Google Analytics',

		'icon'=>'fa-bar-chart',

		'submenu'=>[
			['title'=>'Setting','url'=>route('google-analytics.setting')],
			['title'=>'Reports','url'=>route('google-analytics.report')]
		]
		

	];



	return $sidebar_seo_vn4;

},'manager');


function refesh_token($plugin){
	$access_code = json_decode($plugin->getMeta('access_token_first'),true);
	
	$app_config  = json_decode(file_get_contents(__DIR__ . '/client_secret_app.json'),true);

	$token = json_decode( file_post_contents_curl('https://www.googleapis.com/oauth2/v4/token',
			['client_id'=>$app_config['installed']['client_id'],
			'client_secret'=>$app_config['installed']['client_secret'],
			'refresh_token'=>$access_code['refresh_token'],
			'grant_type'=>'refresh_token']),true);
	// dd($token);
	if( !isset($token['access_token']) ){
		die('<h1 style="text-align:center;">Vui lòng config lại plugin google analytics.</h1>');
	}

	$access_code['created'] = time();
	$access_code['expires_in'] = $token['expires_in'];
	$access_code['access_token'] = $token['access_token'];

	$plugin->updateMeta('access_token_first',$access_code);
	// dd($access_code);
	return $access_code['access_token'];
}

function get_access_token($plugin){

	$access_code = json_decode($plugin->getMeta('access_token_first'),true);

	if( time() >= $access_code['created'] + $access_code['expires_in'] ){
		return refesh_token($plugin);
	}

	return $access_code['access_token'];

}



add_route('plugin/google-analytics/setting','google-analytics.setting','before_route_backend',function($r) use ($plugin) {

	// $file_congig = __DIR__ . '/client_secret_360363510993-afsk88lvm4g2mmm84anmgljc2juf7uqd.apps.googleusercontent.com.json';
	$file_congig = __DIR__ . '/client_secret_app.json';
	
	return include __DIR__.'/setting.php';
});	


add_route('plugin/google-analytics/report-item/{folder}/{view}','google-analytics.report-item','before_route_backend',function($r, $folder, $view) use ($plugin) {
	return include __DIR__.'/report-item.php';
});	


add_route('plugin/google-analytics/report','google-analytics.report','before_route_backend',function($r) use ($plugin) {
	return include __DIR__.'/report.php';
});	




