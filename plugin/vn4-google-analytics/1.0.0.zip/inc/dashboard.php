<?php

return [
	route('google-analytics.report-item',['folder'=>'dashboard','view'=>'index'])
];