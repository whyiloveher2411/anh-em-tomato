<?php


if( is_admin() ){
	include __DIR__.'/inc/backend.php';
} 