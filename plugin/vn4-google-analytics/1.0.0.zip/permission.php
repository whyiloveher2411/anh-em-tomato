<?php
// return [
// 	[
// 		'group'=>'plugin.plugin_google_analytics',
// 		'title_group'=>'Google Analytics',
// 		'key'=>'plugin_google_analytics_view',
// 		'title'=>'View Google Analytics',
// 	],
// ];
