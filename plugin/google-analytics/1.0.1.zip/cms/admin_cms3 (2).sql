-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2017 at 07:10 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_cms3`
--

-- --------------------------------------------------------

--
-- Table structure for table `vn4_code_reference_function`
--

CREATE TABLE `vn4_code_reference_function` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summary` text COLLATE utf8_unicode_ci NOT NULL,
  `parameters` text COLLATE utf8_unicode_ci NOT NULL,
  `return` text COLLATE utf8_unicode_ci NOT NULL,
  `source` text COLLATE utf8_unicode_ci NOT NULL,
  `changelog` text COLLATE utf8_unicode_ci NOT NULL,
  `more_information` text COLLATE utf8_unicode_ci NOT NULL,
  `used_by` text COLLATE utf8_unicode_ci NOT NULL,
  `uses` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn4_code_reference_function`
--

INSERT INTO `vn4_code_reference_function` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `created_at`, `updated_at`, `summary`, `parameters`, `return`, `source`, `changelog`, `more_information`, `used_by`, `uses`) VALUES
(1, 'function_demo', 'function-demo', 'function demo', '', '', 10, 'code_reference_function', '', 'publish', '', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Facebook title","plugin_vn4seo_facebook_description":"Facebook Description","plugin_vn4seo_facebook_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/12243232_697152930418853_7640659803889844973_n.jpg?1487233820560\\" alt=\\"\\"><\\/div>","plugin_vn4seo_twitter_title":"Twitter title","plugin_vn4seo_twitter_description":"Twitter Description","plugin_vn4seo_twitter_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/13895095_733965370080004_1624478753096110425_n.jpg?1487233838135\\" alt=\\"\\"><\\/div>"}', '2017-02-16 08:30:51', '2017-02-16 08:30:51', 'function demo', 'function demo', 'null', 'function demo', 'function demo', 'function demo', 'function demo', ''),
(2, 'function_demo 2', 'function-demo-2', 'function demo', '', '', 10, 'code_reference_function', '', 'publish', '', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Facebook title","plugin_vn4seo_facebook_description":"Facebook Description","plugin_vn4seo_facebook_image":"            <div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/12243232_697152930418853_7640659803889844973_n.jpg?1487233820560\\" alt=\\"\\"><\\/div>\\r\\n        ","plugin_vn4seo_twitter_title":"Twitter title","plugin_vn4seo_twitter_description":"Twitter Description","plugin_vn4seo_twitter_image":"            <div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/13895095_733965370080004_1624478753096110425_n.jpg?1487233838135\\" alt=\\"\\"><\\/div>\\r\\n        "}', '2017-02-16 08:30:51', '2017-02-16 08:44:31', 'function demo 2', 'function demo', 'null', 'function demo', 'function demo', 'function demo', 'function demo', ''),
(3, 'function_demo 3', 'function-demo-3', 'function demo', '', '', 10, 'code_reference_function', '', 'publish', '', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Facebook title","plugin_vn4seo_facebook_description":"Facebook Description","plugin_vn4seo_facebook_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/12243232_697152930418853_7640659803889844973_n.jpg?1487233820560\\" alt=\\"\\"><\\/div>","plugin_vn4seo_twitter_title":"Twitter title","plugin_vn4seo_twitter_description":"Twitter Description","plugin_vn4seo_twitter_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/13895095_733965370080004_1624478753096110425_n.jpg?1487233838135\\" alt=\\"\\"><\\/div>"}', '2017-02-16 08:30:51', '2017-02-16 08:30:51', 'function demo', 'function demo', 'null', 'function demo', 'function demo', 'function demo', 'function demo', ''),
(4, 'function_demo 4', 'function-demo-4', 'function demo', '', '', 10, 'code_reference_function', '', 'publish', '', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Facebook title","plugin_vn4seo_facebook_description":"Facebook Description","plugin_vn4seo_facebook_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/12243232_697152930418853_7640659803889844973_n.jpg?1487233820560\\" alt=\\"\\"><\\/div>","plugin_vn4seo_twitter_title":"Twitter title","plugin_vn4seo_twitter_description":"Twitter Description","plugin_vn4seo_twitter_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/admin\\/user\\/13895095_733965370080004_1624478753096110425_n.jpg?1487233838135\\" alt=\\"\\"><\\/div>"}', '2017-02-16 08:30:51', '2017-02-16 08:30:51', 'function demo', 'function demo', 'null', 'function demo', 'function demo', 'function demo', 'function demo', ''),
(5, 'add_menu_page_demo', 'add-menu-page-demo', 'Actions are the hooks that the WordPress core launches at specific points during execution, or when specific events occur. Plugins can specify that one or more of its PHP functions are executed at these points, using the Action API.', '', '', 23, 'code_reference_function', '', 'publish', 'publish', 'password', '1235', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":""}', '2017-02-16 08:45:43', '2017-03-28 10:50:49', 'Hooks a function on to a specific action.', '<p>[param name="tag" type="string" ]The name of the action to which the $function_to_add is hooked.[/param] [param name="function_to_add" type="callable" ]The name of the function you wish to be called..[/param] [param name="accepted_args" type="int" required="true" default="1" ]The number of arguments the function accepts.[/param]</p>', '(true) Will always return true.', '<p>[source file="cms/route_helper.php" from_line="5" to_line="17" /]</p>', '<p>[log version="2.0.1"] <a href="google.com" target="_blank">Introduced</a><span>. </span>[/log]</p>', '<p> [code]</p>\r\n<p> function do_action(string $hook){</p>\r\n<p>     </p>\r\n<p>}</p>\r\n<p>[/code]</p>\r\n<p><span>To find out the number and name of arguments for an action, simply search the code base for the matching </span><a href="https://developer.wordpress.org/reference/functions/do_action/">do_action()</a><span> call. For example, if you are hooking into ‘save_post’, you would find it in post.php:</span></p>\r\n<p><span>[code]</span></p>\r\n<p><span>do_action( ''save_post'', $post_ID, $post, $update );</span></p>\r\n<p><span>[/code]</span></p>\r\n<p>Your add_action call would look like:</p>\r\n<p>[code]</p>\r\n<p>add_action( ''save_post'', ''wpdocs_my_save_post'', 10, 3 );</p>\r\n<p>[/code]</p>\r\n<p>And your function would be:</p>\r\n<p>[code]</p>\r\n<p>function wpdocs_my_save_post( $post_ID, $post, $update ) {</p>\r\n<p>         </p>\r\n<p>}</p>\r\n<p>[/code]</p>\r\n<p> </p>', '[function name="add_filter"][class name="sdf" function="sdfsdf"]', '[function name=" add_filter"]'),
(6, 'add_menu_page() 2', 'add-menu-page 2', 'Add a top-level menu page.', '', '', 10, 'code_reference_function', '', 'publish', '', '', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-16 08:45:43', '2017-02-16 08:45:43', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', ''),
(7, 'add_menu_page() 3', 'add-menu-page 3', 'Add a top-level menu page.', '', '', 10, 'code_reference_function', '', 'publish', '', '', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-16 08:45:43', '2017-02-16 08:45:43', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', ''),
(8, 'add_menu_page() 4', 'add-menu-page 4', 'Add a top-level menu page.', '', '', 10, 'code_reference_function', '', 'publish', '', '', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-16 08:45:43', '2017-02-16 08:45:43', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', ''),
(9, 'add_menu_page() 5', 'add-menu-page 5', 'Add a top-level menu page.', '', '', 10, 'code_reference_function', '', 'publish', '', '', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-16 08:45:43', '2017-02-16 08:45:43', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', ''),
(10, 'add_menu_page() 6', 'add-menu-page 6', 'Add a top-level menu page.', '', '', 10, 'code_reference_function', '', 'publish', '', '', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"","plugin_vn4seo_facebook_description":"","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"","plugin_vn4seo_twitter_description":"","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-16 08:45:43', '2017-02-16 08:45:43', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', 'Add a top-level menu page.', '');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_comment`
--

CREATE TABLE `vn4_comment` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parent` text COLLATE utf8_unicode_ci NOT NULL,
  `post_id` text COLLATE utf8_unicode_ci NOT NULL,
  `post_type` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn4_comment`
--

INSERT INTO `vn4_comment` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `created_at`, `updated_at`, `parent`, `post_id`, `post_type`) VALUES
(1, 'demo', 'de23123123', '', 'This is a comment', '', 0, 'comment', '', 'publish', 'publish', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '7', 'post'),
(2, 'demo2', 'de231231232', '', 'This is a reply to the comment', '', 0, 'comment', '', 'publish', 'publish', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '7', 'post');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_fanpage`
--

CREATE TABLE `vn4_fanpage` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_token` text COLLATE utf8_unicode_ci NOT NULL,
  `perms` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `category` text COLLATE utf8_unicode_ci NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `fan_count` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn4_fanpage`
--

INSERT INTO `vn4_fanpage` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `created_at`, `updated_at`, `access_token`, `perms`, `name`, `category`, `about`, `fan_count`) VALUES
(138, '1039487402789864', 'vn4fanpage-fanpage-1039487402789864', '', '', '', 23, 'vn4fanpage-fanpage', '', 'publish', 'publish', '', '', '', '{"app_id":"1639513693020593","application":"Fanpage Manager","expires_at":0,"is_valid":true,"issued_at":1489566417,"profile_id":"1039487402789864","scopes":["read_page_mailboxes","email","manage_pages","publish_pages","pages_show_list","pages_manage_cta","pages_manage_instant_articles","public_profile"],"user_id":"959601664173977","error":false,"checked":true}', '2017-03-28 07:46:26', '2017-03-28 07:47:05', 'EAAXTIQdG4bEBAP4oQBUgtzOYZCFZB4A5oq3CrZAtVfrJgoiqIfwUSUnpEoB8F8kVqXEkOQBrfyXXPSsTs95FxVrGsHstlWCZBlZAZAuBMHF6s2ca0KmlZCw8VZCDbGMEZByZCfZCZAx4kRFLjtIDWEN3fjSEuYeJPGMZABfTnI9kA0kGAyZAIHDRJ2VgER7BERvop7jhwZD', '["ADMINISTER","EDIT_PROFILE","CREATE_CONTENT","MODERATE_CONTENT","CREATE_ADS","BASIC_ADMIN"]', 'News For you', 'Community', 'Cung cấp tin tức một cách nhanh chống, chính xác các tin nổi bật nhất trong ngày 2', '100'),
(139, '1717881081760545', 'vn4fanpage-fanpage-1717881081760545', '', '', '', 23, 'vn4fanpage-fanpage', '', 'publish', 'publish', '', '', '', '{"cover":"{\\"cover_id\\":\\"1730340387181281\\",\\"offset_x\\":\\"0\\",\\"offset_y\\":\\"45\\",\\"source\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t31.0-8\\\\\\/q84\\\\\\/s720x720\\\\\\/13040924_1730340387181281_2077825272935295780_o.jpg?oh=45f3091a6313b3c44ae2856211ef2191&oe=594D3221\\",\\"id\\":\\"1730340387181281\\"}"}', '2017-03-28 07:46:26', '2017-03-28 07:46:26', 'EAAXTIQdG4bEBAOmUfaigIYyfLHLfidZBeCc8jsE5BwSmH2cAr2ycZB1Hx8HHgbabKusiDS9EPZA3xw9nZBTYXbPIhHCQZAyN8H3om8P8DMBEM4yZAgZAoHsymWLnGiEvATeTjErhrKQuBuqbBZC4q6msQB1ZAeP9km51KSjbXJQRSVyDeQuI8zoQDK64xmLqN0eIZD', '["ADMINISTER","EDIT_PROFILE","CREATE_CONTENT","MODERATE_CONTENT","CREATE_ADS","BASIC_ADMIN"]', 'League Montage', 'TV Channel', 'Welcome to Level LOL :) Here you can find all your favorite heroes in the video game legend of league', '70'),
(140, '1824709764412586', 'vn4fanpage-fanpage-1824709764412586', '', '', '', 23, 'vn4fanpage-fanpage', '', 'publish', 'publish', '', '', '', '{"cover":"{\\"cover_id\\":\\"1858814721002090\\",\\"offset_x\\":\\"0\\",\\"offset_y\\":\\"88\\",\\"source\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t31.0-8\\\\\\/s720x720\\\\\\/17434882_1858814721002090_8895440652042769827_o.png?oh=a6334dcb79b20268ff8552b221df96c5&oe=5953ACA1\\",\\"id\\":\\"1858814721002090\\"}"}', '2017-03-28 07:46:26', '2017-03-28 07:46:26', 'EAAXTIQdG4bEBAFwAsqQsKhqgnLc2JZCmyn0f0RGFms1d3Df0ogkYg8g5uiWgyCBMKlQZAqL0DVOgaz4z7VZAPqkZAoQI52JjiQumcsNZAjTsOPlxmU3m1iPBtSHJWvPSX6io0btMUPEJ5ZA3k9zuTUpunkrH21BZBroAPvkaBuClpgpjRp2yXMkf0Q1D3MDAMwZD', '["ADMINISTER","EDIT_PROFILE","CREATE_CONTENT","MODERATE_CONTENT","CREATE_ADS","BASIC_ADMIN"]', 'Vn4CMS', 'Software', 'Website development easy, friendly for both users and developers website', '1'),
(141, '289730221459804', 'vn4fanpage-fanpage-289730221459804', '', '', '', 23, 'vn4fanpage-fanpage', '', 'publish', 'publish', '', '', '', '', '2017-03-28 07:46:26', '2017-03-28 07:46:26', 'EAAXTIQdG4bEBAAYl6AiB7TPjWts1v1xX73hZCuNuK5D0NeVdHekyRSRWvzeaGuLZBJabcbXfaodwZBIS87ajAXXYW1HbWZCwGlGy4zwIw8Iu2AFNHOoG0l9xX7xumX0EN1FLkttFcPN3LHE0WtjKtflBdJ2GvrT9MHps4yQbYJ4H8lUYjpEZAZBDLgvjTQw6EZD', '["ADMINISTER","EDIT_PROFILE","CREATE_CONTENT","MODERATE_CONTENT","CREATE_ADS","BASIC_ADMIN"]', 'DNA R&D', 'Science, Technology & Engineering', '<b style="color:red;">(Can not find)</b>', '0'),
(142, '226989890767216', 'vn4fanpage-fanpage-226989890767216', '', '', '', 23, 'vn4fanpage-fanpage', '', 'publish', 'publish', '', '', '', '{"app_id":"1639513693020593","application":"Fanpage Manager","expires_at":0,"is_valid":true,"issued_at":1489566417,"profile_id":"226989890767216","scopes":["read_page_mailboxes","email","manage_pages","publish_pages","pages_show_list","pages_manage_cta","pages_manage_instant_articles","public_profile"],"user_id":"959601664173977","error":false,"checked":true}', '2017-03-28 07:46:27', '2017-03-28 07:46:54', 'EAAXTIQdG4bEBAMGjNqZAP8CrP9vZA3z0ceCztwrKXCHdx8aPrSkveCC2dvUFgfRYfdnneKnKhTz3pmS0q2ij9ukwCHwo4lZA6RdXdU1uze2niudnT0M9jM5571uR1erSv9Bm7uK2goqyiOoun0qg0Q8wOfU0DRoIElZAnWCHF9mDNQNcpx4MkA08jJBVGeEZD', '["ADMINISTER","EDIT_PROFILE","CREATE_CONTENT","MODERATE_CONTENT","CREATE_ADS","BASIC_ADMIN"]', 'FA hội quán', 'TV Show', 'tesst upload about new 2', '0');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_fanpage-photo`
--

CREATE TABLE `vn4_fanpage-photo` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_time` text COLLATE utf8_unicode_ci NOT NULL,
  `picture` text COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `likes` text COLLATE utf8_unicode_ci NOT NULL,
  `reactions` text COLLATE utf8_unicode_ci NOT NULL,
  `page_id` text COLLATE utf8_unicode_ci NOT NULL,
  `photo_type` text COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vn4_fanpage-post`
--

CREATE TABLE `vn4_fanpage-post` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_time` text COLLATE utf8_unicode_ci NOT NULL,
  `post_type` text COLLATE utf8_unicode_ci NOT NULL,
  `page_id` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn4_fanpage-post`
--

INSERT INTO `vn4_fanpage-post` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `created_at`, `updated_at`, `message`, `created_time`, `post_type`, `page_id`) VALUES
(128, '226989890767216_758412424291624', 'vn4fanpage-photo-226989890767216_758412424291624', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"message\\":\\"sdfsdfsd\\",\\"created_time\\":\\"2016-02-14T05:51:13+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"trandaiquang.net\\",\\"link\\":\\"http:\\\\\\/\\\\\\/trandaiquang.net\\\\\\/nga-vo-mong-vi-bi-trung-quoc-dam-sau-lung.html\\",\\"name\\":\\"FA h\\\\u1ed9i qu\\\\u00e1n\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCrBcET5rR9bt55&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Fv%2Ft1.0-1%2Fc141.41.517.517%2Fs200x200%2F380187_226990314100507_506474127_n.jpg%3Foh%3Dc55b464948953fc936522e6482cbd8cc%26oe%3D59540344&_nc_hash=AQA-btp-7MdRpTwh\\",\\"id\\":\\"226989890767216_758412424291624\\"}"}', '2017-03-28 07:46:49', '2017-03-28 07:46:49', 'sdfsdfsd', '2016-02-14T05:51:13+0000', 'link', '142'),
(129, '1717881081760545_1874353766113275', 'vn4fanpage-photo-1717881081760545_1874353766113275', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"message\\":\\"11111111\\",\\"created_time\\":\\"2017-03-22T08:08:31+0000\\",\\"type\\":\\"status\\",\\"id\\":\\"1717881081760545_1874353766113275\\"}"}', '2017-03-28 07:47:13', '2017-03-28 07:47:14', '11111111', '2017-03-22T08:08:31+0000', 'status', '139'),
(130, '1717881081760545_1871095559772429', 'vn4fanpage-photo-1717881081760545_1871095559772429', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"League Montage shared a link.\\",\\"created_time\\":\\"2017-03-15T07:18:44+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"google.com.vn\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.google.com.vn\\\\\\/webhp?hl=vi&sa=X&ved=0ahUKEwiYmMyE_NfSAhVBTbwKHcN9ALQQPAgD\\",\\"name\\":\\"Google\\",\\"id\\":\\"1717881081760545_1871095559772429\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', '', '2017-03-15T07:18:44+0000', 'link', '139'),
(131, '1717881081760545_1730341020514551', 'vn4fanpage-photo-1717881081760545_1730341020514551', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"message\\":\\"This is my channel : https:\\\\\\/\\\\\\/www.youtube.com\\\\\\/channel\\\\\\/UCMcD4YwvYefrmlRutSHoHaw\\",\\"created_time\\":\\"2016-04-18T11:51:51+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"youtube.com\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.youtube.com\\\\\\/channel\\\\\\/UCMcD4YwvYefrmlRutSHoHaw\\",\\"name\\":\\"League Montage\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQBqrZxGV8dfWF3F&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Fv%2Ft1.0-1%2Fc9.0.200.200%2Fp200x200%2F13055572_1730340590514594_8878581513918078731_n.png%3Foh%3Dd0aa9f823a194f699afecd47804f0bce%26oe%3D5953A204&_nc_hash=AQDNq9XDVkrpVFOR\\",\\"id\\":\\"1717881081760545_1730341020514551\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', 'This is my channel : https://www.youtube.com/channel/UCMcD4YwvYefrmlRutSHoHaw', '2016-04-18T11:51:51+0000', 'link', '139'),
(132, '1717881081760545_1730340590514594', 'vn4fanpage-photo-1717881081760545_1730340590514594', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"League Montage updated their profile picture.\\",\\"created_time\\":\\"2016-04-18T11:50:02+0000\\",\\"type\\":\\"photo\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/1717881081760545\\\\\\/photos\\\\\\/a.1717900565091930.1073741825.1717881081760545\\\\\\/1730340590514594\\\\\\/?type=3\\",\\"name\\":\\"League Montage\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t1.0-9\\\\\\/13055572_1730340590514594_8878581513918078731_n.png?oh=ff545d6cf506b660a464300e259abe8e&oe=599B3A98\\",\\"id\\":\\"1717881081760545_1730340590514594\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', '', '2016-04-18T11:50:02+0000', 'photo', '139'),
(133, '1717881081760545_1730340387181281', 'vn4fanpage-photo-1717881081760545_1730340387181281', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"League Montage updated their cover photo.\\",\\"created_time\\":\\"2016-04-18T11:49:04+0000\\",\\"type\\":\\"photo\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/1717881081760545\\\\\\/photos\\\\\\/a.1717908871757766.1073741827.1717881081760545\\\\\\/1730340387181281\\\\\\/?type=3\\",\\"name\\":\\"League Montage''s cover photo\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t1.0-9\\\\\\/q84\\\\\\/s720x720\\\\\\/12592390_1730340387181281_2077825272935295780_n.jpg?oh=e36874ac1596b55131a9f569efa8b19f&oe=599897CE\\",\\"id\\":\\"1717881081760545_1730340387181281\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', '', '2016-04-18T11:49:04+0000', 'photo', '139'),
(134, '1717881081760545_1717913475090639', 'vn4fanpage-photo-1717881081760545_1717913475090639', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"message\\":\\"Welcome to Level LOL :) Here you can find all your favorite heroes in the video game legend of league\\\\nWe are interested to receive your comments, suggestions and questions concerning the video, including images, audio, effects and content\\",\\"created_time\\":\\"2016-03-21T06:55:22+0000\\",\\"type\\":\\"photo\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/1717881081760545\\\\\\/photos\\\\\\/a.1717913508423969.1073741828.1717881081760545\\\\\\/1717913475090639\\\\\\/?type=3\\",\\"name\\":\\"Timeline Photos\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t31.0-8\\\\\\/s720x720\\\\\\/12890986_1717913475090639_2206477921463269389_o.jpg?oh=6ccb98992fea16de683db7c183dac3c5&oe=5999D959\\",\\"id\\":\\"1717881081760545_1717913475090639\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', 'Welcome to Level LOL :) Here you can find all your favorite heroes in the video game legend of league\nWe are interested to receive your comments, suggestions and questions concerning the video, including images, audio, effects and content', '2016-03-21T06:55:22+0000', 'photo', '139'),
(135, '1717881081760545_1717908681757785', 'vn4fanpage-photo-1717881081760545_1717908681757785', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"League Montage updated their cover photo.\\",\\"created_time\\":\\"2016-03-21T06:45:34+0000\\",\\"type\\":\\"photo\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/1717881081760545\\\\\\/photos\\\\\\/a.1717908871757766.1073741827.1717881081760545\\\\\\/1717908681757785\\\\\\/?type=3\\",\\"name\\":\\"League Montage''s cover photo\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t1.0-9\\\\\\/s720x720\\\\\\/12814520_1717908681757785_4531321699563880173_n.png?oh=6fbab567c05802e0902baa27b0e2f83a&oe=5957C856\\",\\"id\\":\\"1717881081760545_1717908681757785\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', '', '2016-03-21T06:45:34+0000', 'photo', '139'),
(136, '1717881081760545_1717900575091929', 'vn4fanpage-photo-1717881081760545_1717900575091929', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"League Montage updated their profile picture.\\",\\"created_time\\":\\"2016-03-21T06:10:05+0000\\",\\"type\\":\\"photo\\",\\"link\\":\\"https:\\\\\\/\\\\\\/www.facebook.com\\\\\\/1717881081760545\\\\\\/photos\\\\\\/a.1717900565091930.1073741825.1717881081760545\\\\\\/1717900575091929\\\\\\/?type=3\\",\\"name\\":\\"League Montage\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/scontent.xx.fbcdn.net\\\\\\/v\\\\\\/t1.0-9\\\\\\/s720x720\\\\\\/12038361_1717900575091929_2805680418479593824_n.jpg?oh=af6256d151e15cfdd4cde9594f929df8&oe=595BDC3D\\",\\"id\\":\\"1717881081760545_1717900575091929\\"}"}', '2017-03-28 07:47:14', '2017-03-28 07:47:14', '', '2016-03-21T06:10:05+0000', 'photo', '139'),
(137, '1039487402789864_1429779773760623', 'vn4fanpage-photo-1039487402789864_1429779773760623', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2017-03-22T10:56:49+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"Kementerian Kesihatan Malaysia (KKM) telah mengeluarkan senarai produk makanan dan minuman untuk kecantikan serta slimming yang dikesan beracun dan telah diharamkan.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/video-senarai-minuman-kecantikan-yang.html\\",\\"name\\":\\"Video: Senarai Minuman Kecantikan Yang Dikesan Beracun Oleh Kementerian Kesihatan Malaysia\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCHTy5gpLNBAMXj&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Ft45.1600-4%2F12480994_6045508986575_1937854852_n.png&_nc_hash=AQBmDwlPRnmx4efL\\",\\"id\\":\\"1039487402789864_1429779773760623\\"}","fb-action":"{\\"id\\":\\"1039487402789864_1429779773760623\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:47:36', '', '2017-03-22T10:56:49+0000', 'link', '138'),
(138, '1039487402789864_1429766340428633', 'vn4fanpage-photo-1039487402789864_1429766340428633', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2017-03-22T10:55:45+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"Kementerian Kesihatan Malaysia (KKM) telah mengeluarkan senarai produk makanan dan minuman untuk kecantikan serta slimming yang dikesan beracun dan telah diharamkan.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/video-senarai-minuman-kecantikan-yang.html\\",\\"name\\":\\"Video: Senarai Minuman Kecantikan Yang Dikesan Beracun Oleh Kementerian Kesihatan Malaysia\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCHTy5gpLNBAMXj&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Ft45.1600-4%2F12480994_6045508986575_1937854852_n.png&_nc_hash=AQBmDwlPRnmx4efL\\",\\"id\\":\\"1039487402789864_1429766340428633\\"}","fb-action":"{\\"id\\":\\"1039487402789864_1429766340428633\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:47:53', '', '2017-03-22T10:55:45+0000', 'link', '138'),
(139, '1039487402789864_1428542760550991', 'vn4fanpage-photo-1039487402789864_1428542760550991', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"message\\":\\"564654564654\\",\\"created_time\\":\\"2017-03-21T11:01:13+0000\\",\\"type\\":\\"status\\",\\"id\\":\\"1039487402789864_1428542760550991\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:47:28', '564654564654', '2017-03-21T11:01:13+0000', 'status', '138'),
(140, '1039487402789864_1047338042004800', 'vn4fanpage-photo-1039487402789864_1047338042004800', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:39:04+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"Kementerian Kesihatan Malaysia (KKM) telah mengeluarkan senarai produk makanan dan minuman untuk kecantikan serta slimming yang dikesan beracun dan telah diharamkan.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/video-senarai-minuman-kecantikan-yang.html\\",\\"name\\":\\"Video: Senarai Minuman Kecantikan Yang Dikesan Beracun Oleh Kementerian Kesihatan Malaysia\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCHTy5gpLNBAMXj&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Ft45.1600-4%2F12480994_6045508986575_1937854852_n.png&_nc_hash=AQBmDwlPRnmx4efL\\",\\"id\\":\\"1039487402789864_1047338042004800\\"}","fb-action":"{\\"comments\\":{\\"data\\":[{\\"comments\\":{\\"data\\":[{\\"message\\":\\"demo 2\\",\\"from\\":{\\"name\\":\\"News For you\\",\\"id\\":\\"1039487402789864\\"},\\"id\\":\\"1047338042004800_1429755670429700\\"},{\\"message\\":\\"demo 3\\",\\"from\\":{\\"name\\":\\"News For you\\",\\"id\\":\\"1039487402789864\\"},\\"id\\":\\"1047338042004800_1429755950429672\\"}],\\"paging\\":{\\"cursors\\":{\\"before\\":\\"WTI5dGJXVnVkRjlqZAFhKemIzSTZANVFF5T1RjMU5UWTNNRFF5T1Rjd01Eb3hORGt3TVRjNU5UZA3gZD\\",\\"after\\":\\"WTI5dGJXVnVkRjlqZAFhKemIzSTZANVFF5T1RjMU5UazFNRFF5T1RZAM01qb3hORGt3TVRjNU5UazUZD\\"}}},\\"message\\":\\"demo\\",\\"from\\":{\\"name\\":\\"News For you\\",\\"id\\":\\"1039487402789864\\"},\\"comment_count\\":2,\\"id\\":\\"1047338042004800_1429755617096372\\"}],\\"paging\\":{\\"cursors\\":{\\"before\\":\\"WTI5dGJXVnVkRjlqZAFhKemIzSTZANVFF5T1RjMU5UWXhOekE1TmpNM01qb3hORGt3TVRjNU5UYzEZD\\",\\"after\\":\\"WTI5dGJXVnVkRjlqZAFhKemIzSTZANVFF5T1RjMU5UWXhOekE1TmpNM01qb3hORGt3TVRjNU5UYzEZD\\"}}},\\"reactions\\":{\\"data\\":[{\\"id\\":\\"1039487402789864\\",\\"name\\":\\"News For you\\",\\"type\\":\\"LOVE\\"}],\\"paging\\":{\\"cursors\\":{\\"before\\":\\"TVRBek9UUTROelF3TWpjNE9UZAzJORG94TkRrd01UZA3dNemsxT2pjNE9EWTBPREF6TnpreE16TXhNZAz09\\",\\"after\\":\\"TVRBek9UUTROelF3TWpjNE9UZAzJORG94TkRrd01UZA3dNemsxT2pjNE9EWTBPREF6TnpreE16TXhNZAz09\\"}}},\\"sharedposts\\":{\\"data\\":[{\\"from\\":{\\"name\\":\\"News For you\\",\\"id\\":\\"1039487402789864\\"},\\"story\\":\\"News For you shared a link.\\",\\"id\\":\\"1039487402789864_1429779773760623\\"},{\\"from\\":{\\"name\\":\\"News For you\\",\\"id\\":\\"1039487402789864\\"},\\"story\\":\\"News For you shared a link.\\",\\"id\\":\\"1039487402789864_1429766340428633\\"}],\\"paging\\":{\\"cursors\\":{\\"before\\":\\"MTQyOTc3OTc3Mzc2MDYyMzo5OjAZD\\",\\"after\\":\\"MTQyOTc2NjM0MDQyODYzMzo5OjAZD\\"},\\"next\\":\\"https:\\\\\\/\\\\\\/graph.facebook.com\\\\\\/v2.8\\\\\\/1039487402789864_1047338042004800\\\\\\/sharedposts?access_token=EAAXTIQdG4bEBAP4oQBUgtzOYZCFZB4A5oq3CrZAtVfrJgoiqIfwUSUnpEoB8F8kVqXEkOQBrfyXXPSsTs95FxVrGsHstlWCZBlZAZAuBMHF6s2ca0KmlZCw8VZCDbGMEZByZCfZCZAx4kRFLjtIDWEN3fjSEuYeJPGMZABfTnI9kA0kGAyZAIHDRJ2VgER7BERvop7jhwZD&pretty=1&fields=from%2Cstory&limit=25&after=MTQyOTc2NjM0MDQyODYzMzo5OjAZD\\"}},\\"id\\":\\"1039487402789864_1047338042004800\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:48:12', '', '2016-03-18T12:39:04+0000', 'link', '138'),
(141, '1039487402789864_1047331568672114', 'vn4fanpage-photo-1039487402789864_1047331568672114', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:23:15+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"Kuala Lumpur : Gambar seorang wanita tanpa seurat benang dengan badannya yang mempamerkan lukisan ''airbrush'' tersebar di laman sosial baru-baru ini.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/identiti-model-melayu-tanpa-seurat.html\\",\\"name\\":\\"Identiti model melayu tanpa seurat benang terdedah\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQA3hcbp0eHyyDzH&url=https%3A%2F%2Fscontent-hkg3-1.xx.fbcdn.net%2Fhphotos-xfa1%2Fv%2Ft1.0-9%2F1604452_1047331515338786_4531794540047327828_n.png%3Foh%3D50fd967db4474815a473686c97ce1e86%26oe%3D5750844E&_nc_hash=AQD778c1GklaZtnJ\\",\\"id\\":\\"1039487402789864_1047331568672114\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:47:28', '', '2016-03-18T12:23:15+0000', 'link', '138'),
(142, '1039487402789864_1047330198672251', 'vn4fanpage-photo-1039487402789864_1047330198672251', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:20:32+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"SEJAK kebelakangan ini, memang ramai usahawan yang memulakan perniagaan secara atas talian atau online kerana mudah dan seiring dengan dengan perkembangan semasa.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/sudah-gila-ke-jual-beli-seluar-dalam.html\\",\\"name\\":\\"SUDAH GILA KE? Jual Beli Seluar Dalam Terpakai \\\\u2018Berbau\\\\u2019 Dalam FB\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQAahJ8gHK_6dP0Q&url=https%3A%2F%2Fscontent-hkg3-1.xx.fbcdn.net%2Fhphotos-xlp1%2Fv%2Fl%2Ft1.0-9%2F1936395_1047330162005588_8576010662748200063_n.png%3Foh%3D39663d61e12edccb9cf2f5d1a173483c%26oe%3D578560BA&_nc_hash=AQBhVrJVNfxrZHxX\\",\\"id\\":\\"1039487402789864_1047330198672251\\"}"}', '2017-03-28 07:47:28', '2017-03-28 07:47:28', '', '2016-03-18T12:20:32+0000', 'link', '138'),
(143, '1039487402789864_1047329358672335', 'vn4fanpage-photo-1039487402789864_1047329358672335', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:17:52+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"WOW!! TAK BUKAK BAJU MAKA TAK CINTA | Itulah ayat memikat yang digunakan awek cun untuk merakam tubuh mangsa.Mangsa yang menyangka awek cun tersebut sangat la sangap maka dia pun membuka pakaian sehelai demi sehelai macam penari tiang.Mangsa yang mahu dikenali sebagai John Tan, 30, berkata, dia meng\\\\u2026\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/lagi-kes-lelaki-terkena-jerat-wanita.html\\",\\"name\\":\\"LAGI KES LELAKI TERKENA JERAT WANITA CANTIK DI LAMAN SOSIAL\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQDQrbUCszUTQ6MB&url=https%3A%2F%2Fscontent.xx.fbcdn.net%2Ft45.1600-4%2F12600764_6045509034975_1455200723_n.png&_nc_hash=AQDgkTGfV3d5JGHG\\",\\"id\\":\\"1039487402789864_1047329358672335\\"}","fb-action":"{\\"id\\":\\"1039487402789864_1047329358672335\\"}"}', '2017-03-28 07:47:29', '2017-03-28 07:48:40', '', '2016-03-18T12:17:52+0000', 'link', '138'),
(144, '1039487402789864_1047328535339084', 'vn4fanpage-photo-1039487402789864_1047328535339084', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:16:04+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"Tajuk hangat..gambar panas..Benarkah wanita melayu zaman sekarang gemar membuat perkara sedemikian? Sejak mula wujudnya laman-laman sosial di internet seperti Facebook, Tagged, Friendster dan lain-lain lagi. Macam-macam hal dapat kita lihat dan tahu, dari yang biasa-biasa hingga ke luar biasa. Dari\\\\u2026\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/panas-wanita-melayu-gemar-tayang.html\\",\\"name\\":\\"PANAS: Wanita Melayu Gemar Tayang Eset..Benarkah?\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCKC3-hWCZQKulQ&url=https%3A%2F%2Fscontent-hkg3-1.xx.fbcdn.net%2Fhphotos-xpa1%2Fv%2Ft1.0-9%2F10259336_1047328468672424_4038999455911643700_n.png%3Foh%3Dd254ff7d443b41f6f8552d1050d955f9%26oe%3D5754E26D&_nc_hash=AQDOKqp1Jqj-9oKr\\",\\"id\\":\\"1039487402789864_1047328535339084\\"}"}', '2017-03-28 07:47:29', '2017-03-28 07:47:29', '', '2016-03-18T12:16:04+0000', 'link', '138'),
(145, '1039487402789864_1047325892006015', 'vn4fanpage-photo-1039487402789864_1047325892006015', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:09:35+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"This is my response to Richard Wee\\\\u2019s post. I wish to credit Aston Paiva for illuminating me on certain aspects of my post.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/justification-on-bar-councils-cpd.html\\",\\"name\\":\\"Justification on Bar Council\\\\u2019s CPD motion attempts to hide the truth?\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQA7Y6kLzdmrFX-l&url=https%3A%2F%2Fscontent-hkg3-1.xx.fbcdn.net%2Fhphotos-xap1%2Fv%2Ft1.0-9%2F10400008_1047325672006037_5937475302613802005_n.png%3Foh%3D22c40d2722c9467e2481c2f46c98f064%26oe%3D57562B0B&_nc_hash=AQBHj8URfo52ynI4\\",\\"id\\":\\"1039487402789864_1047325892006015\\"}"}', '2017-03-28 07:47:29', '2017-03-28 07:47:29', '', '2016-03-18T12:09:35+0000', 'link', '138'),
(146, '1039487402789864_1047325008672770', 'vn4fanpage-photo-1039487402789864_1047325008672770', '', '', '', 23, 'vn4fanpage-post', '', 'publish', 'publish', '', '', '', '{"my-data":"{\\"story\\":\\"News For you shared a link.\\",\\"created_time\\":\\"2016-03-18T12:07:34+0000\\",\\"type\\":\\"link\\",\\"caption\\":\\"malaysianewstop.blogspot.com\\",\\"description\\":\\"A Penang DAP backbencher said the Malaysian Bar has been \\\\u201ctainted\\\\u201d by its actions against attorney-general (AG) Mohamed Apandi Ali and his decision not to press charges against Prime Minister Najib Razak.\\",\\"link\\":\\"http:\\\\\\/\\\\\\/malaysianewstop.blogspot.com\\\\\\/2016\\\\\\/03\\\\\\/malaysian-bar-tainted-by-motion-at-agm.html\\",\\"name\\":\\"Malaysian Bar \\\\u2018tainted\\\\u2019 by motion at AGM to remove AG\\",\\"full_picture\\":\\"https:\\\\\\/\\\\\\/external.xx.fbcdn.net\\\\\\/safe_image.php?d=AQCOV7l_vGsWeVNA&url=https%3A%2F%2Fscontent-hkg3-1.xx.fbcdn.net%2Fhphotos-xfp1%2Fv%2Ft1.0-9%2F12790968_1047324955339442_3463588476538350087_n.png%3Foh%3D324691b3c418a89a534b4244fa388f25%26oe%3D5794D17A&_nc_hash=AQC2WcB9On1iQcvA\\",\\"id\\":\\"1039487402789864_1047325008672770\\"}"}', '2017-03-28 07:47:29', '2017-03-28 07:47:29', '', '2016-03-18T12:07:34+0000', 'link', '138');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_fanpage-video`
--

CREATE TABLE `vn4_fanpage-video` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `updated_time` text COLLATE utf8_unicode_ci NOT NULL,
  `picture` text COLLATE utf8_unicode_ci NOT NULL,
  `page_id` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vn4_menu`
--

CREATE TABLE `vn4_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `json` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `content` text NOT NULL,
  `key_word` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_menu`
--

INSERT INTO `vn4_menu` (`id`, `title`, `author`, `json`, `type`, `status`, `content`, `key_word`, `theme`, `updated_at`, `created_at`) VALUES
(11, 'menu main', 10, '[{"label":"Home","posttype":"page-static","route":"index"}]', 'menu_item', 0, '<li class="dd-item" data-posttype="category" data-label="Thời sự" data-id="78"><div class="dd-handle">Thời sự</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thời sự" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Giao thông" data-id="79"><div class="dd-handle">Giao thông</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Giao thông" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Đô thị" data-id="81"><div class="dd-handle">Đô thị</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Đô thị" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Quốc phòng" data-id="88"><div class="dd-handle">Quốc phòng</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Quốc phòng" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Đời sống" data-id="82"><div class="dd-handle">Đời sống</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Đời sống" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Ảnh &amp; Video" data-id="89"><div class="dd-handle">Ảnh &amp; Video</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Ảnh &amp; Video" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Tết sum vầy" data-id="90"><div class="dd-handle">Tết sum vầy</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tết sum vầy" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Thế giới" data-id="91"><div class="dd-handle">Thế giới</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thế giới" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Ảnh &amp; Video" data-id="92"><div class="dd-handle">Ảnh &amp; Video</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Ảnh &amp; Video" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Quân sự" data-id="93"><div class="dd-handle">Quân sự</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Quân sự" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Tư liệu" data-id="94"><div class="dd-handle">Tư liệu</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tư liệu" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Phân tích" data-id="95"><div class="dd-handle">Phân tích</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Phân tích" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Nguoi việt 4 phương" data-id="96"><div class="dd-handle">Nguoi việt 4 phương</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Nguoi việt 4 phương" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Kinh doanh" data-id="97"><div class="dd-handle">Kinh doanh</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Kinh doanh" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Tài chính" data-id="98"><div class="dd-handle">Tài chính</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tài chính" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Bất động sản" data-id="99"><div class="dd-handle">Bất động sản</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Bất động sản" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Chứng khoán" data-id="100"><div class="dd-handle">Chứng khoán</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Chứng khoán" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Doanh nhân" data-id="101"><div class="dd-handle">Doanh nhân</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Doanh nhân" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Pháp luật" data-id="102"><div class="dd-handle">Pháp luật</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Pháp luật" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Pháp đình" data-id="103"><div class="dd-handle">Pháp đình</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Pháp đình" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Vụ án" data-id="104"><div class="dd-handle">Vụ án</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Vụ án" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Xuât bản" data-id="105"><div class="dd-handle">Xuât bản</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Xuât bản" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Tin tức xuât bản" data-id="106"><div class="dd-handle">Tin tức xuât bản</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tin tức xuât bản" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Sách hay" data-id="107"><div class="dd-handle">Sách hay</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sách hay" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Tác giả" data-id="108"><div class="dd-handle">Tác giả</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tác giả" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Thể thao" data-id="109"><div class="dd-handle">Thể thao</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thể thao" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Thể thao Việt Nam" data-id="110"><div class="dd-handle">Thể thao Việt Nam</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thể thao Việt Nam" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Cúp Châu Âu" data-id="111"><div class="dd-handle">Cúp Châu Âu</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Cúp Châu Âu" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Thể thao thế giới" data-id="112"><div class="dd-handle">Thể thao thế giới</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thể thao thế giới" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Bóng đã" data-id="113"><div class="dd-handle">Bóng đã</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Bóng đã" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Bóng đá Anh" data-id="114"><div class="dd-handle">Bóng đá Anh</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Bóng đá Anh" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Bóng đá Việt Nam" data-id="115"><div class="dd-handle">Bóng đá Việt Nam</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Bóng đá Việt Nam" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Video bóng đá" data-id="116"><div class="dd-handle">Video bóng đá</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Video bóng đá" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Hậu trường thể thao" data-id="117"><div class="dd-handle">Hậu trường thể thao</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Hậu trường thể thao" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Công nghệ" data-id="118"><div class="dd-handle">Công nghệ</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Công nghệ" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Điện thoại" data-id="119"><div class="dd-handle">Điện thoại</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Điện thoại" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Máy tính bảng" data-id="120"><div class="dd-handle">Máy tính bảng</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Máy tính bảng" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Ứng dụng di động" data-id="121"><div class="dd-handle">Ứng dụng di động</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Ứng dụng di động" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Xe 360" data-id="122"><div class="dd-handle">Xe 360</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Xe 360" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Xe máy" data-id="123"><div class="dd-handle">Xe máy</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Xe máy" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Ô tô" data-id="124"><div class="dd-handle">Ô tô</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Ô tô" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Xe độ" data-id="125"><div class="dd-handle">Xe độ</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Xe độ" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Siêu xe" data-id="126"><div class="dd-handle">Siêu xe</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Siêu xe" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Giải trí" data-id="127"><div class="dd-handle">Giải trí</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Giải trí" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Sao việt" data-id="128"><div class="dd-handle">Sao việt</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sao việt" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Sao châu á" data-id="129"><div class="dd-handle">Sao châu á</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sao châu á" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Sao Hollywood" data-id="130"><div class="dd-handle">Sao Hollywood</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sao Hollywood" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Âm nhạc" data-id="131"><div class="dd-handle">Âm nhạc</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Âm nhạc" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Nhạc Việt" data-id="132"><div class="dd-handle">Nhạc Việt</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Nhạc Việt" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Nhạc Hàn" data-id="133"><div class="dd-handle">Nhạc Hàn</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Nhạc Hàn" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Nhạc Âu Mĩ" data-id="134"><div class="dd-handle">Nhạc Âu Mĩ</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Nhạc Âu Mĩ" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Phim ảnh" data-id="135"><div class="dd-handle">Phim ảnh</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Phim ảnh" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Phim chiếu rạp" data-id="136"><div class="dd-handle">Phim chiếu rạp</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Phim chiếu rạp" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Phim truyền hình" data-id="137"><div class="dd-handle">Phim truyền hình</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Phim truyền hình" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Game show" data-id="138"><div class="dd-handle">Game show</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Game show" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Thời trang" data-id="139"><div class="dd-handle">Thời trang</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thời trang" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Thời trang sao" data-id="140"><div class="dd-handle">Thời trang sao</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Thời trang sao" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Mặc đẹp" data-id="141"><div class="dd-handle">Mặc đẹp</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Mặc đẹp" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Làm đẹp" data-id="142"><div class="dd-handle">Làm đẹp</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Làm đẹp" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Sống trẻ" data-id="143"><div class="dd-handle">Sống trẻ</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sống trẻ" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Gương mặt trẻ" data-id="144"><div class="dd-handle">Gương mặt trẻ</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Gương mặt trẻ" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Cộng đồng mạng" data-id="145"><div class="dd-handle">Cộng đồng mạng</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Cộng đồng mạng" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Sự kiện" data-id="146"><div class="dd-handle">Sự kiện</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sự kiện" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Giáo dục" data-id="147"><div class="dd-handle">Giáo dục</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Giáo dục" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Tuyển sinh" data-id="148"><div class="dd-handle">Tuyển sinh</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tuyển sinh" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Tư vấn" data-id="149"><div class="dd-handle">Tư vấn</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Tư vấn" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Du học" data-id="150"><div class="dd-handle">Du học</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Du học" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Sức khỏe" data-id="151"><div class="dd-handle">Sức khỏe</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Sức khỏe" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Khỏe đẹp" data-id="152"><div class="dd-handle">Khỏe đẹp</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Khỏe đẹp" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Dinh dưỡng" data-id="153"><div class="dd-handle">Dinh dưỡng</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Dinh dưỡng" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Mẹ và bé" data-id="154"><div class="dd-handle">Mẹ và bé</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Mẹ và bé" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Bệnh thường gặp" data-id="155"><div class="dd-handle">Bệnh thường gặp</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Bệnh thường gặp" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li><li class="dd-item" data-posttype="category" data-label="Du lịch" data-id="156"><div class="dd-handle">Du lịch</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Du lịch" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div><ol class="dd-list"><li class="dd-item" data-posttype="category" data-label="Địa điểm du lịch" data-id="157"><div class="dd-handle">Địa điểm du lịch</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Địa điểm du lịch" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Kinh nghiệm du lịch" data-id="158"><div class="dd-handle">Kinh nghiệm du lịch</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Kinh nghiệm du lịch" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li><li class="dd-item" data-posttype="category" data-label="Phượt" data-id="159"><div class="dd-handle">Phượt</div><i class="fa"></i><p class="menu_type">Category</p><div class="menu_item_info"><div class="form-group"><label class="control-label col-xs-12"><i>Navigation Label</i></label><div class="col-xs-12"><input type="text" class="form-control input-nav-label" value="Phượt" placeholder="Navigation Label"></div></div><div class="clearfix"></div><p class="menu_item_controls"> <a type="button" class="btn-control btn-remove">Xóa</a> | <a type="button" class="btn-control btn-cancel">Đóng</a></p></div></li></ol></li>', 'nav-main', 'eleven', '2017-04-03 08:34:18', '2016-12-01 07:55:04'),
(13, '', 0, '[]', '', 1, '', 'nav-footer', 'eleven', '2017-02-03 12:46:31', '2017-01-24 17:56:04'),
(14, '', 0, '[{"id":2,"label":"About Us","posttype":"page","slug":"about-us"},{"id":3,"label":"Service","posttype":"page","slug":"service"},{"id":4,"label":"Contact","posttype":"page","slug":"contact"}]', '', 1, '', 'nav-fixed-top', 'eleven', '2017-02-22 17:09:47', '2017-02-12 07:12:49'),
(19, '', 0, '[{"label":"Home","posttype":"page-static","route":"index"},{"label":"About","posttype":"page-theme","page":"about"},{"label":"Blog","posttype":"page-theme","page":"blog"},{"label":"Theme","posttype":"page-theme","page":"theme"},{"label":"Plugin","posttype":"page-theme","page":"plugin"},{"label":"Document","posttype":"page-theme","page":"document","children":[{"label":"Function","posttype":"page-theme","page":"document-function"},{"label":"Hook","posttype":"page-theme","page":"document-hook"},{"label":"Video","posttype":"page-theme","page":"document-video"}]},{"label":"Contact","posttype":"page-theme","page":"contact"}]', '', 1, '', 'nav-main', 'vn4cms-dot-com', '2017-03-28 07:45:46', '2017-02-26 18:51:12');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_page`
--

CREATE TABLE `vn4_page` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `content` longtext NOT NULL,
  `image` text NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `view` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish',
  `status_old` varchar(20) NOT NULL DEFAULT 'publish',
  `visibility` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `post_date_gmt` varchar(20) NOT NULL,
  `meta` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_page`
--

INSERT INTO `vn4_page` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `updated_at`, `created_at`, `tag`) VALUES
(2, 'About Us', 'about-us', '', '<p>Comming soon</p>', '', 10, 'page', '', 'draft', 'publish', 'publish', '', '', '{"seo_vn4_focus_keyword":"","seo_vn4_facebook_title":"","seo_vn4_facebook_description":"","seo_vn4_facebook_image":"","seo_vn4_twitter_title":"","seo_vn4_twitter_description":"","seo_vn4_twitter_image":"","plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"About Us","plugin_vn4seo_facebook_description":"About Us","plugin_vn4seo_facebook_image":"","plugin_vn4seo_twitter_title":"About Us","plugin_vn4seo_twitter_description":"About Us","plugin_vn4seo_twitter_image":""}', '2017-02-27 16:41:03', '2017-02-12 07:11:20', ''),
(3, 'Service', 'service', '', '', '', 10, 'page', '', 'pending', 'publish', 'password', '123', '', '{"seo_vn4_focus_keyword":"","seo_vn4_facebook_title":"","seo_vn4_facebook_description":"","seo_vn4_facebook_image":"","seo_vn4_twitter_title":"","seo_vn4_twitter_description":"","seo_vn4_twitter_image":"","plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Service","plugin_vn4seo_facebook_description":"Service","plugin_vn4seo_facebook_image":"","plugin_vn4seo_twitter_title":"Service","plugin_vn4seo_twitter_description":"Service","plugin_vn4seo_twitter_image":""}', '2017-02-27 16:40:51', '2017-02-12 07:11:34', ''),
(4, 'Contact', 'contact', '', '', '', 10, 'page', '', 'trash', 'publish', 'publish', '', '', '{"seo_vn4_focus_keyword":"","seo_vn4_facebook_title":"","seo_vn4_facebook_description":"","seo_vn4_facebook_image":"","seo_vn4_twitter_title":"","seo_vn4_twitter_description":"","seo_vn4_twitter_image":"","plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Contact","plugin_vn4seo_facebook_description":"Contact","plugin_vn4seo_facebook_image":"            \\r\\n        ","plugin_vn4seo_twitter_title":"Contact","plugin_vn4seo_twitter_description":"Contact","plugin_vn4seo_twitter_image":"            \\r\\n        "}', '2017-02-27 16:40:37', '2017-02-12 07:11:40', '');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_post`
--

CREATE TABLE `vn4_post` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `content` longtext NOT NULL,
  `image` text NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `view` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish',
  `status_old` varchar(20) NOT NULL DEFAULT 'publish',
  `visibility` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `post_date_gmt` varchar(20) NOT NULL,
  `meta` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category` text NOT NULL,
  `tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_post`
--

INSERT INTO `vn4_post` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `updated_at`, `created_at`, `category`, `tag`) VALUES
(1, 'Cảnh rút tiền bi hài ở các ATM bị đập bỏ bậc tam cấp', 'canh-rut-tien-bi-hai-o-cac-atm-bi-dap-bo-bac-tam-cap', 'Bậc tam cấp lấn vỉa hè bị đập bỏ khiến nhiều ATM ở Hà Nội bỗng "lơ lửng" trên cao, khách hàng phải kiễng chân hoặc loay hoay trèo lên những chiếc bục tạm bợ.', '<p>Hơn 3 ngày sau khi cháu Lê Thị Nhật Linh (9 tuổi) bị sát hại ở Nhật, cảnh sát thành phố Abiko nhận định nạn nhân có thể bị xâm hại tình dục; người thân bé gái ở quê nhà Hải Phòng bàng hoàng. Họ vẫn chưa dám tin án mạng xảy ra với bé Linh là sự thật.</p><p>Trong căn nhà ở huyện ven ngoại thành TP Hải Phòng, bà Vũ Thị T. (bà ngoại bé gái) vẫn chưa thể gượng dậy từ ngày nhận tin dữ.</p><h3>"Dã man quá!"</h3><p>Nơi bé Linh sinh ra, gắn bó tuổi thơ với bà ngoại trước khi xảy ra án mạng, nằm cách trung tâm thành phố hoa phượng đỏ gần 20 km. Căn nhà 2 tầng lọt thỏm trong ngõ nhỏ, ở một huyện ngoại thành yên bình.</p><p>Thấy có người đến hỏi thăm bé Linh, bà T. gượng dậy. Đầu trùm khăn kín mít, người phụ nữ vén chăn nhìn ra phòng khách.</p><figure class="image"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490758886283" width="900" height="600" /><figcaption><span>ần 20 km. Căn nhà 2 tầng lọ</span></figcaption></figure><p><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490843477751" alt="" width="900" height="600" /> </p><p>Theo ông T. (ông ngoại bé gái), từ hôm hay tin dữ, vợ ông ngã quỵ. Nhiều hôm khóc cạn nước mắt, sức khỏe bà T. sa sút. Ông lão tỏ ra mệt mỏi, bàn tay run rẩy rót từng chén nước.</p><p>Thi thoảng, ông T. nhìn ra sân nhà, nơi trước đây bé gái vẫn thường vui đùa cùng ông bà ngoại khi cháu chưa sang Nhật.</p><p>Người thân chia sẻ, 2 hôm trước, bố cháu bé - anh Lê Anh H. - gọi điện về thông báo sau khi đến cảnh sát thành phố Abiko nhận dạng cháu Linh. Trưa 28/3, chị Nguyễn Thị N. (mẹ Linh) cũng đã bay trở lại Nhật Bản sau khi về Việt Nam một tuần trước đó.</p><p>Ngày 24/3, khi hay tin cháu Linh rời nhà đi học nhưng không đến trường, người thân ở Hải Phòng không dám nghĩ đến điều xấu xảy ra. Hai hôm sau, khi thi thể cô bé 9 tuổi được nhận diện, cả gia đình bà T. suy sụp.</p><p>Dáng lưng còng, bà T. lê từng bước chân từ phòng ngủ ra ngồi ở ghế phòng khách. “Cháu tôi không có tội tình gì, thế mà cháu bị giết dã man quá. Trước khi sang Nhật, cháu sống với tôi hơn 2 năm, vậy mà bây giờ…”, bà lão khóc nấc.</p><p>Cố nén nước mắt vào trong, bà T. bảo gia đình mong cơ quan chức năng 2 nước sớm tìm ra thủ phạm sát hại cháu bé.</p><p>Nhắc đến bé Linh, người thân cùng thôn nơi ông bà ngoại cháu sinh sống ai cũng xót xa. Anh Nam (hàng xóm, đã đổi tên) cho biết từ khi ra nước ngoài, vào dịp được nghỉ hè bé lại về chơi tại quê ngoại ở Hải Phòng.</p><p>[tag id="40" hello1="sdfsdf" hello2="sdfsdfds"]</p><p>“Bé gái xinh xắn, cao hơn những bạn đồng lứa trong thôn”, người này nhận xét sau lần gặp cháu Linh ở đợt nghỉ hè trước. Nhớ lại hôm đó, anh Nam bảo cháu bé tính vui vẻ, rất hòa đồng với bạn bè và người cùng thôn.</p><p>Theo một số láng giềng, hôm chị N. về đến nhà bố mẹ đẻ vào ngày 24/3, cũng là thời điểm người mẹ nhận tin dữ, con gái mất tích trên đường đến trường học ở Abiko, tỉnh Chiba.</p><p>Theo người thân, vợ chồng chị N. sang Nhật Bản lập nghiệp khoảng chục năm trước. Sau khi mua đất định cư, họ đón bé Linh sang sinh sống và đi học. Đôi vợ chồng có 2 người con.</p><table class="picture" align="center"><tbody><tr><td class="pic"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490773396903" alt="Ba ngoai be gai Viet bi giet o Nhat: ‘Sao nguoi ta lai hai chau toi’ hinh anh 2" width="900" height="600" /></td></tr><tr><td class="pCaption caption">Các nhà điều tra xem xét khu vực tìm thấy thi thể bé gái 9 tuổi ở Abiko, tỉnh Chiba, Nhật Bản. Ảnh: <em>Kyodo</em>.</td></tr></tbody></table><p>Khoảng 8h40 ngày 24/3, không thấy cháu Linh đến trường, giáo viên thông báo cho gia đình. Tìm kiếm xung quanh khu vực trường không thấy cháu, bố bé gái trình báo cảnh sát Abiko, Nhật Bản. Sáng sớm 26/3, thi thể cháu bé được tìm thấy cạnh bãi cỏ bên con sông tại thành phố Abiko, tỉnh Chiba, cách nhà bé khoảng 10 km.</p><p>Qua khám nghiệm, cảnh sát ước tính bé Linh có thể bị sát hại vào khoảng từ sáng 24/3 đến đêm 25/3. Không loại trừ khả năng em bị giết ngay sau khi bị bắt cóc, lúc đang trên đường tới trường vào thứ sáu tuần trước. Nguyên nhân gây tử vong của bé là do bị siết cổ. Cơ thể của nạn nhân có dấu hiệu bị xâm hại tình dục.</p><p> </p><p>Cái chết của bé Nhật Linh gây chấn động đối với người dân địa phương ở tỉnh Chiba và truyền thông Nhật Bản. Bộ Ngoại giao Việt Nam đã chỉ đạo đại sứ quán tại Nhật Bản khẩn trương làm việc với các cơ quan chức năng sở tại yêu cầu phía Nhật Bản xác định nguyên nhân tử vong, điều tra, truy bắt hung thủ và xét xử nghiêm theo đúng các quy định pháp luật.</p><p> </p>', '<div class="item-image-resutl"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490763374030" alt=""></div>', 23, 'post', '', 'publish', 'publish', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"Facebook title","plugin_vn4seo_facebook_description":"Facebook Description","plugin_vn4seo_facebook_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/post\\/chedo_1.jpg?1490725531498\\" alt=\\"\\"><\\/div>","p-lugin_vn4seo_twitter_title":null,"plugin_vn4seo_twitter_description":"Twitter Description","plugin_vn4seo_twitter_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/post\\/beautiful-wallpaper-download-13.jpg?1490725518786\\" alt=\\"\\"><\\/div>","plugin_vn4seo_twitter_title":"Twitter title"}', '2017-04-03 09:39:37', '2017-03-27 04:31:29', '[{"id":14,"title":"Cate 2","slug":"cate-2","description":"","content":"","type":"category","status":"publish","author":23,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 11:43:43","created_at":"2017-03-24 01:12:28","parent":"32","status_old":"publish","post_date_gmt":"","count_post":1},{"id":15,"title":"Cate 3","slug":"cate-3","description":"","content":"","type":"category","status":"publish","author":23,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 11:43:43","created_at":"2017-03-24 01:12:37","parent":"","status_old":"publish","post_date_gmt":"","count_post":1},{"id":32,"title":"Cate 1","slug":"cate-1","description":"","content":"","type":"category","status":"publish","author":23,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-26 01:46:16","parent":"","status_old":"publish","post_date_gmt":"","count_post":2},{"id":33,"title":"Cate 1 1","slug":"cate-1-1","description":"","content":"","type":"category","status":"publish","author":23,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 11:43:43","created_at":"2017-03-26 01:46:22","parent":"","status_old":"publish","post_date_gmt":"","count_post":1}]', '[{"id":45,"title":"tag 1","slug":"tag-1","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 16:39:37","created_at":"2017-04-03 11:37:37","parent":"","status_old":"publish","post_date_gmt":"","count_post":0},{"id":46,"title":"tag 2","slug":"tag-2","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 16:39:37","created_at":"2017-04-03 11:37:37","parent":"","status_old":"publish","post_date_gmt":"","count_post":0},{"id":40,"title":"The 1","slug":"the-1","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-30 01:20:26","parent":"","status_old":"publish","post_date_gmt":"","count_post":1}]'),
(7, 'Hơn 3 ngày sau khi cháu Lê Thị Nhật Linh (9 tuổi) bị sát hại ở Nhật', 'hon-3-ngay-sau-khi-chau-le-thi-nhat-linh-9-tuoi-bi-sat-hai-o-nhat', 'Hơn 3 ngày sau khi cháu Lê Thị Nhật Linh (9 tuổi) bị sát hại ở Nhật, cảnh sát thành phố Abiko nhận định nạn nhân có thể bị xâm hại tình dục; người thân bé gái ở quê nhà Hải Phòng bàng hoàng. Họ vẫn chưa dám tin án mạng xảy ra với bé Linh là sự thật.', '<p>Hơn 3 ngày sau khi cháu Lê Thị Nhật Linh (9 tuổi) bị sát hại ở Nhật, cảnh sát thành phố Abiko nhận định nạn nhân có thể bị xâm hại tình dục; người thân bé gái ở quê nhà Hải Phòng bàng hoàng. Họ vẫn chưa dám tin án mạng xảy ra với bé Linh là sự thật.</p><p>Trong căn nhà ở huyện ven ngoại thành TP Hải Phòng, bà Vũ Thị T. (bà ngoại bé gái) vẫn chưa thể gượng dậy từ ngày nhận tin dữ.</p><h3>"Dã man quá!"</h3><p>Nơi bé Linh sinh ra, gắn bó tuổi thơ với bà ngoại trước khi xảy ra án mạng, nằm cách trung tâm thành phố hoa phượng đỏ gần 20 km. Căn nhà 2 tầng lọt thỏm trong ngõ nhỏ, ở một huyện ngoại thành yên bình.</p><p>Thấy có người đến hỏi thăm bé Linh, bà T. gượng dậy. Đầu trùm khăn kín mít, người phụ nữ vén chăn nhìn ra phòng khách.</p><figure class="image"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490758886283" width="900" height="600" /><figcaption><span>gắn bó tuổi thơ v</span></figcaption></figure><p> </p><table class="picture" align="center"><tbody><tr style="height: 465.859px;"><td class="pic" style="height: 465.859px;"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490773390772" alt="Ba ngoai be gai Viet bi giet o Nhat: ‘Sao nguoi ta lai hai chau toi’ hinh anh 1" width="900" height="600" /></td></tr><tr style="height: 36px;"><td class="pCaption caption" style="height: 36px;">Căn nhà 2 tầng sau rặng cau, nơi bé Linh từng sống với ông bà ngoại ở Hải Phòng. Ảnh: <em>Hoàng Lam.</em></td></tr></tbody></table><p>Theo ông T. (ông ngoại bé gái), từ hôm hay tin dữ, vợ ông ngã quỵ. Nhiều hôm khóc cạn nước mắt, sức khỏe bà T. sa sút. Ông lão tỏ ra mệt mỏi, bàn tay run rẩy rót từng chén nước.</p><p>Thi thoảng, ông T. nhìn ra sân nhà, nơi trước đây bé gái vẫn thường vui đùa cùng ông bà ngoại khi cháu chưa sang Nhật.</p><p>Người thân chia sẻ, 2 hôm trước, bố cháu bé - anh Lê Anh H. - gọi điện về thông báo sau khi đến cảnh sát thành phố Abiko nhận dạng cháu Linh. Trưa 28/3, chị Nguyễn Thị N. (mẹ Linh) cũng đã bay trở lại Nhật Bản sau khi về Việt Nam một tuần trước đó.</p><p>Ngày 24/3, khi hay tin cháu Linh rời nhà đi học nhưng không đến trường, người thân ở Hải Phòng không dám nghĩ đến điều xấu xảy ra. Hai hôm sau, khi thi thể cô bé 9 tuổi được nhận diện, cả gia đình bà T. suy sụp.</p><p>Dáng lưng còng, bà T. lê từng bước chân từ phòng ngủ ra ngồi ở ghế phòng khách. “Cháu tôi không có tội tình gì, thế mà cháu bị giết dã man quá. Trước khi sang Nhật, cháu sống với tôi hơn 2 năm, vậy mà bây giờ…”, bà lão khóc nấc.</p><p>Cố nén nước mắt vào trong, bà T. bảo gia đình mong cơ quan chức năng 2 nước sớm tìm ra thủ phạm sát hại cháu bé.</p><p>Nhắc đến bé Linh, người thân cùng thôn nơi ông bà ngoại cháu sinh sống ai cũng xót xa. Anh Nam (hàng xóm, đã đổi tên) cho biết từ khi ra nước ngoài, vào dịp được nghỉ hè bé lại về chơi tại quê ngoại ở Hải Phòng.</p><p>“Bé gái xinh xắn, cao hơn những bạn đồng lứa trong thôn”, người này nhận xét sau lần gặp cháu Linh ở đợt nghỉ hè trước. Nhớ lại hôm đó, anh Nam bảo cháu bé tính vui vẻ, rất hòa đồng với bạn bè và người cùng thôn.</p><p>Theo một số láng giềng, hôm chị N. về đến nhà bố mẹ đẻ vào ngày 24/3, cũng là thời điểm người mẹ nhận tin dữ, con gái mất tích trên đường đến trường học ở Abiko, tỉnh Chiba.</p><p>Theo người thân, vợ chồng chị N. sang Nhật Bản lập nghiệp khoảng chục năm trước. Sau khi mua đất định cư, họ đón bé Linh sang sinh sống và đi học. Đôi vợ chồng có 2 người con.</p><table class="picture" align="center"><tbody><tr><td class="pic"><img src="../../public/uploads/post/tup-leu-rach-ben-canh-nha-trang-va-niem-tin-cua-nguoi-my-o-trump-21-082511.jpg?1490773396903" alt="Ba ngoai be gai Viet bi giet o Nhat: ‘Sao nguoi ta lai hai chau toi’ hinh anh 2" width="900" height="600" /></td></tr><tr><td class="pCaption caption">Các nhà điều tra xem xét khu vực tìm thấy thi thể bé gái 9 tuổi ở Abiko, tỉnh Chiba, Nhật Bản. Ảnh: <em>Kyodo</em>.</td></tr></tbody></table><p>Khoảng 8h40 ngày 24/3, không thấy cháu Linh đến trường, giáo viên thông báo cho gia đình. Tìm kiếm xung quanh khu vực trường không thấy cháu, bố bé gái trình báo cảnh sát Abiko, Nhật Bản. Sáng sớm 26/3, thi thể cháu bé được tìm thấy cạnh bãi cỏ bên con sông tại thành phố Abiko, tỉnh Chiba, cách nhà bé khoảng 10 km.</p><p>Qua khám nghiệm, cảnh sát ước tính bé Linh có thể bị sát hại vào khoảng từ sáng 24/3 đến đêm 25/3. Không loại trừ khả năng em bị giết ngay sau khi bị bắt cóc, lúc đang trên đường tới trường vào thứ sáu tuần trước. Nguyên nhân gây tử vong của bé là do bị siết cổ. Cơ thể của nạn nhân có dấu hiệu bị xâm hại tình dục.</p><p>Cái chết của bé Nhật Linh gây chấn động đối với người dân địa phương ở tỉnh Chiba và truyền thông Nhật Bản. Bộ Ngoại giao Việt Nam đã chỉ đạo đại sứ quán tại Nhật Bản khẩn trương làm việc với các cơ quan chức năng sở tại yêu cầu phía Nhật Bản xác định nguyên nhân tử vong, điều tra, truy bắt hung thủ và xét xử nghiêm theo đúng các quy định pháp luật.</p>', '<div class="item-image-resutl"><img src="../../public/uploads/post/beautiful-wallpaper-download-13.jpg?1491202723242" alt=""></div>', 23, 'post', '', 'publish', 'publish', 'publish', '', '', '{"plugin_vn4seo_focus_keyword":"","plugin_vn4seo_facebook_title":"H\\u01a1n 3 ng\\u00e0y sau khi ch\\u00e1u L\\u00ea Th\\u1ecb Nh\\u1eadt Linh (9 tu\\u1ed5i) b\\u1ecb s\\u00e1t h\\u1ea1i \\u1edf Nh\\u1eadt","plugin_vn4seo_facebook_description":"H\\u01a1n 3 ng\\u00e0y sau khi ch\\u00e1u L\\u00ea Th\\u1ecb Nh\\u1eadt Linh (9 tu\\u1ed5i) b\\u1ecb s\\u00e1t h\\u1ea1i \\u1edf Nh\\u1eadt, c\\u1ea3nh s\\u00e1t th\\u00e0nh ph\\u1ed1 Abiko nh\\u1eadn \\u0111\\u1ecbnh n\\u1ea1n nh\\u00e2n c\\u00f3 th\\u1ec3 b\\u1ecb x\\u00e2m h\\u1ea1i t\\u00ecnh d\\u1ee5c; ng\\u01b0\\u1eddi th\\u00e2n b\\u00e9 g\\u00e1i \\u1edf qu\\u00ea nh\\u00e0 H\\u1ea3i Ph\\u00f2ng b\\u00e0ng ho\\u00e0ng. H\\u1ecd v\\u1eabn ch\\u01b0a d\\u00e1m tin \\u00e1n m\\u1ea1ng x\\u1ea3y ra v\\u1edbi b\\u00e9 Linh l\\u00e0 s\\u1ef1 th\\u1eadt.","plugin_vn4seo_facebook_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/post\\/beautiful-wallpaper-download-13.jpg?1490811058309\\" alt=\\"\\"><\\/div>","plugin_vn4seo_twitter_title":"H\\u01a1n 3 ng\\u00e0y sau khi ch\\u00e1u L\\u00ea Th\\u1ecb Nh\\u1eadt Linh (9 tu\\u1ed5i) b\\u1ecb s\\u00e1t h\\u1ea1i \\u1edf Nh\\u1eadt","plugin_vn4seo_twitter_description":"H\\u01a1n 3 ng\\u00e0y sau khi ch\\u00e1u L\\u00ea Th\\u1ecb Nh\\u1eadt Linh (9 tu\\u1ed5i) b\\u1ecb s\\u00e1t h\\u1ea1i \\u1edf Nh\\u1eadt, c\\u1ea3nh s\\u00e1t th\\u00e0nh ph\\u1ed1 Abiko nh\\u1eadn \\u0111\\u1ecbnh n\\u1ea1n nh\\u00e2n c\\u00f3 th\\u1ec3 b\\u1ecb x\\u00e2m h\\u1ea1i t\\u00ecnh d\\u1ee5c; ng\\u01b0\\u1eddi th\\u00e2n b\\u00e9 g\\u00e1i \\u1edf qu\\u00ea nh\\u00e0 H\\u1ea3i Ph\\u00f2ng b\\u00e0ng ho\\u00e0ng. H\\u1ecd v\\u1eabn ch\\u01b0a d\\u00e1m tin \\u00e1n m\\u1ea1ng x\\u1ea3y ra v\\u1edbi b\\u00e9 Linh l\\u00e0 s\\u1ef1 th\\u1eadt.","plugin_vn4seo_twitter_image":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/..\\/public\\/uploads\\/post\\/bg-table.png?1490811067796\\" alt=\\"\\"><\\/div>"}', '2017-04-03 06:58:47', '2017-03-29 18:11:23', '[{"id":32,"title":"Cate 1","slug":"cate-1","description":"","content":"","type":"category","status":"publish","author":23,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 11:49:14","created_at":"2017-03-26 01:46:16","parent":"","status_old":"publish","post_date_gmt":"","count_post":2}]', '[{"id":40,"title":"The 1","slug":"the-1","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-30 01:20:26","parent":"","status_old":"publish","post_date_gmt":"","count_post":0},{"id":41,"title":"the 2","slug":"the-2","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-30 01:20:26","parent":"","status_old":"publish","post_date_gmt":"","count_post":0},{"id":42,"title":"the 3","slug":"the-3","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-30 01:20:26","parent":"","status_old":"publish","post_date_gmt":"","count_post":0},{"id":43,"title":"the 4","slug":"the-4","description":"","content":"","type":"tag","status":"publish","author":0,"view":0,"meta":"","password":"","visibility":"","updated_at":"2017-04-03 13:58:47","created_at":"2017-03-30 01:20:43","parent":"","status_old":"publish","post_date_gmt":"","count_post":0}]');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_post_category`
--

CREATE TABLE `vn4_post_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_post_category`
--

INSERT INTO `vn4_post_category` (`id`, `post_id`, `tag_id`, `type`, `updated_at`, `created_at`) VALUES
(254, 7, 32, 'category', '2017-04-03 06:58:47', '0000-00-00 00:00:00'),
(255, 1, 14, 'category', '2017-04-03 09:39:37', '0000-00-00 00:00:00'),
(256, 1, 15, 'category', '2017-04-03 09:39:37', '0000-00-00 00:00:00'),
(257, 1, 32, 'category', '2017-04-03 09:39:37', '0000-00-00 00:00:00'),
(258, 1, 33, 'category', '2017-04-03 09:39:37', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_post_tag`
--

CREATE TABLE `vn4_post_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_post_tag`
--

INSERT INTO `vn4_post_tag` (`id`, `post_id`, `tag_id`, `type`, `updated_at`, `created_at`) VALUES
(113, 7, 40, 'tag', '2017-04-03 06:58:47', '0000-00-00 00:00:00'),
(114, 7, 41, 'tag', '2017-04-03 06:58:47', '0000-00-00 00:00:00'),
(115, 7, 42, 'tag', '2017-04-03 06:58:47', '0000-00-00 00:00:00'),
(116, 7, 43, 'tag', '2017-04-03 06:58:47', '0000-00-00 00:00:00'),
(117, 1, 45, 'tag', '2017-04-03 09:39:37', '0000-00-00 00:00:00'),
(118, 1, 46, 'tag', '2017-04-03 09:39:37', '0000-00-00 00:00:00'),
(119, 1, 40, 'tag', '2017-04-03 09:39:37', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_post_tag_temp`
--

CREATE TABLE `vn4_post_tag_temp` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `option` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_post_tag_temp`
--

INSERT INTO `vn4_post_tag_temp` (`id`, `post_id`, `tag_id`, `type`, `option`, `updated_at`, `created_at`) VALUES
(287, 44, 58, 'tag', '', '2016-12-09 18:15:01', '0000-00-00 00:00:00'),
(304, 45, 55, 'tag', '', '2016-12-09 18:16:48', '0000-00-00 00:00:00'),
(305, 45, 56, 'tag', '', '2016-12-09 18:16:48', '0000-00-00 00:00:00'),
(306, 39, 35, 'category', '', '2016-12-09 18:20:05', '0000-00-00 00:00:00'),
(323, 46, 2, 'category', '', '2016-12-10 14:07:33', '0000-00-00 00:00:00'),
(324, 46, 3, 'category', '', '2016-12-10 14:07:33', '0000-00-00 00:00:00'),
(325, 46, 58, 'tag', '', '2016-12-10 14:07:33', '0000-00-00 00:00:00'),
(326, 46, 57, 'tag', '', '2016-12-10 14:07:33', '0000-00-00 00:00:00'),
(327, 46, 59, 'tag', '', '2016-12-10 14:07:33', '0000-00-00 00:00:00'),
(329, 42, 1, 'category', '', '2016-12-13 04:56:08', '0000-00-00 00:00:00'),
(800, 2, 3, 'category', '', '2017-01-04 10:04:28', '0000-00-00 00:00:00'),
(801, 2, 63, 'tag', '', '2017-01-04 10:04:28', '0000-00-00 00:00:00'),
(802, 2, 64, 'tag', '', '2017-01-04 10:04:28', '0000-00-00 00:00:00'),
(807, 3, 2, 'category', '', '2017-01-04 11:09:37', '0000-00-00 00:00:00'),
(808, 3, 65, 'tag', '', '2017-01-04 11:09:37', '0000-00-00 00:00:00'),
(809, 1, 3, 'category', '', '2017-01-04 11:09:57', '0000-00-00 00:00:00'),
(810, 1, 60, 'tag', '', '2017-01-04 11:09:58', '0000-00-00 00:00:00'),
(811, 1, 61, 'tag', '', '2017-01-04 11:09:58', '0000-00-00 00:00:00'),
(812, 1, 62, 'tag', '', '2017-01-04 11:09:58', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_setting`
--

CREATE TABLE `vn4_setting` (
  `id` int(10) UNSIGNED NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `meta` text NOT NULL,
  `type` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish',
  `group` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `key_word` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_setting`
--

INSERT INTO `vn4_setting` (`id`, `author`, `meta`, `type`, `status`, `group`, `content`, `key_word`, `updated_at`, `created_at`) VALUES
(14, 10, '{"appid":"1639513693020593"}', 'setting', 'publish', 'general', 'active', 'general_status', '2017-04-01 07:49:46', '2016-11-30 17:05:35'),
(16, 10, '', 'setting', 'publish', 'general', 'First website by Vn4CMS', 'general_site_title', '2017-02-13 16:03:17', '2016-11-30 17:05:35'),
(17, 10, '', 'setting', 'publish', 'general', '', 'general_logo', '2016-11-30 17:05:35', '2016-11-30 17:05:35'),
(18, 10, '', 'setting', 'publish', 'general', 'Một trang web đơn giản sử dụng Vn4CMS', 'general_description', '2017-02-13 17:23:59', '2016-11-30 17:05:35'),
(19, 10, '', 'setting', 'publish', 'general', 'dangthuyenquan@gmail.com', 'general_email_address', '2016-11-30 17:05:35', '2016-11-30 17:05:35'),
(20, 10, '', 'setting', 'publish', 'general', 'UTC+7', 'general_timezone', '2016-11-30 17:05:35', '2016-11-30 17:05:35'),
(21, 10, '', 'setting', 'publish', 'general', 'd/m/Y', 'general_date_format', '2017-01-30 18:48:24', '2016-11-30 17:05:35'),
(22, 10, '', 'setting', 'publish', 'general', 'H:i', 'general_time_format', '2016-12-27 17:41:39', '2016-11-30 17:05:35'),
(23, 10, '', 'setting', 'publish', 'general', 'vi', 'general_site_language', '2017-01-08 18:26:18', '2016-11-30 17:05:35'),
(26, 10, '', 'setting', 'publish', 'general', 'eleven', 'general_client_theme', '2017-04-03 04:55:11', '2016-11-30 17:07:05'),
(27, 10, '', 'setting', 'publish', 'security', 'admin2', 'security_prefix_link_admin', '2017-03-28 07:29:24', '2016-11-30 17:27:46'),
(28, 10, '', 'setting', 'publish', 'security', 'login2222', 'security_link_login', '2017-03-27 19:00:35', '2016-11-30 17:27:46'),
(29, 23, '', 'plugin', 'un_publish', '', '', 'maintenance', '2017-03-27 04:26:55', '2016-12-04 09:17:58'),
(30, 10, '', 'plugin', 'un_publish', '', '', 'add_meta_box_demo', '2017-01-29 14:39:50', '2016-12-06 18:45:29'),
(31, 23, '', 'plugin', 'un_publish', '', '', 'export_data_to_excel', '2017-03-27 04:26:50', '2016-12-10 18:11:42'),
(32, 10, '', 'plugin', 'un_publish', '', '', 'manual', '2017-02-06 03:42:18', '2016-12-12 03:58:56'),
(34, 0, '', 'setting', 'publish', '', '', 'general_logo_preview', '2016-12-27 17:37:24', '2016-12-27 17:37:24'),
(36, 0, '{"super-admin":{"title":"Super Admin","list_permission":"[\\"appearance_menu_client_create\\",\\"appearance_menu_client_edit\\",\\"appearance_menu_client_delete\\",\\"view_plugin_debug_error\\",\\"plugin_edit_debug_error\\",\\"post_list\\",\\"post_create\\",\\"post_edit\\",\\"post_trash\\",\\"post_delete\\",\\"post_restore\\",\\"post_detail\\",\\"category_list\\",\\"category_create\\",\\"category_edit\\",\\"category_trash\\",\\"category_delete\\",\\"category_restore\\",\\"category_detail\\",\\"tag_list\\",\\"tag_create\\",\\"tag_edit\\",\\"tag_trash\\",\\"tag_delete\\",\\"tag_restore\\",\\"tag_detail\\",\\"page_list\\",\\"page_create\\",\\"page_edit\\",\\"page_trash\\",\\"page_delete\\",\\"page_restore\\",\\"page_detail\\",\\"user_list\\",\\"user_create\\",\\"user_edit\\",\\"user_trash\\",\\"user_delete\\",\\"user_restore\\",\\"user_detail\\",\\"plugin_export_data_to_excel_list\\",\\"plugin_export_data_to_excel_create\\",\\"plugin_export_data_to_excel_edit\\",\\"plugin_export_data_to_excel_trash\\",\\"plugin_export_data_to_excel_delete\\",\\"plugin_export_data_to_excel_restore\\",\\"plugin_export_data_to_excel_detail\\",\\"appearance-menu_view\\",\\"appearance-theme_view\\",\\"appearance-widget_view\\",\\"index_view\\",\\"media_view\\",\\"plugin_view\\",\\"profile_view\\",\\"statistics_view\\",\\"tool-genaral_view\\",\\"user-role-editor_view\\",\\"view_setting\\",\\"change_setting_general\\",\\"change_setting_security\\",\\"plugin_action\\"]"},"editor":{"title":"Editor","list_permission":"[\\"appearance_menu_client_create\\",\\"category_create\\",\\"tag_create\\",\\"post_create\\",\\"page_create\\"]"},"customer":{"title":"Customer","list_permission":"[\\"category_list\\",\\"tag_list\\",\\"post_list\\",\\"page_list\\"]"},"nguoi-duyet-bai":{"title":"Ng\\u01b0\\u1eddi duy\\u1ec7t b\\u00e0i","list_permission":"[\\"appearance_menu_client_edit\\",\\"appearance_menu_client_delete\\",\\"category_list\\",\\"category_edit\\",\\"category_trash\\",\\"category_delete\\",\\"category_restore\\",\\"tag_list\\",\\"tag_edit\\",\\"tag_trash\\",\\"tag_delete\\",\\"tag_restore\\",\\"tag_detail\\",\\"post_list\\",\\"post_edit\\",\\"post_trash\\",\\"post_delete\\",\\"post_restore\\",\\"post_detail\\",\\"page_list\\",\\"page_edit\\",\\"page_trash\\",\\"page_delete\\",\\"page_restore\\",\\"page_detail\\",\\"user_trash\\"]"},"nguoi-quan-ly-giao-dien":{"title":"Ng\\u01b0\\u1eddi qu\\u1ea3n l\\u00fd giao di\\u1ec7n","list_permission":"[\\"appearance_menu_client_create\\",\\"appearance_menu_client_edit\\",\\"appearance_menu_client_delete\\",\\"appearance-menu_view\\",\\"appearance-theme_view\\",\\"appearance-widget_view\\"]"}}', 'option_permission', 'publish', '', '', 'list_role', '2017-01-04 07:37:52', '2016-12-29 09:01:38'),
(39, 10, '', 'plugin', 'publish', '', '', 'vn4seo', '2017-02-15 03:26:48', '2017-02-15 03:26:48'),
(40, 10, '{"general":{"_token":"cgpOzFwSerpycq7YR9lDlbOofKKrP78eHejO7h4o","debug_backend":"1","debug_frontend":"1","show_debug_message":"1123123","show_query_backend":"1","show_query_frontend":"1","show_query_message":"2"}}', 'plugin', 'publish', '', '', 'vn4debug', '2017-03-13 08:38:31', '2017-03-02 09:39:59'),
(41, 10, '{"general":{"_token":"MhNTWRxN9mZHXsiM0AKi0TRotEZNvFLoK4DCSXvF","debug_backend":"1","debug_frontend":"1","show_debug_message":"","show_query_backend":"1","show_query_frontend":"1","show_query_message":""}}', 'plugin', 'publish', '', '', 'debug_error', '2017-03-03 20:51:00', '2017-03-02 09:39:59'),
(47, 0, '', 'setting', 'publish', '', '{"en":"English"}', 'lang_default', '2017-03-12 18:52:37', '2017-03-12 18:52:09'),
(48, 0, '', 'setting', 'publish', '', '{"en":"English","vi":"Vietnamese"}', 'list_lang', '2017-04-03 04:00:23', '2017-03-12 18:52:09'),
(49, 23, '{"appid":"1639513693020593","app_secret":"49c830fd83cf17b437da0dc2237ce547"}', 'plugin', 'un_publish', '', '', 'vn4fanpage', '2017-04-03 08:33:38', '2017-03-13 03:25:01'),
(50, 23, '', 'plugin', 'publish', '', '', 'vn4subscribe', '2017-03-31 16:49:56', '2017-03-31 03:36:38'),
(51, 23, '', 'plugin', 'publish', '', '', 'vn4singlepost', '2017-03-31 16:19:57', '2017-03-31 16:19:57');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_subscribe`
--

CREATE TABLE `vn4_subscribe` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `status_old` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `visibility` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `post_date_gmt` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `meta` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vn4_subscribe`
--

INSERT INTO `vn4_subscribe` (`id`, `title`, `slug`, `description`, `content`, `image`, `author`, `type`, `view`, `status`, `status_old`, `visibility`, `password`, `post_date_gmt`, `meta`, `created_at`, `updated_at`) VALUES
(1, 'dangthuyenquan@gmail.com', 'dangthuyenquan@gmail.com_TGnrIMWFIsKnc3pPSjPoklkTaTyqz4IziN0TEuM1', '', '', '', 0, 'vn4plugin-subscribe', '', 'publish', '', '', '', '', '', '2017-03-31 14:31:39', '2017-03-31 14:31:39');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_tag`
--

CREATE TABLE `vn4_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `slug` text NOT NULL,
  `description` text NOT NULL,
  `content` longtext NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish',
  `author` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `view` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `meta` text NOT NULL,
  `password` varchar(60) NOT NULL,
  `visibility` varchar(20) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parent` text NOT NULL,
  `status_old` varchar(20) NOT NULL DEFAULT 'publish',
  `post_date_gmt` varchar(20) NOT NULL,
  `count_post` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_tag`
--

INSERT INTO `vn4_tag` (`id`, `title`, `slug`, `description`, `content`, `type`, `status`, `author`, `view`, `meta`, `password`, `visibility`, `updated_at`, `created_at`, `parent`, `status_old`, `post_date_gmt`, `count_post`) VALUES
(14, 'Cate 2', 'cate-2', '', '', 'category', 'publish', 23, 0, '', '', '', '2017-04-03 09:39:37', '2017-03-23 18:12:28', '32', 'publish', '', 1),
(15, 'Cate 3', 'cate-3', '', '', 'category', 'publish', 23, 0, '', '', '', '2017-04-03 09:39:37', '2017-03-23 18:12:37', '', 'publish', '', 1),
(32, 'Cate 1', 'cate-1', '', '', 'category', 'publish', 23, 0, '', '', '', '2017-04-03 09:39:37', '2017-03-25 18:46:16', '', 'publish', '', 2),
(33, 'Cate 1 1', 'cate-1-1', '', '', 'category', 'publish', 23, 0, '', '', '', '2017-04-03 09:39:37', '2017-03-25 18:46:22', '', 'publish', '', 1),
(40, 'The 1', 'the-1', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 09:39:37', '2017-03-29 18:20:26', '', 'publish', '', 2),
(41, 'the 2', 'the-2', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 06:58:47', '2017-03-29 18:20:26', '', 'publish', '', 1),
(42, 'the 3', 'the-3', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 06:58:47', '2017-03-29 18:20:26', '', 'publish', '', 1),
(43, 'the 4', 'the-4', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 06:58:47', '2017-03-29 18:20:43', '', 'publish', '', 1),
(44, 'the 5', 'the-5', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 04:37:26', '2017-03-29 18:20:43', '', 'publish', '', 1),
(45, 'tag 1', 'tag-1', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 09:39:37', '2017-04-03 04:37:37', '', 'publish', '', 1),
(46, 'tag 2', 'tag-2', '', '', 'tag', 'publish', 0, 0, '', '', '', '2017-04-03 09:39:37', '2017-04-03 04:37:37', '', 'publish', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vn4_user`
--

CREATE TABLE `vn4_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text NOT NULL,
  `slug` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `permission` longtext NOT NULL,
  `type` varchar(50) NOT NULL,
  `remember_token` varchar(60) NOT NULL,
  `status` varchar(20) NOT NULL,
  `status_old` varchar(20) NOT NULL,
  `meta` text NOT NULL,
  `post_date_gmt` varchar(20) NOT NULL,
  `visibility` varchar(50) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_user`
--

INSERT INTO `vn4_user` (`id`, `description`, `slug`, `email`, `password`, `first_name`, `last_name`, `permission`, `type`, `remember_token`, `status`, `status_old`, `meta`, `post_date_gmt`, `visibility`, `updated_at`, `created_at`) VALUES
(18, '', 'hoang-doan', 'hoang.doan@dna.vn', '$2y$10$fWjeKXzGOs.xEqiKKvyqFuY3YBITZ0KApM4AWYyQX1zJttSXkVsvi', 'Đoàn Lê Khánh', 'Hoàng 2', '', 'user', 'Bsmap353yq74IY7JafUATEtVRuY8BNu1yB03woU6R8ngGwYh0BAK5BbkGtpj', 'publish', 'trash', '{"seo_vn4_focus_keyword":"","seo_vn4_facebook_title":"","seo_vn4_facebook_description":"","seo_vn4_facebook_image":"            \\r\\n        ","seo_vn4_twitter_title":"","seo_vn4_twitter_description":"","seo_vn4_twitter_image":"            \\r\\n        "}', '', '', '2017-03-22 18:52:54', '2016-08-31 02:47:46'),
(19, '', 'bootstrap', 'bootstrapguru@ff.ff', '$2y$10$4OmZ/7JOBIY0hRCrXSNIHeEDCmxoHne40ArsF/ECFx2aA7mbiLR/.', 'A', 'B', 'appearance_menu_client_create, appearance_menu_client_edit, appearance_menu_client_delete, category_list, category_create, category_edit, category_trash, category_delete, category_restore, category_detail, tag_list, tag_create, tag_edit, tag_trash, tag_delete, tag_restore, tag_detail, post_list, post_create, post_edit, post_trash, post_delete, post_restore, post_detail, page_list, page_create, page_edit, page_trash, page_delete, page_restore, page_detail, user_list, user_create, user_edit, user_trash, user_delete, user_restore, user_detail, plugin_export_data_to_excel_list, plugin_export_data_to_excel_create, plugin_export_data_to_excel_edit, plugin_export_data_to_excel_trash, plugin_export_data_to_excel_delete, plugin_export_data_to_excel_restore, plugin_export_data_to_excel_detail, appearance-menu_view, appearance-theme_view, appearance-widget_view, index_view, media_view, plugin_view, profile_view, statistics_view, tool-genaral_view, user-role-editor_view, view_setting, change_setting_general, change_setting_security, plugin_action', 'user', 'sR046MJPrt7IsSXahWrahBkFqLKraoDFG4Pxg5RutfWltEvkJ7ResBxxmQbV', 'publish', 'trash', '', '', '', '2017-03-22 07:41:11', '2017-01-03 08:27:04'),
(20, '', '545', 'admin@admin.com', '$2y$10$DBehFBGk1QC8cSetyklEaON7ZJPjALdC9YZdMDYOI1qs2eFW4lNES', '123', '545', '', 'user', '', 'publish', 'trash', '', '', '', '2017-03-22 07:41:11', '2017-02-24 09:29:26'),
(21, '', 'quang', 'quang.nguyen@dna.vn', '$2y$10$iUuI1C/qocRC.uIkZrsz9Om8JDnD3LxrhYSXkHckSxv3Iqn5DDbsO', 'Nguyen', 'Quang', 'appearance_menu_client_edit, appearance_menu_client_delete, page_list, page_create, page_edit, page_trash, page_delete, page_restore, page_detail, lang_list, lang_create, lang_edit, lang_trash, lang_delete, lang_restore, lang_detail, user_list, user_create, user_edit, user_trash, user_delete, user_restore, user_detail, plugin_export_data_to_excel_list, plugin_export_data_to_excel_create, plugin_export_data_to_excel_edit, plugin_export_data_to_excel_trash, plugin_export_data_to_excel_delete, plugin_export_data_to_excel_restore, plugin_export_data_to_excel_detail, appearance-menu_view, appearance-theme_view, appearance-widget_view, media_view, plugin_view, profile_view, statistics_view, tool-genaral_view, translate_view, user-role-editor_view, view_setting, change_setting_general, change_setting_security, plugin_action', 'user', 'DzDUD5PSBfcpa3NdCvpTTGC2GyCxUfGidQXclFhjMPoZqx4t3EyxuV2tkqNs', 'publish', 'trash', '', '', '', '2017-03-22 07:41:11', '2017-02-27 08:44:41'),
(23, '', 'quan', 'dangthuyenquan@gmail.com', '$2y$10$gtxtDZhrzQyXZHC3AuMwPO76JnBVv2AcGPueK1id.jQmQxkIeebR2', 'Đặng Thuyền', 'Quân', 'appearance_menu_client_edit, appearance_menu_client_delete, view_plugin_debug_error, category_list, category_create, category_edit, category_trash, category_delete, category_restore, category_detail, post_list, post_create, post_edit, post_trash, post_delete, post_restore, post_detail, tag_list, tag_create, tag_edit, tag_trash, tag_delete, tag_restore, tag_detail, comment_list, comment_create, comment_edit, comment_trash, comment_delete, comment_restore, comment_detail, page_list, page_create, page_edit, page_trash, page_delete, page_restore, page_detail, vn4plugin-subscribe_list, vn4plugin-subscribe_create, vn4plugin-subscribe_edit, vn4plugin-subscribe_trash, vn4plugin-subscribe_delete, vn4plugin-subscribe_restore, vn4plugin-subscribe_detail, user_list, user_create, user_edit, user_trash, user_delete, user_restore, user_detail, appearance-menu_view, appearance-theme_view, appearance-widget_view, language_view, media_view, plugin_view, profile_view, tool-genaral_view, user-new_view, user-role-editor_view, view_setting, change_setting_general, change_setting_security, plugin_action', 'user', '91piepjwyDJP94HZ3VNDEEAX4paeBzH0VeUprBEbgWozWfxogvyG9Xv7GprX', 'publish', 'publish', '{"number_phone":"1","url_social_network":"sdfsdfsd","description":"123123","profile_picture":"<div class=\\"item-image-resutl\\"><img src=\\"..\\/public\\/uploads\\/admin\\/user\\/12243232_697152930418853_7640659803889844973_n.jpg?1490181163169\\" alt=\\"\\"><\\/div>","active_show_toolbar":"","lang":"vi"}', '', '', '2017-04-03 10:06:05', '2017-03-22 07:42:25');

-- --------------------------------------------------------

--
-- Table structure for table `vn4_widget`
--

CREATE TABLE `vn4_widget` (
  `id` int(10) UNSIGNED NOT NULL,
  `sidebar_id` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'publish',
  `meta` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vn4_widget`
--

INSERT INTO `vn4_widget` (`id`, `sidebar_id`, `content`, `status`, `meta`, `updated_at`, `created_at`) VALUES
(1, 'sidebar-left', '{"title":"Widget Left","id":"sidebar-left","description":"Khu v\\u1ef1c widget b\\u00ean tr\\u00e1i trang","before_widget":"<aside id=\\"%1$s\\" class=\\"widget %2$s\\">","after_widget":"<\\/aside>","before_title":"<h2 class=\\"widget-title\\">","after_title":"<\\/h2>"}', 'publish', '[{"__class_name":"Widget_Search","title":"title Search"},{"__class_name":"Widget_Text","title":"Hello widget","text":"Html \\u0111\\u01b0\\u1ee3c t\\u1ea1o b\\u1eb1ng widget text<img src=\\"http:\\/\\/s1.picswalls.com\\/wallpapers\\/2015\\/12\\/12\\/awesome-beautiful-wallpaper_124413582_294.jpg\\" alt=\\"Smiley face\\" style=\\" width: 100%; height: auto;\\">"}]', '2017-02-08 04:04:27', '2016-12-17 20:20:53'),
(2, 'sidebar-right', '{"title":"Widget right","id":"sidebar-right","description":"Khu v\\u1ef1c widget ph\\u1ea3i","before_widget":"<div class=\\"well\\">","after_widget":"<\\/div>"}', 'publish', '[{"__class_name":"Widget_Search","title":"Blog Search"},{"__class_name":"Widget_Button_Share_Social","title":"Chia s\\u1ebb l\\u00ean m\\u1ea1ng x\\u00e3 h\\u1ed9i"}]', '2017-02-15 06:48:28', '2016-12-17 20:37:13'),
(3, 'sidebar-footer', '{"title":"Sidebar Footer","id":"sidebar-footer","description":"Sidebar on the Footer","before_widget":"<div class=\\"col-md-4 footer1_of_3\\">","after_widget":"<\\/div>"}', 'publish', '[{"__class_name":"Widget_Vn4_About","logan":"Content management system simple but full and flexible","phone":"(+84) 949 816 596","email":"dangthuyenquan@gmail.com"},{"__class_name":"Widget_Text","title":"V\\u1ec1 ch\\u00fang t\\u00f4i","text":"Etiam porta sem malesuada magna mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur."}]', '2017-04-01 04:55:27', '2016-12-17 20:38:15'),
(4, 'sidebar-not-uses', '', 'publish', '[{"__class_name":"Widget_Facebook_Fanpage","link_fanpage":"https:\\/\\/www.facebook.com\\/League-Montage-1717881081760545\\/"},{"__class_name":"Widget_Facebook_Fanpage","link_fanpage":"https:\\/\\/www.facebook.com\\/Vn4CMS-1824709764412586\\/"}]', '2017-03-31 05:13:10', '2016-12-21 08:54:31'),
(5, 'sidebar-page-blog', '{"title":"Sidebar Page Blog","id":"sidebar-page-blog","description":"N\\u1ed9i dung sidebar g\\u00f3c ph\\u1ea3i c\\u1ee7a trang blog","before_widget":"<div class=\\"sidebar-blog-item\\">","after_widget":"<\\/div>"}', 'publish', '[{"__class_name":"Vn4SinglePost_Widget","count":"50","post_type":"tag"},{"__class_name":"Vn4Subscribe_Widget"}]', '2017-04-01 07:51:37', '2017-03-31 05:13:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vn4_code_reference_function`
--
ALTER TABLE `vn4_code_reference_function`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_code_reference_function_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_comment`
--
ALTER TABLE `vn4_comment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_comment_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_fanpage`
--
ALTER TABLE `vn4_fanpage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_fanpage_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_fanpage-photo`
--
ALTER TABLE `vn4_fanpage-photo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_fanpage_photo_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_fanpage-post`
--
ALTER TABLE `vn4_fanpage-post`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_fanpage_post_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_fanpage-video`
--
ALTER TABLE `vn4_fanpage-video`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_fanpage_video_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_menu`
--
ALTER TABLE `vn4_menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_menu_unique` (`key_word`,`theme`);

--
-- Indexes for table `vn4_page`
--
ALTER TABLE `vn4_page`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`,`type`);

--
-- Indexes for table `vn4_post`
--
ALTER TABLE `vn4_post`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`,`type`);

--
-- Indexes for table `vn4_post_category`
--
ALTER TABLE `vn4_post_category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_post_tag_unique` (`post_id`,`tag_id`);

--
-- Indexes for table `vn4_post_tag`
--
ALTER TABLE `vn4_post_tag`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_post_tag_unique` (`post_id`,`tag_id`);

--
-- Indexes for table `vn4_post_tag_temp`
--
ALTER TABLE `vn4_post_tag_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vn4_setting`
--
ALTER TABLE `vn4_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vn4_subscribe`
--
ALTER TABLE `vn4_subscribe`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vn4_subscribe_slug_type_unique` (`slug`,`type`);

--
-- Indexes for table `vn4_tag`
--
ALTER TABLE `vn4_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vn4_user`
--
ALTER TABLE `vn4_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`,`type`);

--
-- Indexes for table `vn4_widget`
--
ALTER TABLE `vn4_widget`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sidebar_id` (`sidebar_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vn4_code_reference_function`
--
ALTER TABLE `vn4_code_reference_function`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `vn4_comment`
--
ALTER TABLE `vn4_comment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `vn4_fanpage`
--
ALTER TABLE `vn4_fanpage`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;
--
-- AUTO_INCREMENT for table `vn4_fanpage-photo`
--
ALTER TABLE `vn4_fanpage-photo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `vn4_fanpage-post`
--
ALTER TABLE `vn4_fanpage-post`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;
--
-- AUTO_INCREMENT for table `vn4_fanpage-video`
--
ALTER TABLE `vn4_fanpage-video`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `vn4_menu`
--
ALTER TABLE `vn4_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `vn4_page`
--
ALTER TABLE `vn4_page`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vn4_post`
--
ALTER TABLE `vn4_post`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `vn4_post_category`
--
ALTER TABLE `vn4_post_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;
--
-- AUTO_INCREMENT for table `vn4_post_tag`
--
ALTER TABLE `vn4_post_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
--
-- AUTO_INCREMENT for table `vn4_post_tag_temp`
--
ALTER TABLE `vn4_post_tag_temp`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=813;
--
-- AUTO_INCREMENT for table `vn4_setting`
--
ALTER TABLE `vn4_setting`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `vn4_subscribe`
--
ALTER TABLE `vn4_subscribe`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vn4_tag`
--
ALTER TABLE `vn4_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `vn4_user`
--
ALTER TABLE `vn4_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `vn4_widget`
--
ALTER TABLE `vn4_widget`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
