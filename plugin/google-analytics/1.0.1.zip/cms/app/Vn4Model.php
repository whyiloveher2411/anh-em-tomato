<?php namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;
use File;
use DB;

class Vn4Model extends Model{

    private static $table_static = 'table_name';
    private static $arg = [];

    public function __construct( $tablename = null ){

        if(!$tablename){
            $this->table = self::$table_static;
        }else{
            $this->table = $tablename;
        }


    }

    public function save(array $options = array()){

        if($this->getTableName() == 'table_name' || !$this->getTableName() ){
            if( $this->type === 'plugin'){
                $this->setTable(vn4_tbpf().'setting');
            }else{
                $this->setTable(get_admin_object($this->type)['table']);
            }
        }

        return parent::save($options);

    }

    public function delete(array $options = array()){

        if($this->getTableName() == 'table_name' || !$this->getTableName() ){
            if( $this->type === 'plugin'){
                $this->setTable(vn4_tbpf().'setting');
            }else{
                $this->setTable(get_admin_object($this->type)['table']);
            }
        }

        return parent::delete($options);

    }

    public static function firstOrAddnew( $table, array $attributes  ){

        $instance = new Vn4Model($table);

        $instance = $instance->where($attributes)->first();

        if ( is_null($instance) ){

            $instance = new Vn4Model($table);

            foreach ($attributes as $key => $value) {
                $instance->{$key} = $value;
            }

        }

        $instance->setTable($table);

        return $instance;

    }

    // public static function newOrEdit($type, $input, $param_find, $taxonomy, $r){

    //     $param_find['type'] = $type;

    //     $admin_object = get_admin_object($type);
    //     dd($param_find);
    //     $post = Vn4Model::firstOrAddnew($admin_object['table'],$param_find);

    //     if( $post->exists ){
    //         vn4_create_session_message( __('Sucess'), __('Update post success'), 'success' , true);
    //     }else{
    //         vn4_create_session_message( __('Sucess'), trans('Create post success'), 'success' , true );
    //     }

    //     $post->fillDynamic($input);

    //     apply_function('before_save_post',$post->id, $input);

    //     $save = $post->save();

    //     if( !$save ){
    //         vn4_create_session_message( __('Error'), trans('Can not save object'), 'error' , true );
    //     }

    //     apply_function('after_save_post','',$post, $r );

    //     if ( is_array($taxonomy) && $post){

    //         vn4_create_taxonomy( $taxonomy , $post);

    //     } 

    //     apply_function('saved_post','',$admin_object,$post, $r );

    //     return $save;

    // }

    public static function newOrEdit($type, $param_find, $input, $taxonomy = null , $r = null){

        return DB::transaction(function () use ($type, $param_find, $input, $taxonomy, $r) {

            $param_find['type'] = $type;

            $admin_object = get_admin_object($type);

            $post = Vn4Model::firstOrAddnew($admin_object['table'],$param_find);

            if( $post->exists ){
                $action = 'edit';
                $post->status_old = $post->status;

            }else{
                $action = 'new';
            }

            if( !isset($input['status']) ){
                $input['status'] = 'publish';
            }   
            // dd($input);
            $post->fillDynamic($input);

            if( !$post->status_old ){
                $post->status_old = $post->status;
            }

            do_action('before_save_post',$post, $input);

            $save = $post->save();

            if( !$save && is_callable('vn4_create_session_message') ){
                vn4_create_session_message( __('Error'), __('Can not save object'), 'error' , true );
            }

            if ( is_array($taxonomy) && $post){

                vn4_create_taxonomy( $taxonomy , $post);

            } 

            do_action('saved_post',$post, $r);

            if( $action === 'edit' && is_callable('vn4_create_session_message') ){
                vn4_create_session_message( __('Sucess'), __('Update post success'), 'success' , true);
            }elseif(  is_callable('vn4_create_session_message') ){
                vn4_create_session_message( __('Sucess'), __('Create post success'), 'success' , true );
            }

            return $post;
        });

    }

    public static function objectSlug($table,$slug, $callback = null ){

        $instance = new Vn4Model($table);

        $instance = $instance->where('slug',$slug);

        if( $callback ){
            $instance = call_user_func_array($callback,[$instance]);
        }

        return $instance->first();

    }

    public static function f($post_type , $id,  $columns = array('*')){
        
        $admin_object = get_admin_object($post_type);
        
        if( !$admin_object ){
            return null;
        }

        $instance = new Vn4Model($admin_object['table']);

        if (is_array($id) && empty($id)) return $instance->newCollection();

        return $instance->newQuery()->find($id, $columns);
    }

    public function setTable($table){
        $this->table = $table;

        return $this;
    }
    
    public function getTableName(){
        return $this->table;
    }

    public function updateMeta( $key , $value = null){

        $meta = json_decode($this->meta,true); 

        if( !is_array($meta) ){
            $meta = [];
        }


        if( is_array($key) ){

            $meta = array_merge ($meta, $key);

        }elseif(is_string($key) && $value !== null){

            if ( is_array($value) ){
                $meta[$key] = json_encode($value);
            }else{
                $meta[$key] = $value;
            }

        }


        $this->meta = json_encode($meta);

        $this->save();

        return $this;

    }

    public function is_trash(){
        return $this->status === 'trash';
    }

    public static function autofill($type, array $input){
        $admin_object = get_admin_object($type);

        if( $admin_object ){ 
            
            $object = new Vn4Model($admin_object['table']);

            foreach ($admin_object['fields'] as $key => $field) {
                
                if( isset($input[$key]) ){
                    $object->{$key} = $input[$key];
                }

            }

            $object->type = $type;

            return $object;

        }

        return null;

    }

    public function fillDynamic(array $input){

        $arg = [];

        foreach($input as $key=>$value){

            if( is_string($input[$key])){
                $input[$key] = trim($input[$key]);
            }

            if( is_array($input[$key]) ){
                $input[$key] = json_encode($input[$key]);
            }

            array_push($arg, $key);
        }

        $input['author'] = -1;
        array_push($arg, 'author');

        if(!isset($input['status'])){

            array_push($arg, 'status');
            $input['status'] = 'publish';

        }

        if( Auth::id() ){
            $input['author'] = Auth::id();
        }

        $this->fillable = $arg;
        parent::fill($input);
    }

 


    // public function one( $post_type,$arg = null ){

    //     $admin_object = get_admin_object($post_type);

    //     self::$table_static = $admin_object['table'];

    //     $forence_key = $post_type.'_id';

    //     if(isset($arg['forence_key'])){
    //         $forence_key = $arg['forence_key'];
    //     }

    //     return $this->hasOne('Vn4Model' ,$forence_key, 'id')->first();
    // }

    public function get_many( $post_type, $param = null, $forence_key_change = null ){ 

        $admin_object = get_admin_object($post_type);

        self::$table_static = $admin_object['table'];

        $forence_key = $this->type.'_id';

        if( is_string($param) ){
            $forence_key = $param;
        }elseif( is_callable($param) ){
            $callback = $param;
        }

        if( is_string($forence_key_change) ){
            $forence_key = $forence_key_change;
        }

        $result =  $this->hasMany('Vn4Model', $forence_key , 'id');

        if( isset($callback) ){

            $result = call_user_func_array ($callback, [$result] );

        }


        return $result->get();

    }

    public function get_belongs( $post_type, $param = null, $forence_key_change = null ){

        $admin_object = get_admin_object($post_type);

        self::$table_static = $admin_object['table'];

        if( $post_type === 'user' ){
            $forence_key = 'author';
        }else{
            $forence_key = $post_type.'_id';
        }

        if( is_string($param) ){
            $forence_key = $param;
        }elseif( is_callable($param) ){
            $callback = $param;
        }

        if( is_string($forence_key_change) ){
            $forence_key = $forence_key_change;
        }

        $result =  $this->belongsTo('Vn4Model',$forence_key, 'id');

        if( isset($callback) ){

            $result = call_user_func_array ($callback, [$result] );

        }

        return $result->first();
    }

    public function get_manys( $post_type, $callback = null ){

        $admin_object = get_admin_object($post_type);

        self::$table_static = $admin_object['table'];

        $result = $this->belongsToMany('Vn4Model', 'vn4_'.$this->type.'_'.$post_type, 'post_id',  'tag_id');

        if( is_callable($callback) ){
           $result = call_user_func_array ($callback, [$result] );
        }

        return $result->get();
    }

    public function get_manys_belongs( $post_type, $callback = null ){
        
        $admin_object = get_admin_object($post_type);

        self::$table_static = $admin_object['table'];

        $result = $this->belongsToMany('Vn4Model', 'vn4_'.$post_type.'_'.$this->type,  'tag_id', 'post_id');

        if( is_callable($callback) ){
           $result = call_user_func_array ($callback, [$result] );
        }

        return $result->get();
    }

    public function original($name = null){

        if($name == null){
            return $this->getOriginal();
        }

        if(isset($this->getOriginal()[$name]))
            return $this->getOriginal()[$name];

        return null;
    }

}
