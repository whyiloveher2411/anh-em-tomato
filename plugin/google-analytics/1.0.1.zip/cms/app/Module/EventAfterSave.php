<?php namespace App\Module;
use Mail;
use App\ModelParent;
class EventAfterSave{

    /**
     * Overwrite any vendor / package configuration.
     *
     * This service provider is intended to provide a convenient location for you
     * to overwrite any "vendor" or package configuration that you may want to
     * modify before the application handles the incoming request / command.
     *
     * @return void
     */
    public function sendEmailConfirmRecruitment($recruitment)
    {

        $obj = new ModelParent();
        $obj->setTable('template_email');
        $template1 = $obj->where('type','template_email')->where('key_word','nguoi-ung-tuyen')->whereStatus(1)->first();
        $template2 = $obj->where('type','template_email')->where('key_word','nguoi-quan-ly-cua-tinh-thanh-ung-tuyen')->whereStatus(1)->first();

        $obj->setTable('recruitment');
        if($recruitment->type == 'recruitment_yakult_ladies'){
            $job = $obj->where('id',24)->first();
            $country = $obj->where('id',$recruitment->country)->first();
        }else{
             $job = $obj->where('id',$recruitment->job)->first();
             $country = $obj->where('id',$job->location)->first();
        }

        $listKeyvalue = array_merge($this->prefixKeyArray($job->getAttributes(),'work'),$this->prefixKeyArray($recruitment->getAttributes(),'people_apply'),$this->prefixKeyArray($country->getAttributes(),'country'));


        $content1 = str_replace(array_keys($listKeyvalue ), array_values($listKeyvalue ), $template1->content);
        $content2 = str_replace(array_keys($listKeyvalue ), array_values($listKeyvalue ), $template2->content);

        $this->sendEmail($content1, 'hoang.doan@dna.vn',$recruitment->email,$recruitment->name,'Thông tin ứng tuyển.');
        $this->sendEmail($content2, 'hoang.doan@dna.vn',$country->mail_send,'Country Admin','Thông báo ứng tuyển.','whyiloveher2411@gmail.com');
         
    }

    public function sendEmail($content, $from, $to, $name, $subject, $cc = null){

        Mail::send('emails.dynamic', ['content'=>$content], function($message) use ($from, $to, $name, $subject, $cc)
          {
            $message->from($from);
            if($cc != null){
                $message->cc($cc);
            }
            $message->to($to, $name)->subject($subject);
          });
    }

    private function prefixKeyArray($list, $strFrefix, $special_characters = '##'){
        $result = [];

        foreach ($list as $key => $value) {
            $result[$special_characters.$strFrefix.'.'.$key.$special_characters] = $value;
        }

        return $result;
    }

}
