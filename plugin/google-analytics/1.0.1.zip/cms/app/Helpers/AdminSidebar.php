<?php

namespace App\Helpers;

class AdminSidebar
{
    public static $sidebar = [];
}


