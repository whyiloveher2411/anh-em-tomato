<?php namespace App\Exceptions;

use Exception;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;

class Handler extends ExceptionHandler {

	/**
	 * A list of the exception types that should not be reported.
	 *
	 * @var array
	 */
	protected $dontReport = [
		'Symfony\Component\HttpKernel\Exception\HttpException'
	];

	/**
	 * Report or log an exception.
	 *
	 * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
	 *
	 * @param  \Exception  $e
	 * @return void
	 */
	public function report(Exception $e)
	{
		return parent::report($e);
	}

	/**
	 * Render an exception into an HTTP response.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Exception  $e
	 * @return \Illuminate\Http\Response
	 */
	public function render($request, Exception $e)
	{	
		
		// if (method_exists('getStatusCode', $e) ) {

		// 	$view = 'theme.'.theme_name().'.'.$e->getStatusCode();

		// 	if( view()->exists( $view ) ) {

		// 		return view( $view, [], $e->getStatusCode() );

		// 	}
		// }

		// return $e->getStatusCode();
		// include __DIR__.'/../../cms/core/core_function.php';
		
  //       $value = apply_function('handler_error',false,$request ,$e);

  //       if( $value ){
  //       	return $value;
  //       }

    	return parent::render($request, $e);

	}

}
