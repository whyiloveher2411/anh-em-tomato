<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Vn4Model;
use DB;
use Auth;


class SettingController extends ViewAdminController {

    public function setting(Request $r){

        include 'cms/object_cms/setting.php';

        // if(!isset($setting[$type])){
        //     die('Không tồn tại cấu hình: '.$type);
        // }

        if(!check_permission('view_setting')){
            die('Bạn không có quyền xem cấu hình');
        }

        // if(!check_permission('change_setting_'.$type)){
        //     die('Bạn không có quyền thay đổi Setting: '.$setting[$type]['title']);
        // }

        if($r->isMethod('GET')){

            return vn4_view('admin.setting');
        }

        if($r->isMethod('POST')){

          $input = $r->except('_token');


          $linkAdminNew = $input['security_prefix_link_admin'];
          if( $linkAdminNew === '') $linkAdminNew = 'admin';
          $linkAdminOld = setting('security_prefix_link_admin','admin');

          foreach ($input as $key => $value) {

            setting_save($key, $value);
           
          }

          vn4_create_session_message( __('Success'), __('Update setting successful.'), 'success' , true);

          return redirect(str_replace($linkAdminOld, $linkAdminNew, route('admin.setting')));
        }

    }
}




