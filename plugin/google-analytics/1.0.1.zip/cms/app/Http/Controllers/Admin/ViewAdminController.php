<?php namespace App\Http\Controllers\Admin;

use Illuminate\Routing\Controller as BaseController;

use AdminSidebar;

use Illuminate\Http\Request;

use View;
use Route;
use File;
use Hash;

use Vn4Model;
use DB;



class ViewAdminController extends BaseController {

	protected $object;

	protected $setting;

	public function __construct(){

		$this->object =  (object) get_admin_object();

		View::share ( 'admin_object', $this->object);

	}

	protected function checkPermission(Request $r,$type){

		$routeAray = ['admin.create_and_show_data','admin.create_data','admin.show_data'];

		$post = $r->get('post',false);
		$action = $r->get('action_post',false);

		$routeName = Route::currentRouteName();

		if(!isset($this->object->$type) && array_search($routeName, $routeAray) !== false){
			dd('Không tồn tại Tag type: '.$type);
		}

		if(!check_permission($type.'_delete') && $post && $action == 'delete' && array_search($routeName, $routeAray) !== false){

			vn4_create_session_message( __('Warning'), __('You are not allowed to remove').' '.__($this->object->{$type}['title']), 'warning' , true);

			return redirect()->back();

		}

		if(!check_permission($type.'_detail') && $post && $action == 'detail' && array_search($routeName, $routeAray) !== false){

			vn4_create_session_message( __('Warning'), __('You are not allowed view').' '.__($this->object->{$type}['title']), 'warning' , true);

			return redirect()->back();

		}

		if(!check_permission($type.'_edit') && $post && $action == 'edit' && array_search($routeName, $routeAray) !== false){

			vn4_create_session_message( __('Warning'), __('You are not allowed edit').' '.__($this->object->{$type}['title']), 'warning' , true);

			return redirect()->back();
		}
		
		if(!check_permission($type.'_create') && $routeName != 'admin.show_data' && !$post){

			vn4_create_session_message( __('Warning'), __('You are not allowed create').' '.__($this->object->{$type}['title']), 'warning' , true);

			return redirect()->back();

		}

		if($routeName != 'admin.create_data' && array_search($routeName, $routeAray) !== false){
			if(!check_permission($type.'_list')){

				vn4_create_session_message( __('Warning'), __('You are not allowed watch list').' '.__($this->object->{$type}['title']), 'warning' , true);

				return redirect()->back();

			}
		}

		return apply_function('after_check_permission',true,$r,$type,$routeName);

	}

	private static function changeDataInput( $input, $fields, $table, $type, &$taxonomy ){

        $fields['status'] = true;

        foreach ($fields as $key => $value) {

    		if( is_array($value) && !isset($value['view']) ) $value['view'] = 'input';

    		if( !is_callable($value['view']) ){

    			if( isset( $input [ $key ] ) && is_string( $input [ $key ] ) ){

	                $input[ $key ] = trim($input[ $key ]);

	            }

	            if(  File::exists('resources/views/admin/particle/input_field/'.$value['view'].'/post.php') ){

	                include 'resources/views/admin/particle/input_field/'.$value['view'].'/post.php';

	            }
    		}else{
    			$post = call_user_func($value['view']);

    			if( isset($post['post']) ){
    				$input[ $key ] = call_user_func_array($post['post'], [$input[$key]] );
    			}
    		}
            

        }

        if( isset($input['password']) ){
            if( $input['password'] ){
                $input['password'] = Hash::make($input['password']);
            }else{
                unset($input['password']);
            }
        }

        $input = apply_filter('change_data_'.$type,$input,false);

        return $input;
        
    }

	private function validate_input($r, $type){

		use_module(['post']);
    
        $action_post = $r->get('action_post','default');

        $admin_object = get_admin_object($type);

        $tags = new Vn4Model( $admin_object['table']);

        $input = $r->all();

        $fields = $admin_object['fields'];

        $taxonomy = null;

        $input = self::changeDataInput($input, $fields ,$admin_object['table'],$type, $taxonomy);

        $input = vn4_unset_input_not_belong_post( $admin_object, $input, $type );

        $input['type'] = $type;

		return ['input'=>$input,'taxonomy'=>$taxonomy];	


	}

	protected function post_add_or_update_post_admin( Request $r, $type ){

		$validate = $this->validate_input($r, $type);

        $post_id = $r->get('post',false);

		$result = Vn4Model::newOrEdit( $type, ['id'=>$post_id], $validate['input'], $validate['taxonomy'], $r );

		$routeName =  Route::currentRouteName();
		$routeType = Route::current()->getParameter('type');

		return redirect()->route($routeName,['type'=>$routeType,'post'=>$result->id,'action_post'=>'edit']);

	}

	protected function get_data_view(Request $r, $type){

		$action_post = $r->get('action_post','default');

		$post = $r->get('post',false);

		$data_view['postTypeConfig'] = $this->object->{$type};

		$data_view['post_type'] = $type;

		if( $action_post == 'detail' ){
			$data_view['detail'] = true;
		}

		$tags = new Vn4Model( $data_view['postTypeConfig']['table']);

		$objTag = $tags->where('id',$post)->first();

		if( $post && ($action_post == 'edit' || $action_post == 'detail') && $objTag){

			if($objTag->type == $type){
				
				$data_view['post'] = $objTag;

				add_action('vn4_adminbar',function() use ($objTag) {
					echo '<li class="li-title"><a href="'.get_permalinks($objTag).'" target="_blank"><i class="fa fa-pencil" aria-hidden="true"></i>'.__('View Post').'</a></li>';
				});
			}
		}

		return $data_view;
	}
}




