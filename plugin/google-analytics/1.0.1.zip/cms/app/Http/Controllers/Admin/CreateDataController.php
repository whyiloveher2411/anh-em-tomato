<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class CreateDataController extends ViewAdminController{

    public function index(Request $r,$type){

        $checkPermission = parent::checkPermission($r,$type);

        if($checkPermission !== true){
            return $checkPermission;
        }

        if( !check_post_layout($type,'create_data') ){
            vn4_create_session_message( __('Warning'), __('Object does not exist layout "Create Data"'), 'warning' , true);
            return redirect()->route('admin.index');
        }

        if( isset($this->object->{$type}['region_title_data_table']) ){
            $function = $this->object->{$type}['region_title_data_table'];
            add_function('vn4_admin_title_data_table',function($type) use ($function) {
                $function($type);
            });
        }

        $data_view['post_data'] = $this->object->{$type};

        $data_view['post_type'] = $type;

        $post = $r->get('post',false);

        if($r->isMethod('get')){

            $data_view = array_merge($data_view,$this->get_data_view( $r, $type ));

            return vn4_view('admin.particle.create_data',$data_view);
        }

        if($r->isMethod('POST')){

             return $this->post_add_or_update_post_admin( $r, $type );

        }
    }

}
