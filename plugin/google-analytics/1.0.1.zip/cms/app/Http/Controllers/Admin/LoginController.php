<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\User;
use Auth;
use Session;


class LoginController extends Controller {

    public function index(Request $r){

        if($r->isMethod('GET')){
            
            return vn4_view('admin.particle.login');
        }

        if($r->isMethod('POST')){

            $input = $r->all();

            if( User::where('email',trim($input['username']))->where('status','publish')->count() < 1 ){

                $arg['message'] = 'Username hoặc Password không đúng.';

            }else{
                $rememberme = $r->has('rememberme')?true:false;

                if ( Auth::attempt(['email' => $input['username'], 'password' => $input['password']], $rememberme) ){

                    if( Session::has('url_after_login') ){

                        $redirect = Session::pull('url_after_login');
                        
                        return redirect($redirect);

                    }
                    return redirect()->route('admin.index');
                }

            }

            $arg['message'] = 'Username hoặc Password không đúng.';
            return vn4_view('admin.particle.login',$arg);
        }
    }

    public function logout(){
        use_module(['read_html']);
        Auth::logout();

        $html = str_get_html(redirect()->back());
        $meta = $html->find('meta');

        $string_redirect_back = explode('=', explode(';', $meta[1]->attr['content'])[1])[1];

        if( strpos( $string_redirect_back, url().'/'.setting('security_prefix_link_admin','admin') ) === false ){
            return redirect()->back();
        }

        return redirect()->route('login');
    }
 
}
