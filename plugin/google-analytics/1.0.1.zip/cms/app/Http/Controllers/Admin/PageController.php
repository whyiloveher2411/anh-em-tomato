<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use Vn4Model;
use File;
use DB;
use Hash;
use Auth;

class PageController extends ViewAdminController {

   public function getPage(Request $r, $page){

      if($r->isMethod('GET')){

          $checkPermission = check_permission($page.'_view');

          if(!$checkPermission){
            vn4_create_session_message( __('Access'), __('You do not have access to this page'), 'error' , true );
            return redirect()->route('admin.index');
          }

          $permission = apply_function('check_permission_admin_page',true,$r,$page);

          if($permission != true){
            return $permission;
          }

          $page = str_replace('_','.',$page);

          $data_view['obj'] = new Vn4Model();

          $data_view['request'] = $r;

          if( file_exists('resources/views/admin/page/'.$page.'/get.php') ){
            include_once('resources/views/admin/page/'.$page.'/get.php');
          }

          return vn4_view('admin.page.'.$page.'.'.$page,$data_view);

      }
      
      if($r->isMethod('POST')){

          if( file_exists('resources/views/admin/page/'.$page.'/post.php') ){
            return include_once('resources/views/admin/page/'.$page.'/post.php');
          }else{
            dd('Not Exits Method Post');
          }


          // $method = 'post_'.str_replace('-', '_', str_slug($page));
          // return $this->$method($r,$page);
      }       
   }

   public function getViewIndex(){
      return vn4_view('admin.index');
   }
}
