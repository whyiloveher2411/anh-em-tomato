<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ShowDataController extends ViewAdminController {

    public function index(Request $r, $type){

        use_module(['post']);

        $checkPermission = parent::checkPermission($r,$type);

        if($checkPermission !== true){
            return $checkPermission;
        }

        if( !check_post_layout($type,'show_data') ){
            vn4_create_session_message( __('Warning'), __('Object does not exist layout "Show Data"'), 'warning' , true);
            return redirect()->route('admin.index');
        }

        if( isset($this->object->{$type}['region_title_data_table']) ){
            $function = $this->object->{$type}['region_title_data_table'];
            add_function('vn4_admin_title_data_table',function($type) use ($function) {
                $function($type);
            });
        }

        if($r->isMethod('get')){
            $post = $r->get('post',false);

            $noSeeDetail = $r->get('noSeeDetail',false);

            $action_post = $r->get('action_post','default');

            if($post && $action_post == 'detail' && check_permission($type.'_detail') && $noSeeDetail === false){
                return redirect()->route('admin.create_data',['type'=>$type,'post'=>$post,'action_post'=>$action_post]);
            }

            if($post && $action_post == 'edit' && check_permission($type.'_edit') && $noSeeDetail === false){
                return redirect()->route('admin.create_data',['type'=>$type,'post'=>$post,'action_post'=>$action_post]);
            }


            if( $r->get('noSeeDetail') === false ){
                return redirect()->route('admin.create_data',['type'=>$type,'edit_id'=>$r->get('edit_id')]);
            }

            $data_view['tag'] = $this->object->{$type};

            $data_view['fields'] = $this->object->{$type}['fields'];

            $data_view['type'] = $type;

            return vn4_view('admin.particle.show_data',$data_view);
        }
    }

    public function getDataTable(Request $r){

        use_module(['post']);

        $type = $r->get('post_type');

        return vn4_get_data_table_admin($type, true);

    }
}
