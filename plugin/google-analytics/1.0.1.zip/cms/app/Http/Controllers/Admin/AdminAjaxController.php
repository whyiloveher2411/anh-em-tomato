<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminAjaxController extends ViewAdminController {

    public function index(Request $r, $function){

        return $this->$function($r);

    }

    private function getFormatDateTime(Request $r){
        return response()->json(['result'=>date($r->get('data'))]);
    }
}




