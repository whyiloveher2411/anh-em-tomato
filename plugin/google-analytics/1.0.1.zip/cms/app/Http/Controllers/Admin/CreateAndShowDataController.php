<?php namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CreateAndShowDataController extends ViewAdminController {

    public function index(Request $r, $type){

        use_module(['post']);
        
        $checkPermission = parent::checkPermission($r,$type);

        if($checkPermission !== true){
            return $checkPermission;
        }

        if( !check_post_layout($type,'create_and_show_data') ){
            vn4_create_session_message( __('Warning'), __('Object does not exist layout "Show and Create Data"'), 'warning' , true);
            return redirect()->route('admin.index');
        }

        if( isset($this->object->{$type}['region_title_data_table']) ){
            $function = $this->object->{$type}['region_title_data_table'];
            add_function('vn4_admin_title_data_table',function($type) use ($function) {
                $function($type);
            });
        }

        $post = $r->get('post',false);

        if($r->isMethod('get')){

            $data_view = $this->get_data_view( $r, $type );

            return vn4_view('admin.particle.create_and_show_data',$data_view);
        }

        if($r->isMethod('POST')){

           return $this->post_add_or_update_post_admin( $r, $type );

        }
    }
}




