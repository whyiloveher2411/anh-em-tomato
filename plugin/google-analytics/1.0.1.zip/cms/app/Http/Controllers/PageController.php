<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App;
use Session;
use Cookie;

use Vn4Model;

class PageController extends Controller {

	public function getPage404(Request $r){

		return errorPage(404,'Page note found');

	}

	public function getPage(Request $r, $page){

		$action_before_page = do_action('getPage',$page);

		if( $action_before_page ) return $action_before_page;

		$view = 'theme.'.theme_name().'.page.'.$page;

		if( view()->exists( $view ) ){

			add_body_class(['page',$page]);
			
			title_head(ucwords( preg_replace('/-/', ' ', str_slug(str_replace('.blade.php', '', $page)) )  ));

			return vn4_view($view);

		}

		return errorPage(404,'Page note found');

	}

	public function getPage2(Request $r, $page, $page_current){

		\Illuminate\Pagination\Paginator::currentPageResolver(function() use ($page_current){
		    return $page_current;
		});

		$action_before_page = do_action('getPage',$page);

		if( $action_before_page ) return $action_before_page;

		$view = 'theme.'.theme_name().'.page.'.$page;

		if( view()->exists( $view ) ){

			add_body_class(['page',$page]);
			
			title_head(ucwords( preg_replace('/-/', ' ', str_slug(str_replace('.blade.php', '', $page)) )  ));

			return vn4_view($view);

		}

		return errorPage(404,'Page note found');

	}

	public function postDetail(Request $r, $post_type, $post_slug){

		$action_before_post_detail = do_action('postDetail',$post_type, $post_slug);

		if( $action_before_post_detail ) return $action_before_post_detail;

		$admin_object = get_admin_object($post_type);

		if( $admin_object ){

			$post = get_post($post_type,function($q) use($post_slug) {
				return $q->where('slug',$post_slug);
			});

			if( $post ){
				return view_post($post);
			} 


		}

		return errorPage(404,'Not found post');
	}

	public function index(Request $r){

		$before_index = do_action('index',$r);

		if( $before_index ){
			return $before_index;
		}

		add_body_class(['index','home']);

		title_head(setting('general_description',__('A simple website using Vn4CMS')));

		return vn4_view('theme.'.theme_name().'.index');

	}

	public function passwordProtectedPost(Request $r){

		$input = $r->only('id','post_type','post_password');

		Session::put($input['post_type'].'_password_'.$input['id'],$input['post_password']);

		$post = Vn4Model::f( $input['post_type'], $input['id'] );

		if( $post ) return redirect()->route('client.permalinks',['slug'=>$post->slug]);

		return redirect()->back();


	}

}
