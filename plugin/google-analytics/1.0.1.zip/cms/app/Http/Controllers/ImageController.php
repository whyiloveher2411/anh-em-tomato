<?php namespace App\Http\Controllers;

use Illuminate\Http\Request;

use File;

class ImageController extends Controller {

   public function checkImage(Request $r){
        $url = $r->get('image');

        $url = substr($url, strpos($url,'public'));

        // if (File::exists($url))
        // {
            return response()->json(['result'=>asset($url)]);
        // }
        return response()->json(['error'=>'Không tồn tại file này.']);
   }

}
