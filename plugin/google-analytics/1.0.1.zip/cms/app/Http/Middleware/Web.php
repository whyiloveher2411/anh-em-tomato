<?php namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use Auth;
use App;
use Route;

class Web {

	/**
	 * The Guard implementation.
	 *
	 * @var Guard
	 */
	protected $auth;

	/**
	 * Create a new filter instance.
	 *
	 * @param  Guard  $auth
	 * @return void
	 */
	public function __construct(Guard $auth)
	{
		$this->auth = $auth;
	}

	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next)
	{
		$GLOBALS['route_name'] = Route::currentRouteName();
		$GLOBALS['route_current'] = Route::current();
		do_action('init',$request, $next);
		
       	$result = do_action('middleware_web',$request, $next);

       	if($result != null){

			return $result;

		}
		
		return $next($request);
	}

}



