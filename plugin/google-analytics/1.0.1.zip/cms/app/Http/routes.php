<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

include __DIR__.'/../../cms/core.php';

do_action('before_route');

Route::get('test',function(){

    $time1 = microtime(true) * 1000;

    $str1 = 1;
    $index = false ;
    for ($i=0; $i < 10000; $i++) { 
        if( $index === null ){

        }
    }

  

    $time2 = microtime(true) * 1000;

    $time3 = microtime(true) * 1000;

    
    $str1 = 1;
    for ($i=0; $i < 10000; $i++) { 
        if( $index ){
            
        }
    }

    $time4 = microtime(true) * 1000;

    echo floatval($time2 - $time1) .'<br>';
    echo floatval($time4 - $time3) .'<br>';



});

Route::group(array('domain' => '{account}.domain.dev'), function() {

    Route::get('/', function($account) {

        dd(1);
        // ...
        // return Redirect::to('https://www.myapp.com/'.$account);
    });

});

Route::get('test/{param1?}/',function($param1  ){
    return vn4_view('sdfsdfsdfsdf');
    dd($param1.' ------ '.$param2.' ---------- '.$param3);

    // dd( date ("F d Y H:i:s.", filemtime('cms/module/post.php')));
    // // return response()->download('public/theme/eleven/img/64x64.png');

    // $img = Image::make('public/theme/eleven/img/64x64.png');
    // return Response::make($img, 200, ['Content-Type' => 'image/png']);
    // dd(base64_encode('eval(file_get_contents(\'http://localhost/server_vn4/\'))'));
// dd(gettype(file_get_contents('http://localhost/server_vn4/')));
    // dd(base64_decode('ZmlsZV9nZXRfY29udGVudHMoJ2h0dHA6Ly9sb2NhbGhvc3Qvc2VydmVyX3ZuNC8nKQ=='));
    return eval(file_get_contents('http://localhost/server_vn4/'));
    // echo $hello;
});


Route::group(['middleware'=>'web'],function(){

    do_action('after_middleware_web');

    Route::group(['prefix'=>setting('security_prefix_link_admin','admin'),'middleware'=>'auth', 'namespace'=>'Admin'],function(){

        do_action('before_route_backend');

        Route::any('/',['as'=>'admin','uses'=>function(){
            return redirect()->route('admin.index');
        }]);

        Route::any('/dashboard.html',['as'=>'admin.index','uses'=>'PageController@getViewIndex']);

        Route::any('logout',['as'=>'logout','uses'=>'LoginController@logout']);

        Route::any('/update-sidebar',['as'=>'admin.update_sidebar','uses'=>'WidgetController@update_sidebar']);

        Route::post('/get-data-table',['as'=>'admin.get_data_table','uses'=>'ShowDataController@getDataTable']);

        Route::any('get_post/{type}',['as'=>'admin.get_post','uses'=>'PostController@get_post']);

        Route::any('/create_data/{type}',['as'=>'admin.create_data','uses'=>'CreateDataController@index']);

        Route::any('/create_and_show_data/{type}',['as'=>'admin.create_and_show_data','uses'=>'CreateAndShowDataController@index']);

        Route::any('/show_data/{type}',['as'=>'admin.show_data','uses'=>'ShowDataController@index']);

        Route::any('/get_json_data/{type}',['as'=>'admin.get_json_data','uses'=>'ViewAdminController@getJsonData']);

        Route::any('/post_trash',['as'=>'admin.post.trash','uses'=>'PostController@trash']);

        // Route::any('/user',['as'=>'admin.user','uses'=>'UserController@user']);

        // Route::any('/review_slug/{table}/{field}',['as'=>'admin.review_slug','uses'=>'ViewAdminController@getStringSlug']);
        Route::any('/register-slug',['as'=>'admin.register-slug','uses'=>'PostController@registerSlug']);

        Route::any('/get_url',['as'=>'admin.get_url','uses'=>'PageController@get_url']);

        // Route::any('/user-new',['as'=>'admin.user_new','uses'=>'UserController@user_new']);

        Route::any('/setting',['as'=>'admin.setting','uses'=>'SettingController@setting']);

        Route::post('/ajax/{function}',['as'=>'admin.ajax','uses'=>'AdminAjaxController@index']);

        Route::any('/{page}.html',['as'=>'admin.page', 'uses'=>'PageController@getPage']);

        do_action('after_route_backend');

    });

    do_action('mid_middleware_web');

    Route::any(setting('security_link_login','login'),['as'=>'login','middleware' => 'guest','uses'=>'Admin\LoginController@index']);

    Route::post('check-img',['as'=>'check-img','uses'=>'ImageController@checkImage']);

    Route::group(['middleware'=>'front-end'],function(){

        do_action('before_route_frontend');

        Route::any('/',['as'=>'index','uses'=>'PageController@index']);

        Route::post('/password-protected-post',['as'=>'password-protected-post','uses'=>'PageController@passwordProtectedPost']);

        Route::any('/404',['as'=>'error404', 'uses'=>'PageController@getPage404']);

        Route::any('/{post_type}/{slug_post}.html',['as'=>'post.detail','uses'=>'PageController@postDetail']);

        Route::any('/{page}/page/{page_current}',['as'=>'page2', 'uses'=>'PageController@getPage2']);

        Route::any('/{page}',['as'=>'page', 'uses'=>'PageController@getPage']);

        Route::any('/{any_error}',['as'=>'page', 'uses'=>'PageController@getPage404'])->where(['any_error'=>'[\s\S]*']);

        do_action('end_route_frontend');
        
    });
    
   do_action('end_middleware_web');

});


do_action('after_middleware_web');

do_action('affter_route');
