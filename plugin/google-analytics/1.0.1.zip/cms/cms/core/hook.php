<?php
/**
 Action
 */

/**
 * do action
 */
if (!function_exists('do_action'))
{
    function do_action($action_name)
    {

         if( isset($GLOBALS['action_hook'][$action_name]) ){

            $action_hook = $GLOBALS['action_hook'][$action_name];

            ksort( $action_hook );

            $listParam = array_slice(func_get_args(), 1,10);

            $value = null;

            foreach( $action_hook as $hook){

                $value = call_user_func_array ($hook, array_merge($listParam, [$value]) );

            }

            return $value;
        }

        return null;

    }

}


if (!function_exists('add_action'))
{
    function add_action($action_name, $func_name, $priority = 'a', $unique = false )
    {   

        if(is_array($action_name)){

            $list_action_hook = $action_name;

            foreach ($list_action_hook as $action_name) {
                
                if( !isset($GLOBALS['action_hook'][$action_name]) ){
                   $GLOBALS['action_hook'][$action_name] = array();
                }

                $name = $priority;

                if( $unique == false){

                    while( isset($GLOBALS['action_hook'][$action_name][$name]) ){
                        $name = $name.$priority;
                    }

                    $GLOBALS['action_hook'][$action_name][$name] = $func_name;

                }else{

                    $GLOBALS['action_hook'][$action_name][$name] = $func_name;

                }
                
            }

        }else{

            if( !isset($GLOBALS['action_hook'][$action_name]) ){
               $GLOBALS['action_hook'][$action_name] = array();
            }

            $name = $priority;

            if( $unique == false){

                while( isset($GLOBALS['action_hook'][$action_name][$name]) ){
                    $name = $name.$priority;
                }

                $GLOBALS['action_hook'][$action_name][$name] = $func_name;

            }else{

                $GLOBALS['action_hook'][$action_name][$name] = $func_name;

            }

        }
        
    }
}


/**
 Filter
 */

 $GLOBALS['filter'] = [];
/**
 * apply filter
 */
if (!function_exists('apply_filter'))
{
    function apply_filter($filter_name, $content = null)
    {  

        if( $content === null ) $content = [];

        if( isset($GLOBALS['filter'][$filter_name]) ){

            $filter_hook = $GLOBALS['filter'][$filter_name];

            ksort($filter_hook);

            $index = 1;

            foreach($filter_hook as $value){

               $content = call_user_func_array($value,[$content]) ;

            }
        }

        return $content;
        
        // if( $content !== null )   return $content;

        // return [];
    }

}

// 

/**
 * add filter
 */
if (!function_exists('add_filter'))
{
    function add_filter($filter_name, $func_name, $priority = 'a')
    {

        if(!isset($GLOBALS['filter'][$filter_name])){
            $GLOBALS['filter'][$filter_name] = array();
        }

        $name = $priority;

        while(isset($GLOBALS['filter'][$filter_name][$name])){
            $name = $name.$priority;
        }

        $GLOBALS['filter'][$filter_name][$name] = $func_name;

    }

}


/**
 Function
 */

 
/**
 * apply filter
 */
if (!function_exists('apply_function'))
{
    function apply_function($filter_name, $valueDefault = null )
    {

        if(isset($GLOBALS['function'][$filter_name])){

            ksort($GLOBALS['function'][$filter_name]);

            $arr_parameter = array_slice(func_get_args(), 2,10);

            foreach($GLOBALS['function'][$filter_name] as $value){

                $listParam = array_merge([$valueDefault], $arr_parameter);

                $valueDefault = call_user_func_array ($value, $listParam );
            }
        }
        
        return $valueDefault;

    }

}



/**
 * add filter
 */
if (!function_exists('add_function'))
{
    function add_function($filter_name, $func_name, $priority = 'a', $unique = false)
    {  

         if(is_array($filter_name)){

             $list_action_hook = $filter_name;

             foreach ($list_action_hook as $filter_name) {
                
                if(!isset($GLOBALS['function'][$filter_name])){
                    $GLOBALS['function'][$filter_name] = array();
                }

                $name = $priority;
                
                while(isset($GLOBALS['function'][$filter_name][$name])){
                     
                    $name = $name.$priority;
                }
                    
                $GLOBALS['function'][$filter_name][$name] = $func_name;
                
             }


         }else{

            if(!isset($GLOBALS['function'][$filter_name])){
                $GLOBALS['function'][$filter_name] = array();
            }

            $name = $priority;
            
            while(isset($GLOBALS['function'][$filter_name][$name])){
                 
                $name = $name.$priority;
            }
                
            $GLOBALS['function'][$filter_name][$name] = $func_name;

         }

        
    }

}

if( !function_exists('call_function_if_exists') ){

    function call_function( $func_name){

        if( is_callable( $func_name ) ){

             return call_user_func_array ($func_name, array_slice(func_get_args(), 1,10) );

        }

    }

}

