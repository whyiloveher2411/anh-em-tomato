<?php

function check_key(){
	if( VN4 ) return;

	die();
}


$GLOBALS['vn4_table_prefix'] = env('TABLE_PREFIX','vn4_');

function vn4_tbpf(){
	return $GLOBALS['vn4_table_prefix'] ;
}

function setting($keyword = null , $default = null){

	if( $keyword === null && isset($GLOBALS['setting']) ){
		return $GLOBALS['setting'];
	}elseif( $keyword === null ){

		$obj = new Vn4Model(vn4_tbpf().'setting');

		$obj = $obj->whereType('setting')->lists('content','key_word');

		$GLOBALS['setting'] = $obj;

		return $obj;

	}

	if( isset($GLOBALS['setting'][$keyword]) ){

		if( $GLOBALS['setting'][$keyword] !== '' ) return $GLOBALS['setting'][$keyword];

		return $default;

	} 

	$obj = new Vn4Model(vn4_tbpf().'setting');

	$obj = $obj->whereType('setting')->lists('content','key_word');

	$GLOBALS['setting'] = $obj;

	if( isset($obj[$keyword]) && $obj[$keyword] !== '' ){
		return $obj[$keyword];
	} 

	return $default;
}

$GLOBALS['is_developing'] =(setting('general_status') === 'developing');

function add_route($url, $name, $hook, $callback, $where = [] ){

	add_action($hook,function() use ($url, $name, $hook, $callback, $where) {

		if(!Route::has($name)){

			Route::any($url,['as'=>$name,'uses'=>function() use ($callback) {

				$arg = func_get_args ();

				array_unshift($arg,request());

				return call_user_func_array ($callback, $arg ) ;

			}])->where($where);
		}

	});

}

function is_admin(){

	if( isset($GLOBALS['is_admin'] )) return $GLOBALS['is_admin'];

	$GLOBALS['is_admin'] = request()->is(setting('security_prefix_link_admin','admin').'/*');

	return  $GLOBALS['is_admin'];
}

function register_template($arg){

	add_filter('register_template',function($filter) use ($arg){
		if( is_array($arg))  return array_merge($arg , $filter);

		$filter[] = $arg;
		return $filter;
	});

}

function request($key = null, $default = null)
{
	if( isset( $GLOBALS['request'] ) ){
		return $GLOBALS['request'];
	}

	if (is_null($key)) {
		return app('request');
	}
	if (is_array($key)) {
		return app('request')->only($key);
	}

	$GLOBALS['request'] = app('request')->input($key, $default);
	return $GLOBALS['request'];
}

function is_url($str){
	if(filter_var($str, FILTER_VALIDATE_URL)){
		return true;
	}else{
		return false;
	}
}

$obj = new Vn4Model(vn4_tbpf().'setting');

$theme = $obj->where('type','setting')->where('key_word','general_client_theme')->first();

if($theme == null ){

	$theme = 'general_client_theme';

}else{
	$theme = $theme->content;
}

$GLOBALS['mytheme'] = $theme;

function theme_name(){

	return $GLOBALS['mytheme'];

}

function vn4_view($view = null, $data = array(), $mergeData = array()){

	do_action('vn4_view',$view);

	$view = view($view, $data, $mergeData)->render();

	$developing = setting('general_status');

	if( $developing != 'developing' && $developing != 'general_status'){

		$pattern = '/(?:(?:\/\*(?:[^*]|(?:\*+[^*\/]))*\*+\/)|(?:(?<!\:|\\\|\')\/\/.*))/';
		$view = preg_replace($pattern, '', $view);

	  // $view = trim(preg_replace('/\s\s+/', '', $view));

		$view = preg_replace(
			array(
				'/ {2,}/',
				'/<!--.*?-->|\t|(?:\r?\n[ \t]*)+/s'
				),
			array(
				' ',
				''
				),
			$view
			);

	  // Storage::disk('local')->put('file.html', $view);

	}

	return $view;

}

function vn4_route($name, $parameters = array(), $absolute = true, $route = null){
	
	$before_route = do_action('route',$name, $parameters, $absolute, $route);

	if( $before_route ){
		return $before_route;
	}

	return route($name, $parameters, $absolute, $route);
}

function theme_view($view){
	return vn4_view('theme.'.theme_name().'.'.$view);
}

function get_Date($content = null , $format = null ){

    if( $format === null ){

        $format = setting('general_date_format','d-m-Y');

    }

    return \Carbon\Carbon::parse($content)->format($format);

}

function get_time($content){

    $format = setting('general_time_format','H:i:s');

    return \Carbon\Carbon::parse($content)->format($format);
}

function get_admin_object( $name = null ){
    
    if ( isset($GLOBALS['function_helper_get_admin_object']) ){
        $admin_object = $GLOBALS['function_helper_get_admin_object'];
    }else{
        $admin_object = include __DIR__.'/../object_cms/object.php';
        $GLOBALS['function_helper_get_admin_object'] = $admin_object;
    }


    if( $name !== null ){

        if ( isset($admin_object[$name]) ) return $admin_object[$name];

        return null;
        
    }

    return $admin_object;
}

/**
Function helper
*/

function title_head($title = null){

	if($title === null){
		return apply_function('title_head',setting('general_site_title'));
	}

	add_function('title_head',function() use ($title) {
		return $title;
	});

	return $title;

}

function use_module($arg){
	if( is_array($arg) ){
		foreach ($arg as $value) {
			include_once __DIR__.'/../module/'.$value.'.php';
		}	
	}elseif( is_string($arg) ){
		include_once __DIR__.'/../module/'.$arg.'.php';
	}
	
}

function get_image($content){

	$img = get_img($content);

	if( check_image($img) ){
		return $img;
	}

	return null;

}


/**
add post type
*/

function register_post_type($callback ){

	add_filter('register_post_type',function($post_type) use ($callback) {
		$add_post_type = $callback($post_type);

		if( is_array($add_post_type[0]) ){

			foreach ($add_post_type as $p) {

				list($id,$stt,$arg) = $p;

				if(!isset($post_type[$id])){

					if ( is_int($stt) ){

						$post_type1 = array_slice($post_type, 0 , $stt - 1);
						$post_type2 = array_slice($post_type,$stt - 1);

						$post_type1[$id] = $arg;

						$post_type = array_merge($post_type1, $post_type2);

					}else{
						$post_type[$id] = $arg;
					}

				}
			}
		}else{
			list($id,$stt,$arg) = $add_post_type;

			if(!isset($post_type[$id])){

				if ( is_int($stt) ){

					$post_type1 = array_slice($post_type, 0 , $stt - 1);
					$post_type2 = array_slice($post_type,$stt - 1);

					$post_type1[$id] = $arg;

					$post_type = array_merge($post_type1, $post_type2);

				}else{
					$post_type[$id] = $arg;
				}

			}

		}

		return $post_type;

	});

}



/**
Trans
*/

function __( $trans, $source_lang = 'system', $parameters = array(), $domain = 'messages', $locale = null ){
	// return $trans;
	$result = $trans;

	if( $GLOBALS['is_developing'] ){

		$code = str_replace('-', ' ', str_slug(str_replace('##', 'parametervn4', $trans)));

		$code = str_replace('parametervn4', '##', $code);

		$id = $source_lang.'.'.$code;

		$result2 = app('translator')->trans($id, $parameters, $domain, $locale);

		if( $id != $result2 ){
			$result = $result2;
		}

		$langCache = Cache::get('__ : '.App::getLocale(),[]);

		$langCache[$trans] = $result;

		Cache::forever('__ : '.App::getLocale(), $langCache );

	}else{
		$language = App::getLocale();

		if( !isset($GLOBALS['trans_framework_'.$language]) ){
			$GLOBALS['trans_framework_'.$language] = Cache::get('__ : '.$language,[]);
		}

		if( isset($GLOBALS['trans_framework_'.$language][$trans]) ){
			$result = $GLOBALS['trans_framework_'.$language][$trans];
		}

	}

	return $result;

}

function __p($trans, $plugin_keyword = null ){
	// return $trans;
	$result = $trans;
		
	if( $GLOBALS['is_developing'] ){

		if( file_exists(public_path().'/../resources/views/plugins/'.$plugin_keyword.'/lang/'.App::getLocale().'.php') ){
			
			if( !isset($GLOBALS['trans_plugin'][$plugin_keyword]) ){
				$GLOBALS['trans_plugin'][$plugin_keyword] = include_once public_path().'/../resources/views/plugins/'.$plugin_keyword.'/lang/'.App::getLocale().'.php';
			}

			$code = str_replace('-', ' ', str_slug(str_replace('##', 'parametervn4', $trans)));

			$code = str_replace('-', ' ', str_slug($trans));

			$code = str_replace('parametervn4', '##', $code);

			if( isset($GLOBALS['trans_plugin'][$plugin_keyword][$code]) ){
				$result = $GLOBALS['trans_plugin'][$plugin_keyword][$code];
			}

			$langCache = Cache::get('__p : '.$plugin_keyword.' : '.App::getLocale(),[]);

			$langCache[$trans] = $result;

			Cache::forever('__p : '.$plugin_keyword.' : '.App::getLocale(), $langCache );
		}

	}else{

		$theme_name = theme_name();

		if( !isset($GLOBALS['trans_plugin'][$plugin_keyword] ) ){
			$GLOBALS['trans_plugin'][$plugin_keyword] = Cache::get('__p : '.$plugin_keyword.' : '.App::getLocale(),[]);
		}

		if( isset($GLOBALS['trans_plugin'][$plugin_keyword][$trans]) ){
			$result = $GLOBALS['trans_plugin'][$plugin_keyword][$trans];
		}
	}

	return $result;

}

function __t($trans){

	$result = $trans;

	if( $GLOBALS['is_developing'] ){

		if( !isset($GLOBALS['trans_theme']) && file_exists(public_path().'/../resources/views/theme/'.theme_name().'/lang/'.App::getLocale().'.php') ){
			$GLOBALS['trans_theme'] = include public_path().'/../resources/views/theme/'.theme_name().'/lang/'.App::getLocale().'.php';
		}
		$code = str_replace('-', ' ', str_slug(str_replace('##', 'parametervn4', $trans)));
		$code = str_replace('parametervn4', '##', $code);

		if( isset($GLOBALS['trans_theme'][$code]) ){
			$result = $GLOBALS['trans_theme'][$code];
		}

		$langCache = Cache::get('__t : '.theme_name().' : '.App::getLocale(),[]);

		$langCache[$trans] = $result;

		Cache::forever('__t : '.theme_name().' : '.App::getLocale(), $langCache );

	}else{

		$theme_name = theme_name();
		$lang = App::getLocale();

		if( !isset($GLOBALS['trans_theme_'.$theme_name.'_'.$lang]) ){
			$GLOBALS['trans_theme_'.$theme_name.'_'.$lang] = Cache::get('__t : '.$theme_name.' : '.$lang,[]);
		}

		if( isset($GLOBALS['trans_theme_'.$theme_name.'_'.$lang][$trans]) ){
			$result = $GLOBALS['trans_theme_'.$theme_name.'_'.$lang][$trans];
		}

	}

	return $result;
}

/**
Menu
*/

function register_nav_menus($arg){

	add_filter('register_nav_menus',function($filters) use ($arg) {

		return array_merge($filters,$arg);

	} );

}


/**
  Error 404
*/

function errorPage($code, $messages){

	$view = 'theme.'.theme_name().'.error.'.$code;

	if( view()->exists( $view ) ) return response()->view($view,['errorCode'=>$code,'messages'=>$messages],$code);

	return redirect()->route('index');
}


/**
 Widget
 */

function register_widget(){
	$class_name = func_get_args();

	add_function('vn4_list_widgets',function($list_widgets) use ($class_name) {

		foreach ($class_name as $class) {

			if(is_string($class)){
				$list_widgets[] = $class;
			}

		}

		return $list_widgets;

	});

}

function vn4_list_widgets(){

	$list_widgets = apply_function('vn4_list_widgets',[]);

	foreach ($list_widgets as $widget) {
		(new $widget())->form_widget_html_left();
	}

}


function register_sidebar($callback){

	add_filter('list_sidebar',function($list_sidebar) use ($callback) {

		$args = $callback($list_sidebar);

		if( $args ){
			$list_sidebar[str_slug($args['id'])] = $args;
		}

		return $list_sidebar;
	});

}

class Widget_Text extends Vn4Widget{

	function __construct(){

		parent::__construct('text',__('Text Html'),[
			'description'=>__('Text or HTML'),
			'instance' => ['title'=>'title 2','text'=>'Text html 2'],
			]);

	}

	function form(){

		?>
		<label><?php echo __('Title'); ?>
			<input type="text" name="title" value="<?php echo e($this->get_field_value('title')) ?>" class="form-control">
		</label>
		<label><?php echo __('Text'); ?>
			<textarea rows="6" name="text" type="text" class="form-control"><?php echo e($this->get_field_value('text')); ?></textarea>
		</label>
		<?php

	}

	function widget(){
		?>
		<div class="widget-text-html">
			<h4><?php echo $this->get_field_value('title'); ?></h4>
			<div class="content-widget">
				<p><?php echo $this->get_field_value('text'); ?></p>
			</div>
		</div>
		<?php
	}

}

register_widget('Widget_Text');  


/**
    Plugin
*/

function plugins($all = false){

    if( isset($GLOBALS['listPlugin']) ) return $GLOBALS['listPlugin'];

     $obj = new Vn4Model(vn4_tbpf().'setting');

     if( !$all ){
        $listPlugin = $obj->whereType('plugin')->where('status','publish')->get();
     }else{
         $listPlugin = $obj->whereType('plugin')->get();
     }

     $GLOBALS['listPlugin'] = $listPlugin;

     return $listPlugin;
}

function plugin($name){

  foreach ($GLOBALS['listPlugin'] as $plugin) {
    if( $plugin->key_word === $name ) return $plugin;
  }

  return null;

}

function plugin_save($plugin, $input){
  
  $plugin->updateMeta($input);

  return true;

}

function view_plugin($plugin_key_word, $view, $data = array(), $mergeData = array())
{
     return vn4_view('plugins.'.$plugin_key_word.'.'.$view, $data, $mergeData);
}

function plugin_asset($plugin_key_word, $file = ''){
    return  asset('public/plugins/'.$plugin_key_word.'/'.trim($file,'/'));
}

function get_parameter_route($arg){

    if( is_string($arg) ){
        $return1 = Route::current()->getParameter($arg);
        $return2 = Input::get('param_of_route_'.$arg);

        return vn4_one_or( $return1, $return2 );
    }
    if( is_array($arg) ){

        $return = [];

        foreach ($arg as $name) {

            $result1 = Route::current()->getParameter($name);
            $result2 = Input::get('param_of_route_'.$name);

            $return[$name] =  vn4_one_or($result1, $result2 );
        }

        return $return;

    }

    return null;

}


/**
    POST
*/

/**
 * function name: get_posts
 * Description: Returns the registered post types as found in $post_type.
 * @param (string) post_type name post type
 * @param (int or array) 
 *      int: number of posts
 *      array:
 *      array['count']: number of posts
 *      array['function']: a customized query callback function
 * @param (Closure) a customized query callback function if param1 is int
 */

function get_posts($post_type, $param1 = null , $callback = null){

    $order = ['created_at','desc'];

    if( is_array($param1) ){

        if( isset($param1['count']) && is_int($param1['count']) ){

            $count = $param1['count'];

        }

        if( isset($param1['function']) ){
            $callback = $param1['function'];
        }

        if( isset($param1['order']) ){
            $order = $param1['order'];
        }

    }

    //param1 is number post
    if( is_int($param1) ) $count = $param1;

    //The default number is 15
    if( !isset($count) ) $count = 15;

    $admin_object = get_admin_object($post_type);

    //not found post_type
    if(!$admin_object){
        return [];
    }

    $posts = (new Vn4Model($admin_object['table']))->where('status','publish')->where('visibility','!=','private')->where('type',$post_type);

    $posts2 = do_action('get_posts', $posts, $post_type);

    if( $posts2 ) $posts = $posts2;

    if(is_callable ($callback) ){
        $posts = call_user_func_array($callback,[$posts]);
    }

    $posts = $posts->orderBy($order[0],$order[1]);

    $posts = $posts->paginate($count);

    return $posts;
}

function get_posts_not_paginate($post_type, $param1 = null , $callback = null){

    $order = ['created_at','desc'];

    if( is_array($param1) ){

        if( isset($param1['count']) && is_int($param1['count']) ){

            $count = $param1['count'];

        }

        if( isset($param1['function']) ){
            $callback = $param1['function'];
        }

        if( isset($param1['order']) ){
            $order = $param1['order'];
        }

    }

    //param1 is number post
    if( is_int($param1) ) $count = $param1;

    //The default number is 15
    if( !isset($count) ) $count = 15;

    $admin_object = get_admin_object($post_type);

    //not found post_type
    if(!$admin_object){
        return [];
    }

    $posts = new Vn4Model($admin_object['table']);

    $posts = $posts->where('status','publish')->where('visibility','!=','private')->where('type',$post_type);


    $posts2 = do_action('get_posts', $posts, $post_type);

    if( $posts2 ) $posts = $posts2;

    if(is_callable ($callback) ){
        $posts = call_user_func_array($callback,[$posts]);
    }

    $posts = $posts->orderBy($order[0],$order[1])->take($count)->get();

    return $posts;
}

 /**
 * function name: get_post
 * Description: Retrieves post data given a post ID or post object.
 * @param (string) post_type name post type
 * @param (int) id  Post ID
 */
// function get_post($post_type = null , $id = null ){

//     if( $post_type == null || $id == null ){

//         if( isset($GLOBALS['post_current']) ){
//             return $GLOBALS['post_current'];
//         }

//         return null;
//     }

//     $admin_object = get_admin_object($post_type);
    
//     if(!$admin_object){
//         return null;
//     }

//     if( !is_admin() ){
        
//         $post = Cache::rememberForever($post_type.'_'.$id, function() use( $admin_object, $id, $post_type) {

//             $post = new Vn4Model($admin_object['table']);

//             $post = $post->where('id',$id)->where('status','publish')->where('visibility','!=','private')->where('type',$post_type)->first();

//             return $post;

//         });

//         return $post;

//     }else{

//        $post = (new Vn4Model($admin_object['table']))->where('id',$id)->first();

//         return $post; 
        
//     }

// }

function get_post($post_type = null, $id = null ){

	 if( $post_type == null || $id == null ){

        if( isset($GLOBALS['post_current']) ){
            return $GLOBALS['post_current'];
        }

        return null;
    }

    $admin_object = get_admin_object($post_type);
    
    if(!$admin_object){
        return null;
    }

    if( !is_admin() ){
        
    	if( is_callable($id) ){

			$post = new Vn4Model($admin_object['table']);

			$post = call_user_func_array($id,[$post]);

    		$post = $post->where('status','publish')->where('visibility','!=','private')->where('type',$post_type)->first();

    	}else{

    		$post = Cache::rememberForever($post_type.'_'.$id, function() use( $admin_object, $id, $post_type) {

	            $post = new Vn4Model($admin_object['table']);

            	$post = $post->where('id',$id)->where('status','publish')->where('visibility','!=','private')->where('type',$post_type)->first();
	            
	            return $post;

	        });

    	}

        

        return $post;

    }else{

       $post = (new Vn4Model($admin_object['table']))->where('id',$id)->first();

        return $post; 
        
    }
}


/**
 * function name: get_permalinks
 * Description: Retrieves friendly links of post.
 * @param (object) post object post type
 * @param (string) slug
 */
function get_permalinks( $post, $slug = null ){

    if( is_string($post) ){

        $type = $post;

    }else{

        if( is_array($post) ){
            $type = $post['type'];
            $slug = $post['slug'];
        }else{
            $type = $post->type;
            $slug = $post->slug;
        }
    }

    return vn4_route('post.detail',['post_type'=>$type,'post_slug'=>$slug]);
    
}

function get_relationship( $post, $name){
    
    return json_decode($post->{$name});

}

function get_post_meta( $post, $key = null , $default = null ){

    if( $post ){

        $meta = json_decode($post->meta, true);

        if( !$key ){
            
            if( !is_array( $meta ) ) return [];

            return $meta;
        } 
        
        if( is_string($key) ){
            if( isset($meta[$key]) ){
                return $meta[$key];
            }    
        }elseif( is_array($key) ){

            $result = [];
            foreach ($key as $k) {

                if( isset($meta[$k]) ){
                    $result[$k] = $meta[$k];
                }else{
                    $result[$k] = null;
                }  

            }

            return $result;

        }

    }

    return $default;

}


function update_post_meta( $post, $key, $value = null){

    if ( $post->exists ){

        $post = $post->updateMeta($key, $value);

    }else{

        vn4_create_session_message( trans('master.word_error'), trans('master.message_error_update_post_meta'), 'error' , true);

    }

    return $post;

}

/**
 
    FUNCTION HELPERS

 */

function add_load_javascript_unique($src, $meo, $async = false, $time = 500){
    if(!isset($GLOBALS['javscript_admin'])){
        $GLOBALS['javscript_admin'] = array();
    }

    if(in_array($src,$GLOBALS['javscript_admin'])){
        return;
    }

    $GLOBALS['javscript_admin'][] = $src;
    
    add_action($meo, function() use ($src, $async, $time){

        if($async){
        ?>
            <script>

                $(document).ready(function() {

                  setTimeout(function(){ $.getScript('<?php echo $src ?>'); }, <?php echo $time ?>);
                  
                });

            </script>
        <?php }else{ ?>
            <script type="text/javascript" src="<?php echo $src; ?>" async></script>
        <?php
        }
    },'z');
    
}

function vn4_one_or(){
    $numargs = func_get_args();
    foreach ($numargs as $key => $value) {
        if($value){
            return $value;
        }
    }
}

function add_load_css_unique($src, $meo){

    if(!isset($GLOBALS['css_admin'])){
        $GLOBALS['css_admin'] = array();
    }

    if(in_array($src,$GLOBALS['css_admin'])){
        return;
    }
    $GLOBALS['css_admin'][] = $src;

    add_action($meo, function() use ($src){
        ?>
            <link rel="stylesheet" type="text/css" id="u0" href="<?php echo $src; ?>">
        <?php
    },'z');
    
}

function get_param($arg = null, $only = true){

    if($arg != null && $only){
         $input = Input::only($arg);
    }elseif(!$only){
        $input = Input::except($arg);
    }else{
        $input = Input::all();
    }

    $param = '';

    foreach ($input as $key => $value) {
        if($value){
            $param = $param.'&'.$key.'='.$value;
        }
    }
        
    return substr($param, 1);
}

/**
    IMAGE LAZY LOADING
*/

/* USER-AGENTS
================================================== */
function check_user_agent ( $type = NULL ) {
        $user_agent = strtolower ( $_SERVER['HTTP_USER_AGENT'] );
        if ( $type == 'bot' ) {
                // matches popular bots
                if ( preg_match ( "/googlebot|adsbot|yahooseeker|yahoobot|msnbot|watchmouse|pingdom\.com|feedfetcher-google/", $user_agent ) ) {
                        return true;
                        // watchmouse|pingdom\.com are "uptime services"
                }
        } else if ( $type == 'browser' ) {
                // matches core browser types
                if ( preg_match ( "/mozilla\/|opera\//", $user_agent ) ) {
                        return true;
                }
        } else if ( $type == 'mobile' ) {
                // matches popular mobile devices that have small screens and/or touch inputs
                // mobile devices have regional trends; some of these will have varying popularity in Europe, Asia, and America
                // detailed demographics are unknown, and South America, the Pacific Islands, and Africa trends might not be represented, here
                if ( preg_match ( "/phone|iphone|itouch|ipod|symbian|android|htc_|htc-|palmos|blackberry|opera mini|iemobile|windows ce|nokia|fennec|hiptop|kindle|mot |mot-|webos\/|samsung|sonyericsson|^sie-|nintendo/", $user_agent ) ) {
                        // these are the most common
                        return true;
                } else if ( preg_match ( "/mobile|pda;|avantgo|eudoraweb|minimo|netfront|brew|teleca|lg;|lge |wap;| wap /", $user_agent ) ) {
                        // these are less common, and might not be worth checking
                        return true;
                }
        }
        return false;
}


function _bot_detected() {

    if( isset($_GET['fb']) && $_GET['fb'] == 1){
        return true;
    }

    if (isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/bot|crawl|slurp|spider|facebook|google/i', $_SERVER['HTTP_USER_AGENT'])) {
        return TRUE;
    }
    else {
        return FALSE;
    }

}


add_action('vn4_footer',function(){
  ?>
      <script>
      /**
      *image lazy loadding
      */
!function(window){
var $q = function(q, res){
    if (document.querySelectorAll) {
      res = document.querySelectorAll(q);
    } else {
      var d=document
        , a=d.styleSheets[0] || d.createStyleSheet();
      a.addRule(q,'f:b');
      for(var l=d.all,b=0,c=[],f=l.length;b<f;b++)
        l[b].currentStyle.f && c.push(l[b]);

      a.removeRule(0);
      res = c;
    }
    return res;
  }
, addEventListener = function(evt, fn){
    window.addEventListener
      ? this.addEventListener(evt, fn, false)
      : (window.attachEvent)
        ? this.attachEvent('on' + evt, fn)
        : this['on' + evt] = fn;
  }
, _has = function(obj, key) {
    return Object.prototype.hasOwnProperty.call(obj, key);
  }
;

function loadImage (el, fn) {
var img = new Image()
  , src = el.getAttribute('data-src');
img.onload = function() {
  if (!! el.parent)
    {el.parent.replaceChild(img, el);}
  else{el.src = src;}
    

  fn? fn() : null;
};
img.src = src;
}

function elementInViewport(el) {
var rect = el.getBoundingClientRect();

return (
   rect.top    >= 0
&& rect.left   >= 0
&& rect.top <= (window.innerHeight || document.documentElement.clientHeight)
)
}

var images = new Array()
  , query = $q('img.image-lazy-loading')
  , processScroll = function(){
      for (var i = 0; i < images.length; i++) {
        if (elementInViewport(images[i])) {
          loadImage(images[i], function () {
            images.splice(i, i);
          });
        }
      };
    }
  ;
// Array.prototype.slice.call is not callable under our lovely IE8 
for (var i = 0; i < query.length; i++) {
  images.push(query[i]);
};

processScroll();
addEventListener('scroll',processScroll);

}(this)
</script>
  <?php
}, 'image_lazy_loading');


function image_lazy_loading($src, $class = ''){

    if( !_bot_detected() ){
        return '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAAA1BMVEX6+vqsEtnpAAAACklEQVQI12NgAAAAAgAB4iG8MwAAAABJRU5ErkJggg==" class="image-lazy-loading '.$class.'" data-src="'.$src.'" />';
    }else{
        return '<img class="image-lazy-loading '.$class.'" src="'.$src.'" />';
    }
}


