<?php

function setting_save($keyword, $value){
          
	$obj = Vn4Model::firstOrAddnew(vn4_tbpf().'setting',['key_word'=>$keyword,'type'=>'setting']);

	$obj->content = trim($value);

	return $obj->save();

}


function admin_data_table($type){
	echo vn4_view('admin.layout.template-table-data',['type'=>$type]);
}

function get_field($name, $fields){

	if( is_callable($name) && $form = call_user_func($name) ){

		if( isset($form['form']) ){
			return call_user_func_array($form['form'], [$fields]);
		}

	}

return vn4_view('admin.particle.input_field.'.$name.'.form',$fields);

}



/**
Meta Box
*/

function add_meta_box( $id, $title, $post_type, $type , $priority, $callback_html ,  $callback_save, $argParameter = array() ){

	$mock_action = 'add_meta_box_left';

	if( $type === 'right' ){

		$mock_action = 'add_meta_box_right';

		if( isset($argParameter['positions']) && $argParameter['positions'] === 'top' ){
			$mock_action = 'add_meta_box_right_top';
		}

	}  

	add_action($mock_action, function($customePostConfig, $post) use ( $id,$title,$post_type,$callback_html, $argParameter ) {

		if( !isset($customePostConfig['is_object_system']) || $customePostConfig['is_object_system'] !== true ){

			if( $post_type === null || ( is_string($post_type) && request()->route()->parameters()['type'] === $post_type ) || ( is_array($post_type) &&  in_array(request()->route()->parameters()['type'] , $post_type))   ){
				?>
				<div class="x_panel" id="<?php echo $id; ?>">
					<div class="x_title">
						<h2><?php echo $title; if( isset($argParameter['callback_title']) && is_callable($argParameter['callback_title']) ) $argParameter['callback_title'](); ?></h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							</li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<input type="text" hidden name="check_meta_<?php echo $id; ?>" value="<?php echo time(); ?>">
						<?php 

						if ( is_callable($callback_html) ){

							call_user_func_array ( $callback_html,[$customePostConfig, $post] );

						}else{
							vn4_create_session_message( trans('master.word_warning'), trans('master.message_info_miss_function_add_meta_box').' tại vị trí ['.$title.']', 'warning' , true);
							echo '<div style="background:red;padding:10px;color:#fff;font-size:15px;">(expects parameter to be a valid callback_html, no array or string given)</div>';
						}


						?>
					</div>
				</div>
				<?php

			}
			return $post;
		}

	},$priority);

	add_action('saved_post',function($post, $request) use ($id, $callback_save){

		  // if( !isset($admin_object['is_object_system']) || $admin_object['is_object_system'] !== true ){
		if( $request->has('check_meta_'.$id) ){

			$value = call_user_func_array ( $callback_save,[$post, $request] );

			if( $value ){
				return $value;
			}

		}

		return $post;

		  // }

	},$priority);

}


/**
Register Slug
*/

function registerSlug($slug_old, $me_type = 'PostController_line_47', $me_id = null){

	$slug_old = str_slug($slug_old);

	if( !$me_id ) $me_id = -1;

	$slug_new = $slug_old;

	$admin_objects = get_admin_object();

	$array_keys = array_keys($admin_objects);

	$count = count($array_keys);

	$index_slug = 2;

	for ($i=0; $i < $count;) { 

		if( isset($admin_objects[$array_keys[$i]]['fields']['slug']) ){

			if( $array_keys[$i] === $me_type ){

				$object = Vn4Model::objectSlug($admin_objects[$array_keys[$i]]['table'],$slug_new,function($query) use($me_id){

					return $query->where('id','!=',$me_id);

				});



			}else{

				$object = Vn4Model::objectSlug($admin_objects[$array_keys[$i]]['table'],$slug_new, function($query) use ($me_type){
					return $query->where('type','!=',$me_type);
				});
			}

			if( $object ){
				$slug_new = $slug_old.'-'.$index_slug;
				$index_slug++;
				$i = 0;
				continue;
			}
		}
		
		$i++;
	}

	return $slug_new;
}




/**

	SIDEBAR

*/

$GLOBALS['sidebar'] = [];

function array_insert_after($key, array &$array, $new_key, $new_value) {
	if (array_key_exists($key, $array)) {
		$new = array();
		foreach ($array as $k => $value) {
  //sdfsdfsdf
			$new[$k] = $value;
			if ($k === $key) {
				$new[$new_key] = $new_value;
			}
		}
		return $new;
	}
	return FALSE;
}

function add_sidebar_admin( $id , $callback, $stt = null ){

	add_filter('sidebar_admin',function($filter) use ($id, $callback, $stt ) {

		if ( is_int($stt) ){

			$sidebar1 = array_slice($filter, 0 , $stt - 1);
			$sidebar2 = array_slice($filter,$stt - 1);
	  // dd($sidebar1);
			$sidebar = $callback();

			if($id){
				$sidebar1[$id] = $sidebar;
			}else{
				$sidebar1[] = $sidebar;
			}
			$filter = array_merge($sidebar1, $sidebar2);

		} 

		return $filter;

	});

}


/**

  PERMISSION

*/

function check_permission($name)
{
	if(!Auth::check()){
		return false;
	}

	$permission = Auth::user()->permission;

	$permission = explode(', ',  $permission );

	if( is_string($name) ){
		return array_search($name,$permission) !== false;
	}

	if( is_array($name) ){

		foreach ($name as $p) {
			if( array_search($p, $permission) === false ){
				return false;
			}
		}

		return true;

	}

	return false;
}

function register_group_permission(array $list_id_parent, $id ,$title ){

	add_filter('register_group_permission',function($filter) use ($list_id_parent,$id, $title) {

		$templ = &$filter;

		foreach ($list_id_parent as $value) {

			if( !isset($templ[$value]) ){
				return false;
			}else{
				$templ = &$templ[$value]['list_group_children'];
			}

		}

		$templ[$id] = ['title'=>$title,'list_group_children'=>[]];

		return $filter;

	});

}


  function register_permission( $group, $id, $title ){

  	add_filter('register_permission',function($filter) use ($group,$id, $title) {

  		$filter[$id] = ['title'=>$title, 'group'=>$group];

  		return $filter;

  	});

  }

register_group_permission(['group_permission_page'],'group_permission_page_menu','Appearance Menu');
register_permission('.group_permission_page.group_permission_page_menu','appearance_menu_client_edit','Edit Menu');
register_permission('.group_permission_page.group_permission_page_menu','appearance_menu_client_delete','Delete Menu');



/**

  TEMPLATE

*/


/**
TAB
*/
function vn4_tabs_left($tabs,  $new_link = false){

	$param = get_param('vn4-tab-left',false);

	$tab_current = Input::get('vn4-tab-left',key($tabs));

	if( !isset($tabs[$tab_current]) ){ $tab_current = key($tabs); }

	if( !$param ) $param = '?vn4-tab-left='; else $param = '?'.$param.'&vn4-tab-left=';


	if( $new_link ){
		?>
		<div class="vn4_tabs_left">
			<div class="menu-left">
				<ul>
					<?php foreach( $tabs as $key_tab => $tab ): ?>
					<li  class="<?php if($tab_current === $key_tab): ?> active <?php endif; echo 'tab_control_'.$key_tab; ?>"><a class="new-link" aria-controls="<?php echo $key_tab; ?>" href="<?php echo $param.$key_tab; ?>">
						<?php echo $tab['title']; ?>
					</a></li>
				<?php endforeach; ?>

			</ul>
		</div>
		<div class="content-right">
			<div class="tab content-tab-<?php echo $tab_current; ?> active " >

				<?php $tabs[$tab_current]['content'](); ?>

			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	<?php
}else{
	?>
	<div class="vn4_tabs_left">
		<div class="menu-left">
			<ul>
				<?php foreach( $tabs as $key_tab => $tab ): ?>
				<li  class="<?php if($tab_current === $key_tab): ?> active <?php endif; echo 'tab_control_'.$key_tab; ?>"><a aria-controls="<?php echo $key_tab; ?>" href="<?php echo $param.$key_tab; ?>">
					<?php echo $tab['title']; ?>
				</a></li>
			<?php endforeach; ?>

		</ul>
	</div>
	<div class="content-right">
		<?php foreach( $tabs as $key_tab => $tab ): ?>
		<div class="tab content-tab-<?php echo $key_tab; if($tab_current === $key_tab): ?> active <?php endif; ?> " >

			<?php $tab['content'](); ?>

		</div>

	<?php endforeach; ?>
</div>
<div class="clearfix"></div>
</div>
<?php
}

}

function vn4_tabs_top($tabs, $new_link = false){

	$param = get_param('vn4-tab-top',false);

	$tab_current = Input::get('vn4-tab-top',key($tabs));

	if( !isset($tabs[$tab_current]) ){ $tab_current = key($tabs); }

	if( !$param ) $param = '?vn4-tab-top='; else $param = '?'.$param.'&vn4-tab-top=';

	if( $new_link ){
		?>
		<div class="vn4_tabs_top">
			<div class="menu-top">
				<?php foreach( $tabs as $key_tab => $tab ): ?>
				<a href="<?php echo $param.$key_tab; ?>" class="new-link <?php if($key_tab === $tab_current): ?>  active <?php endif; echo 'tab_control_'.$key_tab; ?>" aria-controls="<?php echo $key_tab; ?>" ><?php echo $tab['title']; ?></a>
			<?php endforeach; ?>

		</div>

		<div class="content-bottom">

			<div class="tab-content-<?php echo $tab_current; ?> active">

				<?php $tabs[$tab_current]['content'](); ?> 

				<div class="clearfix"></div>
			</div>

		</div>
		<div class="clearfix"></div>
	</div>
	<?php
}else{
	?>
	<div class="vn4_tabs_top">
		<div class="menu-top">
			<?php foreach( $tabs as $key_tab => $tab ): ?>
			<a href="#" class=" <?php if($key_tab === $tab_current): ?>  active <?php endif; echo 'tab_control_'.$key_tab; ?>" aria-controls="<?php echo $key_tab; ?>" ><?php echo $tab['title']; ?></a>
		<?php endforeach; ?>

	</div>
	<div class="content-bottom">

		<?php foreach ($tabs as $key_tab => $tab): ?>
		<div class="<?php echo 'tab-content-'.$key_tab; if($key_tab === $tab_current): ?> active <?php endif; ?> ">

			<?php $tab['content'](); ?> 

			<div class="clearfix"></div>
		</div>
	<?php endforeach; ?>

</div>
<div class="clearfix"></div>
</div>
<?php
}

}


/**
Panel
*/
function vn4_panel($title, $content, $plugin_collapse = true,  $plugin = null, $arrayParamert = array()){
	?>
	<div class="x_panel">
		<div class="x_title">
			<h2><?php if( is_string($title)) echo $title; elseif(is_callable($title)) $title(); ?>
				<?php if( isset($arrayParamert['callback_title']) && is_callable($content) ) $arrayParamert['callback_title'](); ?>
			</h2>
			<ul class="nav navbar-right panel_toolbox">
				<?php if( is_string($plugin)) echo $plugin; elseif(is_callable($plugin)) $plugin(); ?>

				<?php 
				if( $plugin_collapse === true ){
					echo '<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>';
				}
				?>

			</ul>
			<div class="clearfix"></div>
		</div>
		<div class="x_content">
			<?php if( is_string($content)) echo $content; elseif(is_callable($content)) $content(); ?>
		</div>
	</div>
	<?php
}


/**
Tool
*/

if( !function_exists('vn4_register_tool')){

	/**
	 * Thêm 1 công cụ
	 * $id: định danh của công cụ
	 * $title: tiêu đề
	 * $description: mô tả
	 * $title-button: tiêu đề cho button
	 * $link: đường dẫn của button
	 */
	function vn4_register_tool($callback){


		add_function('vn4_register_tool',function() use ($callback) {

			$input = $callback();

			if( !isset($input[0]) ){
				$title = '';$description = ''; $id = str_random(10);$link = '#';
				extract($input);

				?>
				<div class="x_panel" id="<?php echo $id; ?>">
					<div class="x_title">
						<h2><label><?php echo $title; ?></label></h2>
						<ul class="nav navbar-right panel_toolbox">
							<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
							</li>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<p class="note"><?php echo $description; ?></p><br>
						<a class="vn4-btn vn4-btn-blue" href="<?php echo $link; ?>"><?php echo $button; ?></a>
					</div>
				</div>
				<?php
			}else{
				foreach ($input as $tool) {
					$title = '';$description = ''; $id = str_random(10);$link = '#';
					extract($tool);

					?>
					<div class="x_panel" id="<?php echo $id; ?>">
						<div class="x_title">
							<h2><label><?php echo $title; ?></label></h2>
							<ul class="nav navbar-right panel_toolbox">
								<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
								</li>
							</ul>
							<div class="clearfix"></div>
						</div>
						<div class="x_content">
							<p class="note"><?php echo $description; ?></p><br>
							<a class="vn4-btn vn4-btn-blue" href="<?php echo $link; ?>"><?php echo $button; ?></a>
						</div>
					</div>
					<?php
				}
			}
		});
	}
}

/**
 
*/

function vn4_create_session_message( $title , $content , $status , $flash = false  ){
    
    if( $flash ){

        Session::flash('message',['title'=>$title,'content'=>$content,'status'=>$status]);

    }else{

        Session::put('message',['title'=>$title,'content'=>$content,'status'=>$status]);

    }
}


function get_sidebar_admin_object(){

    if ( isset($GLOBALS['function_helper_get_sidebar_admin_object']) ){
        return $GLOBALS['function_helper_get_sidebar_admin_object'];
    }

    $sidebar = include __DIR__.'/object_cms/sidebar_admin.php';
    $GLOBALS['function_helper_get_sidebar_admin_object'] = $sidebar;

    return $sidebar;
}

function way_show($post){

    $customPost = get_admin_object($post->type);

    if( isset($customPost['way_show']) ){
        return $post->{$customPost['way_show']};
    }

    return $post->{key($customPost['fields'])};

}

function register_image_size($post_type, $field, array $size){

    add_filter('object_admin',function($list) use ($post_type, $field, $size){

        if( isset($list[$post_type]['fields'][$field]) && $list[$post_type]['fields'][$field]['view'] === 'image' ){
            $list[$post_type]['fields'][$field] = array_merge($list[$post_type]['fields'][$field], $size);
        }

        return $list;
    });
}

function get_setting_object(){

    if ( isset($GLOBALS['get_setting_object']) ){
        return $GLOBALS['get_setting_object'];
    }

    $object = include __DIR__.'/object_cms/setting.php';
    $GLOBALS['get_setting_object'] = $object;
    return $object;
}


function check_post_layout($post_type, $layout_name){

    $admin_object = get_admin_object($post_type);

    if( isset($admin_object['layout']) ){

        if( (is_string($admin_object['layout']) && $admin_object['layout'] === $layout_name) || (is_array($admin_object['layout']) && array_search($layout_name, $admin_object['layout']) !== false ) ){
            return true;
        }

        return false;

    }

    return true;

}