<?php
$sidebar[] = [
     'title'=>__('Home'),
     'url'=>route('admin.index'),
     'icon'=>'fa-home'
];

$sidebar[] =  [
    'title'=>__('Post'),
    'icon'=>'fa-pencil',
    'submenu'=>[
        'a'=>[
            'title'=>__('All Posts'),
            'url'=>route('admin.show_data',['type'=>'post']),
        ],
        'b'=>[
            'title'=>__('Add New'),
            'url'=>route('admin.create_data',['type'=>'post']),
        ],
        'c'=>[
            'title'=>__('Categories'),
            'url'=>route('admin.create_and_show_data',['type'=>'category']),
        ],
        'd'=>[
            'title'=>__('Tags'),
            'url'=>route('admin.create_and_show_data',['type'=>'tag']),
        ],
    ]
];


$sidebar[] = [
    'title'=>__('Page'),
    'icon'=>'fa-clipboard',
    'submenu'=>[
        [
            'title'=>__('All Pages'),
            'url'=>route('admin.show_data',['type'=>'page']),
            'permission'=>['page_list'],
        ],
        [
            'title'=>__('Add New'),
            'url'=>route('admin.create_data',['type'=>'page']),
        ],
    ]
];

// $sidebar[] = [
//     'title'=>__('Comment'),
//     'icon'=>'fa-comments-o',
//     'url'=>route('admin.show_data',['type'=>'comment']),
// ];

// $admin_object = get_admin_object();



// $sidebar[] = [
//     'title'=>$admin_object['post']['title'],
//     'icon'=>'fa-pencil',
//     'submenu'=>[
//         'a'=>[
//             'title'=>trans('master.menu_left_all_post'),
//             'url'=>route('admin.show_data',['type'=>'post']),
//         ],
//         'b'=>[
//             'title'=>trans('master.menu_left_create_post'),
//             'url'=>route('admin.create_data',['type'=>'post']),
//         ],
//         'c'=>[
//             'title'=>$admin_object['category']['title'],
//             'url'=>route('admin.create_and_show_data',['type'=>'category']),
//         ],
//         'd'=>[
//             'title'=>$admin_object['tag']['title'],
//             'url'=>route('admin.create_and_show_data',['type'=>'tag']),
//         ],
//     ]
// ];

// $sidebar[] = [
//     'title'=>$admin_object['page']['title'],
//     'icon'=>'fa-clipboard',
//     'submenu'=>[
//         'a'=>[
//             'title'=>trans('master.menu_left_all_page'),
//             'url'=>route('admin.show_data',['type'=>'page']),
//         ],
//         'aa'=>[
//             'title'=>trans('master.menu_left_create_page'),
//             'url'=>route('admin.create_data',['type'=>'page']),
//         ],
//     ]
// ];





$sidebar = apply_filter('add_sidebar_admin',$sidebar);

$sidebar[] = [
  'title'=>__('Manager'),
  'not-menu'=>true,
];

$sidebar['media'] = [
    'title'=>__('Media'),
    'icon'=>'fa-archive',
    'url'=>route('admin.page',['page'=>'media']),
    'permission'=>['media_view'],
];

$sidebar['user'] = [
  'title'=>__('User'),
  'icon'=>'fa-user',
  'submenu'=>[
    'a'=>[
        'title'=>__('All User'),
        'url'=>route('admin.show_data',['type'=>'user']),
        'permission'=>['user_list'],
    ],
    'b'=>[
        'title'=>__('Create User'),
        'url'=>route('admin.page',['page'=>'user-new']),
        'permission'=>['user_create'],
    ],
    'c'=>[
        'title'=>__('Profile'),
        'url'=>route('admin.page',['type'=>'profile']),
        'permission'=>['profile_view'],
    ],
    'd'=>[
        'title'=>__('User Role Editor'),
        'url'=>route('admin.page',['type'=>'user-role-editor']),
        'permission'=>['user-role-editor_view'],
    ],
  ]  
];

$sidebar['appearance'] = [
  'title'=>__('Appearance'),
  'icon'=>'fa-paint-brush',
  'submenu'=>[
    'a'=>[
        'title'=>__('Theme'),
        'url'=>route('admin.page',['page'=>'appearance-theme']),
        'permission'=>['appearance-theme_view'],
    ],
    'b'=>[
        'title'=>__('Widget'),
        'url'=>route('admin.page',['page'=>'appearance-widget']),
        'permission'=>['appearance-widget_view'],
    ],
    'c'=>[
        'title'=>__('Menu'),
        'url'=>route('admin.page',['page'=>'appearance-menu']),
        'permission'=>['appearance-menu_view'],
    ],
  ]  
];

$sidebar['tool'] = [
  'title'=>__('Tool'),
  'icon'=>'fa-wrench',
  'submenu'=>[
    'a'=>[
      'title'=>__('All Tool'),
      'url'=>route('admin.page',['page'=>'tool-genaral']),
      'permission'=>['tool-genaral_view'],
    ]
  ]
];

$sidebar['plugin'] = [
  'title'=>__('Plugin'),
  'icon'=>'fa-plug',
  'url'=>route('admin.page',['page'=>'plugin']),
  'permission'=>['plugin_view'],
];



$sidebar['setting'] = [
  'title'=>__('Setting'),
  'icon'=>'fa-cog',
  'submenu'=>[
      ['title'=>__('General'),'url'=>route('admin.setting'),'permission'=>['view_setting']],
      ['title'=>__('Language'),'url'=>route('admin.page',['page'=>'language']),'permission'=>['language_view']]
  ],
];


$sidebar = apply_filter('add_sidebar_admin_plugin',$sidebar);

$sidebar = apply_filter('sidebar_admin',$sidebar);

return $sidebar;


