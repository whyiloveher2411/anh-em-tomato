<?php


check_key();

$object['category'] = [
    'table'=>vn4_tbpf().'tag',
    'title'=>__('Category'),
    'way_show'=>'title',
    'fields'=>[
        'title'=>[
            'title'=>__('Title'),
            'view'=>'input',
            'type'=>'text',
            'required'=>true,
            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
        ],
        'slug' => [
            'title'=>__('Slug'),
            'view' =>'slug',
            'key_slug'=> 'title',
            'type' =>'text',
            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
        ],
        'parent' => [
            'title'=>__('Parent'),
            'view' =>'relationships_mm',
            'show_data'=>false,
            'object_relationship'=>'category',
            // 'show_child'=>false,
            'note'=>'Chuyên mục khác với thẻ, bạn có thể sử dụng nhiều cấp chuyên mục. Ví dụ: Trong chuyên mục nhạc, bạn có chuyên mục con là nhạc Pop, nhạc Jazz. Việc này hoàn toàn là tùy theo ý bạn.'
        ],
        'count_post'=>[
            'title'=>__('Count post'),
            'view'=>'input',
            'type'=>'number',
            'not_create_and_update'=>true,
        ],
        'description' => [
            'title'=>__('Description'),
            'show_data'=>false,
            'view' =>'textarea',
            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
        ],
    ],
];

$object['post'] = [
    'table'=>vn4_tbpf().'post',
    'title'=> __('Post'),
    'way_show'=>'title',
    'fields'=>[
        'title'=>[
            'title'=>__('Title'),
            'view'=>'input',
            'type'=>'text',
            'required'=>true,
        ],
        'slug' => [
            'title'=>__('Slug'),
            'view' =>'slug',
            'key_slug'=>'title',
            'type' => 'text',
            'show_data'=>false,
        ],
        'description' => [
            'title'=>__('Description'),
            'view' =>'textarea',
            'show_data'=>false,
        ],
        'content' => [
            'title'=>__('Content'),
            'view' =>'editor',
            'show_data'=>false,
            'required'=>true,
        ],
         'category' => [
            'title'=>__('Category'),
            'view' =>'relationships_nn',
            'show_data'=>true,
            'advance'=>'right',
        ],
        'tag' => [
            'title'=>__('Tag'),
            'view' =>'relationships_nn',
            'type'=>'tags',
            'show_data'=>true,
            'advance'=>'right',
        ],
        'image' => [
            'title'=>__('Featured Image'),
            'view' =>'image',
            'required'=>true,
            'advance'=>'right',
            'note'=>'featured image is the way it appears on your website'],
    ],
];

$object['tag'] =  [
    'table'=>vn4_tbpf().'tag',
    'title'=> __('Tag'),
    'way_show'=>'title',
    'fields'=>[
        'title'=>[
            'title'=>__('Title'),
            'view'=>'input',
            'type'=>'text',
            'required'=>true,
            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
        ],
        'slug' => [
            'title'=>__('Slug'),
            'view' =>'slug',
            'key_slug'=> 'title',
            'type' =>'text',
            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
        ],
        'count_post'=>[
            'title'=>__('Count post'),
            'view'=>'input',
            'type'=>'number',
            'not_create_and_update'=>true,
        ],
        'description' => [
            'title'=>__('Description'),
            'show_data'=>false,
            'view' =>'textarea',
            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
        ],
    ],
];

$object['page'] = [
    'table'=>vn4_tbpf().'page',
    'title'=>__('Page'),
    'way_show'=>'title',
    'fields'=>[
        'title'=>[
            'title'=>__('Title'),
            'view'=>'input',
            'type'=>'text',
            'required'=>true,
        ],
        'slug' => [
            'title'=>__('Slug'),
            'view' =>'slug',
            'key_slug'=> 'title',
            'type' => 'text',
        ],
        'content' => [
            'title'=>__('Content'),
            'view' =>'editor',
            'show_data'=>false,
            'required'=>true,
        ],
        'template' => [
            'title'=>__('Template'),
            'view'=>function(){

                return [

                    'form'=> function($options){

                        $files = glob(public_path().'/../resources/views/theme/'.theme_name().'/post-type/page-template/*.php');

                        $select = '<select name="'.$options['key'].'" class="form-control">';

                        foreach ($files as $f){

                            $name = explode('/', $f);

                            $name = substr(end($name), 0, -10);

                            $file_content = File::get($f);

                            $tokens = token_get_all($file_content);

                            $comment_first = ucwords(preg_replace('/-/', ' ', str_slug($name)));

                            foreach($tokens as $token) {
                                if($token[0] == T_COMMENT || $token[0] == T_DOC_COMMENT) {
                                    $comment_first = $token[1];
                                    break;
                                }
                            }

                            $select .= '<option '.($name === $options['value']? 'selected':'').' value="'.$name.'">'.__t(trim(preg_replace('/[\/\*\r\n]/', '', $comment_first))).'</option>';

                        }

                        $select  .= '</select>';
                        
                        return $select;
                    },

                ];

            },
            'advance'=>'right',
            'note'=>'Template is the way it appears on your website'],
    ],
];

$object = apply_filter('object_admin',$object);
$object = apply_filter('register_post_type',$object);

$object['user'] = [
    'table'=>vn4_tbpf().'user',
    'title'=>__('User'),
    'layout'=>'show_data',
    'fields' => [
        'email' => [
            'title'=>__('Email'),
            'view' =>'input',
            'type' => 'email',
            'unique'=>true,
            'note'=>'Email dùng để đăng nhập.'],
        'first_name'=>[
            'title'=>__('First Name'),
            'view'=>'input',
            'type'=>'text',
        ],
        'last_name'=>[
            'title'=>__('Last Name'),
            'view'=>'input',
            'type'=>'text',
        ],
        'password'  => [
            'title'=>__('Password'),
            'show_data'=>false,
            'view' =>'password',
            'note'=>'Password dùng để đăng nhập vào user'
        ],
    ],
    'row_actions'=>function($post, $row_actions){

        if( check_permission('user_edit') && !$post->is_trash() )
        $row_actions['edit'] = '<a href="'.route('admin.page',['page'=>'user-new','post'=>$post->id,'ref'=>'row_actions']).'"><strong>Edit</strong></a>';

        return $row_actions;
    },
    'region_title_data_table'=>function(){
        if( check_permission('user_create') ){
            echo '<a class="vn4-btn" href="'.route('admin.page',['page'=>'user-new','ref'=>'button_title_data_table']).'">'.__('Add new User').'</a>';
        }
    },
    'show_in_nav_menus'=>false,
    'public'=>false,
];

$object = apply_filter('object_admin_all',$object);

return $object;







