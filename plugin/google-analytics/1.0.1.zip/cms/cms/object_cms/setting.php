<?php 
    
$setting['general'] = [
    'title'=>__('General'),
    'fields'=>[
        'status'=>[
            'title'=>__('Status Site'),
            'view'=>'input',
            'type'=>'radio',
            'list_option'=>['developing'=>'Developing', 'active'=>'Active'],
            'note'=>'Một số chức năng sẽ được kích hoạt khi website chuyển đổi trạng thái, view sẽ tự động minify, nên vui lòng kiểm tra lỗi javascript,css,html trước khi bật',
        ],
        'site_title'=>[
            'title'=>__('Site Title'),
            'view'=>'input',
            'type'=>'text',
        ],
        'logo'=>[
            'title'=>__('Logo'),
            'view'=>'image',
        ],
        'description'=>[
            'title'=>__('Description'),
            'view'=>'input',
            'type'=>'text',
            'note'=>__('In a few words, explain what this site is about'),
        ],
        'email_address'=>[
            'title'=>__('Email Address'),
            'view'=>'input',
            'type'=>'email',
            'note'=>__('This address is used for admin purposes, like new user notification'),
        ],
        'timezone'=>[
            'title'=>__('Timezone'),
            'view'=>'input',
            'type'=>'text',
            'note'=>__('Choose a city in the same timezone as you'),
        ],
        'date_format'=>[
            'title'=>__('Date Format'),
            'view'=>'input',
            'type'=>'radio',
            'list_option'=>['F j, Y'=>date('F j, Y'),'Y-m-d'=>date('Y-m-d'),'m/d/Y'=>date('m/d/Y'),'d/m/Y'=>date('d/m/Y')],
            'input_custom'=>'getFormatDateTime',
        ],
        'time_format'=>[
            'title'=>__('Time Format'),
            'view'=>'input',
            'type'=>'radio',
            'list_option'=>['g:i a'=>date('g:i a'),'g:i A'=>date('g:i A'),'H:i'=>date('H:i')],
            'input_custom'=>'getFormatDateTime',
        ],
    ]
];



$setting['security'] = [
    'title'=>__('Security'),
    'fields'=>[    
        'prefix_link_admin'=>[
            'title'=>__('Prefix Link Admin'),
            'view'=>'input',
            'type'=>'text',
            'value_default'=>'admin',
            'note'=>__('Do not use the following words: {admin}, {backend}, {user} .... keep it secret only you and the site administrator know')
        ],
        'link_login'=>[
            'title'=>__('Link Login'),
            'view'=>'input',
            'type'=>'text',
            'value_default'=>'login',
            'note'=>__('Do not use the following words: {login}, {signin},.... keep it secret only you and the site administrator know')
        ],
      
    ]
];

$setting = apply_filter('setting',$setting);

return $setting;