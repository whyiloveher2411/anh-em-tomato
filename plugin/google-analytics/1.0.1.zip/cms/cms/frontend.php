<?php


function theme_asset($file = ''){
	if( $file === ''){
		return asset('public/theme/'.theme_name().'/').'/';
	}
	return asset('public/theme/'.theme_name().'/'.$file);
}


function body_class( $class = '' ){

	return 'class="' . trim(join( ' ', apply_filter('body_class',[$class]) )) . '"';

}

function add_body_class( $class ){

	add_filter('body_class',function($filter) use ($class) {

		if( is_string( $class ) ){

			if( false === array_search($class, $filter) ){
				$filter[] = $class;
			}

		}elseif( is_array( $class )){

			foreach ($class as $c) {
				if( false === array_search($c, $filter) ){
					$filter[] = $c;
				}
			}

		}

		return $filter;

	});

}

function vn4_register_style($id, $source, $version = 1, $media = 'all', $in_footer = false ){

	if( $in_footer ){
		$GLOBALS['vn4_footer_style'][] = '<link id="style-'.$id.'" href="'.$source.'?v='.$version.'" rel="stylesheet" media="'.$media.'">';
	}else{
		$GLOBALS['vn4_head_style'][] = '<link id="style-'.$id.'" href="'.$source.'?v='.$version.'" rel="stylesheet" media="'.$media.'">';
	}

	return true;
}

function vn4_register_script($id, $source, $version = 1, $in_footer = true){

	if( $in_footer ){
		$GLOBALS['vn4_enqueue_scripts'][] = '<script id="script-'.$id.'" type="text/javascript" src="'.$source.'?v='.$version.'"></script>';
	}else{
		$GLOBALS['vn4_head_style'][] = '<script id="script-'.$id.'" type="text/javascript" src="'.$source.'?v='.$version.'"></script>';
	}

	return true;

}


function the_header($header = 'header'){

	do_action('before_header');

	$them = theme_name();

	$view = vn4_view('theme.'.$them.'.'.$header);

	if(Auth::check()){
		$view = vn4_view('nav-top').$view;
	}

	echo $view;
}









function the_footer($footer = 'footer'){

	do_action('before_footer');

	$them = theme_name();

	echo theme_view($footer);

	if( isset($GLOBALS['vn4_footer_style'][0]) ){
		foreach ($GLOBALS['vn4_footer_style'] as $style) {
			echo $style;
		}
	}

	if( isset($GLOBALS['vn4_enqueue_scripts'][0]) ){
		foreach ($GLOBALS['vn4_enqueue_scripts'] as $script) {
			echo $script;
		}
	}

	do_action('vn4_footer');

	return '';


// vn4_footer();
}

function get_particle($particle, $arg = array() ){

	do_action('get_particle'.$particle);
	return vn4_view('theme.'.theme_name().'.'.$particle, $arg);    

}

function vn4_head(){

	do_action('before_vn4_head');

	$title = apply_function('title_head',__t(setting('general_description','A simple website using Vn4CMS')));

	echo '<title>'.$title.' &laquo; '.__t(setting('general_site_title','Vn4CMS')).'</title>';

	$list_meta = do_action('meta');

	if( is_array($list_meta) ){

		foreach ($list_meta as $meta) {
			echo $meta;
		}
	}

	if( isset($GLOBALS['vn4_head_style'][0]) ){
		foreach ($GLOBALS['vn4_head_style'] as $style) {
			echo $style;
		}
	}

	do_action('vn4_head');

}


function theme_extends($name = 'master'){
	return 'theme.'.theme_name().'.layout.'.$name;
}

function get_page_current(){

	$route_name = Route::currentRouteName();

	if( $route_name === 'page2' ){
		return Route::current()->getParameter('page_current');
	}

	return request()->get('page',1);
}

function get_pagination( $paginator ,$theme = 'pagination.default'){
	return vn4_view($theme,['paginator'=>$paginator]);
}


function vn4_nav_menu($argParam, $view = null){

	if( is_string($argParam) ){
		$key = $argParam;
		$argParam = ['key'=>$argParam];
	}elseif( is_array($argParam) && isset($argParam['key']) ){
		$key =  $argParam['key'];
	}

	$result = '';

	if( isset($key) ){

		if( !isset($GLOBALS['vn4_nav'][$key]) ){

			$obj = new Vn4Model(vn4_tbpf().'menu');

			$theme = theme_name();

			$obj = $obj->where('key_word',$key)->whereTheme($theme)->first();

			if( !$obj ){

				$json = [];

			}else{

				$json = json_decode($obj->json,true);

			}

			$json2 = do_action('vn4_nav_menu',$json, $key);

			if( $json2 ) $json = $json2;

			$GLOBALS['vn4_nav'][$key] = $json;

		}

		$json = $GLOBALS['vn4_nav'][$key];
		

		if( is_callable($view) ){

			$result = $view($json, $view);

		}else{

			if( $view === null ){
				$result = vn4_view('default.nav',['menu'=>$json],$argParam);
			}else{
				$result = vn4_view('theme.'.theme_name().'.nav.'.$view ,['menu'=>$json],$argParam );
			}
			
		}
		
	}

	return $result;

}

function get_link_menu($menu_item){

	$menuType = $menu_item['posttype'];

	switch ($menuType) {
		case 'custom links':

			if( is_url($menu_item['links']) ){
				$link = $menu_item['links'];
			}else{
				$link = '';
			}
			
			break;
		case 'page-theme':
			$link = route('page',$menu_item['page']);
			break;

		case 'page-static':
			$link = route($menu_item['route']);
			break;
		default:
			$link = get_permalinks($menu_item['posttype'] , $menu_item['slug']);
			break;
	}

	$link2 = do_action('get_link_menu',$link, $menuType, $menu_item);

	if( $link2 ) $link = $link2;

	return $link;

}

function dynamic_sidebar($id_sidebar){

	$id_sidebar2 = do_action('dynamic_sidebar',$id_sidebar);

	if( $id_sidebar2 ) $id_sidebar = $id_sidebar2;

	$sidebar = DB::table(vn4_tbpf().'widget')->where('sidebar_id',$id_sidebar)->where('theme',theme_name())->take(1)->select('meta','content')->first();

	if( $sidebar ){

		$sidebar_register = json_decode($sidebar->content,true);

		$sidebar_widget = json_decode($sidebar->meta, true);

		foreach ($sidebar_widget as  $widget_instance) {

			$class_name = array_shift($widget_instance);

			if( class_exists ($class_name) ){

				$widget = new $class_name();

				$widget->update_instance($widget_instance);

				if( isset($sidebar_register['before_widget']) &&  isset($sidebar_register['after_widget']) ){
					echo $sidebar_register['before_widget'];
				}

				$widget->widget();

				if( isset($sidebar_register['before_widget']) &&  isset($sidebar_register['after_widget']) ){
					echo $sidebar_register['after_widget'];
				}


			}

		}

	}

}

/**
	SHORTCODE
*/
function load_shortcode_posttype(){

	$admin_object = get_admin_object();

	foreach ($admin_object as $object_key => $object) {

		add_shortcode( $object_key, function($param, $content) use ($object_key){

			extract( shortcode_atts([
				'id'=>false,
				'slug'=>false,
				], $param) );

			$param['is_shortcode'] = true;

			if( $id ){

				$post = get_post($object_key, $id);

				if( $post ){
					$param['post'] = $post;
					return get_single_post($post, $param);

				}
			}

			return;

		} );
	}
}


function shortcode_atts( $param_default, $param ){

	foreach ($param_default as $key => $value) {
		if( !isset($param[$key]) || !trim($param[$key]) ){
			$param[$key] = $value;
		}
	}

	return $param;
}

function do_shortcode($content, $list_short_code = false, $only_content_shortcode = false){
// preg_match_all( '/\[([\S]+.*?)[\s]*([\S]+.*?)[\s]*\/\]|\[([\S]+.*?)[\s]*([\S]+.*?)\]/', $content, $shortcodes );

	if( $list_short_code ){
		$all_shortcode = $list_short_code;
	}else{
		$all_shortcode = apply_filter('add_shortcode',[]);
	}

	preg_match_all( '/\\[(\\[?)('.implode('|', array_keys($all_shortcode)).')(?![\\w-])([^\\]\\/]*(?:\\/(?!\\])[^\\]\\/]*)*?)(?:(\\/)\\]|\\](?:([^\\[]*+(?:\\[(?!\\/\\2\\])[^\\[]*+)*+)\\[\\/\\2\\])?)(\\]?)/', $content, $shortcodes );

	$count = count($shortcodes[0]);

	$array_key = array_keys($all_shortcode);

	$str_result = '';

	for ($i=0; $i < $count; $i++) { 

	//type 1: not tag close, not content
		$string_replace = $shortcodes[0][$i];
		$shortcode_content = $shortcodes[5][$i];
		$shortcode_name = $shortcodes[2][$i];
		$shortcode_param = $shortcodes[3][$i];

		if( $shortcode_param ){

			preg_match_all('/(.+?)="(.+?)"/', $shortcode_param, $parameter_matches);

			$shortcode_param = [];
			$parameter_count = count($parameter_matches[0]);
			for ($j=0; $j < $parameter_count; $j++) { 
				$shortcode_param[trim($parameter_matches[1][$j])] =  trim($parameter_matches[2][$j]);
			}

		}

		if( $only_content_shortcode ){
			$str_result = $str_result.call_user_func_array ($all_shortcode[$shortcode_name], [$shortcode_param,$shortcode_content] );
		}else{
			$content = str_replace($string_replace, call_user_func_array ($all_shortcode[$shortcode_name], [$shortcode_param,$shortcode_content] ) , $content);
		}

	}

	if( $only_content_shortcode ){
		return $str_result;
	}else{
		return $content;
	}

}

function add_shortcode( $name, $callback ){

	add_filter('add_shortcode',function($filter) use ($name, $callback) {

		if( !isset($filter[$name]) ){
			$filter[$name] = $callback;
		}

		return $filter;

	});
}


/**
	Template
*/

function get_single_post( $post, $arg = array() ){

	$arg['post'] = $post;

	if( $post->visibility === 'password' && session($post->type.'_password_'.$post->id,false) !== $post->password ) return vn4_view('default.post-type.post-protected',$arg);

	$theme_name = theme_name();

	if( view()->exists('theme.'.$theme_name.'.post-type.'.$post->type.'-single-'.$post->id ) ) {
		$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-single-'.$post->id;
	}elseif( view()->exists('theme.'.$theme_name.'.post-type.'.$post->type.'-single-'.$post->slug ) ) {
		$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-single-'.$post->slug;
	}elseif( view()->exists('theme.'.$theme_name.'.post-type.'.$post->type.'-single' ) ){
		$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-single';
	}else{
		$view = false;
	}

	if( $view !== false ) return vn4_view($view,$arg);

	return;

}

function get_single_post2( $type, $id, $arg = array() ){

	$post = get_post($type, $id);
	if( $post ) return get_single_post($post,$arg);

}

/**
	POST
*/

function view_post( $post ){

	if( !$post->exists ){
		return errorPage(404,'Page note found');
	}

	if( $post->visibility === 'password' &&  Session::get($post->type.'_password_'.$post->id, false) !== $post->password ) return redirect()->back();

	$theme_name = theme_name();

	load_shortcode_posttype();

	$view = '';

	$register_template = apply_filter('register_template');

	if( array_search($post->type, $register_template) !== false ){

		if( $post->template ){
			$view =  'theme.'.$theme_name.'.post-type.'.$post->type.'-template.'.$post->template;
		}
	}

	if( !view()->exists($view) ){

		$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-content';

		if( view()->exists('theme.'.$theme_name.'.post-type.'.$post->type.'-content-'.$post->id ) ) {
			$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-content-'.$post->id;
		}elseif( view()->exists('theme.'.$theme_name.'.post-type.'.$post->type.'-content-'.$post->slug ) ) {
			$view = 'theme.'.$theme_name.'.post-type.'.$post->type.'-content-'.$post->slug;
		}

	}

	if( !view()->exists($view) ){
		return errorPage(404,'Page note found');
	}

	add_body_class(['post-detail',$post->type]);

	title_head($post->title);

	$GLOBALS['post_current'] = $post;

	add_action('vn4_adminbar',function() use ($post) {
		echo '<li class="li-title"><a href="'.route('admin.create_data',['type'=>$post->type,'post'=>$post->id,'action_post'=>'edit','rel'=>'vn4-adminbar']).'" target="_blank"><i class="fa fa-pencil" aria-hidden="true"></i>'.__('Edit Post').'</a></li>';
	});

	$update_view = Cookie::get('update-view',[]);

	if( !isset($update_view[$post->type.'-'.$post->id]) ){
		
		$post->view = $post->view + 1;
		$post->save();
		$update_view[$post->type.'-'.$post->id] =  true;

		Cookie::queue('update-view', $update_view, 1140);

	}

	return vn4_view($view,['post'=>$post]);
}

