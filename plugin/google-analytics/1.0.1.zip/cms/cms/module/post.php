<?php

if ( !function_exists('vn4_get_post_count_status') ){

    function vn4_get_post_count_status( $admin_object, $type, &$arg_where_count = null, $status = null ){

        $table = $admin_object['table'];
        
        $arg_where_count = [
            'status_'=>['key'=>'status','value'=>'','dk'=>'!=','identification'=>__('All')],
            'status_publish'=>['key'=>'status','value'=>'publish','identification'=>__('Published')],
            'post_date_gmt_'=>['key'=>'post_date_gmt','value'=>'','dk'=>'!=', 'identification'=>__('Future')],
            'status_draft'=>['key'=>'status','value'=>'draft','identification'=>__('Drafts')],
            'status_pending'=>['key'=>'status','value'=>'pending','identification'=>__('Pending')],
            'visibility_private'=>['key'=>'visibility','value'=>'private','identification'=>__('Private')],
            'visibility_password'=>['key'=>'visibility','value'=>'password','identification'=>__('Password protected')],
            'status_trash'=>['key'=>'status','value'=>'trash','identification'=>'<span style="color:#be0000">'.__('Trash').'</span>']
         ];

        if( isset($admin_object['register_post_status']) ){

            $valueTemp = $admin_object['register_post_status']($arg_where_count);

            if( $valueTemp ) $arg_where_count = $valueTemp;
        }

        add_function('post_filter',function() use ($arg_where_count){
            return $arg_where_count;
         });

        if( isset($GLOBALS['post_php']['button_status']['status']) && $GLOBALS['post_php']['button_status']['status'] === $status ){
            return $GLOBALS['post_php']['button_status'];
        }

        if( !$status ) $status = Input::get('post_filter','status_');

        $str_query_count = '';

        $sql_filter = '';



        if( isset($admin_object['data_filter']) ){
            foreach ($admin_object['data_filter'] as $key_filter => $value) {
                $condition = '=';
                if( is_array($value) && isset($value['value_callback']) && is_callable($value['value_callback']) ){

                    $value = $value['value_callback']();

                    if( isset($value['condition']) ) $condition = $value['condition'];

                }elseif ( is_callable($value) ) {
                    $value = $value();
                }

                $sql_filter = $sql_filter.' AND `'.$key_filter.'`'.$condition.' \''.$value.'\' ';
            }
        }

        foreach ($arg_where_count as $key=>$where) {

            $str_query_count = $str_query_count.', (SELECT COUNT(id) FROM `'.$table.'` WHERE `type` = \''.$type.'\' AND `'.$where['key'].'` '.(isset($where['dk'])?$where['dk']:'=').' \''.$where['value'].'\' '.$sql_filter.') AS `'.$key.'`';

        }

        $str_query_count = 'SELECT '.substr($str_query_count, 1).' FROM dual';
        // dd($str_query_count);
        $counts = DB::select($str_query_count)[0];

        $string_html = '';
        // dd($status);
        // dd($count);
        foreach ( $counts as $key => $count ) {
            // dd($status === $key);
            if( $count != 0 ){
                $string_html = $string_html.'<button class="btn btn-sm post-status '.($status === $key?'btn-primary active':'').'" type="button" data="'.$key.'"> '.(isset($arg_where_count[$key]['identification'])?$arg_where_count[$key]['identification']:'').' ('.$count.')</button>';
            }

        }

        $GLOBALS['post_php']['button_status'] = ['status_count'=>$string_html, 'status'=>$status];
        
        return $GLOBALS['post_php']['button_status'];

    }

}

if( !function_exists('vn4_add_new_post') ){

    function vn4_add_new_post( $admin_object, $input, $type, $save = true ){

        $input['type'] = $type;

        $tableName = null;

        if( isset( $admin_object['table']) ){
          $tableName = $admin_object['table'];
        }

        $tag = new Vn4Model($tableName);

        $tag->fillDynamic($input);

        return $tag;

    }

}
if( !function_exists('vn4_unset_input_not_belong_post') ){

    function vn4_unset_input_not_belong_post( $admin_object, $input, $type ){

        $fields = $admin_object['fields'];

        $fields = apply_filter('add_fields_'.$type,$fields);

        if( isset($input['select-status-password'])  ){

            if( $input['select-status-password'] === 'password' && trim($input['publish-password']) !== '' ){
                $input['password'] = $input['publish-password'];
                $input['visibility'] = 'password';
            }elseif( $input['select-status-password'] == 'private' ){
                $input['visibility'] = 'private';
                
            }else{
                $input['visibility'] = 'publish';
            }
        }


        if( isset($input['publish-date']) &&  isset($input['publish-hour']) && trim( $input['publish-date'] ) !== '' &&  trim( $input['publish-hour'] ) !== '' ){

            $input['post_date_gmt'] = date_format( date_create($input['publish-date'].' '.$input['publish-hour']) , 'Y-m-d H:i:s');

        }else{

            $input['post_date_gmt'] = '';

        }

        $list_default = ['password','visibility','post_date_gmt','status'];

        foreach ($input as $key => $value) {
            if( !isset($fields[$key]) && !in_array( $key , $list_default ) ){
                unset($input[$key]);
            }
        }

        return $input;

    }

}

function encoding_to_html_code($string){
    return mb_convert_encoding(mb_strtolower(trim($string),'UTF-8'),'HTML-ENTITIES');
}

function vn4_create_taxonomy( $taxonomys, $post ){

    foreach ($taxonomys as $taxonomy) {
        // dd($taxonomys);
        if( $taxonomy['relationship_type'] === 'relationships_nn' ){

            if( $taxonomy['type'] === 'input_check' ){

                if ( isset($taxonomy['list_id'][0]) ){

                    $table = $taxonomy['table'];
                    $key = $taxonomy['key'];

                    $list_insert = [];
                    foreach ($taxonomy['list_id'] as $id) {
                        $list_insert[] = ['post_id'=>$post->id,'tag_id'=>$id['id'],'type'=>$key];
                    }

                    DB::table($table)->insert($list_insert);

                    $admin_object = get_admin_object();

                    $list_id = DB::table($table)->where('post_id',$post->id)->where('type',$key)->lists('tag_id');

                    // DB::table($table)->where('post_id',$postId)->where('type',$key)->delete();

                    $list_count_upload = 'UPDATE `'.$admin_object[$key]['table'].'` SET `count_'.str_slug($post->type).'` = CASE id';

                    foreach ($list_id as  $categoryId) {
                        
                        $list_count_upload = $list_count_upload.' WHEN '.$categoryId.' THEN ( SELECT count(`id`) FROM `'.$table.'` WHERE  `tag_id` = '.$categoryId.' AND `type` = \''.$key.'\'  )';

                    }


                    $list_count_upload = $list_count_upload.' END WHERE id in ( '.implode(',', $list_id).' )';

                }

            }elseif( $taxonomy['type'] === 'tags' ){

                DB::table($taxonomy['table'])->where('post_id',$post->id)->where('type',$taxonomy['key'])->where('type',$taxonomy['key'])->delete();

                 if ( isset($taxonomy['tags'][0]) && trim($taxonomy['tags'][0]) !== '' ){

                    $admin_object = get_admin_object();

                    $string_find = $taxonomy['tags'];

                    $table_object = $admin_object[$taxonomy['key']]['table'];

                    $list_insert = [];
                    $post_tags = [];
                    $list_count_upload = 'UPDATE `'.$admin_object[$taxonomy['key']]['table'].'` SET `count_'.str_slug($post->type).'` = CASE id';

                    foreach ($string_find as $title) {

                        $tag = Vn4Model::firstOrAddnew($table_object,['title'=>$title]);

                        if( !$tag->exists ){
                            $tag->slug = registerSlug($title, $taxonomy['key'] , null);
                            $tag->type = $taxonomy['key'];
                            $tag->save();
                        }

                        $list_insert[] = ['post_id'=>$post->id,'tag_id'=>$tag->id,'type'=>$taxonomy['key']];

                        $post_tags[] = $tag;

                        $list_tag_id[] = $tag->id;

                        $list_count_upload = $list_count_upload.' WHEN '.$tag->id.' THEN ( SELECT count(`id`) FROM `'.$taxonomy['table'].'` WHERE  `tag_id` = '.$tag->id.' AND `type` = \''.$taxonomy['key'].'\'  )';

                    }


                    DB::table($taxonomy['table'])->insert($list_insert);

                    if(isset($list_tag_id[0])){
                        $list_count_upload = $list_count_upload.' END WHERE id in ( '.implode(',', $list_tag_id).' )';
                    }else{
                        unset($list_count_upload);
                    }
                    $post->setAttribute($taxonomy['key'], json_encode($post_tags));

                    $post->save();
                }
            }

            if(isset($list_count_upload)){
                DB::update($list_count_upload);
            }
            
        }
    }

}

function vn4_delete_post( $type, $ids ){

    DB::transaction(function () use( $type, $ids ) {

        $list_admin_object = get_admin_object();

        $admin_object = $list_admin_object[$type];

        $table = $admin_object['table'];

        if( is_string($ids) ) $ids = explode(',', $ids);

        foreach ($admin_object['fields'] as $key_field => $field) {

            if( !isset($field['view']) ) $field['view'] = 'input';

            if( $field['view'] === 'relationships_nn' ){

                $table_relationships = $admin_object['table'].'_'.$key_field;

                $relationships = new Vn4Model($table_relationships);

                $list_tag_id = $relationships->whereIn('post_id',$ids)->lists('tag_id');

                if( isset($list_tag_id[0]) ){

                    $list_count_upload = 'UPDATE `'.$list_admin_object[$key_field]['table'].'` SET `count_'.str_slug($type).'` = CASE `id`';

                    foreach ($list_tag_id as $tagid) {
                        $list_count_upload = $list_count_upload.' WHEN '.$tagid.' THEN ( SELECT count(`id`) FROM `'.$table_relationships.'` WHERE  `tag_id` = '.$tagid.' AND `post_id` NOT IN ('.implode(',', $ids).'))';
                    }

                    $list_count_upload = $list_count_upload.' END WHERE `id` in ( '.implode(',', $list_tag_id).' )';

                    DB::update($list_count_upload);

                    $relationships->whereIn('post_id',$ids)->delete();

                }

            }
        }
        foreach ($list_admin_object as $post_type => $object) {

            foreach ($object['fields'] as $key_field => $field) {

                if( !isset($field['view']) ) $field['view'] = 'input';

                if( $field['view'] === 'relationships_nn' && $key_field === $type ){

                    $table_relationships = vn4_tbpf().$post_type.'_'.$key_field ;

                    $relationships = new Vn4Model($table_relationships);

                    $list_post_id = $relationships->whereIn('tag_id',$ids)->lists('post_id','id');

                    //change post
                    $list_post = new Vn4Model($object['table']);

                    $list_post = $list_post->whereIn('id',$list_post_id)->get();

                    foreach ($list_post as $post ) {

                        $list_tag = json_decode($post->{$type},true);

                        $list_tag2 = [];

                        $count = count($list_tag);
                        for ($i=0; $i < $count; $i++) { 
                            if( array_search($list_tag[$i]['id'], $ids ) === false ){
                                $list_tag2[] = $list_tag[$i];
                            }
                        }

                        $post->{$type} = json_encode($list_tag2);

                        $post->save();

                    }

                    $relationships->whereIn('tag_id',$ids)->delete();

                }

            }

        }

        foreach ($ids as $id) {

            $post = Vn4Model::f($type, $id);
            
            if( $post ){

                if( isset($admin_object['action_callback']['delete']) ){
                    $admin_object['action_callback']['delete']($post);
                }

                do_action('delete_post',$post);

                $post->delete();

            }

        }

        // DB::table($table)->where('type',$type)->whereIn('id',$ids)->delete();

    });
}

function vn4_trash_post( $type, $ids ){

    $admin_object = get_admin_object($type);

    if( is_string($ids) )  $ids = explode(',', $ids);

    if( is_array($ids) ){

         foreach ($ids as $id) {
            $post = Vn4Model::f($type, $id);

            if( $post ){

                if( $post->status != 'trash' ){

                    if( isset($admin_object['action_callback']['trash']) ){
                        $admin_object['action_callback']['trash']($post);
                    }

                    $post->status_old = $post->status;
                    $post->status = 'trash';
                    $post->save();

                }
               
            }
        }

        
    }
   

    

}

/**
 * Lấy lại 1 bài post đã xóa
 */
function vn4_restore_post( $admin_object ,$type, $ids ){

    $ids = explode(',', $ids);

    foreach ($ids as $id) {
        $post = Vn4Model::f($type, $id);

        if( $post ){

            if( isset($admin_object['action_callback']['restore']) ){
                $admin_object['action_callback']['restore']($post);
            }

            $status_old = $post->status_old;
            $post->status_old = 'trash';

            if( $status_old != 'trash' ){
                $post->status = $status_old;
            }else{
                $post->status = 'publish';
            }

            $post->save();
        }

    }

}


/**
 * Trả về dữ liệu cần thiết cho 1 bảng của vn4 table
 * $r request
 * $type post type
 * $getJS trả về js hay data
 * $order_by_default: thứ tự sắp xêp
 */
function vn4_get_data_table_admin( $type, $getJS = false, $post_filter = null ){

    $r = request();

    $admin_object = get_admin_object($type);

    $admin_object2 = do_action('custome-post-table',$type, $admin_object);

    if( $admin_object2 ) $admin_object = $admin_object2;

    $obj = new Vn4Model( $admin_object['table'] );

    $input = '';

    //action post
    //
    $post = $r->get('post',false);

    $action_post = $r->get('action_post','default');

    $isMethodPost =  $r->isMethod('POST');

    if( $post && $isMethodPost && $r->has('submit_action_post') ){

        if( $action_post == 'delete' && check_permission($type.'_delete')){
            vn4_delete_post( $type, $post);
        }

        if( $action_post == 'trash' && check_permission($type.'_trash')){
           vn4_trash_post( $type, $post );
        }

        if( $action_post == 'restore' && check_permission($type.'_restore')){

            vn4_restore_post( $admin_object, $type, $post );

        }
    }

    $multi_trash = $r->get('multi_trash',false);

    if( $multi_trash != false && $isMethodPost ){

        vn4_trash_post( $type, $multi_trash );
    }

    $multi_trash = $r->get('multi_restore',false);

    if( $multi_trash != false && $isMethodPost ){
        vn4_restore_post( $admin_object, $type, $multi_trash );
    }

     $multi_trash = $r->get('multi_delete',false);

    if( $multi_trash != false && $isMethodPost ){
        vn4_delete_post( $type, $multi_trash );
    }

    //end action post

    $data = $obj->where('type',$type);

    $data2 = do_action('vn4_get_data_table_admin',$data,$type);

    if( $data2 ) $data = $data2;

    if( !$post_filter ) $post_filter = $r->get('post_filter', 'status_');
    // dd($post_filter);
    $list_post_filter = null;

    $post_filter_count = vn4_get_post_count_status( $admin_object , $type , $list_post_filter, $post_filter );

    if( $post_filter && isset($list_post_filter[$post_filter]) ){

        $data = $data->where($list_post_filter[$post_filter]['key'], isset($list_post_filter[$post_filter]['dk'])?$list_post_filter[$post_filter]['dk']:'=' ,$list_post_filter[$post_filter]['value'] );

    }

    if( isset($admin_object['data_filter']) ){
        foreach ($admin_object['data_filter'] as $key_filter => $value) {
            $condition = '=';
            if( is_array($value) && isset($value['value_callback']) && is_callable($value['value_callback']) ){

                $value = $value['value_callback']();

                if( isset($value['condition']) ) $condition = $value['condition'];

            }elseif ( is_callable($value) ) {
                $value = $value();
            }

            $data = $data->where($key_filter, $condition, $value);
        }
    }

    if( isset($admin_object['data_table_callback']) && is_callable($admin_object['data_table_callback']) ) {

        if( $result = $admin_object['data_table_callback']($data) ){
             $data = $result;
        }else{
           //not
        }

    }

    $fields = $admin_object['fields'];

    $page = $r->get('page',1);

    $order_by_default = isset($admin_object['order_by_default'])?$admin_object['order_by_default']:['created_at','desc'];

    $data = $data->orderBy($r->get('order_field',$order_by_default[0]),$r->get('order_value',$order_by_default[1]));

    $length = $r->get('length',10);
    $length = intval ($length);
    $count  = $data->count('id');

    if($count != 0 && $length * $page > $count){
        $page = (int) ($count / $length);

        if($count % $length != 0){
            $page = $page + 1;
        }
    }
    
    Illuminate\Pagination\Paginator::currentPageResolver(function() use ($page){
        return $page;
    });

    $data = $data->paginate($length)->setPath($type);

    if ( $data->count() === 0 &&  $post_filter !== 'status_' ){
       return vn4_get_data_table_admin( $type, $getJS,'status_' );
    }

    if(!$getJS){
        return $data;
    }

    $html = vn4_get_tbody_data( $data, $type, $admin_object );

    $result = ['data'=>$html, 'pagination'=>vn4_get_pagination($data, $post_filter),'pnk'=>$input,'post_filter'=>$post_filter];

    $result = array_merge($result, $post_filter_count);

    return response()->json($result);

}

function get_row_actions($post){

    $pEdit = check_permission($post->type.'_edit');
    $pTrash = check_permission($post->type.'_trash');
    $pRestore = check_permission($post->type.'_restore');
    $pDetail = check_permission($post->type.'_detail');
    $pDelete = check_permission($post->type.'_delete');


    $row_actions = [
        'edit' => '<a class="editRow action_post" action="edit" href="#"><strong>'.__('Edit').'</strong></a>',
        'trash' => '<a class="trashRow action_post" href="#" action="trash"><strong>'.__('Trash').'</strong></a>',
        'detail' => '<a class="detailRow action_post" href="#" action="detail"><strong>'.__('Detail').'</strong></a>',
        'delete' => '<a class="delete action_post" href="#" action="delete"><strong>'.__('Delete').'</strong></a>',
        'restore' => '<a class="restoreRow action_post" href="#" action="restore"><strong>'.__('Restore').'</strong></a>',
    ];

    $status = $post->status;

    $row_actions_result = [];
    
    if($status === 'trash'){
        if($pDelete) $row_actions_result['delete'] = $row_actions['delete'];
        if($pRestore) $row_actions_result['restore'] = $row_actions['restore'];

    }else{
        if($pEdit) $row_actions_result['edit'] = $row_actions['edit'];

        if($pTrash) $row_actions_result['trash'] = $row_actions['trash'];

        if($pDetail) $row_actions_result['detail'] = $row_actions['detail'];
    }

    return $row_actions_result;

}


/**
 * Trả về html của tbody
 * $list_data: danh sách data,
 * $type: post type
 */
function vn4_get_tbody_data( $list_data, $type, $admin_object ){

    $fields = $admin_object['fields'];

    $post_active = Input::get('post',0);

    $is_add_row_action = isset( $admin_object['row_actions'] );

    $str = '';
    if($list_data->total()  == 0){
        $tbody = '<tr class="odd"><td valign="top" colspan="1000" class="dataTables_empty">'.__('No data available in table').'</td></tr>';
    }else{

        $list_post_filter = apply_function('post_filter',null);

        $tbody  = '';

        $post_filter = Input::get('post_filter','status_');

        foreach($list_data as $item){
            $showed_filter = true;
            $class = '';

            if($item->id == $post_active){
                $class = 'my-post';
            }

            $row_actions = get_row_actions($item);

            if( $is_add_row_action ){

                $row_actions2 = $admin_object['row_actions']($item, $row_actions);

                if( is_array($row_actions2) ) $row_actions = $row_actions2;

            }

            $row_actions_html = '<div class="action" >'.join(' | ',$row_actions).'</div>';

            $tbody = $tbody.'<tr class="'.$class.'" data-status="'.$item->status.'" data-edit="'.route('admin.create_and_show_data',['type'=>$type]).'"" data-id="'.$item->id.'" post-type="'.$item->group.'" tag-type="'.$item->type.'">';
            $tbody = $tbody.'<td><div class="add-row-action">'.$row_actions_html.'</div><input class="data-show-item" type="checkbox" value="'.$item->id.'" ></td>';



            $string_status = '';


            if( $item->visibility !== 'publish' && $post_filter != 'visibility_'.str_slug($item->visibility) && isset($list_post_filter['visibility_'.str_slug($item->visibility)]['identification']) ){

                $string_status = $string_status.' - '.$list_post_filter['visibility_'.str_slug($item->visibility)]['identification'];

            }

            if ($item->post_date_gmt !== '' && $post_filter != 'post_date_gmt_' && isset( $list_post_filter['post_date_gmt_']['identification'] ) ){

                 $string_status = $string_status.' - '.$list_post_filter['post_date_gmt_']['identification'];

            }

            if( $item->status !== 'publish' && $post_filter != 'status_'.str_slug($item->status)  && isset($list_post_filter['status_'.str_slug($item->status)]['identification']) ){

                $string_status = $string_status.' - '.$list_post_filter['status_'.str_slug($item->status)]['identification'];

            }

            $string_status = '<strong style="font-size:14px;"> '.$string_status.'</strong>';

            $add_row_action = true;

            foreach($fields as $key => $value){

                if( !isset($value['view']) ) $value['view'] = 'input';

               

                if( !isset($value['show_data']) || $value['show_data'] ){

                    if(isset($value['data_callback'])){
                        $content =  call_user_func_array($value['data_callback'],[$item]);
                    }else{
                        if( !is_callable($value['view']) ){
                            if( view()->exists( $view = 'admin.particle.input_field.'.$value['view'].'.view' ) ){
                                $content = vn4_view($view,['post'=>$item,'key'=>$key, 'field'=>$value]);
                            }else{
                                $content = e($item[$key]);
                            }
                        }else{
                            $view = call_user_func($value['view']);

                            if( isset($view['view']) ){
                                $content = call_user_func_array($view['view'], ['post'=>$item,'key'=>$key, 'field'=>$value]);
                            }
                        }
                        
                    }

                    if( $add_row_action ){
                        $add_row_action = false;
                        $tbody = $tbody.'<td>'.$content.$row_actions_html.'</td>';
                    }else{
                        $tbody = $tbody.'<td>'.$content.'</td>';
                    }
                }

            }

            if( !isset($admin_object['show_created_at']) || $admin_object['show_created_at'] ){
                $tbody = $tbody.'<td>'.$item->created_at.'</td>';
            }
        }
    }

     $str = $str.$tbody;
    
    return $str;
}

/**
 * Trả về html của phân trang dựa trên $list_data
 * $list_data danh sách data phân trang
 */
function vn4_get_pagination($list_data, $post_filter = null ){

    if( $post_filter === null ) $post_filter = Input::get('post_filter','status_');

    $total = $list_data->total();

    $itemForm = $list_data->perPage()*($list_data->currentPage()  - 1);

    $itemTo = $itemForm + $list_data->perPage();

    if($itemTo>$total ){
        $itemTo = $total;
    }

    if($total!= 0){
        $itemForm = $itemForm  + 1;
    }

     $showing = str_replace( ['##from##','##to##','##count##'], ['<span class="show_item_form">'.$itemForm.'</span>','<span class="show_item_to">'.$itemTo.'</span>','<span class="total_item">'.$total.'</span>'], __('Showing ##from## to ##to## of ##count## entries'));
    
    $option_action_post = '<option value="trash" >'.__('Move to Trash').'</option>';

    if ( $post_filter === 'status_trash' ){
         $option_action_post = '<option value="restore" >'.__('Restore').'</option><option value="delete" >'.__('Delete forever').'</option>';
    }

    // config
    $link_limit = 4; // maximum number of links (a little bit inaccurate, but will be ok for now)
    $str = '<div class=" action-multi-post vn4-wat"><select class="form-control pull-left vn4-wat" ><option value="">'.__('Action').'</option>'.$option_action_post.'</select><button type="submit" class="btn-apply-action-multi-post vn4-btn-white pull-left" name="status" value="draft">'.__('Apply').'</button>  </div> <div class="dataTables_info" role="status" aria-live="polite">'.$showing.'</div><div class="dataTables_paginate paging_simple_numbers">';


    if ($list_data->lastPage() > 1){
        
        $showing_go_to_page = str_replace( '##page##', '<input  data-old="'.$list_data->currentPage().'" class="number_page form-control input-sm go_page" type="number" name="" value="'.$list_data->currentPage().'">' , __('Go to page ##page## OR'));

        $str = $str.'<div class="go_to_page">'.$showing_go_to_page.'</div>';
        
        $str = $str.'<ul class="pagination">';

        $param = get_param(['edit_id']);

        if($param != ''){
            $param = '&'.$param;
        }

        $show_page_before = __('«');

        if($list_data->currentPage() == 1){
            $str = $str.'<li class="disabled paginate_button"><span>'.$show_page_before.'</span></li>';
         }else{
            $str = $str.'<li class="paginate_button">'
                .'<a href="'.$list_data->url($list_data->currentPage()  - 1).$param.'">'.$show_page_before.'</a>'
                .'</li>';
         }
            

        $result = '';

        for ($i = 1; $i <= $list_data->lastPage(); $i++){



            $half_total_links = floor($link_limit / 2);
            $from = $list_data->currentPage() - $half_total_links;
            $to = $list_data->currentPage() + $half_total_links;
            if ($list_data->currentPage() < $half_total_links) {
               $to += $half_total_links - $list_data->currentPage();
            }
            if ($list_data->lastPage() - $list_data->currentPage() < $half_total_links) {
                $from -= $half_total_links - ($list_data->lastPage() - $list_data->currentPage()) - 1;
            }

            if ($from < $i && $i < $to){
                
                    $active = $list_data->currentPage() == $i ? ' active' : '';
                $result = $result. '<li class="paginate_button '.$active.'">'
                            .'<a href="'.$list_data->url($i). $param .'">'.$i.'</a>'
                        .'</li>' ;
                
            }

        }

        if($from > 2){
            $str = $str.'<li class="paginate_button">'
                       .'<a href="'.$list_data->url(1).$param.'">1</a>'
                       .'</li><li class="disabled"><span>...</span></li>';
            // <li class="">
            //     <a href="{{$paginator->url(2)}}{!!$param!!}">2</a>
            // </li>
           
        }else{
            for($i = 1; $i<= $from; $i++){
              $str = $str.'<li class="paginate_button">'
                         .'<a href="'.$list_data->url($i).$param.'">'.$i.'</a></li>';
            }
        }
        $str = $str.$result;

        if($list_data->lastPage() - $to > 1){
            $str = $str.'<li class="disabled paginate_button"><span>...</span></li>';
           // <li class="">
           //      <a href="{{$paginator->url($paginator->lastPage() - 1)}}{!!$param!!}">{!!$paginator->lastPage() - 1!!}</a>
           //  </li>
             $str = $str.'<li class="paginate_button"><a href="'.$list_data->url($list_data->lastPage()).$param.'">'.$list_data->lastPage().'</a></li>';
        }else{
            for($i = $to; $i<= $list_data->lastPage(); $i++){
             $str = $str.'<li class="paginate_button"><a href="'.$list_data->url($i).$param.'">'.$i.'</a></li>';
            }
        }
        
        $show_page_after = __('»');
        if($list_data->currentPage() == $list_data->lastPage()){

            $str = $str.'<li class="disabled paginate_button"><span>'.$show_page_after.'</span></li>';
        }else{
            $str = $str.'<li class="paginate_button"><a href="'.$list_data->url($list_data->currentPage() +1).$param.'">'.$show_page_after.'</a></li>';
        }
           
         $str = $str.'</ul></div>';
    }else{
        $str = $str.'<div class="clearfix"></div></div>';
    }
    return $str;
}

