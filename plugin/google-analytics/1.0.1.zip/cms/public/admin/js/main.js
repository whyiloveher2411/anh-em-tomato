/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 	function vn4_ajax(arg){
 		var url = window.location.href, dataType= 'Json', type = 'POST', data = {}  ;
 		if( arg['url'] ){
 			url = arg['url'];
 		}

 		if( arg['type'] ){
 			type = arg['type'];
 		}

 		if( arg['dataType'] ){
 			dataType = arg['dataType'];
 		}

 		data._token = $('#laravel-token').val();

 		if( arg['data'] ){

		    for (var attrname in arg['data']) { data[attrname] = arg['data'][attrname]; }

 		}

 		$.ajax({
 			url: url,
 			type: type,
 			dataType: dataType,
 			data: data,
 			beforeSend:function(){
 				if( arg['show_loading'] ){

 					$('html').addClass('show-popup');
 				}
 			},
 			success:function(data){
 				if( arg['default_handling'] == undefined || arg['default_handling'] ){

 					if(data.url_redirect){
	 					window.location.href = data.url_redirect;
	 				}

	 				if(data.message){
	 					alert(data.message);
	 				}

	 				if( data.reload ){
	 					location.reload();
	 				}

	 				// if(data.error){
	 				// 	alert('Error');
	 				// }

	 				// if(data.success){
	 				// 	alert('Success');
	 				// }

	 				if(data.append){
	 					htmls = data.append;
	 					for(i = 0 ; i<htmls.length; i++ ){
	 						$(htmls[i].selector).append(htmls[i].html);
	 					}
	 				}

 				}
 				

 				if( arg['callback'] ){
 					arg['callback'](data);
 				}

 				
 			},
 			error:function(data){
 				if( arg['error_callback'] ){
 					arg['error_callback'](data);
 				}
 			}

 		}).fail(function(data) {

 			if( arg['fail_callback'] ){
				arg['fail_callback'](data);
			}

 			console.log('vn4_ajax fail');
 		})
 		.always(function() {
 			if( arg['show_loading'] ){
 				$('html').removeClass('show-popup');
 			}
 		});

 	}



 	var CURRENT_URL = window.location.href.split('?')[0],
 	$BODY = $('body'),
 	$MENU_TOGGLE = $('.menu_toggle'),
 	$SIDEBAR_MENU = $('#sidebar-menu'),
 	$SIDEBAR_FOOTER = $('.sidebar-footer'),
 	$LEFT_COL = $('.left_col'),
 	$RIGHT_COL = $('.right_col'),
 	$NAV_MENU = $('.nav_menu'),
 	$FOOTER = $('footer');

// Sidebar
$(document).ready(function() {
	// TODO: This is some kind of easy fix, maybe we can improve this
	var setContentHeight = function () {
		// reset height

		$left_height = $('.left_col').height();

		$window_height = $(window).height();
		if($left_height > $window_height){
			$RIGHT_COL.css('min-height', $left_height);
		}else{
			$RIGHT_COL.css('min-height', $window_height);
		}



		// var bodyHeight = $BODY.outerHeight(),
		//     footerHeight = $BODY.hasClass('footer_fixed') ? 0 : $FOOTER.height(),
		//     leftColHeight = $LEFT_COL.eq(1).height() + $SIDEBAR_FOOTER.height(),
		//     contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;

		// // normalize content
		// contentHeight -= $NAV_MENU.height() + footerHeight;

		// $RIGHT_COL.css('min-height', bodyHeight);
	};
	// $SIDEBAR_MENU.find('a').hover(function() {

	//     var $li = $(this).parent();
	//     // prevent closing menu if we are on child menu
	//     if (!$li.parent().is('.child_menu')) {
	//         $SIDEBAR_MENU.find('li').removeClass('active active-sm');
	//         $SIDEBAR_MENU.find('li ul').slideUp();
	//     }
	
	//     $li.addClass('active');

	//     $('ul:first', $li).slideDown(function() {
	//         setContentHeight();
	//     });
	// }, function() {
	//     var $li = $(this).parent();
	//      $li.removeClass('active active-sm');
	//     $('ul:first', $li).slideUp(function() {
	//         setContentHeight();
	//     });

	// });
$SIDEBAR_MENU.find('a').on('click', function(ev) {
	var $li = $(this).parent();

	if ($li.is('.active')) {
		$li.removeClass('active active-sm');
		$('ul:first', $li).slideUp(function() {
			setContentHeight();
		});
	} else {
			// prevent closing menu if we are on child menu
			if (!$li.parent().is('.child_menu')) {
				$SIDEBAR_MENU.find('li').removeClass('active active-sm');
				$SIDEBAR_MENU.find('li ul').slideUp();
			}

			$li.addClass('active');

			$('ul:first', $li).slideDown(function() {
				setContentHeight();
			});
		}
	});

	// toggle small or large menu
	$MENU_TOGGLE.on('click', function() {
		if ($BODY.hasClass('nav-md')) {
			$SIDEBAR_MENU.find('li.active ul').hide();
			$SIDEBAR_MENU.find('li.active').addClass('active-sm').removeClass('active');
		} else {
			$SIDEBAR_MENU.find('li.active-sm ul').show();
			$SIDEBAR_MENU.find('li.active-sm').addClass('active').removeClass('active-sm');
		}

		$BODY.toggleClass('nav-md nav-sm');

		setContentHeight();
	});

	// check active menu
	$SIDEBAR_MENU.find('a[href="' + CURRENT_URL + '"]').parent('li').addClass('current-page');

	$SIDEBAR_MENU.find('a').filter(function () {
		return this.href == CURRENT_URL;
	}).parent('li').addClass('current-page').parents('ul').slideDown(function() {
		setContentHeight();
	}).parent().addClass('active');

	// recompute content when resizing
	$(window).smartresize(function(){  
		setContentHeight();
	});

	setContentHeight();

	// fixed sidebar
	if ($.fn.mCustomScrollbar) {
		$('.menu_fixed').mCustomScrollbar({
			autoHideScrollbar: true,
			theme: 'minimal',
			mouseWheel:{ preventDefault: true }
		});
	}
});
// /Sidebar

// Panel toolbox
$(document).ready(function() {
	$('.x_panel ').on('click','.collapse-link', function(event) {
		event.stopPropagation() ;
		var $BOX_PANEL = $(this).closest('.x_panel'),
		$ICON = $(this).find('i'),
		$BOX_CONTENT = $BOX_PANEL.find('.x_content:first');

		// fix for some div with hardcoded fix class
		if ($BOX_PANEL.attr('style')) {

			$BOX_CONTENT.slideToggle(200, function(){
				$BOX_PANEL.removeAttr('style');
			});


		} else {
			$BOX_CONTENT.slideToggle(200); 

			$BOX_PANEL.css({'height':'auto','padding-bottom':'0' });  

		}

		$ICON.toggleClass('fa-chevron-up fa-chevron-down');
	});

	$('.close-link').click(function () {
		var $BOX_PANEL = $(this).closest('.x_panel');

		$BOX_PANEL.remove();
	});
});
// /Panel toolbox

// Tooltip
// $(document).ready(function() {
// 	$('[data-toggle="tooltip"]').tooltip({
// 		container: 'body'
// 	});
// });
// /Tooltip

// Progressbar
if ($(".progress .progress-bar")[0]) {
	$('.progress .progress-bar').progressbar();
}
// /Progressbar

// Switchery
$(document).ready(function() {
	if ($(".js-switch")[0]) {
		var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
		elems.forEach(function (html) {
			var switchery = new Switchery(html, {
				color: '#26B99A'
			});
		});
	}
});
// /Switchery

// iCheck
$(document).ready(function() {
	if ($("input.flat")[0]) {
		$(document).ready(function () {
			$('input.flat').iCheck({
				checkboxClass: 'icheckbox_flat-green',
				radioClass: 'iradio_flat-green'
			});
		});
	}
});
// /iCheck

// Table
$('table input').on('ifChecked', function () {
	checkState = '';
	$(this).parent().parent().parent().addClass('selected');
	countChecked();
});
$('table input').on('ifUnchecked', function () {
	checkState = '';
	$(this).parent().parent().parent().removeClass('selected');
	countChecked();
});

var checkState = '';

$('.bulk_action input').on('ifChecked', function () {
	checkState = '';
	$(this).parent().parent().parent().addClass('selected');
	countChecked();
});
$('.bulk_action input').on('ifUnchecked', function () {
	checkState = '';
	$(this).parent().parent().parent().removeClass('selected');
	countChecked();
});
$('.bulk_action input#check-all').on('ifChecked', function () {
	checkState = 'all';
	countChecked();
});
$('.bulk_action input#check-all').on('ifUnchecked', function () {
	checkState = 'none';
	countChecked();
});

function countChecked() {
	if (checkState === 'all') {
		$(".bulk_action input[name='table_records']").iCheck('check');
	}
	if (checkState === 'none') {
		$(".bulk_action input[name='table_records']").iCheck('uncheck');
	}

	var checkCount = $(".bulk_action input[name='table_records']:checked").length;

	if (checkCount) {
		$('.column-title').hide();
		$('.bulk-actions').show();
		$('.action-cnt').html(checkCount + ' Records Selected');
	} else {
		$('.column-title').show();
		$('.bulk-actions').hide();
	}
}

// Accordion
$(document).ready(function() {
	$(".expand").on("click", function () {
		$(this).next().slideToggle(200);
		$expand = $(this).find(">:first-child");

		if ($expand.text() == "+") {
			$expand.text("-");
		} else {
			$expand.text("+");
		}
	});
});

// NProgress
if (typeof NProgress != 'undefined') {
	$(document).ready(function () {
		NProgress.start();
	});

	$(window).load(function () {
		NProgress.done();
	});
}
/**
 * Resize function without multiple trigger
 * 
 * Usage:
 * $(window).smartresize(function(){  
 *     // code here
 * });
*/
(function($,sr){
	// debouncing function from John Hann
	// http://unscriptable.com/index.php/2009/03/20/debouncing-javascript-methods/
	var debounce = function (func, threshold, execAsap) {
		var timeout;

		return function debounced () {
			var obj = this, args = arguments;
			function delayed () {
				if (!execAsap)
					func.apply(obj, args);
				timeout = null; 
			}

			if (timeout)
				clearTimeout(timeout);
			else if (execAsap)
				func.apply(obj, args);

			timeout = setTimeout(delayed, threshold || 100); 
		};
	};

	// smartresize 
	jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };

})(jQuery,'smartresize');



function replaceUrlParam(url, paramName, paramValue){
	if(paramValue == null)
		paramValue = '';
	var pattern = new RegExp('\\b('+paramName+'=).*?(&|$)');
	if(url.search(pattern)>=0){
		return url.replace(pattern,'$1' + paramValue + '$2');
	}
	return url + (url.indexOf('?')>0 ? '&' : '?') + paramName + '=' + paramValue ;
}

function removeParam(key, sourceURL) {
	var rtn = sourceURL.split("?")[0],
	param,
	params_arr = [],
	queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
	if (queryString !== "") {
		params_arr = queryString.split("&");
		for (var i = params_arr.length - 1; i >= 0; i -= 1) {
			param = params_arr[i].split("=")[0];
			if (param === key) {
				params_arr.splice(i, 1);
			}
		}
		rtn = rtn + "?" + params_arr.join("&");
	}
	return rtn;
} 

function url_value(url, k){

	var params = url.split('?'); 
	if( params[1] ){
		params = params[1].split('&');
		for(var i =0;i<params.length;i++){
			var temp = params[i].split('=');
			var key   = temp[0];
			var value = temp[1];

			if(k == key ){
				return value;
			}

		}

		return null;

	}

	return null;

}


function get_val_checkbox(select){
	return list_object = $(select+':checked').map(function(index, el) {
		return $(el).val();
	}).get();

}

function upload_input_image(warpper){
	warpper.find('.action-image').remove();
	var index2 = 1;
	warpper.find('.item-image-resutl').each(function(index, el) {
		$(el).find('.stt:first').text(index2);
		index2++;
	});

	warpper.find('.result_real:first').val(warpper.find('.default_input_img_result').eq(0).html());
}

$(document).on("mouseenter", ".item-image-resutl:has(img)", function() {
	var url = $(this).find('img').eq(0).attr('src');
	$(this).append('<div class="action-image"><a href="'+url+'" title="'+$('#text-download').val()+'" download><i class="fa fa-cloud-download download" aria-hidden="true"></i></a><i title="'+$('#text-edit').val()+'" class="fa fa-pencil edit-img" aria-hidden="true"></i><i title="'+$('#text-remove').val()+'" class="fa fa-times remove" aria-hidden="true"></i></div>');
});

$(document).on("mouseleave", ".item-image-resutl:has(img)", function() {
	$(this).find('.action-image').remove();
});

$('.default_input_img_result').on("click", ".item-image-resutl .action-image .remove", function() {
	var warpper = $(this).closest('.default_input_img_warpper');
	$(this).closest('.item-image-resutl').remove();
	upload_input_image(warpper);
});

$('#backUrl').click(function(){
	window.history.back();
});


function clickIconTopnav(){
	$('.topnav').toggleClass('responsive');
}

$('.iconbacktotop').click(function(e){
	e.preventDefault();
	$('html,body').animate({
		scrollTop: 0
	}, 700);
});

WebFontConfig = {
	google: { families: [ 'Roboto::latin,latin-ext' ] }
};

$('.trigger_fullscreen').click(function(event) {
	if ((document.fullScreenElement && document.fullScreenElement !== null) ||    
		(!document.mozFullScreen && !document.webkitIsFullScreen)) {
		if (document.documentElement.requestFullScreen) {  
			document.documentElement.requestFullScreen();  
		} else if (document.documentElement.mozRequestFullScreen) {  
			document.documentElement.mozRequestFullScreen();  
		} else if (document.documentElement.webkitRequestFullScreen) {  
			document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);  
		}  
	} else {  
		if (document.cancelFullScreen) {  
			document.cancelFullScreen();  
		} else if (document.mozCancelFullScreen) {  
			document.mozCancelFullScreen();  
		} else if (document.webkitCancelFullScreen) {  
			document.webkitCancelFullScreen();  
		}  
	} 
});

$('.session-message-icon-close, .warpper').click(function(event) {
	$(this).closest('.session-message').addClass('fadeInDown');
});



$(".session-message .progress-bar").animate({
	width: "100%"
}, 10000,function(){
	$('.session-message').addClass('fadeInDown');
});



$('.not-href').click(function(event) {
	event.preventDefault();
});

$('.btn-open-toggle').click(function(event) {
	$($(this).attr('data-toggle')).slideDown('fast');
	$(this).css({display:'none'});
});

$('.cancel-open-toggle').click(function(event) {
	$(this).closest('.warpper-toggle').slideUp('fast');
	$($(this).attr('data-toggle')).css({display:'inline'});
});

$('.screen-warp-button button').click(function(event) {


	$('.screen-warp-button button.active:not(#'+$(this).attr('id')+')').removeClass('active');

	$(this).toggleClass('active');

	$('#screen-meta .screen-meta-warp.active').removeClass('active').slideUp('fast');

	if($(this).hasClass('active')){
		$('#screen-meta .screen-meta-warp.'+$(this).attr('aria-controls')).addClass('active').slideToggle('fast');
	}

});


$('.contextual-help-tabs li a').click(function(event) {
	$('.contextual-help-tabs li.active').removeClass('active');
	$(this).closest('li').addClass('active');

	$('.contextual-help-tabs-wrap .active').removeClass('active');
	$('.contextual-help-tabs-wrap .'+$(this).attr('aria-controls').trim()).addClass('active');
});

//tabs
$('.vn4_tabs_left .menu-left li a:not(.new-link)').click(function(event) {
	event.preventDefault();

	$(this).closest('.vn4_tabs_left').find('.menu-left li.active').removeClass('active');
	$(this).closest('li').addClass('active');

	$(this).closest('.vn4_tabs_left').find('.content-right>.tab.active').removeClass('active');
	$(this).closest('.vn4_tabs_left').find('.content-right>.tab.content-tab-'+$(this).attr('aria-controls').trim()).addClass('active');

});

$('.vn4_tabs_top .menu-top a:not(.new-link)').click(function(event) {
	event.preventDefault();

	$(this).closest('.menu-top').find('a.active').removeClass('active');
	$(this).addClass('active');

	if( $(this).attr('aria-controls') ){
		$(this).closest('.vn4_tabs_top').find('.content-bottom .active').removeClass('active');
		$(this).closest('.vn4_tabs_top').find('.content-bottom .tab-content-'+$(this).attr('aria-controls').trim()).addClass('active');
	}

});

$('.warpper-editor .menu-top a').click(function(event) {
	$(this).closest('.warpper-editor').find('.content-visual .editor-content, .content-visual .mce-tinymce').css({'visibility':'hidden','opacity':'0','z-index':'-1','position':'fixed'});
	$(this).closest('.warpper-editor').find('.'+$(this).attr('data')).css({'visibility':'initial','opacity':'1','z-index':'1','position':'initial','display':'block'});
});


var ctrlDown = false,shiftDown = false,altDown = false,
    ctrlKey = 17,
    altKey = 18,
    cmdKey = 91,
    shiftkey = 16,
    dkey = 68,
    vKey = 86,
    pkey = 80,
    fkey = 70,
    cKey = 67;
    position = 0;

$(window).keydown(function(e) {
	// alert(e.keyCode);
	if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
	if (e.keyCode == altKey) altDown = true;
	if( e.keyCode == shiftkey ) shiftDown = true;
	if( altDown && e.keyCode == fkey ){
		$('.quan_table_filter input[type=search]').focus();
		e.preventDefault();
  		e.stopPropagation();
	}

	if( altDown && e.keyCode == dkey ){
		$('#vn4debug').trigger('click');

		if( $('#vn4debug').hasClass('active') ){
		 $('html,body').animate({ scrollTop: 0 }, 'fast');
		}
		e.preventDefault();
  		e.stopPropagation();
	}

	if( ctrlDown && shiftDown && e.keyCode == pkey ){


		template = '<div id="popup-info-theme" class="modal fade in" role="dialog" style="display: block;"><div class="modal-dialog" style="left: 50%;transform: translate(-50%,0%);margin: 0;max-width:1100px;width:auto;padding:10px;padding-top: 40px;"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">×</button><h4 class="modal-title theme-name">Eleven</h4></div><div class="modal-body"><div class="col-sm-6 col-xs-12"><img class="img-theme" src="http://vn4cms.com/cms/resources/views/theme/eleven/screenshot.png" alt=""></div><div class="col-sm-6 col-xs-12 theme-detail"><p class="name"><span class="theme-name" style="font-size: 33px;color: #000;">Eleven</span> Phiên bản: <span class="version">1.0</span></p><p class="author">By <a class="theme-author" href="dangthuyenquan@gmail.com">Quân Đặng</a></p><p class="theme-description" style="color:#797979;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><hr><p class="tags"><strong style="color: #444">Thẻ:</strong> <span class="theme-tags">vn4 theme</span></p></div><div class="clearfix"></div></div><div class="modal-footer" style="text-align: center;"><button type="submit" name="general_client_theme" value="eleven" class="vn4-active-theme vn4-btn vn4-btn-blue" style="display: none;"><i class="fa fa-user"> </i> Kích hoạt </button><button type="button" class="vn4-btn vn4-btn-red delete-theme" value="eleven" style="display: none;"> <i class="fa fa-trash"> </i> Xóa</button><button type="button" class="vn4-btn" data-dismiss="modal">Close</button></div></div></div></div>';
		$('body').append(template);
		e.preventDefault();
  		e.stopPropagation();
	}
    
});
$(window).keyup(function(e) {
     if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;
     if (e.keyCode == shiftkey ) shiftDown = false;
     if (e.keyCode == altKey ) altDown = false;
});


// editor.on('keydown', function(e) {
//     if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = true;
//     if( e.keyCode == vKey &&  ctrlDown ){
//       e.preventDefault();
//       e.stopPropagation();
//     }
// });

// editor.on('keyup', function(e) {
//      if (e.keyCode == ctrlKey || e.keyCode == cmdKey) ctrlDown = false;

// });

// editor.on('keypress',function(e){
//   console.log(e);
// });