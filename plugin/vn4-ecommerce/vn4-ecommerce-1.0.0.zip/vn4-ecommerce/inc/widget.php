<?php
// return [
// 	'wiget-plugin'=>[
// 		'title'=>'Widget By Plugin',
// 		'description'=>'Widget Create By Plugin Demo',
// 		'fields'=>[
// 			'content'=>[
// 				'title'=>'Content',
// 				'view'=>'editor',
// 			]
// 		],
// 	 	'show'=>function($data){
// 	 		return $data->get_data('content');
//       	}
// 	]
// ];