<?php
// return [
// 	[
// 		'group'=>'plugin.demo',
// 		'title_group'=>'Plugin Demo',
// 		'key'=>'plugin_demo_permission',
// 		'title'=>'Permission Plugin Demo',
// 	],
// ];

// check permission
// check_permission('plugin_demo_permission')
