<?php 

register_post_type(function($list_post_type) use ($plugin) {

	$add_object = [];

	$add_object[] = [
			'ecommerce_product',
	    	1,
			[
		    'table'=>'ecommerce_product',
		    'title'=> __p('Product',$plugin->key_word),
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		        ],
		        'slug' => [
		            'title'=>__('Slug'),
		            'view' =>'slug',
		            'key_slug'=>'title',
		        ],
		        'short_description' => [
		            'title'=>'Short Description',
		            'view' =>'editor',
		            'show_data'=>false,
		        ],
		        'long_description' => [
		            'title'=>'long Description',
		            'view' =>'editor',
		            'show_data'=>false,
		        ],
		        'details'=>[
		        	'title'=>'Details',
		        	'view'=>'editor',
		            'show_data'=>false,
		        ],
		        'product_type'=>[
		        	'title'=>'Product Type',
		        	'view'=>'hidden',
		        	'data_type'=>'custom',
		        	'type'=>'text',
		        	'length'=>20,
		        ],
		        'price'=>[
		        	'title'=>'Price',
		        	'view'=>'hidden',
		        	'data_type'=>'custom',
		        	'type'=>'text',
		        	'length'=>20,
		        	'show_data'=>function($post){

		        		// if( $post->product_type === 'variable' ){

	        			$meta = $post->getMeta('product-info');

	        			if( isset($meta['price_min']) && isset($meta['sale_price_min']) ){
			        		if( $meta['price_min'] === $meta['price_max'] ) $price = number_format($meta['price_min']);
			        		else $price = number_format($meta['price_min']).' - '.number_format($meta['price_max']);

			        		if( $meta['sale_price_min'] === $meta['sale_price_max'] ) $sale_price = number_format($meta['sale_price_min']);
			        		else $sale_price = number_format($meta['sale_price_min']).' - '.number_format($meta['sale_price_max']);

			        		return '<div><del style="text-decoration: line-through;">'.$price.'</del> <br> '.$sale_price.'</div>';
		        		}
		        	}
		        ],
		        'sale_price'=>[
		        	'title'=>'Sale Price',
		        	'view'=>'hidden',
		        	'data_type'=>'custom',
		        	'type'=>'text',
		        	'length'=>20,
		        	'show_data'=>false,
		        ],
		        'ecommerce_category' => [
		            'title'=>__('Category'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>false,
		            'object'=>'ecommerce_category',
		        	'advance'=>'right',
		        ],
		        'ecommerce_tag' => [
		            'title'=>__('Tag'),
		            'view' =>'relationship_manytomany',
		            'show_data'=>false,
		            'type'=>'tags',
		            'object'=>'ecommerce_tag',
		        	'advance'=>'right',
		        ],
		        'thumbnail'=>[
		        	'title'=>'Thumbnail',
		        	'view'=>'image',
		        	'advance'=>'right',
		            'show_data'=>false,
		        ],
		        'images'=>[
		        	'title'=>'Images',
		        	'view'=>'image',
		        	'advance'=>'right',
		        	'multiple'=>true,
		            'show_data'=>false,
		        ],
		    ],
		    'row_actions'=>function($post, $actions){
		    	$actions['report'] = '<a class="" href="#">Report</a>';

		    	return $actions;
		    }
		]
	];


	$add_object[] = [
			'ecommerce_product_variable',
	    	1,
			[
		    'table'=>'ecommerce_product_variable',
		    'title'=> __p('Product Variable',$plugin->key_word),
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title (SKU)',
		            'view'=>'text',
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'view' =>'textarea',
		            'show_data'=>false,
		        ],
		        'price' => [
		            'title'=>'Price',
		            'view' =>'text',
		        ],
		        'sale_price'=>[
		        	'title'=>'Sale Price',
					'view'=>'text',
		        ],
		        'thumbnail'=>[
		        	'title'=>'Thumbnail',
		        	'view'=>'image',
		        	'advance'=>'right',
		            'show_data'=>false,
		        ],
		        'images'=>[
		        	'title'=>'Images',
		        	'view'=>'image',
		        	'advance'=>'right',
		        	'multiple'=>true,
		            'show_data'=>false,
		        ],
		       	
		       	'weight'=>[
		       		'title'=>'Weight',
		       		'view'=>'text',
		       	],
		       	'length'=>[
		       		'title'=>'Length',
		       		'view'=>'text',
		       	],
		       	'width'=>[
		       		'title'=>'Width',
		       		'view'=>'text',
		       	],
		       	'height'=>[
		       		'title'=>'Height',
		       		'view'=>'text',
		       	],
		       	'check_list' => [
					'title'=>'Check List',
					'view'=>'checkbox',
					'layout'=>'horizontal',
					'list_option'=>[
						'enabled'=>'Enabled',
						'downloadable'=>'Downloadable',
						'virtual'=>'Virtual',
						'manage_stock'=>'Manage Stock',
					]
				],
				'stock_status' => [
					'title'=>'Stock Status',
					'view'=>'select',
					'list_option'=>[
						'instock'=>'In Stock',
						'outofstock'=>'Outof Stock',
						'onbackorder'=>'On Back Order',
					]
				],
				'shipping' => [
					'title'=>'shipping',
					'view'=>'select',
					'list_option'=>[
						'-1'=>'Tương tự bản gốc',
					]
				],
				'download_file' => [
					'title'=>'Các tập tin có thể tải xuống',
					'view'=>'repeater',
					'sub_fields'=>[
						'name'=>['title'=>'Name'],
						'file'=>['title'=>'File','view'=>'asset-file'],
					]
				],
				'download_limit' => [
					'title'=>'Giới hạn số lần tải xuống',
					'view'=>'text',
				],
				'download_expiry' => [
					'title'=>'Giới hạn ngày tải xuống',
					'view'=>'text',
				],
		        'ecommerce_product' => [
		            'title'=>'Product',
		            'view' =>'relationship_onetomany',
		            'show_data'=>false,
		            'type'=>'many_record',
		            'object'=>'ecommerce_product',
		        	'advance'=>'right',
		        ],
		        'attribute_value' => [
		            'title'=>'Product Attribute Value',
		            'view' =>'relationship_manytomany',
		            'type'=>'many_record',
		            'show_data'=>false,
		            'object'=>'ecommerce_product_attribute_value',
		        	'advance'=>'right',
		        ],
		    ],
		    'layout_custom'=> [
				[ [ 'col-md-6',[ 
					['col-md-12','check_list'],
					['col-md-12','title'],
					['col-md-6','price'],
					['col-md-6','sale_price'], 
					['col-md-12','stock_status'],
					['col-md-12','weight'],
					['col-md-4','length'],
					['col-md-4','width'],
					['col-md-4','height'],
					['col-md-12','shipping'],
				]],[ 'col-md-6', [  ['col-md-12','thumbnail'] , ['col-md-12','images'] ] ] ],
				[ ['col-md-12','description'] ],
				[ ['col-md-12','download_file'] ],
				[ ['col-md-6','download_limit'], ['col-md-6','download_expiry'] ]
			]
		]
	];

	$add_object[] =  [
		'ecommerce_product_attribute',
    	1,
    	[
		    'table'=>'ecommerce_product_attribute',
		    'title'=> __('Attribute'),
		    'way_show'=>'title',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		        'values' => [
		            'title'=>__('Values'),
		            'view' =>'relationship_onetomany_show',
		            'show_data'=>false,
		            'object'=>'ecommerce_product_attribute_value',
		            'field'=>'ecommerce_product_attribute',
		        ],
		    ],
		]
	];

	$add_object[] =  [
		'ecommerce_product_attribute_value',
    	1,
    	[
		    'table'=>'ecommerce_product_attribute_value',
		    'title'=> __('Attribute Value'),
		    'way_show'=>'title',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		        'ecommerce_product_attribute' => [
		            'title'=>__('Product Attribute'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>false,
		            'object'=>'ecommerce_product_attribute',
		        ],
		    ],
		]
	];

	$add_object[] = [
		'ecommerce_category',
    	1,
    	[
		    'table'=>'ecommerce_category',
		    'title'=>__('Category'),
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).',
		        ],
		        'parent' => [
		            'title'=>__('Parent'),
		            'view' =>'relationship_onetomany',
		            'show_data'=>false,
		            'object'=>'ecommerce_category',
		            'note'=>'Chuyên mục khác với thẻ, bạn có thể sử dụng nhiều cấp chuyên mục. Ví dụ: Trong chuyên mục nhạc, bạn có chuyên mục con là nhạc Pop, nhạc Jazz. Việc này hoàn toàn là tùy theo ý bạn.',

		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		    ],
	    ]
	];

	$add_object[] =  [
		'ecommerce_tag',
    	1,
    	[
		    'table'=>'ecommerce_tag',
		    'title'=> __('Tag'),
		    'way_show'=>'title',
		    'fields'=>[
		        'title'=>[
		            'title'=>__('Title'),
		            'view'=>'text',
		            'required'=>true,
		            'note'=>'Tên riêng sẽ hiển thị trên trang mạng của bạn.',
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=> 'title',
		            'type' =>'text',
		            'note'=>'Chuỗi cho đường dẫn tĩnh là phiên bản của tên hợp chuẩn với Đường dẫn (URL). Chuỗi này bao gồm chữ cái thường, số và dấu gạch ngang (-).'
		        ],
		        'description' => [
		            'title'=>__('Description'),
		            'show_data'=>false,
		            'view' =>'textarea',
		            'note'=>'Mô tả bình thường không được sử dụng trong giao diện, tuy nhiên có vài giao diện hiện thị mô tả này.',
		        ],
		    ],
		]
	];

	$add_object[] = [
			'ecommerce_customer',
	    	1,
			[
		    'table'=>'ecommerce_customer',
		    'slug'=>'customer',
		    'title'=> 'Customer',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Email',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'name'=>[
		            'title'=>'name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'slug' => [
		            'title'=>'Slug',
		            'view' =>'slug',
		            'key_slug'=>'name',
		            'type' => 'text',
		            'show_data'=>false,
		        ],
		        'password'=>[
		            'title'=>'Password',
		            'view'=>'password',
		        	'show_data'=>false,
		        ],
			]
		]
	];


	$add_object[] = [
			'ecommerce_faq',
	    	1,
			[
		    'table'=>'ecommerce_faq',
		    'title'=> 'FAQ',
		    'slug'=>'ecommerce-faq',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Question',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'anwser'=>[
		        	'title'=>'Anwser',
		        	'view'=>'textarea',
		        ],
		        'ecommerce_product' => [
		            'title'=>'Product',
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'ecommerce_product',
		            'type'=>'many_record',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];


	$add_object[] = [
			'ecommerce_review',
	    	1,
			[
		    'table'=>'ecommerce_review',
		    'title'=> 'Review',
		    'slug'=>'review',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Title',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'rating'=>[
		        	'title'=>'Rating',
		        	'view'=>'number',
		        ],
		        'count_voice'=>[
		        	'title'=>'Count Voice',
		        	'view'=>'number',
		        ],
		        'count_reply'=>[
		        	'title'=>'Count Reply',
		        	'view'=>'number',
		        ],
		        'message'=>[
		        	'title'=>'Message',
		        	'view'=>'textarea',
		        ],
		        'ecommerce_customer'=>[
		        	'title'=>'Customer',
		        	'view'=>'relationship_onetomany',
		        	'object'=>'ecommerce_customer',
		            'type'=>'many_record',
		        	'fields_related'=>['name'],
		        	'advance'=>'right',
		        ],
		        'product' => [
		            'title'=>'Product',
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'ecommerce_product',
		            'type'=>'many_record',
		            'fields_related'=>['title'],
		            'advance'=>'right',
		        ],
			]
		]
	];


	$add_object[] = [
			'ecommerce_comment',
	    	1,
			[
		    'table'=>'ecommerce_comment',
		    'title'=> 'Comment',
		    'slug'=>'comment',
		    'fields'=>[
		        'title'=>[
		            'title'=>'Name',
		            'view'=>'text',
		            'required'=>true,
		        ],
		        'content'=>[
		        	'title'=>'Content',
		        	'view'=>'editor',
		        	'show_data'=>false,
		        ],
		        'ecommerce_customer' => [
		            'title'=>'Customer',
		            'view' =>'relationship_onetomany',
		            'show_data'=>true,
		            'object'=>'ecommerce_customer',
		            'type'=>'many_record',
		            'fields_related'=>['name'],
		            'advance'=>'right',
		        ],
		        'ecommerce_review' => [
		            'title'=>'Product review',
		            'view' =>'relationship_onetomany',
		            'fields_related'=>['title'],
		            'show_data'=>true,
		            'type'=>'many_record',
		            'object'=>'ecommerce_review',
		            'advance'=>'right',
		        ],
			]
		]
	];


	


	return $add_object;

});


if( is_admin() ){

	include __DIR__.'/inc/backend.php';

}else{

	include __DIR__.'/inc/frontend.php';

}