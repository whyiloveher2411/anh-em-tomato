<?php

if( $r->isMethod('GET') ){

	if( $r->has('viewsimap') ){

		return response()->view( 'plugins.'.$plugin->key_word.'.view.frontend.sitemap',['plugin'=>$plugin])->header('Content-Type', 'application/xml');
	}
	return view_plugin($plugin,'view.sitemap',['plugin'=>$plugin]);
}

if( env('EXPERIENCE_MODE') ){
	return experience_mode();
}

if( $r->isMethod('POST') ){
	if( $r->get('active_sitemap') ){
		$plugin->updateMeta('active_sitemap', '["active"]');
		$plugin->updateMeta('post-type-sitemap',$r->get('post-type-sitemap',[]));
	}else{
		$plugin->updateMeta('active_sitemap', '');
	}

	vn4_create_session_message( __('Success'), __p('Update Sitemap Setting Success.',$plugin->key_word), 'success' , true);
}


return redirect()->back();