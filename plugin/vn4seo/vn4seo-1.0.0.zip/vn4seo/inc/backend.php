<?php

add_route('/seo-vn4/{page}','admin.plugins.'.$plugin->key_word,'backend',function($r, $__vn4_page) use ($plugin) {
	if( file_exists(__DIR__.'/'.$__vn4_page.'.php') ){
		return include __DIR__.'/'.$__vn4_page.'.php';
	}

	return redirect()->route('admin.index');
});


add_sidebar_admin(function() use ($plugin) {

	$sidebar_seo_vn4[] = [
		'title'=>'Vn4SEO <span class="label lable-info label-success pull-right">'.__('Coming Soon').'</span>',
		'image-icon'=>plugin_asset($plugin,'img/icon-sidebar.png'),
		'submenu'=>[
			['title'=>'Setting','url'=>route('admin.plugins.'.$plugin->key_word,'setting')],
			['title'=>'SEO Page','url'=>route('admin.plugins.'.$plugin->key_word,'page_setting')],
			['title'=>'Sitemap','url'=>route('admin.plugins.'.$plugin->key_word,'sitemap')],
			['title'=>'AMP','url'=>'#'],
			['title'=>'JSON-LD','url'=>'#'],
			['title'=>'Tool','url'=>route('admin.plugins.'.$plugin->key_word,'tool')],
		],
	];

	return $sidebar_seo_vn4;
},'manager');

add_meta_box(
	'plugin-seo-general',
	'Search Engine Optimization',
	function($config){
		return isset($config['public_view']) && $config['public_view'];
	},
	'left',
	'plugin-seo-general' ,
	function($customePostConfig, $post) use ($plugin){
		if( $customePostConfig['public_view'] ){

			if( $post ){
				$data = [
					'plugin_vn4seo_google_title'=>$post->getMeta('plugin_vn4seo_google_title',$post->title),
					'plugin_vn4seo_google_description'=>$post->getMeta('plugin_vn4seo_google_description',''),
					'plugin_vn4seo_focus_keyword'=>$post->getMeta('plugin_vn4seo_focus_keyword',''),
					'link'=>get_permalinks($post),
					'plugin_vn4seo_canonical_url'=>$post->getMeta('plugin_vn4seo_canonical_url',''),
					'plugin_vn4seo_facebook_title'=>$post->getMeta('plugin_vn4seo_facebook_title'),
					'plugin_vn4seo_facebook_description'=>$post->getMeta('plugin_vn4seo_facebook_description'),
					'plugin_vn4seo_facebook_image'=>$post->getMeta('plugin_vn4seo_facebook_image'),
					'plugin_vn4seo_twitter_title'=>$post->getMeta('plugin_vn4seo_twitter_title'),
					'plugin_vn4seo_twitter_description'=>$post->getMeta('plugin_vn4seo_twitter_description'),
					'plugin_vn4seo_twitter_image'=>$post->getMeta('plugin_vn4seo_twitter_image'),
				];
			}else{
				$data = [
					'plugin_vn4seo_google_title'=>'',
					'plugin_vn4seo_google_description'=>'',
					'plugin_vn4seo_focus_keyword'=>'',
					'plugin_vn4seo_canonical_url'=>'',
					'link'=>'https://www.google.com.vn',
					'plugin_vn4seo_facebook_title'=>'',
					'plugin_vn4seo_facebook_description'=>'',
					'plugin_vn4seo_facebook_image'=>'',
					'plugin_vn4seo_twitter_title'=>'',
					'plugin_vn4seo_twitter_description'=>'',
					'plugin_vn4seo_twitter_image'=>'',
				];
			}
			
			echo view_plugin($plugin,'view.post-type.master', ['plugin_keyword'=>$plugin->key_word,'post'=>$post,'data'=>$data]);
		}else{
			echo 'None SEO';
		}
	}, 
	function($post, $request){

		if( get_admin_object($post->type)['public_view'] ){

			$input = $request->get('plugin_vn4seo');

			$arg = ['plugin_vn4seo_google_title','plugin_vn4seo_google_description','plugin_vn4seo_focus_keyword','plugin_vn4seo_facebook_title','plugin_vn4seo_facebook_description','plugin_vn4seo_facebook_image','plugin_vn4seo_twitter_title','plugin_vn4seo_twitter_description','plugin_vn4seo_twitter_image','plugin_vn4seo_canonical_url'];

			foreach ($input as $key => $value) {
				if( array_search($key, $arg) === false ){
					unset($input[$key]);
				}
			}

			$meta = '<meta name="description" content="'.e(vn4_one_or($input['plugin_vn4seo_google_description'],$post->title)).'" />';
			if( isset($input['plugin_vn4seo_canonical_url']) && $input['plugin_vn4seo_canonical_url'] ){
				$meta .= '<link rel="canonical" href="'.$input['plugin_vn4seo_canonical_url'].'" />';
			}
			
			$meta .= '<meta property="og:type" content="article" />';
			$meta .= '<meta property="og:title" content="'.e(vn4_one_or($input['plugin_vn4seo_facebook_title'],$post->title)).'" />';
			$meta .= '<meta property="og:description" content="'.e(vn4_one_or($input['plugin_vn4seo_facebook_description'],$post->title)).'" />';
			$meta .= '<meta property="og:url" content="'.get_permalinks($post).'" />';
			$meta .= '<meta property="og:site_name" content="'.e(setting('general_site_title')).'" />';
			if( $input['plugin_vn4seo_facebook_image'] && $img = get_media($input['plugin_vn4seo_facebook_image']) ){
				$meta .= '<meta property="og:image" content="'.$img.'" />';
			}

			$meta .= '<meta name="twitter:card" content="summary" />';
			$meta .= '<meta name="twitter:title" content="'.e(vn4_one_or($input['plugin_vn4seo_twitter_title'],$post->title)).'" />';
			$meta .= '<meta name="twitter:description" content="'.e(vn4_one_or($input['plugin_vn4seo_twitter_description'],$post->title)).'" />';
			if( $input['plugin_vn4seo_twitter_image'] && $img = get_media($input['plugin_vn4seo_twitter_image']) ){
				$meta .= '<meta name="twitter:image" content="'.$img.'" />';
			}
			

			$input['meta'] = $meta;

			$post->updateMeta($input);
		}
		return $post;
	}
);

