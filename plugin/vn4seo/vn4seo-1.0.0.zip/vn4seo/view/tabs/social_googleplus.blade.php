<h4>Google+ settings</h4>
<p>If you have a Google+ page for your business, add that URL here and link it on your Google+ page's about page.</p>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" >Google Publisher Page:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>
