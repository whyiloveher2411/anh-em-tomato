<?php

return [
	'seo'=>['title'=>'SEO','callback'=>function( $searchArray, $searchString ) use ($plugin){

		return [
			[
				'title_type'=>'Vn4SEO',
				'title'=>'Cài đặt',
				'link'=>route('admin.plugins.'.$plugin->key_word,'setting'),
			],
			[
				'title_type'=>'Vn4SEO',
				'title'=>'Cài đặt SEO Cho trang tĩnh',
				'link'=>route('admin.plugins.'.$plugin->key_word,'page_setting'),
			],
			[
				'title_type'=>'Vn4SEO',
				'title'=>'Sitemap',
				'link'=>route('admin.plugins.'.$plugin->key_word,'sitemap'),
			],
			[
				'title_type'=>'Vn4SEO',
				'title'=>'Tool',
				'link'=>route('admin.plugins.'.$plugin->key_word,'tool'),
			]
		];
		

	}]
];