<?php
if( $r->isMethod('GET') ){
	return view_plugin($plugin,'view.page_setting',['plugin'=>$plugin]);
}

$theme_name = theme_name();

if( file_exists(cms_path('resource','views/themes/'.$theme_name.'/page/'.$r->get('file_page').'.blade.php') ) ){

	$file = $r->get('file_page');

	$input = $r->get('plugin_vn4seo');

	$arg = ['plugin_vn4seo_google_title','plugin_vn4seo_google_description','plugin_vn4seo_focus_keyword','plugin_vn4seo_facebook_title','plugin_vn4seo_facebook_description','plugin_vn4seo_facebook_image','plugin_vn4seo_twitter_title','plugin_vn4seo_twitter_description','plugin_vn4seo_twitter_image'];

	foreach ($input as $key => $value) {
		if( array_search($key, $arg) !== false ){
			save_theme_options($file.'_page',$key,$value);
		}
	}

	return redirect()->back();
}

return redirect()->route('admin.plugins.'.$plugin->key_word,'page_setting');