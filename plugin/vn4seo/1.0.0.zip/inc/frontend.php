<?php
add_action('frontend_init',function($request) use ($plugin) {
	
	add_filter('meta',function($meta_old) use ($request,$plugin){

		if( !is_array($meta_old )) $meta_old = [];

		$meta_vn4seo = [];

		$post = get_post();

		$title = __t(setting('general_site_title','Vn4CMS'));

		$webmaster_tools = json_decode($plugin->getMeta('webmaster-tools'),true);

		if( isset($webmaster_tools['google']['tag']) ){

			$meta_vn4seo['webmaster_tools_google'] = '<meta name="google-site-verification" content="'.$webmaster_tools['google']['tag'].'" />';
		}

		if( $post ){

			$meta = $post->getMeta(['plugin_vn4seo_facebook_title','plugin_vn4seo_facebook_description','plugin_vn4seo_facebook_image','plugin_vn4seo_twitter_title','plugin_vn4seo_twitter_description','plugin_vn4seo_twitter_image','plugin_vn4seo_google_description','plugin_vn4seo_google_title']);
			//google
			title_head(vn4_one_or($meta['plugin_vn4seo_google_title'],$post->title));
			
			$meta_vn4seo[] = '<meta name="description" content="'.vn4_one_or($meta['plugin_vn4seo_google_description'],$post->title).'" />';

			//facebook
			$meta_vn4seo['fb_locale'] = '<meta property="og:locale" content="'.App::getLocale().'" />';
			$meta_vn4seo['fb_type'] = '<meta property="og:type" content="article" />';
			$meta_vn4seo['fb_title'] = '<meta property="og:title" content="'.vn4_one_or($meta['plugin_vn4seo_facebook_title'],$post->title).'" />';
			$meta_vn4seo['fb_description'] = '<meta property="og:description" content="'.vn4_one_or($meta['plugin_vn4seo_facebook_description'],$post->title).'" />';
			$meta_vn4seo['fb_url'] = '<meta property="og:url" content="'.URL::current().'" />';
			$meta_vn4seo['fb_site_name'] = '<meta property="og:site_name" content="'.$title.'" />';
			if( $meta['plugin_vn4seo_facebook_image'] ){
				$meta_vn4seo['fb_image'] = '<meta property="og:image" content="'.get_media($meta['plugin_vn4seo_facebook_image']).'" />';
			}

			//twitter
			$meta_vn4seo['tw_card'] = '<meta name="twitter:card" content="summary" />';
			$meta_vn4seo['tw_title'] = '<meta name="twitter:title" content="'.vn4_one_or($meta['plugin_vn4seo_twitter_title'],$post->title).'" />';
			$meta_vn4seo['tw_description'] = '<meta name="twitter:description" content="'.vn4_one_or($meta['plugin_vn4seo_twitter_description'],$post->title).'" />';
			if( $meta['plugin_vn4seo_twitter_image'] ){
				$meta_vn4seo['tw_image'] = '<meta name="twitter:image" content="'.get_media($meta['plugin_vn4seo_twitter_image']).'" />';
			}


		}elseif( $GLOBALS['route_name'] === 'page' || $GLOBALS['route_name'] === 'vn4-multiple-language.page' ){

			$page = $request->route('page');

			$theme_option = theme_options($page.'_page');
			// dd($theme_option);

			$title = isset($theme_option['plugin_vn4seo_google_title'])?$theme_option['plugin_vn4seo_google_title']:title_head();

			title_head($title);
			
			$meta_vn4seo[] = '<meta name="description" content="'.(isset($theme_option['plugin_vn4seo_google_description'])?$theme_option['plugin_vn4seo_google_description']:$title).'" />';

			//facebook
			$meta_vn4seo['fb_locale'] = '<meta property="og:locale" content="'.App::getLocale().'" />';
			$meta_vn4seo['fb_type'] = '<meta property="og:type" content="article" />';
			$meta_vn4seo['fb_title'] = '<meta property="og:title" content="'.(isset($theme_option['plugin_vn4seo_facebook_title'])?$theme_option['plugin_vn4seo_facebook_title']:$title).'" />';
			$meta_vn4seo['fb_description'] = '<meta property="og:description" content="'.(isset($theme_option['plugin_vn4seo_facebook_description'])?$theme_option['plugin_vn4seo_facebook_description']:$title).'" />';
			$meta_vn4seo['fb_url'] = '<meta property="og:url" content="'.URL::current().'" />';
			$meta_vn4seo['fb_site_name'] = '<meta property="og:site_name" content="'.$title.'" />';
			if( isset($theme_option['plugin_vn4seo_facebook_image'] ) ){
				$meta_vn4seo['fb_image'] = '<meta property="og:image" content="'.get_media($theme_option['plugin_vn4seo_facebook_image']).'" />';
			}

			//twitter
			$meta_vn4seo['tw_card'] = '<meta name="twitter:card" content="summary" />';
			$meta_vn4seo['tw_title'] = '<meta name="twitter:title" content="'.(isset($theme_option['plugin_vn4seo_twitter_title'])?$theme_option['plugin_vn4seo_twitter_title']:$title ).'" />';
			$meta_vn4seo['tw_description'] = '<meta name="twitter:description" content="'.((isset($theme_option['plugin_vn4seo_twitter_description'])?$theme_option['plugin_vn4seo_twitter_description']:$title )).'" />';
			if( isset($theme_option['plugin_vn4seo_twitter_image'] ) ){
				$meta_vn4seo['tw_image'] = '<meta name="twitter:image" content="'.get_media($theme_option['plugin_vn4seo_twitter_image']).'" />';
			}

		}else{
			$meta_vn4seo['fb_type'] = '<meta property="og:type" content="website" />';
		}

		return array_merge($meta_old,$meta_vn4seo);

	},'vn4seo',true);
	

});



// add_shortcode('video_youtube',function($param, $content){

// 	extract( shortcode_atts([
// 		'width'=>'560',
// 		'height'=>'315',
// 		'id'=>'Bx8I5rWRo1M'
// 		], $param) );

// 	return '<iframe width="'.$width.'" height="'.$height.'" src="https://www.youtube.com/embed/'.$id.'" frameborder="0" allowfullscreen></iframe>';

// });

