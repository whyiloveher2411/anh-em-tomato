<?php

// add_route('/seo-vn4/dashboard','admin.plugins.'.$plugin->key_word.'.dashboard','after_route_backend',function($r) use ($plugin) {
// 	return view_plugin($plugin,'view.dashboard',['plugin_source'=>$plugin->key_word]);
// });

// add_route('/seo-vn4/social','admin.plugins.'.$plugin->key_word.'.social','after_route_backend',function($r) use ($plugin) {
// 	return view_plugin($plugin,'view.social',['plugin_source'=>$plugin->key_word]);
// });

// add_action('vn4_adminbar_tool',function() use ($plugin) {
// 	echo '<a href="'.route('seo.tool').'"><img src="https://dev.dna.vn/cms_dev/plugins/vn4seo/img/icon-sidebar.png" /> SEO TOOL</a>';
// });

add_route('/seo-vn4/{page}','admin.plugins.'.$plugin->key_word,'after_route_backend',function($r, $__vn4_page) use ($plugin) {
	if( file_exists(__DIR__.'/'.$__vn4_page.'.php') ){
		return include __DIR__.'/'.$__vn4_page.'.php';
	}

	return redirect()->route('admin.index');
});


add_action('vn4_adminbar',function() use ($plugin) {
	echo view_plugin($plugin,'view.nav-top');
},'z');


add_sidebar_admin(function() use ($plugin) {

	$sidebar_seo_vn4[] = [
		'title'=>'Vn4SEO <span class="label lable-info label-success pull-right">'.__('Coming Soon').'</span>',
		// 'icon'=>'fa-usb',
		'image-icon'=>plugin_asset($plugin,'img/icon-sidebar.png'),
		// 'url'=>'#',
		'submenu'=>[
			['title'=>'Setting','url'=>route('admin.plugins.'.$plugin->key_word,'setting')],
			['title'=>'SEO Page','url'=>route('admin.plugins.'.$plugin->key_word,'page_setting')],
			['title'=>'Sitemap','url'=>route('admin.plugins.'.$plugin->key_word,'sitemap')],
			['title'=>'AMP','url'=>'#'],
			['title'=>'JSON-LD','url'=>'#'],
			['title'=>'Tool','url'=>route('admin.plugins.'.$plugin->key_word,'tool')],
		],
	];

	return $sidebar_seo_vn4;
},'manager');

add_meta_box(
	'plugin-seo-general',
	'Search Engine Optimization',
	function($config){
		return isset($config['public_view']) && $config['public_view'];
	},
	'left',
	'plugin-seo-general' ,
	function($customePostConfig, $post) use ($plugin){
		if( $customePostConfig['public_view'] ){

			if( $post ){
				$data = [
					'plugin_vn4seo_google_title'=>$post->getMeta('plugin_vn4seo_google_title',$post->title),
					'plugin_vn4seo_google_description'=>$post->getMeta('plugin_vn4seo_google_description',''),
					'plugin_vn4seo_focus_keyword'=>$post->getMeta('plugin_vn4seo_focus_keyword',''),
					'link'=>get_permalinks($post),
					'plugin_vn4seo_facebook_title'=>$post->getMeta('plugin_vn4seo_facebook_title'),
					'plugin_vn4seo_facebook_description'=>$post->getMeta('plugin_vn4seo_facebook_description'),
					'plugin_vn4seo_facebook_image'=>$post->getMeta('plugin_vn4seo_facebook_image'),
					'plugin_vn4seo_twitter_title'=>$post->getMeta('plugin_vn4seo_twitter_title'),
					'plugin_vn4seo_twitter_description'=>$post->getMeta('plugin_vn4seo_twitter_description'),
					'plugin_vn4seo_twitter_image'=>$post->getMeta('plugin_vn4seo_twitter_image'),
				];
			}else{
				$data = [
					'plugin_vn4seo_google_title'=>'',
					'plugin_vn4seo_google_description'=>'',
					'plugin_vn4seo_focus_keyword'=>'',
					'link'=>'https://www.google.com.vn',
					'plugin_vn4seo_facebook_title'=>'',
					'plugin_vn4seo_facebook_description'=>'',
					'plugin_vn4seo_facebook_image'=>'',
					'plugin_vn4seo_twitter_title'=>'',
					'plugin_vn4seo_twitter_description'=>'',
					'plugin_vn4seo_twitter_image'=>'',
				];
			}
			
			echo view_plugin($plugin,'view.post-type.master', ['plugin_keyword'=>$plugin->key_word,'post'=>$post,'data'=>$data]);
		}else{
			echo 'None SEO';
		}
	}, 
	function($post, $request){

		if( get_admin_object($post->type)['public_view'] ){

			$input = $request->get('plugin_vn4seo');

			$arg = ['plugin_vn4seo_google_title','plugin_vn4seo_google_description','plugin_vn4seo_focus_keyword','plugin_vn4seo_facebook_title','plugin_vn4seo_facebook_description','plugin_vn4seo_facebook_image','plugin_vn4seo_twitter_title','plugin_vn4seo_twitter_description','plugin_vn4seo_twitter_image'];

			foreach ($input as $key => $value) {
				if( array_search($key, $arg) === false ){
					unset($input[$key]);
				}
			}

			$post->updateMeta($input);
		}
		return $post;
	}
);

