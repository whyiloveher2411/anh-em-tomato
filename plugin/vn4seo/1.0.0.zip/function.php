<?php

$plugin_key_word = $plugin->key_word;


if( $plugin->getMeta('active_sitemap') ){

	add_route('{type}.xml','sitemap_detail','before_route_frontend',function($r,$type) use ($plugin) {
		return response()->view( 'plugins.'.$plugin->key_word.'.view.frontend.sitemap',['plugin'=>$plugin,'type'=>$type])->header('Content-Type', 'application/xml');
	});
}


if( is_admin() ){
	include __DIR__.'/inc/backend.php';
}else{
	include __DIR__.'/inc/frontend.php';
}

/*
class Widget_Facebook_Fanpage extends Vn4Widget {

	private $plugin;

	function __construct(){

		$this->plugin = basename (__DIR__);

		parent::__construct('facebook_fanpage','Vn4SEO: '.__p('Facebook Fanpage',$this->plugin),[
			'description'=>__p('Insert facebook fanpage onto website',$this->plugin),
			'instance' => ['link_fanpage'=>''],
		]);

	}

	function form(){
		?>
			<label><?php echo __p('Link fanpage',$this->plugin) ?>
              <input type="text" name="link_fanpage" value="<?php echo e($this->get_field_value('link_fanpage')) ?>"  class="form-control">
            </label>
            
		<?php
	}

	function widget(){

		add_action('vn4_footer',function(){
			echo '<div id="fb-root"></div><script defer async="async" src="'.plugin_asset($this->plugin,'js/facebook_sdk.js').'"></script>';
		},'facebook_sdk',true);

		?>

			<div class="fb-page" data-href="<?php echo $this->get_field_value('link_fanpage'); ?>" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
			  <blockquote cite="<?php echo $this->get_field_value('link_fanpage'); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo $this->get_field_value('link_fanpage'); ?>">Facebook Fanpage</a></blockquote>
			</div>
		<?php
	}

}

class Widget_Button_Share_Social extends Vn4Widget{
	private $plugin;
	function __construct(){

		$this->plugin = basename (__DIR__);

		parent::__construct('Widget_Button_Share_Social','Vn4SEO: '.__p('Button Share Social',$this->plugin),[
			'description'=>__p('Insert the button to share the website on social networks',$this->plugin),
			'instance' => ['title'=>'Tiêu đề'],
		]);

	}

	function form(){
		?>
			<label><?php echo __p('Title',$this->plugin); ?>
              <input type="text" name="title" value="<?php echo e($this->get_field_value('title')) ?>"  class="form-control">
            </label>
            
		<?php
	}

	function widget(){

		?>	
			<div class="button-share-socual">
				<h4><?php echo $this->get_field_value('title'); ?></h4>
				<p><a href="http://www.facebook.com/sharer/sharer.php?u=<?php echo Request::fullUrl(); ?>"  onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
						target="_blank" title="Share on Facebook">Facebook</a> &nbsp;
				<a href="https://plus.google.com/share?url=<?php echo Request::fullUrl(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
						target="_blank" class="gg" title="Share on Google">Google+</a> &nbsp;
				<a href="http://api.addthis.com/oexchange/0.8/forward/email/offer?url=<?php echo Request::fullUrl(); ?>&title=<?php echo vn4_one_or(do_action('title_head'),setting('general_site_title')) ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;"
						target="_blank" class="mail" title="Share on Google">Email</a></p>
			</div>
					
		<?php
	}

}

register_widget('Widget_Facebook_Fanpage','Widget_Button_Share_Social');  



