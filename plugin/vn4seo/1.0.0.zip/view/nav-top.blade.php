<li class="li-title">
	<a href="http://dev.dna.vn/cms_dev/admin2/create_data/page?post=13&amp;action_post=edit&amp;rel=vn4-adminbar" target="_blank"><i class="fa fa-share-alt" aria-hidden="true"></i>SEO</a>

	<div class="sub-menu menu-admin">
		<ul>
			<li class="li-title"><a href="#">Thông báo</a></li>
			<li class="li-title"><a href="#">Các bước cấu hình</a></li>
			<li class="li-title"><a href="#">Nghiên cứu từ khóa <span class="fa fa-caret-down"></span></a>
				<div class="sub-menu">
					<ul>
						<li class="li-title"><a href="#">Keyword research training</a></li>
						<li class="li-title"><a href="#">AdWords External</a></li>
						<li class="li-title"><a href="#">Google Trends</a></li>
						<li class="li-title"><a href="#">Sách SEO</a></li>
					</ul>
				</div>
			</li>
			<li class="li-title"><a href="#">Phân tích trang này <span class="fa fa-caret-down"></span></a>
				<div class="sub-menu">
					<ul>
						<li class="li-title"><a href="#">Check links to this URL</a></li>
						<li class="li-title"><a href="#">Kiểm tra mật độ từ khóa</a></li>
						<li class="li-title"><a href="#">Kiểm tra Google Cache</a></li>
						<li class="li-title"><a href="#">Kiểm tra Header</a></li>
						<li class="li-title"><a href="#">Công cụ kiểm tra dữ liệu có cấu trúc của Google</a></li>
						<li class="li-title"><a href="#">Công cụ tìm lỗi Facebook</a></li>
						<li class="li-title"><a href="#">Công cụ xác nhận Pinterest Rich Pins</a></li>
						<li class="li-title"><a href="#">Trình kiểm tra HTML</a></li>
						<li class="li-title"><a href="#">Kiểm tra Google Page Speed</a></li>
						<li class="li-title"><a href="#">Kiểm tra mức độ thân thiện trên di động</a></li>
					</ul>
				</div>
			</li>
			<li class="li-title"><a href="#">Thiết lập SEO</a></li>
		</ul>
	</div>
</li>