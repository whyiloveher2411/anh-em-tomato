<h4>Webmaster Tools verification</h4>
<p>You can use the boxes below to verify with the different Webmaster Tools, if your site is already verified, you can just forget about these. Enter the verify meta values for:</p>

<?php 
	$webmaster_tools = json_decode($plugin->getMeta('webmaster-tools'),true);
 ?>
<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" ><a href="">Bing Webmaster Tools:</a></label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>
<br>
<style type="text/css">
	.preview_file img{
		max-width: 45px;
	}
</style>
<div class="form-group">
	<div class="row">

		<div class="col-md-3 col-xs-12">
			<label>Google Search Console:</label>
			<p class="note">Vui lòng chọn phương thức xác thực.</p>
			<p><a href="https://search.google.com/u/0/search-console?resource_id={!!env('APP_URL')!!}" target="_blank">Xem Chi tiết</a></p>
		</div>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">

			<label>Tệp HTML

			@if( isset($webmaster_tools['google']['file']) )
				<?php 

					$file = json_decode($webmaster_tools['google']['file'],true);
					$file_info = pathinfo(cms_path('public',$file['link']));
				 ?>
				| <a href="{!!env('APP_URL').'/'.$file_info['basename']!!}" target="_blank">Kiểm tra</a>
			@endif

			</label>
			{!!get_field('asset-file',['value'=>isset($webmaster_tools['google']['file'])?$webmaster_tools['google']['file']:'','name'=>'webmaster-tools[google][file]','key'=>'webmaster_tools_google_file'])!!}
			<br>
			<label>Thẻ HTML</label>
			<input name="webmaster-tools[google][tag]" value="{!!isset($webmaster_tools['google']['tag'])?$webmaster_tools['google']['tag']:''!!}" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note">Get your Google verification code in <a href="https://search.google.com/u/0/search-console?resource_id={!!env('APP_URL')!!}" target="_blank">Google Search Console</a>.</p>
		</div>
	</div>
</div>


<br>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" ><a href="">Yandex Webmaster Tools:</a></label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
		</div>
	</div>
</div>
