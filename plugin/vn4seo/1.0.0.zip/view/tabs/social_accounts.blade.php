<h3>Your social profiles</h3>
<p class="note">To let search engines know which social profiles are associated to this site, enter them below:</p><br>
<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > Facebook Page URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>
<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > Twitter Username:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > Instagram URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > LinkedIn URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > MySpace URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > Pinterest URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > YouTube URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

<div class="form-group">
	<div class="row">
		<label class="col-md-3 col-xs-12" > Google+ URL:</label>
		<div class="col-md-8 col-sm-8 col-xs-12 vn4-pd0">
			<input name="title" required="" value="" type="text" id="title" class="form-control col-md-7 col-xs-12">
			<p class="note"></p>
		</div>
	</div>
</div>

