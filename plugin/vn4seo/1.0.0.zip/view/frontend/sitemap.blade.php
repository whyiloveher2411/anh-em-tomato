<?xml version="1.0" encoding="UTF-8"?>


@if( isset($type) && $post_type = get_admin_object($type) )

<?php 
$posts = get_posts($type,1000000);
?>

<urlset xmlns="http://www.google.com/schemas/sitemap/0.84" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84 http://www.google.com/schemas/sitemap/0.84/sitemap.xsd">


     @foreach($posts as $p)
	<url>
		<loc>{!!get_permalinks($p)!!}</loc>
		<priority>1.0</priority>
		<lastmod>{!!date_format($p->updated_at,DATE_ATOM)!!}</lastmod>
		<changefreq>daily</changefreq>
	</url>
	 @endforeach

</urlset>



@else

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
	<?php

	$post_type_actived = json_decode($plugin->getMeta('post-type-sitemap'),true);

	if( !is_array($post_type_actived) ) $post_type_actived = [];

	$domain = env('APP_URL');

	?>
	@foreach($post_type_actived as $p)
	<sitemap>
      <loc>{!!route('sitemap_detail',$p)!!}</loc>
   </sitemap>
	@endforeach

</sitemapindex>
@endif
