<script type="text/javascript">
     var before_loadtime = new Date().getTime();

     if (window.addEventListener) // W3C standard
	{
	  window.addEventListener('load', function(){
	  	
	  	var aftr_loadtime = new Date().getTime();
         // Time calculating in seconds
         pgloadtime = (aftr_loadtime - before_loadtime) / 1000;

         document.getElementById("loadtime").innerHTML = 'Page load time is <font color="red"><b><span id="time3">' + pgloadtime + '</span></b></font> Seconds (Thời gian user tải về các tài nguyên cần thiết VD: javascript, style, image, fonts, ....) (3)<a href="#"> (Hướng dẫn tối ưu) </a>';

         var total_time = document.getElementsByClassName("total_time"),
         	kqdb = (parseFloat( document.getElementById("time1").innerHTML) / 1000 + parseFloat(document.getElementById("time2").innerHTML) + pgloadtime ).toFixed(5);

		for (var i = 0; i < total_time.length; i++) {
			total_time[i].innerHTML = kqdb;
		};

	  }, false); // NB **not** 'onload'
	}
     // window.onload  = function() {

         

     // }

</script>