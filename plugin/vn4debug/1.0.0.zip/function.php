<?php
if( is_admin() ){

	add_action('before_route_backend',function() use ($plugin) {

		if(!Route::has('admin.plugins.'.$plugin->key_word.'.index')){

			Route::any('/plugins/'.$plugin->key_word,['as'=>'admin.plugins.'.$plugin->key_word.'.index','uses'=>function() use ( $plugin){

				$viewplugin = check_permission('view_plugin_debug_error');

				if(!$viewplugin){
					die('Bạn không có quyền xem cài đặt plugin debug.');
				}

				$r = request();

				if($r->isMethod('GET')){	

					$data['plugin'] = plugin($plugin->key_word);

					$data2 =  $data['plugin']->getMeta();
					
					if($data2){

						$data = array_merge($data, $data2  );

					}

					return view_plugin($plugin,'view.admin-setting',$data);
				}

				if($r->isMethod('POST')){

					$input = $r->all();

					$data =  $plugin->getMeta();

					$data['general'] = $input;

					$plugin->updateMeta($data);

					return redirect()->back();

				}

			}]);

		}
		
	});
	
	add_filter('add_sidebar_admin_',function($sidebar) use ($plugin){

		if( !isset($sidebar['manager']['setting']) ){

			$sidebar['manager']['setting'] = [
				  'title'=>'Setting',
				  'icon'=>'fa-cog',
				  'submenu'=>[
				    'a'=>[ 
				    	'title'=>'Debug',
	        			'url'=>route('admin.plugins.'.$plugin->key_word.'.index')
	        		],
				  ]  
				];

		}else{
			$sidebar['manager']['setting']['submenu'][] = [ 'title'=>'Debug',
	        'url'=>route('admin.plugins.'.$plugin->key_word.'.index')];
		}

		return $sidebar;

	});

}


add_action('handler_error',function($valuedefault,$request ,$e) use ($plugin){

	try {

		if ($e instanceof \Illuminate\Session\TokenMismatchException) {

	      	vn4_create_session_message( trans('master.word_error'), trans('master.message_error_miss_token'), 'error' , true);

	      	return redirect()->route('login');
	    }

		$data_plugin = $plugin->getMeta();

		$debugClient 	= false;
		$debugAdmin 	= false;

		$active_debug = $request->get('active_debug',false);

		if( isset($data_plugin['general']['show_debug_message']) && $data_plugin['general']['show_debug_message'] != '' && $active_debug == $data_plugin['general']['show_debug_message']){
			$active_debug = true;
		}else{
			$active_debug = false;
		}


		if(isset($data_plugin['general']['debug_backend'])){
			$debugAdmin = $data_plugin['general']['debug_backend'];
		}

		if(isset($data_plugin['general']['debug_frontend'])){
			$debugClient = $data_plugin['general']['debug_frontend'];
		}


		$is_link_admin =  is_admin();

		if ( $is_link_admin ) {

			if( $debugAdmin == '1' || $active_debug){

				return $valuedefault;

			}else{

				$statusCode = $e->getStatusCode();

				if( !View::exists( 'admin.error.'.$statusCode ) ){

					$viewError = 'default.error.'.$statusCode;

				}else{

					$viewError =  'admin.error.'.$statusCode;

				}

				if( View::exists( $viewError ) ){

					return response()->view($viewError , ['exception'=>$e], $statusCode);
				
				}

				dd($statusCode);
			}

	    }else{

	    	if( $debugClient == '1' || $active_debug){

				return $valuedefault;

			}else{

				if( method_exists($e,'getStatusCode') ){
					$statusCode = $e->getStatusCode();
				}else{
					$statusCode = 0;
				}

				$theme = theme_name();

				if( !View::exists( 'themes.'.$theme.'.error.'.$statusCode ) ){

					if( !View::exists( 'themes.'.$theme.'.'.$statusCode ) ){

						$viewError = 'default.error.'.$statusCode;

					}else{

						$viewError = 'themes.'.$theme.'.'.$statusCode;

					}


				}else{

					$viewError = 'themes.'.$theme.'.error.'.$statusCode;

				}

				if( View::exists( $viewError ) ){

					return response()->view($viewError , ['exception'=>$e], $statusCode);
				
				}

				dd($statusCode);
			}

	    }
	    return $valuedefault;

	} catch (Exception $e) {
		return $valuedefault;					
	}


},'a');

//show query
add_action('init',function() use ($plugin){

	if(!Auth::check()){
		return;
	}

	$data_plugin = $plugin->getMeta();

	$query_admin 	= false;
	$query_client 	= false;
	$request = request();

	$active_query = $request->get('active_query',false);

	if(isset($data_plugin['general']['show_query_message']) && $data_plugin['general']['show_query_message'] != '' && $active_query == $data_plugin['general']['show_query_message']){
		$active_query = true;
	}else{
		$active_query = false;
	}

	if(isset($data_plugin['general']['show_query_backend'])){
		$query_admin = $data_plugin['general']['show_query_backend'];
	}

	if(isset($data_plugin['general']['show_query_frontend'])){
		$query_client = $data_plugin['general']['show_query_frontend'];
	}

	$is_link_admin =  is_admin();

	if( ($is_link_admin && $query_admin) || (!$is_link_admin && $query_client ) || $active_query){

		if( Auth::user()->customize_time < time() ){
			add_action(['admin_after_open_head','before_vn4_head'],function() use ($plugin){
				echo view_plugin($plugin,'view.script-debug');
			},'debug_error_plugin_time_load_page',true);
		}
		
		$GLOBALS['total_query_debug'] = 0;
		$GLOBALS['total_query_time_debug'] = 0;

		DB::listen(
		    function ($q) {

		    	add_action(['debug_error_query'],function() use ($q){
		    		$bindings = $q->bindings;
		    		$time = $q->time;
		    		$sql = $q->sql;
		    		foreach ($bindings as $value) {
		    			// substr_replace(string, replacement, start)
		    			// $sql = substr_replace('?', $value, strpos($sql, '?'), 1);
		    			$sql = substr_replace($sql, $value, strpos($sql,'?'), 1 );
		    			// $sql = str_replace('?', $value, $sql);
		    		}

	    			$GLOBALS['total_query_debug'] = $GLOBALS['total_query_debug'] + 1;
	    			$GLOBALS['total_query_time_debug'] = $GLOBALS['total_query_time_debug'] + $time;
	    			echo '<span style="background:#a20000;border: 1px solid white;color:white;display:inline-block;width:100%;font-size:13px;">'.$sql;
	    			echo ' <span style="color:black;background:white;"> Time: '.$time.'</span>';
	        		echo "</span>";
				});
		    }
		); 

		if(!$is_link_admin ){

			if( Auth::user()->customize_time < time() ){

						
				add_action(['vn4_footer'],function() use ($plugin) {

					echo view_plugin($plugin,'view.info-query');
					
				},'debug_error_plugin_time_query',true);
			}
		}else{

			add_action('list_screen',function($list_screen) use ($plugin) {

				$list_screen[$plugin->key_word] = [
					'title'=>'Plugin Debug Error _ Show Query',
					'title_button'=>'Plugin Debug | <font color="red"><b><span class="total_time"></span></b></font>',
					'html_screen'=>view_plugin($plugin,'view.info-query'),
				];

				return $list_screen;
			});
				
		}

	}

});

