<?php
return [
	[
		'group'=>'plugin.plugin_vn4debug',
		'key'=>'view_plugin_debug_error',
		'title'=>'View setting plugin Vn4Debug',
		'title_group'=>'Vn4 Debug'
	],
];
