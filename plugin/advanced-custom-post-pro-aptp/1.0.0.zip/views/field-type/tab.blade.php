<tr class="field_option field_option_tab">
    <td class="td-label">
      <label for="post_type">Instructions</label>
    </td>
    <td>
    	<p>
    		Use "Tab Fields" to better organize your edit screen by grouping your fields together under separate tab headings.
    		</p>
    		<p>All the fields following this "tab field" (or until another "tab field" is defined) will be grouped together.
    		</p>
    		<p>Use multiple tabs to divide your fields into sections.
    	</p>
    </td>
</tr>