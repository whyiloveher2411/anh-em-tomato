<?php return array (
  'Customise Post Type with powerful, professional and intuitive fields.' => 'Customise Post Type with powerful, professional and intuitive fields.',
);