<?php $param['type'] = 'email'; ?>
{!!get_field('input',$param, $param['post'])!!}
