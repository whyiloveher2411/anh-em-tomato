<?php
if( $r->isMethod('GET') ){
	return view_plugin($plugin, 'views.setting.translate');
}

if( $r->isMethod('POST') ){

	$type = $r->get('type');

	$languages = languages();

	$updateKey = $r->has('update_key');

	if( $type === 'core' ){

		if($updateKey){

			$argTransKey = [];

			foreach ($languages as $k => $l) {
				if( !file_exists($file = 'resources/lang/'.$l['lang_slug'].'.php') ){
					File::put($file, '<?php return [];');
					$argTransFile = [];
				}else{
					$argTransFile = include $file;
				}

				$argTransKey = array_merge($argTransKey, $argTransFile);
			}



			session(['___temp_key_core'=>['key'=>array_keys($argTransKey)]]);

			return response()->json(['error'=>false]);
		}

		$values = $r->get('value');

		$___temp_key_core = session('___temp_key_core',[]);

		foreach ($values as $k => $v) {
			foreach ($v as $k2 => $v2) {
				$___temp_key_core[$k][ $k2 ] = $v2;
			}
		}


		if( $r->has('is_lasted') ){

			foreach ($languages as $k => $l) {

				$str = "<?php \r\n return [\r\n";

				$count = count($___temp_key_core['key']);

				for ($i=0; $i < $count; $i++) {

					if( $___temp_key_core[$l['lang_slug']][$i] ){
						$str .= "\t'".str_replace("'", '&apos;', $___temp_key_core['key'][$i])."' => '".str_replace("'", '&apos;', $___temp_key_core[$l['lang_slug']][$i])."',\r\n";
					}else{
						$str .= "\t'".str_replace("'", '&apos;',$___temp_key_core['key'][$i])."' => '".str_replace("'", '&apos;',$___temp_key_core['key'][$i])."',\r\n";
					}
				}
				
				$str .= '];';

				File::put('resources/lang/'.$l['lang_slug'].'.php', $str);

			}

			Session::forget('___temp_key_core');

			return response()->json(['error'=>false,'message'=>'success']);
		}

		session(['___temp_key_core'=>$___temp_key_core]);

		return response()->json(['error'=>false]);

	}elseif( $type === 'plugin' ){

		if($updateKey){

			$argTransKeyPlugins = [];

			$obj = new Vn4Model(vn4_tbpf().'setting');

			$listPlugin = $obj->whereType('plugin')->where('status','publish')->pluck('key_word')->toArray();

			$folder_plugin = Config::get('view.paths')[0].'/plugins/';

			$count = count($listPlugin);

			for ($i=0; $i < $count; $i++) { 

				$argTransKey = [];

				foreach ($languages as $k => $l) {

					if( !file_exists($file = $folder_plugin.$listPlugin[$i].'/lang/'.$l['lang_slug'].'.php') ){
						$argTransFile = [];
					}else{
						$argTransFile = include $file;
					}

					$argTransKey = array_merge($argTransKey, $argTransFile);
				}

				$argTransKeyPlugins[$listPlugin[$i]] = array_keys($argTransKey); 

			}

			session(['___temp_key_plugin'=>['key'=>$argTransKeyPlugins]]);

			return response()->json(['error'=>false]);
		}

		$values = $r->get('value');

		$___temp_key_plugin = session('___temp_key_plugin',[]);

		$___temp_key_plugin = array_merge($___temp_key_plugin, $values);


		if( $r->has('is_lasted') ){

			$folder_plugin = Config::get('view.paths')[0].'/plugins/';

			foreach ($___temp_key_plugin['key'] as $key_plugin => $word) {

				if (!File::exists($folder_plugin.$key_plugin.'/'))
				{	
					continue;
				}

				if (!File::exists($folder_plugin.$key_plugin.'/lang/'))
				{	
					File::makeDirectory($folder_plugin.$key_plugin.'/lang/', 0777, true, true);
				}

				foreach ($languages as $k => $l) {
					$str = "<?php \r\n return [\r\n";
					
					$count = count($word);

					for ($i=0; $i < $count; $i++) { 
						if( $___temp_key_plugin[$l['lang_slug']][$key_plugin][$i] ){
							$str .= "\t'".str_replace("'", '&apos;', $word[$i])."' => '".str_replace("'", '&apos;', $___temp_key_plugin[$l['lang_slug']][$key_plugin][$i])."',\r\n";
						}else{
							$str .= "\t'".str_replace("'", '&apos;',$word[$i])."' => '".str_replace("'", '&apos;',$word[$i])."',\r\n";
						}
					}

					$str .= '];';

					File::put($folder_plugin.$key_plugin.'/lang/'.$l['lang_slug'].'.php', $str);

				}
			}

			Session::forget('___temp_key_plugin');

			return response()->json(['error'=>false,'message'=>'success']);

		}

		session(['___temp_key_plugin'=>$___temp_key_plugin]);

		return response()->json(['error'=>false,'data'=>$___temp_key_plugin]);


	}else{
		if($updateKey){

			$argTransKey = [];

			foreach ($languages as $k => $l) {
				if( !file_exists($file = 'resources/views/themes/'.theme_name().'/lang/'.$l['lang_slug'].'.php') ){
					File::put($file, '<?php return [];');
					$argTransFile = [];
				}else{
					$argTransFile = include $file;
				}

				$argTransKey = array_merge($argTransKey, $argTransFile);
			}

			session(['___temp_key_theme'=>['key'=>array_keys($argTransKey)]]);

			return response()->json(['error'=>false]);
		}

		$values = $r->get('value');

		$___temp_key_theme = session('___temp_key_theme',[]);

		foreach ($values as $k => $v) {
			foreach ($v as $k2 => $v2) {
				$___temp_key_theme[$k][ $k2 ] = $v2;
			}
		}

		if( $r->has('is_lasted') ){

			foreach ($languages as $k => $l) {

				$str = "<?php \r\n return [\r\n";

				$count = count($___temp_key_theme['key']);

				for ($i=0; $i < $count; $i++) {

					if( $___temp_key_theme[$l['lang_slug']][$i] ){
						$str .= "\t'".str_replace("'", '&apos;', $___temp_key_theme['key'][$i])."' => '".str_replace("'", '&apos;', $___temp_key_theme[$l['lang_slug']][$i])."',\r\n";
					}else{
						$str .= "\t'".str_replace("'", '&apos;',$___temp_key_theme['key'][$i])."' => '".str_replace("'", '&apos;',$___temp_key_theme['key'][$i])."',\r\n";
					}
				}
				
				$str .= '];';

				File::put('resources/views/themes/'.theme_name().'/lang/'.$l['lang_slug'].'.php', $str);
			}

			Session::forget('___temp_key_theme');

			return response()->json(['error'=>false,'message'=>'success']);
		}

		session(['___temp_key_theme'=>$___temp_key_theme]);

		return response()->json(['error'=>false]);

	}

	// return response()->json(['error'=>false]);

	return redirect()->back();
}