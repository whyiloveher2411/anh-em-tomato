<?php
if( $r->isMethod('GET') ){

	$languages = languages();
	// dd($languages);
	include __DIR__.'/lang_flags.php';

	if( $r->get('action') === 'default-lang' && $lang_default = $r->get('lang') ){

		$not_set = true;

		foreach ($languages as $key => $value) {
			if( $value['lang_slug'] === $lang_default ){
				$languages[$key]['is_default'] = true;
				$not_set = false;
			}else{
				$languages[$key]['is_default'] = false;
			}
		}

		if( $not_set ){
			$languages[key($languages)]['is_default'] = true;
		}

		$plugin->updateMeta('vn4-languages', $languages);

		// if( isset($languages[$lang_default]) ){
		// 	$plugin->updateMeta('default-lang', array_merge($languages[$lang_default], ['key'=>$lang_default]));
		// }else{
		// 	dd( array_merge(reset($languages), ['key'=>key($languages)]) );
		// 	$plugin->updateMeta('default-lang', array_merge(reset($languages), ['key'=>key($languages)]) );
		// }

		return redirect()->route('plugin.'.$plugin->key_word.'.languages');
	}

	if( $r->get('action') === 'delete' && $lang_delete = $r->get('lang') ){
		
		if( $languages[$lang_delete]['is_default'] ){
			foreach ($languages as $key => $value) {
				if( $key !== $lang_delete ){
					$languages[$key]['is_default'] = true;
					break;
				}
			}
		}

		if( isset($languages[$lang_delete]) ){
			unset($languages[$lang_delete]);
			$plugin->updateMeta('vn4-languages', $languages);
		}

		return redirect()->route('plugin.'.$plugin->key_word.'.languages');

	}


	return view_plugin($plugin, 'views.setting.languages',['languages'=>$arg_languages,'flags'=>$flags]);
}

if( $r->isMethod('POST') ){

	if( $r->has('add-language') ){

		$lang = languages();

		if( !is_array($lang) ) $lang = [];

		$lang_slug = $r->get('lang_slug');

		foreach ($lang as $key => $l) {
			if( $l['lang_slug'] === $lang_slug ){
				unset($lang[$key]);
			}				
		}

		$order = intval($r->get('order'));

		$lang_list = explode(':', $r->get('lang_list'));

		$lang[$r->get('lang_slug')] = ['lang_slug'=>$lang_slug,'lang_locale'=>$r->get('lang_locale'),'lang_name'=>$r->get('lang_name'),'order'=>$order,'flag'=>$r->get('flag'),'country_name'=>$r->get('country_name'),'text_direction'=>$r->get('text_direction'),'is_default'=>false];

		if( count($lang) < 2 ){
			$lang[$r->get('lang_slug')]['is_default'] = true;
		}

		$lang2 = [];

		usort($lang,function($a, $b){
			return $a['order'] >= $b['order'];
		});

		foreach ($lang as $value) {
			$lang2[$value['lang_slug']] = $value;
		}

		$plugin->updateMeta('vn4-languages', $lang2);

		return redirect(URL::previous());
		// $list_language = setting_save('');

	}

}