<?php

$regex_lang_page = '';
$custom_post_types = json_decode($plugin->getMeta('custom-post-types'),true);

$custom_post_types = $custom_post_types ? $custom_post_types : [];

// $my_bowser_lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
$my_bowser_lang = 'not_lang';

$GLOBALS['list_language'] = [];

foreach ($languages as $key=>$l) {
	
	$GLOBALS['list_language'][$l['lang_slug']] = $key ;

	if( $l['lang_slug'] === $my_bowser_lang ){
		$GLOBALS['lang_default'] = array_merge($l,['key'=>$key]);
	}

	$regex_lang_page .= '|('.$l['lang_slug'].')';
}

$regex_lang_page = substr($regex_lang_page, 1);

function register_page_slug($arg){

	add_filter('register_page_slug',function($filter) use ($arg) {
		return array_merge($filter, $arg);
	});

}

function register_action_miss_post_translate($arg){


	add_filter('register_action_miss_post_translate',function($filter) use ($arg){
		return array_merge($filter, $arg);
	} );

}

function get_translate_post($post, $callback = null ){

	if( !$callback ) $callback = function($key, $lang, $post){

		if( !$post ){
			return '<span hreflang="'.$lang['lang_slug'].'" title="'.__t('This post does not exist language').' '.$lang['lang_name'].'" class="language language-no-translate"><img src="'.get_flag_language($lang).'" alt="Language '.$lang['lang_slug'].'"> '.$lang['lang_name'].'?</span>';
		}

		$vn4mtl_custom_post_standard_config_page = vn4mtl_custom_post_standard_config_page();

		if( isset($vn4mtl_custom_post_standard_config_page[$post->type]) ){
			$post_type = $vn4mtl_custom_post_standard_config_page[$post->type][$lang['lang_slug']]['slug'];
		}else{
			$post_type = get_slug_custom_post_config($post->type);
		}

		return '<a hreflang="'.$lang['lang_slug'].'" href="'.route('vn4-multiple-language.post.detail',['language'=>$post->language,'post_type'=>$post_type,'slug'=>$post->slug]).'" class="post-translate language"><img src="'.get_flag_language($lang).'" alt="Language '.$lang['lang_slug'].'"> '.$lang['lang_name'].'</a>';
	};

	$meta = json_decode($post->getMeta('vn4-multiple-language-post-connect'),true);

	$result = '';

	$languages = languages();

	if( is_array($languages) ){

		foreach ($languages as $key=>$value) {

			if( $value['lang_slug'] !== $post->language ){
				if(  isset($meta[$value['lang_slug']]['id']) ){

					$post_relationship = get_post($post->type, $meta[$value['lang_slug']]['id']);

					if( $post_relationship ){
						$result .= $callback($key, $value, $post_relationship);
					}

				}else{
					$result .= $callback($key, $value, null);
				}
				
			}

		}
	}
	return $result;
	
}

function vn4mtl_get_standard_config_page(&$keyPage = null){

	if( isset($GLOBALS['vn4mtl_get_standard_config_page']) ){
		$keyPage = $GLOBALS['vn4mtl_get_standard_config_page']['keypage'];
		return $GLOBALS['vn4mtl_get_standard_config_page']['register_page_slug'];
	}

	$register_page_slug = apply_filter('register_page_slug');

	$languages = languages();

	$page_current = (isset($GLOBALS['route_current']->parameters['page']) )? $GLOBALS['route_current']->parameters['page']: null;

	foreach ($register_page_slug as $key => $value) {

		foreach ($languages as $key2 => $value2) {

			if( !isset($value[$value2['lang_slug']]['slug']) ){
				$register_page_slug[$key][$value2['lang_slug']]['slug'] = $key;
			}

			if( $register_page_slug[$key][$value2['lang_slug']]['slug'] === $page_current ){

				$keyPage = ['lang'=>$value2['lang_slug'],'slug'=>$page_current,'key_page'=>$key];

			}

		}

		
	}

	$GLOBALS['vn4mtl_get_standard_config_page'] = ['keypage'=>$keyPage,'register_page_slug'=>$register_page_slug];

	return $register_page_slug;

}

function register_custom_post_slug_languages($arg){

	add_filter('register_custom_post_slug',function($filter) use ($arg) {
		return array_merge($filter, $arg);
	});

}

function vn4mtl_custom_post_standard_config_page($post_type = null, &$post_type_match = null ){

	if( isset($GLOBALS['vn4mtl_custom_post_standard_config_page']) ){
		return $GLOBALS['vn4mtl_custom_post_standard_config_page'];
	}

	$register_custom_post_slug = apply_filter('register_custom_post_slug');

	$languages = languages();


	foreach ($register_custom_post_slug as $key => $value) {

		foreach ($languages as $key2 => $value2) {

			if( !isset($value[$value2['lang_slug']]['slug']) ){
				$register_custom_post_slug[$key][$value2['lang_slug']]['slug'] = $key;
			}

			if( $post_type === $register_custom_post_slug[$key][$value2['lang_slug']]['slug'] ){
				$post_type_match = $key;
			}

		}

		
	}

	$GLOBALS['vn4mtl_custom_post_standard_config_page'] = $register_custom_post_slug;

	return $register_custom_post_slug;
}

//hien thi tuy chon ngon ngu
function the_languages(){

	$callback = '';

	switch ($GLOBALS['route_name']) {

		case 'vn4-multiple-language.page':

			$register_page_slug = vn4mtl_get_standard_config_page($keyPage);

			if( $keyPage !== null ){

				$callback = function($key, $lang) use ($keyPage, $register_page_slug){
					return route('vn4-multiple-language.page',['language'=>$lang['lang_slug'],'page'=>$register_page_slug[$keyPage['key_page']][$lang['lang_slug']]['slug']]);
				};

			}else{
				$callback = function($key, $lang){
					return route('vn4-multiple-language.page',['language'=>$lang['lang_slug'],'page'=>$GLOBALS['route_current']->parameters['page']]);
				};

			}

			break;

		case 'vn4-multiple-language.index':
			$callback = function($key, $lang){
				return route('vn4-multiple-language.index',['language'=>$lang['lang_slug']]);
			};
			break;

		case 'vn4-multiple-language.post.detail':

			$post = get_post();


			if( !$post ){

				$callback = function($key, $lang){
					return route('vn4-multiple-language.404',['language'=>$lang['lang_slug']]);
				};

			}else{

				$post_relationship = json_decode($post->getMeta('vn4-multiple-language-post-connect'), true);

				if( is_array($post_relationship) ){

					$callback = function($key, $lang) use ($post_relationship,$post) {

						// Nếu tồn tại bài dịch
						if( isset($post_relationship['post'][$lang['lang_slug']]) && $postConnect = get_post($post->type, $post_relationship['post'][$lang['lang_slug']]['id']) ){

							$vn4mtl_custom_post_standard_config_page = vn4mtl_custom_post_standard_config_page();

							if( isset($vn4mtl_custom_post_standard_config_page[$postConnect->type][$lang['lang_slug']]['slug']) ){
								$post_type = $vn4mtl_custom_post_standard_config_page[$postConnect->type][$lang['lang_slug']]['slug'];
							}else{
								get_admin_object();
								
								$temp = array_flip($GLOBALS['custom_post_slug']);

								$post_type = $temp[$post->type];

							}

							return route('vn4-multiple-language.post.detail',['language'=>$postConnect->language,'post_type'=>$post_type,'slug'=>$postConnect->slug]);

						
						}

						$action = apply_filter('register_action_miss_post_translate');

						// Nếu tồn tại register register_action_miss_post_translate

						if( isset($action[$post->type]) ){

							if( is_string($action[$post->type])){

								$page_translate_slug = vn4mtl_get_standard_config_page();

								if( isset($page_translate_slug[$action[$post->type]]) ){
									return route('vn4-multiple-language.page',['page'=>$page_translate_slug[$action[$post->type]][$lang['lang_slug']]['slug'],'language'=>$lang['lang_slug']]);
								}

								return route('vn4-multiple-language.page',['page'=>$action[$post->type],'language'=>$lang['lang_slug']]);

							}else{
								return $action[$post->type]($key, $lang, $post);
							}
							
						}

						return route('vn4-multiple-language.index',['language'=>$lang['lang_slug']]);
						
					};

				}else{
					
					$callback = function($key, $lang) use ($post) {

						$action = apply_filter('register_action_miss_post_translate');

						if( $post && isset($action[$post->type]) ){

							if( is_string($action[$post->type]) ){
								return route('page',['page'=>$action[$post->type],'language'=>$key]);
							}else{
								return $action[$post->type]($key, $lang, $post);
							}
						}

						return route('vn4-multiple-language.index',['language'=>$lang['lang_slug']]);

					};
					
				}
			}
			break;
		
		case 'vn4-multiple-language.404':
			$callback = function($key, $lang){
				return route('vn4-multiple-language.404',['language'=>$lang['lang_slug']]);
			};
			break;
		default:
			$change_lang_ajax = true;
			$callback = function($key, $lang){
				return '<span onclick="the_languages(\''.$key.'\', this)" class="language"><img src="'.get_flag_language($lang).'" alt="Language '.$lang['lang_slug'].'"> '.$lang['lang_name'].'</span>';
			};
			break;
	}

	$languages = languages();

	$string = '';

	$localeCode = App::getLocale();

	foreach($languages as $key=>$lang){

		$languages[$key]['url'] = $callback($key, $lang);
		$languages[$key]['flag_image'] = get_flag_language($lang);

		if( $lang['lang_slug'] ===  $localeCode){
			$languages[$key]['active'] = true;
		// 	$string = $string.'<a hreflang="'.$lang['lang_slug'].'" href="'.$callback($key, $lang).'" class="language"><img src="'.get_flag_language($lang).'" alt="Language '.$lang['lang_slug'].'"> '.$lang['lang_name'].'</a>';

		}else{
			$languages[$key]['active'] = false;
		}

	}	

	return $languages;

	// dd($languages);
	// $string = preg_replace('[\']', '\\\'', $string);

	$random_string = str_random(10);

	echo '<div id="vn4-the-languages_'.$random_string.'">'.$string.'</div>';


}

/**
	CHANGE LANGUAGE DEFAULT FRONTEND
*/
add_action('frontend_init',function(){
	App::setLocale(language_default()['lang_slug']);
});

/**
	CHANGE SIDEBAR RESOURCE
*/

add_action('get_sidebar',function($id_sidebar){
	return $id_sidebar.'-'.App::getLocale();
});


/**
	CHANGE RESOURCE NAV MENU LANGUAGE
*/
add_action('vn4_nav_menu',function($key){
	return $key.'-'.App::getLocale();
});



/**
	CHANGE LINK ROUTE
*/
add_action('route',function($name, $parameters, $absolute, $route ) use ($plugin, $languages, $custom_post_types) {

	$lang_current = App::getLocale();

	if( $name === 'index' ){

		if( isset($parameters['language']) ) {
			$lang_current = languages()[$parameters['language']]['lang_slug'];
		}

		$parameters['language'] = $lang_current;
		return route('vn4-multiple-language.index', $parameters, $absolute, $route, false);
	}

	if( $name === 'page' ){

		$register_page_slug = vn4mtl_get_standard_config_page();

		if( !is_array($parameters) ){
			$parameters = ['page'=>$parameters];
		}

		if( isset($parameters['language']) ) {
			$lang_current = languages()[$parameters['language']]['lang_slug'];
		}

		$parameters['language'] = $lang_current;

		if( isset($register_page_slug[$parameters['page']][$lang_current]['slug']) ){
			$parameters['page'] = $register_page_slug[$parameters['page']][$lang_current]['slug'];
		}

		return route('vn4-multiple-language.page', $parameters, $absolute, $route, false);
	}

	if( $name === 'post.detail' ){

		$post_type = convert_slug_custom_post_to_name($parameters['custom_post_slug']);
		
		$vn4mtl_custom_post_standard_config_page = vn4mtl_custom_post_standard_config_page();

		$admin_object = get_admin_object($post_type);

		if( array_search($post_type, $custom_post_types) !== false ){

			$post = getPostBySlug($post_type,$parameters['post_slug']);

			if( !$post ){
				return false;
			}
			if( !isset($GLOBALS['list_language'][$post->language]) ){
				$post->language = language_default()['lang_slug'];
				$post->save();

				// $post = getPostBySlug($post_type,$parameters['post_slug'], false);
				// $parameters['language'] = $post->language;
			}
			// dd($post);
			
			$parameters['language'] = $post->language;

			if( isset($vn4mtl_custom_post_standard_config_page[$post_type]) ){

				if( isset($vn4mtl_custom_post_standard_config_page[$post_type][$post->language]['slug']) ){

					$parameters['custom_post_slug'] = $vn4mtl_custom_post_standard_config_page[$post_type][$post->language]['slug'];
					$parameters['language'] = $post->language;

				}else{

					dd($parameters);
				}
			}

		}else{
			$parameters['language'] = $lang_current;
		}

		return route('vn4-multiple-language.post.detail',$parameters, $absolute, $route, false);

	}

});

/**
	ROUTE 404
*/
add_route('{language}/404','vn4-multiple-language.404','before_route_frontend',function($r, $language) {

	App::setLocale($language);

	return errorPage(404,'Page note found');

},['language'=>$regex_lang_page]);

/**
	ROUTE INDEX LANGUAGE
*/
add_route('/{language}','vn4-multiple-language.index','before_route_frontend',function($r, $language) use ($languages) {

	App::setLocale($language);

	title_head(setting('general_description',__('A simple website using Vn4CMS')));

	add_body_class(['index','home']);

	$theme_option = json_decode(setting('reading_homepage'),true);

	if( !isset($theme_option['type']) ) $theme_option = ['type'=>'default','static-page'=>'none','post-type'=>'page','post-id'=>0];

	$theme = theme_name();

	if( $theme_option['type'] === 'custom' && $page = get_post($theme_option['post-type'],$theme_option['post-id']) ){

		if( $page->language !== $language ){

			$post_connect = json_decode($page->getMeta('vn4-multiple-language-post-connect'),true);

			if( isset($post_connect['post']) && isset($post_connect['post'][$language]) ){
				$page = get_post($theme_option['post-type'],$post_connect['post'][$language]['id']);
			}
		}

		return view_post($page);

	}elseif( $theme_option['type'] === 'static-page' && view()->exists( $view = 'themes.'.$theme.'.page.'.$theme_option['static-page']) ){
		add_body_class(['page',$theme_option['static-page']]);
		return vn4_view($view);
	}

	return vn4_view('themes.'.theme_name().'.index');



	// $theme_option = get_option('reading_homepage', false);
	// if( $theme_option !== false && isset($theme_option['type']) && isset($theme_option['post-type']) && isset($theme_option['post-id']) && $page = get_post($theme_option['post-type'],$theme_option['post-id']) ){

	// dd($page);

	// 	return view_post($page);
	// }
	

	// add_body_class(['index','home']);

	// title_head(setting('general_description',__('A simple website using Vn4CMS')));

	// return vn4_view('themes.'.theme_name().'.index');

},['language'=>$regex_lang_page] );

// Redirect home to home language
add_action('index',function($r){

	if( !strpos(Request::url(), 'dialog.php') ){
		return vn4_redirect(route('vn4-multiple-language.index',language_default()['lang_slug']));
	}

});


/**
	ROUTE POST DETAIL
*/

add_route('/{language}/{post_type}/{post_slug}','vn4-multiple-language.post.detail','before_route_frontend',function($r, $language, $post_type, $post_slug) use ($custom_post_types, $languages, $plugin) {

	App::setLocale($language);

	$slugOfPostType = vn4mtl_custom_post_standard_config_page($post_type,$post_type2);

	if( !$post_type2 ){
		
		$post_type2 = convert_slug_custom_post_to_name($post_type);

		if( !$post_type2 ){
			return errorPage(404,'Page note found');
		}

	}


	$post = getPostBySlug($post_type2,$post_slug);

	if( $post ){

		if( !Auth::check() ){

			if( $post->status !== 'publish' ) return errorPage(404,'Not found post');

			if( $post->post_date_gmt - time() > 0 )  return errorPage(404,'Not found post');

		}

		if( array_search($post->type, $custom_post_types) !== false ){

			if( !$post->language || !isset($languages[$post->language]) ){
				$post->language = language_default()['lang_slug'];
			}

		 	$post_connect = json_decode($post->getMeta('vn4-multiple-language-post-connect'), true);

			if( $post->is_homepage || (isset($post_connect['is_homepage']) && $post_connect['is_homepage']) ){
				return vn4_redirect(route('vn4-multiple-language.index',$post->language),301);
			}
			

			//

			// $list_id = [];

			// foreach ($post_connect as $key => $value) {
			// 	$list_id[] = $value['id'];
			// }

			// $postsConnect = get_posts($post->type,100,null,null,function($q) use ($list_id,$post){
			// 	dd($q->whereIn('id',$list_id)->where('id','!=',$post->id)->toSql());
			// 	return $q->whereIn('id',$list_id)->where('id','!=',$post->id)->toSql();
			// });

			// dd($postsConnect);

			

			//redirect link when language or slug typ not same of post object

			if( $post->language != $language 
				|| (isset($slugOfPostType[$post->type][$post->language]['slug']) && $post_type !== $slugOfPostType[$post->type][$post->language]['slug']) ){

				if( isset($slugOfPostType[$post->type][$post->language]['slug']) ){
					return Redirect::to(route('vn4-multiple-language.post.detail',['language'=>$post->language,'post_type'=>$slugOfPostType[$post->type][$post->language]['slug'],'post_slug'=>$post->slug]), 301);
				}else{
					return Redirect::to(route('vn4-multiple-language.post.detail',['language'=>$post->language,'post_type'=>get_admin_object($post->type)['slug'],'post_slug'=>$post->slug]), 301);
				}
			}
		}
		// else{
			// die($post->title.' - '.$languages[$language]['lang_name']);
			// title_head($post->title.' - '.$languages[$language]['lang_name']);
		// }
		return view_post($post);

	}

	return errorPage(404,'Not found post');

},['language'=>$regex_lang_page]);


add_action('postDetail',function($post, $post_type,$post_slug) use ($languages) {

	$slugOfPostType = vn4mtl_custom_post_standard_config_page();

	if( isset($slugOfPostType[$post_type][$post->language]['slug']) ){
		return Redirect::to(route('vn4-multiple-language.post.detail',['language'=>$post->language,'post_type'=>$slugOfPostType[$post_type][$post->language]['slug'],'post_slug'=>$post_slug]), 301);
	}

	if( !$post->language || !isset($languages[$post->language]) ) $post->language = language_default()['lang_slug']; 

	return Redirect::to(route('vn4-multiple-language.post.detail',['language'=>$post->language,'post_type'=>$post_type,'post_slug'=>$post_slug]), 301);
});


add_route('/'.$plugin->key_word.'/change-the-language','vn4-multiple-language.change-the-language','before_route_frontend',function($r){

	$lang = $r->get('lang');

	$languages = languages();

	if( isset($languages[$lang]) ){

		Cookie::queue('lang', $languages[$lang], 2628000);

		if( $vn4_multiple_language_page_current = $r->get('vn4_multiple_language_page_current') ){

			$register_page_slug = apply_filter('register_page_slug');

			if( isset($register_page_slug[$vn4_multiple_language_page_current][$languages[$lang]['lang_slug']]['slug'] ) ){
				return response()->json(['redirect'=>route('vn4-multiple-language.page',['language'=>$languages[$lang]['lang_slug'], 'page'=>$register_page_slug[$vn4_multiple_language_page_current][$languages[$lang]['lang_slug']]['slug']])]);

			}

			return response()->json(['redirect'=>route('vn4-multiple-language.page',['language'=>$languages[$lang]['lang_slug'], 'page'=>$vn4_multiple_language_page_current])]);

		}

		return response()->json(['result'=>true]);
	}

	return response()->json(['message'=>__('No language found.')]);
});

add_action('theme_options_function',function($key1,$key2, $default = ''){

	return App::getLocale().'.'.$key1;

});

/**
	ACTION PAGE: REDIRECT PAGE TO PAGE LANGUAGE
*/


add_action('getPage',function($page){

	$language_default = language_default();

	$register_page_slug = vn4mtl_get_standard_config_page();

	if( isset($register_page_slug[$page][$language_default['lang_slug']]['slug']) ){

		return vn4_redirect(route('vn4-multiple-language.page',['language'=>$language_default['lang_slug'],'page'=>$register_page_slug[$page][$language_default['lang_slug']]['slug']]));

	}

	return vn4_redirect(route('vn4-multiple-language.page',['language'=>$language_default['lang_slug'],'page'=>$page]));

});


/**
	CHANGE LINK PAGE
*/
add_route('/{language}/{page}','vn4-multiple-language.page','before_route_frontend',function($r, $language, $page) use ($languages) {

	App::setLocale($language);

	$register_page_slug = vn4mtl_get_standard_config_page($keyPage);

	$theme_name = theme_name();

	//Register page translate slug

	if( isset($register_page_slug[$page]) && $register_page_slug[$page][$language]['slug'] !== $page ){
		return vn4_redirect(route('vn4-multiple-language.page',['language'=>$language,'page'=>$register_page_slug[$page][$language]['slug']]));
	}

	if( is_array($keyPage) ){

		$view = 'themes.'.$theme_name.'.page.'.$keyPage['key_page'];

		if( view()->exists($view) ){

			if( $register_page_slug[$keyPage['key_page']][$language]['slug'] === $page ){
				return vn4_view($view);
			}

			$language_default = language_default();

			return vn4_redirect(route('vn4-multiple-language.page',['language'=>$language_default['lang_slug'],'page'=>$register_page_slug[$keyPage['key_page']][$language_default['lang_slug']]['slug']]));

		}
			
	}

	$view = 'themes.'.$theme_name.'.page.'.$page;

	if( view()->exists( $view ) ){

		add_body_class(['page',$page]);
			
		title_head(ucwords( preg_replace('/-/', ' ', str_slug(str_replace('.blade.php', '', $page)) )  ));

		if(  File::exists('../resources/views/themes/'.$theme_name.'/page/'.$page.'-post.php') ){
			
           $result = include '../resources/views/themes/'.$theme_name.'/page/'.$page.'-post.php';

           if( $result !== 1 ) return $result;
        }

		return vn4_view($view);


		// return vn4_view('themes.'.$theme_name.'.page.'.$page);
	}

	// $post = get_posts('page',1,function($q) use ($page) {
	// 		return $q->where('slug',$page);
	// 	});

	// if( isset($post[0]) ){
	// 	return view_post($post[0]);
	// }

	return errorPage(404,'Page note found');

},['language'=>$regex_lang_page]);

/**
	View Menu
*/

add_custom_menu_view('vn4-multiple-language-language-switcher-menu',function($menu_item){
	return the_languages();
});


add_filter('meta',function($meta_old) {
	$language = languages();
	$meta_old['fb_locale'] = '<meta property="og:locale" content="'.$language[App::getLocale()]['lang_locale'].'" />';

	return $meta_old;

},'zzzzzz',true);