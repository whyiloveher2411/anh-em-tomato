<?php

function mergeImage($i){
	$backgroundUrl = cms_path('public','uploads/video/video-demo/alpha/Alpha-'.$i.'.png');

	$image = new Imagick($backgroundUrl); 

	$data = [];

	$image->trimImage(20000);


	// get the new image size
	$geometry = $image->getImageGeometry();

	// Retrieve the trim info
	$pageInfo = $image->getImagePage();

	$tam = [$pageInfo['x'] + $geometry['width']/2 , $pageInfo['y'] + $geometry['height']/2];
	// dd($tam);

	// dd($geometry);
	$xmax = $geometry['width'];
	$ymax = $geometry['height'];

	$max = $xmax;

	if( $max < $ymax ){
	 	$max =  $ymax;
	}

	// dd($geometry);
	$x = $pageInfo['width'];
	$y = $pageInfo['height'];

	$point = ['x'=>$pageInfo['x']  ,'y'=> $pageInfo['y']];

	//ria tren
	if( $pageInfo['y'] - $max < 0 ){
		$point = ['x'=> $pageInfo['x'], 'y'=> $pageInfo['y'] - ($max - $ymax )];
	}

	//ria duoi
	if( $pageInfo['y'] + $max > $y ){
		$point = ['x'=>$pageInfo['x']  ,'y'=> $pageInfo['y']];
	}


	//ria phai
	if( $pageInfo['x'] + $max > $x ){
		$point = ['x'=>$pageInfo['x']  ,'y'=> $pageInfo['y']];
	}

	//ria trai
	if( $pageInfo['x'] - $max < 0 ){
		$point = ['x'=> $pageInfo['x'] - ($max - $xmax ) ,'y'=> $pageInfo['y']];
	}

	$background = imagecreatetruecolor($x, $y);

	$white = imagecolorallocate($background, 255, 255, 255);
	imagefill($background, 0, 0, $white);


	// $firstUrl = $backgroundUrl;

	$secondUrl = cms_path('public','uploads/video/image.png');


	$outputImage = $background;

	// $first = imagecreatefrompng($backgroundUrl);

	// header('Content-Type: image/png');
	// imagepng($first);

	// dd(1);

	$opacity = 100;
	if( $i >= 451 && $i <= 500){
		$point = ['x'=>0,'y'=>0];
		$max = 1100;

		
	}



	if( $i >= 201 && $i <= 217){
		$opacity = 5.88 * ( $i - 201 );
	}
	if( $i >= 326 && $i <= 342 ){
		$opacity = 5.88 * ( $i - 326 );
	}
	if( $i >= 451 && $i <= 467 ){
		$opacity = 5.88 * ( $i - 451 );
	}

	if( $i >= 576 && $i <= 592 ){
		$opacity = 5.88 * ( $i - 576 );
	}
	
	$second = imagecreatefrompng($secondUrl);
	$second = imagescale($second, $max, $max);

	//lưu max + point
	// imagecopymerge($outputImage,$first,0,0,0,0, $x, $y,100);

	imagecopymerge($outputImage,$second,$point['x'],$point['y'],0,0, $max, $max,$opacity);
	// imagecopymerge($outputImage,$second,$point['x'],$point['y'],0,0, $max, $max,100);

	$image3 = '/var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/result/result-'.$i.'.png';

	$image3 = imagecreatefrompng($image3);


	// Copy the stamp image onto our photo using the margin offsets and the photo 
	// width to calculate positioning of the stamp. 
	imagecopy($outputImage, $image3, 0, 0, 0, 0, imagesx($image3), imagesy($image3));

	// header('Content-Type: image/png');

	imagepng($outputImage,cms_path('public','uploads/video/video-demo/video/image-'.sprintf ('%03d',$i).'.png'));

	// imagepng($outputImage);
	// dd(1);

	// imagejpeg($outputImage, cms_path('public','uploads/video/image2.jpg'));

	// imagedestroy($outputImage);
}




// dd(1);


set_time_limit(100000000);

$arg = [
	[201,250],
	[326,375],
	[451,500],
	[576,625]
];
// dd(sprintf ('%03d',10));
for ($i=576; $i <= 625; $i++) { 

	if( ($i >= 201 && $i <= 250) || ($i >= 326 && $i <= 375) || ($i >= 451 && $i <= 500) || ($i >= 576 && $i <= 625) ){
		// shell_exec('convert "'.cms_path('public','uploads/video/video-demo/image ('.$i.').png').'" -fuzz 1% -fill none -transparent "rgba(255,0,0)" '.cms_path('public','uploads/video/video-demo/objectOnTransparent/ObjectOnTransparent-'.$i.'.png'));

		
		// shell_exec('convert '.cms_path('public','uploads/video/video-demo/objectOnTransparent/ObjectOnTransparent-'.$i.'.png').' -alpha extract '.cms_path('public','uploads/video/video-demo/alpha/Alpha-'.$i.'.png'));

		// shell_exec('convert '.cms_path('public','uploads/video/video-demo/alpha/Alpha-'.$i.'.png').' -edge 1 '.cms_path('public','uploads/video/video-demo/alpha/AlphaEdges-'.$i.'.png'));


		// shell_exec('convert "'.cms_path('public','uploads/video/video-demo/image ('.$i.').png').'" \( +clone -fill white -colorize 10% \) -compose difference -composite '.cms_path('public','uploads/video/video-demo/diff/Diff-'.$i.'.png'));


		// shell_exec('convert '.cms_path('public','uploads/video/video-demo/alpha/AlphaEdges-'.$i.'.png').' '.cms_path('public','uploads/video/video-demo/diff/Diff-'.$i.'.png').' -compose multiply -composite '.cms_path('public','uploads/video/video-demo/diff/EdgexDiff-'.$i.'.png'));
		// dd(cms_path('public','uploads/video/video-demo/alpha/AlphaEdges-'.$i.'.png'));

		// /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/

		// shell_exec('convert /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/alpha/Alpha-'.$i.'.png /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/diff/EdgexDiff-'.$i.'.png -compose add -composite /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/reEdgedAlpha/ReEdgedAlpha-'.$i.'.png');


		// shell_exec('convert "/var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/image ('.$i.').png" \( /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/reEdgedAlpha/ReEdgedAlpha-'.$i.'.png -colorspace gray \) -compose copyopacity -composite /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/remaskedPhone/RemaskedPhone-'.$i.'.png');

		// shell_exec('convert -size 1100x1600 xc:transparent /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/remaskedPhone/RemaskedPhone-'.$i.'.png -composite /var/www/clients/client0/web10/web/cms_dev/public/uploads/video/video-demo/result/result-'.$i.'.png');

		// mergeImage($i);
		



	}else{
		// copy(cms_path('public','uploads/video/video-demo/image ('.$i.').png'), cms_path('public','uploads/video/video-demo/objectOnTransparent/ObjectOnTransparent-'.$i.'.png'));
		// copy(cms_path('public','uploads/video/video-demo/image ('.$i.').png'), cms_path('public','uploads/video/video-demo/video/image-'.$i.'.png'));
	}
}


dd(1);