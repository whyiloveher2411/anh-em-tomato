<?php

$GLOBALS['languages'] = json_decode($plugin->getMeta('vn4-languages','[]'),true);

foreach ($GLOBALS['languages'] as $key => $value) {
	if( $value['is_default'] ){
		$GLOBALS['lang_default'] = $value;
	}
}

if( !isset($GLOBALS['lang_default']) ) $GLOBALS['lang_default'] = reset($GLOBALS['languages']);

// if( !$GLOBALS['lang_default'] ){
// 	$GLOBALS['lang_default'] = reset($GLOBALS['languages']);
// 	$GLOBALS['lang_default']['key'] = $GLOBALS['lang_default']['lang_slug'];
// }

$GLOBALS['plugin_languages'] = $plugin;

//danh sach ngon ngu
function languages(){
	return $GLOBALS['languages'];
}

$languages = languages();

function get_flag_language($lang){
	return plugin_asset($GLOBALS['plugin_languages'], 'flags/'.$lang['flag'].'.png');
}

// ngon ngu mac dinh khi vao website
function language_default(){
	return $GLOBALS['lang_default'];
}

// //lay ngon ngu hien tai
// function language_current(){
// 	$language_current = Cookie::get('lang');

// 	if( $language_current && is_array($language_current) ){
// 		return $language_current;
// 	}

// 	return language_default();
// }


add_action('get_posts',function($posts,$post_type) use ($plugin, $languages) {

	$custom_post_types = json_decode( $plugin->getMeta('custom-post-types'),true );

	if( !is_array($custom_post_types) ) $custom_post_types = [];

	$admin_object = get_admin_object($post_type);

	if( array_search($post_type, $custom_post_types) !== false  ){

		$lang_default = language_default();

		$language_current = App::getLocale();
		// }
		if( $lang_default['lang_slug'] === $language_current ){
			$posts->where(function($q) use ($language_current) {
				$q->whereIn('language',[$language_current,''])->orWhereNull('language');
			});
		}else{
			$posts->where('language',$language_current);
		}

	}

});


if( is_admin() ){
	
		include __DIR__.'/inc/backend.php';
}else{

	if($languages){
		include __DIR__.'/inc/frontend.php';
	}
}
