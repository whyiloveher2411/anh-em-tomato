<?php

$GLOBALS['languages'] = $plugin->getMeta('vn4-languages',[]);

foreach ($GLOBALS['languages'] as $key => $value) {
	if( $value['is_default'] ){
		$GLOBALS['lang_default'] = $value;
	}
}

if( !isset($GLOBALS['lang_default']) ) $GLOBALS['lang_default'] = reset($GLOBALS['languages']);

$GLOBALS['plugin_languages'] = $plugin;

function languages(){
	return $GLOBALS['languages'];
}

$languages = languages();

function get_flag_language($lang){
	return plugin_asset($GLOBALS['plugin_languages'], 'flags/'.$lang['flag'].'.png');
}

function language_default(){
	return $GLOBALS['lang_default'];
}


if( is_admin() ){
	
		include __DIR__.'/inc/backend.php';
}else{

	if($languages){
		include __DIR__.'/inc/frontend.php';
	}
}
