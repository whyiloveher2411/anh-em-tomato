<?php

return [
	'language'=>['title'=>'Plugin Multi Language','callback' => function( $searchArray, $searchString ) use ($plugin){

		return [
			[
				'title_type'=>'Language',
				'title'=>'Cài đặt',
				'link'=>route('plugin.'.$plugin->key_word.'.languages'),
			],
			[
				'title_type'=>'Language',
				'title'=>'Cài đặt bài viết',
				'link'=>route('plugin.'.$plugin->key_word.'.setting'),
			],
			[
				'title_type'=>'Language',
				'title'=>'Làm mới cài ngôn ngữ',
				'link'=>route('plugin.'.$plugin->key_word.'.refresh-lang'),
			],
		];
		

	}]
];